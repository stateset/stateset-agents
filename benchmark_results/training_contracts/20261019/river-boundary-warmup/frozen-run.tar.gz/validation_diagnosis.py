"""Diagnose only the preceding run's validation traces; never inspect its test."""

import asyncio
from collections import Counter
import hashlib
import json
from pathlib import Path

from stateset_agents.evaluation.refund_trace import replay_refund_trace
from stateset_agents.remote.river_rl import atomic_json

ROOT = Path("/home/dom/stateset-agents/outputs/river-boundary-warmup-20261019")
PREVIOUS = ROOT.parent / "river-boundary-rl-20261019/rl"


async def main():
    cases_path = PREVIOUS / "validation.json"
    validation_path = PREVIOUS / "validation_results.json"
    cases = {row["order_id"]: row for row in json.loads(cases_path.read_text())}
    results = []
    for entry in json.loads(validation_path.read_text()):
        failed_families, errors, boundary_actions = Counter(), Counter(), Counter()
        for outcome in entry["outcomes"]:
            case = cases[outcome["case_id"]]
            replay = await replay_refund_trace(
                "refund-policy-v2", case, outcome["environment_trace"]
            )
            assert replay["reward"] == outcome["reward"]
            if not replay["success"]:
                failed_families[case["family"]] += 1
            for step in outcome["environment_trace"]["steps"]:
                for observation in step["observations"]:
                    try:
                        body = json.loads(observation["content"])
                    except (KeyError, ValueError):
                        continue
                    if isinstance(body, dict) and "error" in body:
                        errors[str(body["error"])] += 1
                if case["family"] == "window_boundary":
                    try:
                        action = json.loads(step["action"]["content"])
                    except (KeyError, ValueError):
                        boundary_actions["invalid_json"] += 1
                        continue
                    if isinstance(action, dict):
                        tool = action.get("tool", "unknown")
                        reason = action.get("args", {}).get("reason", "")
                        boundary_actions[f"{tool}:{reason}"] += 1
        results.append(
            {
                "validation_step": entry["step"],
                "failed_by_family": dict(failed_families),
                "rejected_action_errors": dict(errors),
                "boundary_actions": dict(boundary_actions),
            }
        )
    atomic_json(
        ROOT / "previous-validation-diagnosis.json",
        {
            "scope": "Previous validation only, descriptive replay after the new protocol was frozen; no training or configuration changes derived here",
            "source_sha256": {
                str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in (cases_path, validation_path)
            },
            "replayed_cases": len(cases) * len(results),
            "evaluations": results,
        },
    )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
