"""Complete two unattempted, prespecified fixed-model tests after zero-update stop.

No training, no native RL test, no retries, no new token allocation or deadline.
The original failed training attempt and frozen protocol remain unchanged.
"""

import asyncio
from contextlib import closing
from dataclasses import asdict
import getpass
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

REPO = Path("/home/dom/stateset-agents")
ROOT = REPO / "outputs/river-boundary-warmup-20261019"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    from stateset_agents.remote.river_rl import atomic_json

    atomic_json(Path(path), value)


def frozen_experiment():
    spec = importlib.util.spec_from_file_location(
        "frozen_warmup", ROOT / "runtime/experiment.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_stopped_and_untested():
    plan = frozen_experiment().validate()
    execution = read(ROOT / "execution-summary.json")
    assert execution["exit_code"] != 0 and not execution["timed_out"]
    stop = read(ROOT / "rl/training_stop.json")
    assert stop["reason"] == "consecutive_skipped_optimizer_updates"
    activity = read(ROOT / "rl/training_activity.json")
    assert (
        activity["observed_optimizer_updates"]
        == activity["unknown_update_batches"]
        == 0
    )
    assert activity["observed_skipped_batches"] == activity["completed_batches"] == 3
    assert all(
        entry["metrics"]["train/updated"] == 0
        for entry in read(ROOT / "rl/training_metrics.json")
    )
    assert not (ROOT / "rl/test_attempt.json").exists()
    assert not (ROOT / "rl/test_results.json").exists()
    for arm in ("original", "warmup"):
        assert not (ROOT / f"{arm}-test-attempt.json").exists()
        assert not (ROOT / f"{arm}-test.json").exists()
    budget = read(ROOT / "external-budget.json")
    assert budget["limit"] == 262144 and budget["reserved_generated_tokens"] == 0
    assert budget["fingerprint"] == plan["plan_hash"]
    assert read(ROOT / "sft-result.json")["status"] == "succeeded"
    assert read(ROOT / "warmup/river_checkpoint.json")["steps"] == 16
    return plan


def prepare():
    from stateset_agents.evaluation.agent_runs import content_hash

    plan = require_stopped_and_untested()
    assert not (ROOT / "evaluation-completion-plan.json").exists()
    shutil.copyfile(__file__, ROOT / "runtime/complete_evaluation.py")
    completion = {
        "schema_version": 1,
        "original_plan_hash": plan["plan_hash"],
        "reason": "Three observed zero-update batches stopped the native RL stage before any test attempt. Complete only the original two fixed-model test arms, which were prespecified but unattempted.",
        "protocol_deviation": "Run the two fixed SFT tests after the guarded RL failure rather than after a completed native RL test. No RL test will be sampled or reported.",
        "arms": ["original", "warmup"],
        "training_calls": 0,
        "token_allocation_increase": 0,
        "deadline_extension_seconds": 0,
        "original_absolute_deadline_unix": read(ROOT / "execution-attempt.json")[
            "started_at_unix"
        ]
        + plan["limits"]["wall_seconds"],
        "source_hashes": {
            name: sha(ROOT / name)
            for name in (
                "execution-summary.json",
                "rl/training_stop.json",
                "rl/training_activity.json",
                "rl/training_metrics.json",
                "warmup/river_checkpoint.json",
                "original/river_checkpoint.json",
            )
        },
        "runner_sha256": sha(ROOT / "runtime/complete_evaluation.py"),
    }
    completion["plan_hash"] = content_hash(completion)
    write(ROOT / "evaluation-completion-plan.json", completion)
    print(
        json.dumps({"prepared": True, "training_calls": 0, "new_token_allocation": 0}),
        flush=True,
    )


def validate():
    from stateset_agents.evaluation.agent_runs import content_hash

    plan = require_stopped_and_untested()
    completion = read(ROOT / "evaluation-completion-plan.json")
    assert (
        content_hash({k: v for k, v in completion.items() if k != "plan_hash"})
        == completion["plan_hash"]
    )
    assert completion["original_plan_hash"] == plan["plan_hash"]
    assert sha(__file__) == completion["runner_sha256"]
    for name, digest in completion["source_hashes"].items():
        assert sha(ROOT / name) == digest
    return plan, completion


def worker():
    import river_client as river
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_rl import exclusive_run
    from stateset_agents.remote.river_runtime import require_model_access
    from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget

    plan, completion = validate()
    module = frozen_experiment()
    with exclusive_run(ROOT):
        budget = RolloutAdmissionBudget(
            ROOT / "external-budget.json",
            limit=262144,
            trajectory_tokens=1024,
            fingerprint=plan["plan_hash"],
        )
        with closing(
            river.Client(
                api_key=os.environ["RIVER_API_KEY"], timeout=180, enable_retries=False
            )
        ) as client:
            require_model_access(client, plan["base_model"])
            renderer = get_river_renderer(plan["base_model"], thinking=False)
            checkpoints = [
                (
                    arm,
                    river.Checkpoint(
                        path=read(ROOT / arm / "river_checkpoint.json")["checkpoint"],
                        step=16,
                        checkpoint_type="inference",
                    ),
                )
                for arm in completion["arms"]
            ]
            with client.session(
                experiment="stateset-boundary-warmup",
                role="fixed-evaluation-completion",
            ) as session:
                for arm, checkpoint in checkpoints:
                    with (ROOT / f"{arm}-test-attempt.json").open("x") as stream:
                        json.dump(
                            {
                                "plan_hash": plan["plan_hash"],
                                "completion_plan_hash": completion["plan_hash"],
                                "checkpoint": asdict(checkpoint),
                                "test_hash": plan["split_hashes"]["test"],
                            },
                            stream,
                        )
                        stream.flush()
                        os.fsync(stream.fileno())
                helpers = module.evaluation_module()

                async def evaluate():
                    await asyncio.gather(
                        *(
                            helpers.evaluate(
                                session,
                                renderer,
                                checkpoint,
                                read(ROOT / "data/test.json"),
                                "test",
                                arm,
                                budget,
                                plan["implementation"],
                            )
                            for arm, checkpoint in checkpoints
                        )
                    )

                asyncio.run(evaluate())


def launch():
    from stateset_agents.remote.river_runtime import river_preflight

    plan, completion = validate()
    assert time.time() + 60 < completion["original_absolute_deadline_unix"]
    key = (
        os.environ.get("RIVER_API_KEY")
        or getpass.getpass("River credential (hidden): ").strip()
    )
    assert key
    os.environ["RIVER_API_KEY"] = key
    preflight = river_preflight([plan["base_model"]], live=True, timeout_seconds=20)
    write(ROOT / "evaluation-completion-preflight.json", preflight)
    assert preflight["passed"]
    with (ROOT / "evaluation-completion-attempt.json").open("x") as stream:
        json.dump(
            {"plan_hash": completion["plan_hash"], "started_at_unix": time.time()},
            stream,
        )
        stream.flush()
        os.fsync(stream.fileno())
    env = {
        **os.environ,
        "PYTHONPATH": str(ROOT / "runtime"),
        "HF_HUB_OFFLINE": "1",
        "HF_HUB_DISABLE_PROGRESS_BARS": "1",
        "TOKENIZERS_PARALLELISM": "false",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    }
    started, timed_out = time.monotonic(), False
    with (ROOT / "evaluation-completion-log.txt").open("x") as log:
        process = subprocess.Popen(
            [
                sys.executable,
                "-u",
                str(ROOT / "runtime/complete_evaluation.py"),
                "worker",
            ],
            cwd=REPO,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            exit_code = process.wait(
                timeout=max(
                    1, completion["original_absolute_deadline_unix"] - time.time()
                )
            )
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                exit_code = process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                exit_code = process.wait()
    summary = {
        "exit_code": exit_code,
        "timed_out": timed_out,
        "elapsed_seconds": time.monotonic() - started,
        "plan_hash": completion["plan_hash"],
    }
    write(ROOT / "evaluation-completion-summary.json", summary)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    {"prepare": prepare, "validate": validate, "worker": worker, "launch": launch}[
        sys.argv[1]
    ]()
