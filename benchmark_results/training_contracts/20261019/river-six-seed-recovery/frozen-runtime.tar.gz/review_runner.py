"""Source-matched offline audit and retention of the frozen River replication."""
import asyncio
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import tarfile
import xml.etree.ElementTree as ET

from stateset_agents.core.environments.json_action import parse_json_action
from stateset_agents.core.environments.refund_policy_environment import RefundPolicyEnvironment
from stateset_agents.core.trajectory import ConversationTurn
from stateset_agents.evaluation.agent_runs import compare_runs,content_hash,validate_report
from stateset_agents.evaluation.implementation import package_implementation
from stateset_agents.evaluation.refund_trace import audit_refund_traces,select_replayed_validation_checkpoint

ROOT=Path('/home/dom/stateset-agents/outputs/river-six-seed-recovery-20261019')
read=lambda path:json.loads(Path(path).read_text())


def audit_provenance(plan):
    """Verify frozen inputs and account for both attempts without double counting."""
    original_root=Path(plan['original_source'])
    original=read(original_root/'plan.json')
    assert original['plan_hash']==plan['original_plan_hash']
    assert content_hash({k:v for k,v in original.items() if k!='plan_hash'})==original['plan_hash']
    for name,digest in plan['runner_hashes'].items():
        assert hashlib.sha256((ROOT/'runtime'/name).read_bytes()).hexdigest()==digest
    excluded_ids=set()
    excluded_facts=set()
    historical=[original_root]
    historical.extend(ROOT.parent/name for name in (
        'river-sft-warmup-20261018','river-integration-review-20261018-live',
        'river-prompt-fix-20261018-live'))
    for root in historical:
        for path in root.rglob('*.json'):
            if 'runtime' in path.relative_to(root).parts:
                continue
            value=read(path)
            if isinstance(value,list):
                for case in value:
                    if isinstance(case,dict) and 'order_id' in case:
                        excluded_ids.add(case['order_id'])
                        excluded_facts.add(RefundPolicyEnvironment.case_fingerprint(case))
    fresh_ids=set()
    fresh_facts=set()
    for entry in plan['datasets']:
        directory=ROOT/f"seed-{entry['seed']}"
        expected=next(row for row in original['datasets'] if row['seed']==entry['seed'])
        manifest=read(directory/'data/data_manifest.json')
        assert content_hash(manifest)==expected['manifest_hash']
        for name,digest in manifest['artifacts'].items():
            assert hashlib.sha256((directory/'data'/name).read_bytes()).hexdigest()==digest
        cases=read(directory/'primary-test.json')
        assert content_hash(cases)==entry['fresh_test_hash']
        assert len(cases)==plan['counts_per_seed']['test']
        for name,digest in entry['inherited_artifacts'].items():
            path=directory/'sft/river_checkpoint.json' if name=='sft_pointer' else directory/name
            assert content_hash(read(path))==digest
        for case in cases:
            identifier=case['order_id']
            fingerprint=RefundPolicyEnvironment.case_fingerprint(case)
            assert identifier not in excluded_ids|fresh_ids
            assert fingerprint not in excluded_facts|fresh_facts
            fresh_ids.add(identifier);fresh_facts.add(fingerprint)
    budgets=[]
    for label,root in [('original',original_root),('recovery',ROOT)]:
        for path in sorted(root.glob('seed-*/**/*budget.json')):
            budget=read(path)
            assert 0<=budget['reserved_generated_tokens']<=budget['limit']
            assert budget['reserved_generated_tokens']==budget['admitted_trajectories']*budget['trajectory_tokens']
            budgets.append({'attempt':label,'path':str(path.relative_to(root)),
                'reserved_generated_tokens':budget['reserved_generated_tokens'],
                'admitted_trajectories':budget['admitted_trajectories'],'limit':budget['limit']})
    original_reserved=sum(row['reserved_generated_tokens'] for row in budgets if row['attempt']=='original')
    recovery_reserved=sum(row['reserved_generated_tokens'] for row in budgets if row['attempt']=='recovery')
    assert original_reserved==plan['limits']['original_reserved_tokens']
    assert recovery_reserved<=plan['limits']['recovery_reserved_token_limit']
    assert original_reserved+recovery_reserved<=plan['limits']['combined_reserved_token_limit']<=plan['limits']['original_ceiling']
    return {'frozen_runner_hashes_verified':True,'dataset_artifacts_verified':True,
        'fresh_primary_cases':len(fresh_ids),'fresh_primary_disjoint_from_prior_cases':True,
        'original_reserved_generated_tokens':original_reserved,
        'recovery_reserved_generated_tokens':recovery_reserved,
        'combined_reserved_generated_tokens':original_reserved+recovery_reserved,
        'combined_allocated_bound':plan['limits']['combined_reserved_token_limit'],
        'original_ceiling':plan['limits']['original_ceiling'],'budgets':budgets,
        'scope':'Durable admission reservations, not generated tokens or billed dollars'}


async def audit():
    plan=read(ROOT/'plan.json')
    assert package_implementation()==plan['implementation']
    assert content_hash({k:v for k,v in plan.items() if k!='plan_hash'})==plan['plan_hash']
    provenance=audit_provenance(plan)
    reports={arm:{} for arm in plan['arms']}
    per_seed=[]
    family=defaultdict(lambda:Counter())
    formats={arm:Counter() for arm in plan['arms']}
    drift=[]
    initial_selections=[]
    for seed in plan['seeds']:
        directory=ROOT/f'seed-{seed}'
        cases=read(directory/'primary-test.json')
        item={'seed':seed,'arms':{}}
        if (directory/'sft/river_checkpoint.json').exists():
            pointer=read(directory/'sft/river_checkpoint.json')
            item['sft_reported_optimizer_updates']=pointer['steps']
        if (directory/'execution-summary.json').exists():
            item['execution']=read(directory/'execution-summary.json')
        if (directory/'rl-status.json').exists():
            item['rl_execution']=read(directory/'rl-status.json')
        if (directory/'sft_rl/training_activity.json').exists():
            item['rl_training_activity']=read(directory/'sft_rl/training_activity.json')
        for arm,name in [('base','base-test.json'),('sft','sft-test.json'),('sft_rl','sft_rl/test_results.json')]:
            path=directory/name
            if not path.exists():
                item['arms'][arm]={'status':'missing_or_failed'}
                continue
            report=read(path)
            validate_report(report)
            assert report['seed']==seed
            assert report['implementation']==plan['implementation']
            if arm=='base':
                assert report['selected_checkpoint']==read(directory/'base-checkpoint.json')
            elif arm=='sft':
                assert report['selected_checkpoint']['path']==read(directory/'sft/river_checkpoint.json')['checkpoint']
                assert report['selected_checkpoint']['step']==16
            replay=await audit_refund_traces(report,cases)
            assert replay['passed']
            reports[arm][seed]=report
            item['arms'][arm]={'passed':report['passed'],'total':report['total'],
                'violation_rate':report['violation_rate'],'truncation_rate':report['truncation_rate']}
            for outcome in report['outcomes']:
                counter=family[(arm,report['case_families'][outcome['case_id']])]
                counter['total']+=1
                counter['passed']+=int(outcome['success'])
                for step in outcome['environment_trace']['steps']:
                    formats[arm]['actions']+=1
                    try:
                        tool,args=parse_json_action(ConversationTurn(**step['action']))
                        formats[arm]['valid_json']+=1
                        if tool!='finish' and args.get('order_id')!=outcome['case_id']:
                            formats[arm]['wrong_order_id']+=1
                    except (ValueError,TypeError):
                        formats[arm]['invalid_json']+=1
            if arm=='sft_rl':
                entry=next(row for row in plan['datasets'] if row['seed']==seed)
                native_directory=(Path(plan['original_source'])/f'seed-{seed}') if entry['reuse_trained_models'] else directory
                manifest=read(native_directory/'sft_rl/run_manifest.json')
                assert manifest['checkpoint']==read(directory/'sft/river_checkpoint.json')['checkpoint']
                if entry['reuse_trained_models']:
                    inherited=read(directory/'inherited-rl-checkpoint.json')
                    original_test=read(native_directory/'sft_rl/test_results.json')
                    assert content_hash(original_test)==inherited['source_test_report_hash']
                    assert report['selected_checkpoint']==original_test['selected_checkpoint']==inherited['checkpoint']
                validation=read(directory/'sft_rl/validation_results.json')
                selected=await select_replayed_validation_checkpoint(validation,steps=2,
                    cases={r['order_id']:r for r in read(directory/'data/validation.json')},environment='refund-policy-v2')
                assert selected['checkpoint']==report['selected_checkpoint']
                assert selected['step']==report['selected_validation_step']
                item['rl_selected_validation_step']=selected['step']
                item['rl_selected_optimizer_step']=report['selected_checkpoint'].get('step')
                item['rl_training_activity']=report['training_activity']
                indexed={v['step']:v for v in validation}
                metrics=read(directory/'sft_rl/training_metrics.json')
                item['selected_checkpoint_has_observed_update']=any(
                    batch['step']<=selected['step'] and batch['metrics'].get('train/updated')==1
                    for batch in metrics)
                if not item['selected_checkpoint_has_observed_update'] and seed in reports['sft']:
                    baseline=reports['sft'][seed]
                    before={outcome['case_id']:outcome['success'] for outcome in baseline['outcomes']}
                    after={outcome['case_id']:outcome['success'] for outcome in report['outcomes']}
                    initial_selections.append({'seed':seed,'selected_validation_step':selected['step'],
                        'sft_passed':baseline['passed'],'selected_initial_checkpoint_passed':report['passed'],
                        'different_success_outcomes':sum(before[key]!=after[key] for key in before),
                        'interpretation':'SFT-initialized checkpoint selected without observed RL updates; differences cannot establish RL learning. Cause unconfirmed.'})
                for batch in metrics:
                    step=batch['step']
                    if batch['metrics'].get('train/updated')!=0 or step-1 not in indexed:
                        continue
                    before,after=indexed[step-1],indexed[step]
                    if before['checkpoint'].get('step')==after['checkpoint'].get('step') and before['metrics']['reward_mean']!=after['metrics']['reward_mean']:
                        drift.append({'seed':seed,'batch':step,
                            'reported_optimizer_step':after['checkpoint'].get('step'),
                            'before_reward_mean':before['metrics']['reward_mean'],
                            'after_reward_mean':after['metrics']['reward_mean'],
                            'cause':'Unconfirmed; no learning gain established by this score change'})
        per_seed.append(item)
    comparisons={}
    for left,right in plan['acceptance']['pairs']:
        seeds=sorted(reports[left].keys() & reports[right].keys())
        key=f'{right}_vs_{left}'
        if seeds:
            comparisons[key]=compare_runs([reports[left][s] for s in seeds],
                [reports[right][s] for s in seeds],min_seeds=6,min_gain=0.03,
                require_significance=True,alpha=0.05,comparisons=3)
        else:
            comparisons[key]={'passed':False,'reason':'No complete paired seed reports'}
    families={arm:{name:dict(values) for (member,name),values in family.items() if member==arm}
        for arm in plan['arms']}
    regressions=[]
    for left,right in plan['acceptance']['pairs']:
        for name in sorted(set(families[left]) & set(families[right])):
            a,b=families[left][name],families[right][name]
            if a['total']==b['total'] and b['passed']<a['passed']:
                regressions.append({'baseline':left,'candidate':right,'family':name,
                    'baseline_passed':a['passed'],'candidate_passed':b['passed'],'total':a['total']})
    coverage_complete=all(len(reports[arm])==6 for arm in plan['arms'])
    execution_clean=all(item.get('execution',{}).get('exit_code')==0
        and not item.get('execution',{}).get('timed_out',True) for item in per_seed)
    complete=coverage_complete and execution_clean
    training_totals={
        'sft_reported_optimizer_updates':sum(row.get('sft_reported_optimizer_updates',0) for row in per_seed),
        'rl_completed_batches':sum(row.get('rl_training_activity',{}).get('completed_batches',0) for row in per_seed),
        'rl_observed_optimizer_updates':sum(row.get('rl_training_activity',{}).get('observed_optimizer_updates',0) for row in per_seed),
        'rl_observed_skipped_batches':sum(row.get('rl_training_activity',{}).get('observed_skipped_batches',0) for row in per_seed),
        'rl_selections_with_observed_update':sum(row.get('selected_checkpoint_has_observed_update',False) for row in per_seed),
        'scope':'Each seed counted once, including two inherited trained model sets; SDK reports do not prove learning'}
    assert training_totals['sft_reported_optimizer_updates']<=plan['limits']['combined_sft_updates']
    assert training_totals['rl_completed_batches']<=plan['limits']['combined_rl_batches']
    result={'schema_version':1,'kind':'six-seed-synthetic-paired-river-review','plan_hash':plan['plan_hash'],
        'review_runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'complete':complete,'accepted_comparisons':all(c['passed'] for c in comparisons.values()),
        'primary_outcome_coverage_complete':coverage_complete,'execution_clean':execution_clean,
        'quality_certification':False,'provenance_and_admission':provenance,
        'per_seed':per_seed,'comparisons':comparisons,'training_activity_totals':training_totals,
        'pooled':{arm:{'completed_seeds':len(rows),'passed':sum(r['passed'] for r in rows.values()),
            'total':sum(r['total'] for r in rows.values())} for arm,rows in reports.items()},
        'families':families,'family_regressions':regressions,'action_formats':{k:dict(v) for k,v in formats.items()},
        'zero_update_validation_score_changes':drift,
        'unupdated_sft_selection_comparisons':initial_selections,
        'cost_usd':None,'dollar_cap_enforced':False,
        'scope':'Synthetic six-seed model learning replication; not reviewed real-world quality, backend parity, live crash recovery, or billing verification'}
    (ROOT/'review-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def retain(result):
    retained=Path('/home/dom/stateset-agents/benchmark_results/training_contracts/20261019/river-six-seed-recovery')
    retained.mkdir(exist_ok=False,parents=True)
    copied=[]
    for source in sorted(ROOT.rglob('*')):
        if not source.is_file() or 'runtime' in source.relative_to(ROOT).parts:
            continue
        relative=source.relative_to(ROOT)
        if source.name.startswith('.') or source.suffix not in {'.json','.jsonl','.txt','.xml'}:
            continue
        payload=source.read_bytes()
        assert re.search(rb'\brv_[A-Za-z0-9_-]{20,}',payload) is None,str(relative)
        destination=retained/(str(relative)+'.txt' if source.suffix=='.jsonl' else relative)
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(payload)
        copied.append(destination)
    with tarfile.open(retained/'frozen-runtime.tar.gz','w:gz') as archive:
        for path in sorted((ROOT/'runtime').rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
                archive.add(path,arcname=str(path.relative_to(ROOT/'runtime')),recursive=False)
    rows=[]
    for row in result['per_seed']:
        counts=[row['arms'].get(arm,{}).get('passed','failed') for arm in ('base','sft','sft_rl')]
        selected=row.get('rl_selected_validation_step','failed')
        rows.append(f"| {row['seed']} | {counts[0]} | {counts[1]} | {counts[2]} | {selected} |")
    pooled=result['pooled']
    compare_text='\n'.join(f"- {key}: passed={value['passed']}; mean gain={value.get('mean_success_gain','unavailable')}" for key,value in result['comparisons'].items())
    text=f'''# River six-seed synthetic replication — 2026-10-19

This frozen study compares base, expert SFT, and SFT followed by two native RL batches on six independent training seeds. Every seed uses 128 synthetic training cases, 64 validation cases, and 64 fresh held-out cases. The ordinary data generator, policy, rewards, and held-out 7/45-day windows are unchanged. Training coverage doubles the earlier warmup, including 16 boundary and 16 misleading-note examples per seed.

| Seed | Base test /64 | SFT test /64 | SFT+RL test /64 | RL selected batch |
| --- | --- | --- | --- | --- |
{chr(10).join(rows)}

Pooled descriptive counts: base {pooled['base']['passed']}/{pooled['base']['total']}; SFT {pooled['sft']['passed']}/{pooled['sft']['total']}; SFT+RL {pooled['sft_rl']['passed']}/{pooled['sft_rl']['total']}. Statistical comparisons use independent seeds as the units; pooled case counts do not create additional training seeds.

All six seeds complete across every arm: **{result['complete']}**. All prespecified comparison gates passed: **{result['accepted_comparisons']}**.

{compare_text}

The comparison rules require six seeds, at least 3 percentage points mean success gain, improvement in every seed, no violation/truncation regression per seed, no success or safety regression within any seed's scenario families, and an exact seed-sign test with Bonferroni correction across three planned comparisons. Thresholds were fixed before provider calls. The JSON review includes per-seed family gates and pooled family regressions; successful transport does not certify model quality.

Validation score changes after a reported skipped update at the same optimizer step: {len(result['zero_update_validation_score_changes'])}. Their cause is unconfirmed; they are retained as a repeatability limitation and are not evidence of learning.

The SFT+RL procedure may select its initial SFT checkpoint rather than updated weights. Per-seed records distinguish the selected validation batch from the optimizer step and state whether an actual optimizer update was observed before the selected checkpoint. Missing or failed RL arms remain explicit in the summary.

For selections with no observed RL update, the review also compares fresh test outcomes against the separately sampled SFT arm. Any differences in these outcomes are repeatability limitations with an unconfirmed cause, not evidence of RL learning. The raw model scores remain unchanged.

Reported SFT updates across six model sets: {result['training_activity_totals']['sft_reported_optimizer_updates']}. Completed RL batches: {result['training_activity_totals']['rl_completed_batches']}; observed RL optimizer updates: {result['training_activity_totals']['rl_observed_optimizer_updates']}; skipped batches: {result['training_activity_totals']['rl_observed_skipped_batches']}. These counts include the two inherited model sets once. Selected RL checkpoints with at least one observed prior update: {result['training_activity_totals']['rl_selections_with_observed_update']}.

The original attempt and its partial results are preserved in ../river-six-seed/. The recovery amendment changes operational deadlines and removes redundant fixed-arm validation rescoring for four seeds; model hyperparameters, package code, validation selection, scoring, and acceptance thresholds remain unchanged. New primary holdouts were frozen before recovery sampling. The 768 rule-based expert chats were replayed in fresh sandbox instances and checked with the real tokenizer. The training data excludes all 224 historical canary cases. Fresh recovery primary holdouts additionally exclude every original reserved study case by ID and factual fingerprint. The original dataset bundle is retained intact; primary-test.json, rather than data/test.json, defines the fresh paired test cases. All study splits and seeds were mutually disjoint. Base and SFT checkpoints are fixed by the plan; the native RL arm chooses only on validation, with earliest-step ties. Each model's held-out test attempt is sealed before sampling, including uncertain attempts. Original timeouts and stops remain archived in the first-attempt evidence. Two completed model sets are reused without training; only four previously untrained seeds perform new SFT/RL. This is one operational recovery with fresh primary holdouts, and no remaining failure is retried.

The operational recovery allows at most two concurrent seeds, 30 minutes per seed, and a 90-minute recovery supervisor deadline. Across the original attempt and recovery, the limits remain 96 requested SFT updates, 12 requested RL batches, and the original 3,690,000-token rollout reservation ceiling; the conservative combined allocated bound is 3,478,720 tokens. These limits do not establish a dollar cap or verified billed cost. SFT automatic restarts are disabled; RL recovery remains limited by its durable admission ledger and execution deadline.

The final durable admission ledgers reserve {result['provenance_and_admission']['combined_reserved_generated_tokens']:,} generated-output tokens across both attempts. Reservations are upper bounds for admitted trajectories, not actual token usage or billed cost. The audit verifies frozen runner hashes, dataset artifact hashes, all 384 primary cases, disjointness from prior cases, and every ledger ceiling.

[Review summary](review-summary.json), [frozen plan](plan.json), and per-seed reports contain the evidence. The frozen-runtime.tar.gz archive includes the exact package files and runners needed for source-matched replay. JSONL exports and cost ledgers have an added .txt suffix; their bytes are unchanged. Dataset manifests retain original names and hashes. No credential is retained.

This remains a synthetic experiment rather than independent human-reviewed production-quality evidence. It does not establish live crash recovery, backend parity, provider inventory cleanup, or billing correctness. A+ readiness is not claimed. Preserve all exposed held-out cases.
'''
    (retained/'README.md').write_text(text)
    hashes={p.relative_to(retained).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(retained.rglob('*')) if p.is_file()}
    (retained/'artifacts.sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'evidence':str(retained),'files':len(hashes)+1,'complete':result['complete'],
        'pooled':result['pooled'],'comparison_gates_passed':result['accepted_comparisons']}))


if __name__=='__main__':
    result=asyncio.run(audit())
    retain(result)
