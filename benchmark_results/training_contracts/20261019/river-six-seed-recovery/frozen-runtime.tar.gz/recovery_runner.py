"""Operational recovery with fixed models, fresh paired holdouts, and no retraining."""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor,as_completed
from contextlib import closing
from dataclasses import asdict
import getpass
import hashlib
from importlib.machinery import SourceFileLoader
import importlib.util
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import time
import sys

REPO=Path('/home/dom/stateset-agents')
OLD=REPO/'outputs/river-six-seed-20261019'
ROOT=REPO/'outputs/river-six-seed-recovery-20261019'


def load(path):
    return json.loads(Path(path).read_text())


def write(path,value):
    from stateset_agents.remote.river_rl import atomic_json
    atomic_json(Path(path),value)


def helper():
    loader=SourceFileLoader('replication_helpers',str(ROOT/'runtime/replication_helpers.py'))
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(loader.name,loader))
    loader.exec_module(module)
    module.ROOT=ROOT
    return module


def prepare():
    from stateset_agents.core.environments.refund_policy_environment import RefundPolicyEnvironment,refund_policy_benchmark
    from stateset_agents.evaluation.agent_runs import content_hash
    from stateset_agents.evaluation.implementation import package_implementation
    original=load(OLD/'plan.json')
    ROOT.mkdir(exist_ok=False)
    runtime=ROOT/'runtime'
    runtime.mkdir()
    shutil.copytree(OLD/'runtime/stateset_agents',runtime/'stateset_agents',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copyfile(OLD/'runtime/warmup_runner.py',runtime/'warmup_runner.py')
    shutil.copyfile(OLD/'runtime/study_runner.py',runtime/'replication_helpers.py')
    shutil.copyfile(__file__,runtime/'recovery_runner.py')
    seen_ids=set()
    seen_facts=set()
    for path in list(OLD.glob('seed-*/data/*.json'))+list((REPO/'outputs/river-sft-warmup-20261018/data').glob('*.json'))+list((REPO/'outputs/river-integration-review-20261018-live/run').glob('*.json'))+list((REPO/'outputs/river-prompt-fix-20261018-live/run').glob('*.json')):
        rows=load(path)
        if isinstance(rows,list):
            for row in rows:
                if isinstance(row,dict) and 'order_id' in row:
                    seen_ids.add(row['order_id']); seen_facts.add(RefundPolicyEnvironment.case_fingerprint(row))
    old_reserved=sum(load(p).get('reserved_generated_tokens',0) for p in OLD.glob('seed-*/**/*budget.json'))
    entries=[]
    for index,seed in enumerate(original['seeds']):
        directory=ROOT/f'seed-{seed}'
        shutil.copytree(OLD/f'seed-{seed}/data',directory/'data')
        # Keep original training/validation artifacts and their manifest unchanged.
        fresh=refund_policy_benchmark('test',64,seed+1000000)
        for row in fresh:
            assert row['order_id'] not in seen_ids
            fingerprint=RefundPolicyEnvironment.case_fingerprint(row)
            assert fingerprint not in seen_facts
            seen_ids.add(row['order_id']); seen_facts.add(fingerprint)
        write(directory/'primary-test.json',fresh)
        inherited={}
        for name in ('base-checkpoint.json',):
            path=OLD/f'seed-{seed}'/name
            if path.exists():
                inherited[name]=content_hash(load(path))
                shutil.copyfile(path,directory/name)
        if index<2:
            shutil.copytree(OLD/f'seed-{seed}/sft',directory/'sft')
            inherited['sft_pointer']=content_hash(load(directory/'sft/river_checkpoint.json'))
            checkpoint=load(OLD/f'seed-{seed}/sft_rl/test_results.json')
            write(directory/'inherited-rl-checkpoint.json',{'checkpoint':checkpoint['selected_checkpoint'],
                'selected_validation_step':checkpoint['selected_validation_step'],'training_activity':checkpoint['training_activity'],
                'source':str(OLD/f'seed-{seed}/sft_rl'),'source_test_report_hash':content_hash(checkpoint)})
            (directory/'sft_rl').mkdir()
            for name in ('validation_results.json','training_metrics.json','training_activity.json'):
                shutil.copyfile(OLD/f'seed-{seed}/sft_rl'/name,directory/'sft_rl'/name)
        entries.append({'seed':seed,'reuse_trained_models':index<2,'fresh_test_hash':content_hash(fresh),
            'inherited_artifacts':inherited,'external_evaluation_cap':196608 if index<2 else 131072,
            'native_rl_cap':0 if index<2 else 350000})
    recovery_cap=sum(e['external_evaluation_cap']+e['native_rl_cap'] for e in entries)
    assert old_reserved+recovery_cap<=original['limits']['total_reserved_output_token_limit']
    plan={'schema_version':1,'kind':'six-seed-fresh-holdout-operational-recovery',
        'original_plan_hash':original['plan_hash'],'original_source':str(OLD),
        'implementation':package_implementation(),'seeds':original['seeds'],'arms':original['arms'],
        'acceptance':original['acceptance'],'counts_per_seed':original['counts_per_seed'],
        'datasets':entries,'model_hyperparameters_unchanged':True,
        'reason':'Original 20-minute cap interrupted primary tests. Preserve original failures; no exposed holdout is repeated. Reuse two fully trained model sets, and complete four untrained seeds.',
        'operational_changes':['30 minutes per seed, 90-minute recovery supervisor deadline',
            'Use cached Hugging Face tokenizer assets without remote metadata reloads',
            'Skip redundant base/SFT validation rescoring for four fixed candidate models; native RL validation selection remains unchanged',
            'Evaluate fixed base/SFT test arms concurrently after native RL selection and test'],
        'limits':{'original_reserved_tokens':old_reserved,'recovery_reserved_token_limit':recovery_cap,
            'combined_reserved_token_limit':old_reserved+recovery_cap,'original_ceiling':3690000,
            'additional_sft_updates':64,'additional_rl_batches':8,'combined_sft_updates':96,'combined_rl_batches':12,
            'max_parallel_seeds':2,'seconds_per_seed':1800,'total_seconds':5400,'dollar_cap':None},
        'quality_certification':False}
    plan['runner_hashes']={name:hashlib.sha256((runtime/name).read_bytes()).hexdigest() for name in ('warmup_runner.py','replication_helpers.py','recovery_runner.py')}
    plan['plan_hash']=content_hash(plan)
    write(ROOT/'plan.json',plan)
    print(json.dumps({'prepared':True,'limits':plan['limits'],'fresh_heldout_cases':384,'trained_model_sets_reused':2}),flush=True)


def worker(seed):
    import river_client as river
    from stateset_agents.evaluation.agent_runs import content_hash
    from stateset_agents.evaluation.implementation import package_implementation
    from stateset_agents.remote.river import RiverExecutor
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_rl import exclusive_run
    from stateset_agents.remote.river_runtime import require_model_access
    from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget
    from stateset_agents.training.river_refund import prepare_run,execute_run
    plan=load(ROOT/'plan.json')
    assert package_implementation()==plan['implementation']
    entry=next(d for d in plan['datasets'] if d['seed']==seed)
    directory=ROOT/f'seed-{seed}'
    assert content_hash({k:v for k,v in plan.items() if k!='plan_hash'})==plan['plan_hash']
    for name,digest in plan['runner_hashes'].items():
        assert hashlib.sha256((ROOT/'runtime'/name).read_bytes()).hexdigest()==digest
    original=load(OLD/'plan.json')
    assert original['plan_hash']==plan['original_plan_hash']
    expected=next(d for d in original['datasets'] if d['seed']==seed)
    manifest=load(directory/'data/data_manifest.json')
    assert content_hash(manifest)==expected['manifest_hash']
    for name,digest in manifest['artifacts'].items():
        assert hashlib.sha256((directory/'data'/name).read_bytes()).hexdigest()==digest
    assert content_hash(load(directory/'primary-test.json'))==entry['fresh_test_hash']
    for name,digest in entry['inherited_artifacts'].items():
        path=directory/'sft/river_checkpoint.json' if name=='sft_pointer' else directory/name
        assert content_hash(load(path))==digest
    h=helper(); w=h.evaluate_module(seed)
    with exclusive_run(directory):
        with (directory/'execution-attempt.json').open('x') as stream:
            json.dump({'plan_hash':plan['plan_hash'],'seed':seed,'recovery':True},stream)
        budget=RolloutAdmissionBudget(directory/'eval_budget.json',limit=entry['external_evaluation_cap'],
            trajectory_tokens=1024,fingerprint=content_hash({'plan':plan['plan_hash'],'seed':seed}),create=True)
        renderer=get_river_renderer(h.MODEL,thinking=False)
        with closing(river.Client(api_key=os.environ['RIVER_API_KEY'],timeout=180,enable_retries=False)) as client:
            require_model_access(client,h.MODEL)
            base_path=directory/'base-checkpoint.json'
            if base_path.exists():
                base=river.Checkpoint(**load(base_path))
            else:
                with client.session(experiment='stateset-recovery',role='base') as session:
                    model=session.create_model(base_model=h.MODEL,tokenizer=renderer.tokenizer,
                        lora=river.LoraConfig(rank=16,seed=seed,train_unembed=False))
                    base=model.save_weights('base-comparison',mode='inference')
                write(base_path,asdict(base))
            if not entry['reuse_trained_models']:
                executor=RiverExecutor(tokenizer=renderer.tokenizer,ledger_path=directory/'ledger.jsonl')
                executor.MAX_TRANSIENT_ATTEMPTS=1
                handle=executor.submit(h.sft_spec(seed)); result=executor.wait(handle)
                write(directory/'sft-result.json',{'status':result.status.value,'logs':result.logs,'duration_s':result.duration_s,'cost_usd':None})
                assert result.succeeded
            pointer=load(directory/'sft/river_checkpoint.json')
            assert pointer['steps']==16
            sft=river.Checkpoint(path=pointer['checkpoint'],step=16,checkpoint_type='inference')
            primary=load(directory/'primary-test.json')
            if not entry['reuse_trained_models']:
                args=h.rl_args(seed)
                splits={name:load(directory/'data'/f'{name}.json') for name in ('train','validation')}
                splits['test']=primary
                try:
                    with exclusive_run(args.output):
                        prepare_run(args,splits); execute_run(args,splits)
                    write(directory/'rl-status.json',{'status':'completed'})
                except Exception as exc:
                    write(directory/'rl-status.json',{'status':'failed','reason':str(exc),'exception':type(exc).__name__})
            with client.session(experiment='stateset-recovery',role='eval') as evaluation:
                arms=[('base',base),('sft',sft)]
                if entry['reuse_trained_models']:
                    inherited=load(directory/'inherited-rl-checkpoint.json')
                    arms.append(('sft_rl',river.Checkpoint(**inherited['checkpoint'])))
                for arm,checkpoint in arms:
                    with (directory/f'{arm}-test-attempt.json').open('x') as stream:
                        json.dump({'plan_hash':plan['plan_hash'],'checkpoint':asdict(checkpoint),
                            'test_hash':content_hash(primary)},stream)
                        stream.flush();os.fsync(stream.fileno())
                async def tests():
                    return await asyncio.gather(*(w.evaluate(evaluation,renderer,checkpoint,primary,
                        'test',arm,budget,plan['implementation']) for arm,checkpoint in arms))
                reports=asyncio.run(tests())
                if entry['reuse_trained_models']:
                    report=reports[-1]
                    report.update(selected_validation_step=inherited['selected_validation_step'],
                        training_activity=inherited['training_activity'],training_lineage=inherited['source'],
                        primary_test_plan_hash=plan['plan_hash'])
                    write(directory/'sft_rl/test_results.json',report)
                    write(directory/'rl-status.json',{'status':'completed','training_reused':True})
        assert package_implementation()==plan['implementation']
        write(directory/'seed-result.json',{'seed':seed,'base_test_passed':load(directory/'base-test.json')['passed'],
            'sft_test_passed':load(directory/'sft-test.json')['passed'],
            'rl_test_passed':load(directory/'sft_rl/test_results.json')['passed'] if (directory/'sft_rl/test_results.json').exists() else None})


def launch():
    from stateset_agents.remote.river_runtime import river_preflight
    plan=load(ROOT/'plan.json')
    key=getpass.getpass('River credential (hidden): ').strip();assert key
    os.environ['RIVER_API_KEY']=key
    preflight=river_preflight([helper().MODEL],live=True,timeout_seconds=20)
    write(ROOT/'preflight-live.json',preflight);assert preflight['passed']
    environment={**os.environ,'PYTHONPATH':str(ROOT/'runtime'),'HF_HUB_OFFLINE':'1',
        'HF_HUB_DISABLE_PROGRESS_BARS':'1','TOKENIZERS_PARALLELISM':'false','WANDB_MODE':'disabled',
        'STATESET_RIVER_VERBOSE':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
    started=time.monotonic()
    def one(seed):
        directory=ROOT/f'seed-{seed}';began=time.monotonic()
        proc=subprocess.Popen([sys.executable,str(ROOT/'runtime/recovery_runner.py'),'worker','--seed',str(seed)],
            cwd=ROOT/'runtime',env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        selector=selectors.DefaultSelector();selector.register(proc.stdout,selectors.EVENT_READ)
        pending=b'';timed_out=False
        with (directory/'live-run.txt').open('x',buffering=1) as log:
            while proc.poll() is None:
                if time.monotonic()-began>1800 or time.monotonic()-started>5400:
                    timed_out=True;os.killpg(proc.pid,signal.SIGINT)
                    try:proc.wait(timeout=30)
                    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL)
                    break
                for registered,_ in selector.select(timeout=1):
                    pending+=os.read(registered.fileobj.fileno(),8192)
                    while b'\n' in pending:
                        line,pending=pending.split(b'\n',1)
                        clean=line.decode(errors='replace').replace(key,'[REDACTED]')
                        log.write(clean+'\n');print(f'[{seed}] {clean}',flush=True)
            tail=(pending+proc.stdout.read()).decode(errors='replace').replace(key,'[REDACTED]')
            log.write(tail)
            if tail:print(tail,flush=True)
        proc.wait()
        summary={'seed':seed,'exit_code':proc.returncode,'timed_out':timed_out,'elapsed_seconds':round(time.monotonic()-began,1)}
        write(directory/'execution-summary.json',summary);print(json.dumps(summary),flush=True)
        return summary
    results=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(one,s) for s in plan['seeds']]):
            results.append(future.result());write(ROOT/'execution-progress.json',{'completed':len(results),'results':results})
    write(ROOT/'execution-summary.json',{'elapsed_seconds':round(time.monotonic()-started,1),'results':results,'credential_in_files':False})
    os.environ.pop('RIVER_API_KEY',None);key=''


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare','launch','worker']);parser.add_argument('--seed',type=int)
    args=parser.parse_args()
    if args.mode=='worker':worker(args.seed)
    else:{'prepare':prepare,'launch':launch}[args.mode]()
