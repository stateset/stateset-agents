"""Discoverable terminal actions for desktop and compact layouts."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Action:
    """An existing keyboard command with a human-readable label."""

    key: str
    label: str


CONFIGURE_ACTIONS = (
    Action("w", "Guided setup"),
    Action("m", "Choose model"),
    Action("b", "Choose compute backend"),
    Action("f", "Browse dataset files"),
    Action("v", "Check settings"),
    Action("u", "Inspect dataset"),
    Action("i", "Check runtime readiness"),
    Action("p", "Preview resources"),
    Action("r", "Review training launch"),
    Action("s", "Save draft"),
    Action("TAB", "Open retained runs"),
    Action("?", "Keyboard guide"),
)

RUN_ACTIONS = (
    Action("d", "Run details"),
    Action("l", "View logs"),
    Action("g", "View metrics"),
    Action("e", "Inspect quality evidence"),
    Action("j", "Evaluate run"),
    Action("z", "Review checkpoint recovery"),
    Action("r", "Review prepared launch"),
    Action("k", "Review local stop"),
    Action("c", "Reuse settings for a new run"),
    Action("a", "Pin / unpin comparison run"),
    Action("x", "Compare runs"),
)


class ActionMenu:
    """A scrollable menu delegating execution to existing reviewed workflows."""

    def __init__(self, tab: str, *, has_run: bool) -> None:
        self.index = 0
        self.actions: tuple[Action, ...] = (
            CONFIGURE_ACTIONS
            if tab == "configure"
            else (
                *(RUN_ACTIONS if has_run else ()),
                Action("/", "Search all retained runs"),
                Action("t", "Cycle status filter"),
                Action("BACKSPACE", "Clear run filters"),
                Action("TAB", "Configure training"),
                Action("?", "Keyboard guide"),
            )
        )

    def handle(self, key: str) -> str | None:
        """Move selection or return the selected command on Enter."""
        if key == "ENTER":
            return self.actions[self.index].key
        if key in {"UP", "DOWN", "PAGEUP", "PAGEDOWN", "HOME", "END"}:
            delta = 6 if key.startswith("PAGE") else 1
            target = self.index + (delta if key in {"DOWN", "PAGEDOWN"} else -delta)
            if key == "HOME":
                target = 0
            elif key == "END":
                target = len(self.actions) - 1
            self.index = max(0, min(len(self.actions) - 1, target))
        return None

    def lines(self, available: int) -> list[str]:
        """Keep the selected action visible even in the smallest terminal."""
        count = max(1, available - 2)
        start = max(0, min(self.index - count // 2, len(self.actions) - count))
        return [
            f"ACTIONS {self.index + 1}/{len(self.actions)}",
            "",
            *[
                (" > " if index == self.index else "   ") + action.label
                for index, action in enumerate(self.actions)
                if start <= index < start + count
            ],
        ]
