"""Frozen, bounded base/SFT/SFT+RL replication using packaged StateSet runners."""
from __future__ import annotations

import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import closing
from dataclasses import asdict
import getpass
import hashlib
from importlib.machinery import SourceFileLoader
import importlib.util
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import sys
import time
from types import SimpleNamespace

REPO=Path('/home/dom/stateset-agents')
ROOT=REPO/'outputs/river-six-seed-20261019'
SEEDS=tuple(range(2026101901,2026101907))
MODEL='Qwen/Qwen3.5-9B'


def read(path):
    return json.loads(Path(path).read_text())


def write(path,value):
    from stateset_agents.remote.river_rl import atomic_json
    atomic_json(Path(path),value)


def sft_spec(seed):
    from stateset_agents.remote.job import RemoteJobSpec
    directory=ROOT/f'seed-{seed}'
    return RemoteJobSpec(dataset=directory/'data/train.jsonl',base_model=MODEL,
        output_dir=directory/'sft',num_epochs=1,lora_r=16,learning_rate=2e-5,
        max_length=4096,per_device_batch_size=8,gradient_accumulation_steps=1,
        seed=seed,timeout_s=1200,job_kind='sft')


def rl_args(seed):
    directory=ROOT/f'seed-{seed}'
    return SimpleNamespace(output=directory/'sft_rl',base_model=MODEL,benchmark='refund-policy-v2',
        seed=seed,steps=2,concurrency=8,max_staleness=0,learning_rate=1e-5,
        checkpoint=str(directory/'sft'),evaluate_only=False,collect_only=False,dry_run=False,
        zero_update_patience=2,rollout_token_budget=350000)


def prepare():
    from stateset_agents.core.environments.refund_policy_environment import RefundPolicyEnvironment
    from stateset_agents.data.refund_demonstrations import prepare_refund_data
    from stateset_agents.evaluation.agent_runs import content_hash
    from stateset_agents.evaluation.implementation import package_implementation
    ROOT.mkdir(exist_ok=False)
    runtime=ROOT/'runtime'
    runtime.mkdir()
    shutil.copytree(REPO/'stateset_agents',runtime/'stateset_agents',
        ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copyfile('/tmp/stateset_river_sft_warmup_20261018.py',runtime/'warmup_runner.py')
    shutil.copyfile(__file__,runtime/'study_runner.py')
    seen_ids=set()
    seen_facts=set()
    for directory in ('river-integration-review-20261018-live','river-prompt-fix-20261018-live'):
        for split in ('train','validation','test'):
            for row in read(REPO/'outputs'/directory/'run'/f'{split}.json'):
                seen_ids.add(row['order_id'])
                seen_facts.add(RefundPolicyEnvironment.case_fingerprint(row))
    for split in ('train','validation','test'):
        for row in read(REPO/'outputs/river-sft-warmup-20261018/data'/f'{split}.json'):
            seen_ids.add(row['order_id'])
            seen_facts.add(RefundPolicyEnvironment.case_fingerprint(row))
    historical=len(seen_ids)
    datasets=[]
    for seed in SEEDS:
        directory=ROOT/f'seed-{seed}'
        manifest=asyncio.run(prepare_refund_data(directory/'data',seed=seed,
            train_count=128,validation_count=64,test_count=64))
        for split in ('train','validation','test'):
            for row in read(directory/'data'/f'{split}.json'):
                identity=row['order_id']
                facts=RefundPolicyEnvironment.case_fingerprint(row)
                assert identity not in seen_ids and facts not in seen_facts
                seen_ids.add(identity)
                seen_facts.add(facts)
        datasets.append({'seed':seed,'manifest_hash':content_hash(manifest),
            'sft_spec':sft_spec(seed).to_dict(),'training_families':manifest['families']})
    identity=package_implementation()
    for name,digest in identity['files'].items():
        assert hashlib.sha256((runtime/'stateset_agents'/name).read_bytes()).hexdigest()==digest
    runner_hashes={name:hashlib.sha256((runtime/name).read_bytes()).hexdigest()
        for name in ('warmup_runner.py','study_runner.py')}
    plan={'schema_version':1,'kind':'six-seed-synthetic-paired-river-study',
        'seeds':list(SEEDS),'base_model':MODEL,'arms':['base','sft','sft_rl'],
        'datasets':datasets,'implementation':identity,'runner_hashes':runner_hashes,
        'counts_per_seed':{'train':128,'validation':64,'test':64},
        'sft':{'epochs':1,'batch_size':8,'updates_per_seed':16,'learning_rate':2e-5,'max_attempts':1},
        'rl':{'batches_per_seed':2,'groups_per_batch':4,'group_size':8,'learning_rate':1e-5,
            'max_staleness':0,'zero_update_patience':2,'initialization':'matching seed SFT checkpoint'},
        'selection':{'base':'fixed initial checkpoint','sft':'fixed one-epoch checkpoint',
            'sft_rl':'Validation-reward maximum across baseline and two RL batches; earliest-step ties'},
        'acceptance':{'min_seeds':6,'min_gain':0.03,'require_significance':True,'alpha':0.05,
            'comparisons':3,'pairs':[['base','sft'],['sft','sft_rl'],['base','sft_rl']]},
        'limits':{'max_parallel_seeds':2,'seconds_per_seed':1200,'total_seconds':3600,
            'evaluation_reserved_output_tokens_per_seed':265000,'rl_reserved_output_tokens_per_seed':350000,
            'total_reserved_output_token_limit':3690000,'nominal_reserved_output_tokens':3538944,
            'maximum_requested_sft_updates':96,'maximum_requested_rl_batches':12,'dollar_cap':None},
        'historical_cases_excluded':historical,'cross_split_cross_seed_fact_overlap':0,
        'quality_certification':False,'scope':'Synthetic replication, not independent reviewed quality evidence',
        'failure_policy':'Never resubmit a seed. Retain failed or zero-update RL arms as failures. Continue independent seeds; incomplete arms cannot pass the six-seed gate.'}
    plan['plan_hash']=content_hash(plan)
    write(ROOT/'plan.json',plan)
    print(json.dumps({'prepared':True,'workspace':str(ROOT),'seeds':list(SEEDS),'training_examples':768,
        'validation_cases':384,'test_cases':384,'historical_cases_excluded':historical,
        'limits':plan['limits']}),flush=True)


def check():
    from transformers import AutoTokenizer
    from stateset_agents.data.refund_demonstrations import replay_refund_candidate
    from stateset_agents.evaluation.agent_runs import content_hash
    from stateset_agents.remote.river_batches import build_sft_batch
    plan=read(ROOT/'plan.json')
    tokenizer=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
    checks=[]
    async def one(seed):
        directory=ROOT/f'seed-{seed}'
        rows=[json.loads(line) for line in (directory/'data/train.jsonl').read_text().splitlines()]
        by_id={r['order_id']:r for r in read(directory/'data/train.json')}
        for row in rows:
            meta=row['metadata']
            await replay_refund_candidate(by_id[meta['case_id']],{'case_id':meta['case_id'],
                'case_hash':meta['case_hash'],'messages':row['messages'],'truncated':None})
        batch=build_sft_batch(rows,tokenizer,max_length=4096)
        assert len(batch)==len(rows)==128
        maximum=0
        for row,datum in zip(rows,batch,strict=True):
            text=tokenizer.apply_chat_template(row['messages'],tokenize=False,add_generation_prompt=False)
            length=len(tokenizer.encode(text,add_special_tokens=False))
            assert length<=4096 and len(datum['input_ids'])==length-1
            trained=tokenizer.decode([t for t,w in zip(datum['target_tokens'],datum['weights'],strict=True) if w])
            assert 'lookup_order' in trained and 'finish' in trained
            assert 'Please resolve my refund request.' not in trained
            maximum=max(maximum,length)
        return {'seed':seed,'replayed_examples':128,'trainable_examples':128,'max_sequence_tokens':maximum,
            'input_tokens':sum(len(d['input_ids']) for d in batch),'assistant_target_tokens':sum(sum(d['weights']) for d in batch)}
    for seed in SEEDS:
        checks.append(asyncio.run(one(seed)))
    write(ROOT/'data-check.json',{'plan_hash':plan['plan_hash'],'datasets':checks,
        'provider_requests':0,'replayed_examples':768,'passed':True})
    print(json.dumps({'passed':True,'replayed_examples':768,'maximum_sequence_tokens':max(x['max_sequence_tokens'] for x in checks)}),flush=True)


def evaluate_module(seed):
    path=ROOT/'runtime/warmup_runner.py'
    loader=SourceFileLoader('frozen_warmup',str(path))
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(loader.name,loader))
    loader.exec_module(module)
    module.ROOT=ROOT/f'seed-{seed}'
    module.SEED=seed
    return module


def worker(seed):
    import river_client as river
    from stateset_agents.evaluation.agent_runs import content_hash
    from stateset_agents.evaluation.implementation import package_implementation
    from stateset_agents.remote.river import RiverExecutor
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_rl import exclusive_run
    from stateset_agents.remote.river_runtime import require_model_access
    from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget
    from stateset_agents.training.river_refund import prepare_run,execute_run
    plan=read(ROOT/'plan.json')
    assert seed in SEEDS and package_implementation()==plan['implementation']
    import stateset_agents
    assert Path(stateset_agents.__file__).resolve().is_relative_to(ROOT/'runtime')
    for name,digest in plan['runner_hashes'].items():
        assert hashlib.sha256((ROOT/'runtime'/name).read_bytes()).hexdigest()==digest
    expected=next(x for x in plan['datasets'] if x['seed']==seed)
    directory=ROOT/f'seed-{seed}'
    data_manifest=read(directory/'data/data_manifest.json')
    assert content_hash(data_manifest)==expected['manifest_hash']
    for name,digest in data_manifest['artifacts'].items():
        assert hashlib.sha256((directory/'data'/name).read_bytes()).hexdigest()==digest
    w=evaluate_module(seed)
    with exclusive_run(directory):
        with (directory/'execution-attempt.json').open('x') as stream:
            json.dump({'plan_hash':plan['plan_hash'],'seed':seed,'resubmit':False},stream)
        budget=RolloutAdmissionBudget(directory/'eval_budget.json',limit=265000,
            trajectory_tokens=1024,fingerprint=content_hash({'plan':plan['plan_hash'],'seed':seed}),create=True)
        renderer=get_river_renderer(MODEL,thinking=False)
        with closing(river.Client(api_key=os.environ['RIVER_API_KEY'],timeout=120,enable_retries=False)) as client:
            require_model_access(client,MODEL)
            with client.session(experiment='stateset-six-seed',role='base') as session:
                model=session.create_model(base_model=MODEL,tokenizer=renderer.tokenizer,
                    lora=river.LoraConfig(rank=16,seed=seed,train_unembed=False))
                base_checkpoint=model.save_weights('base-comparison',mode='inference')
            write(directory/'base-checkpoint.json',asdict(base_checkpoint))
            with client.session(experiment='stateset-six-seed',role='eval') as evaluation:
                validation=read(directory/'data/validation.json')
                asyncio.run(w.evaluate(evaluation,renderer,base_checkpoint,validation,'validation','base',budget,plan['implementation']))
                executor=RiverExecutor(ledger_path=directory/'ledger.jsonl')
                executor.MAX_TRANSIENT_ATTEMPTS=1
                handle=executor.submit(sft_spec(seed))
                result=executor.wait(handle)
                write(directory/'sft-result.json',{'status':result.status.value,'logs':result.logs,
                    'duration_s':result.duration_s,'cost_usd':result.cost_usd})
                assert result.succeeded
                pointer=read(directory/'sft/river_checkpoint.json')
                assert pointer['steps']==16
                sft_checkpoint=river.Checkpoint(path=pointer['checkpoint'],step=16,checkpoint_type='inference')
                asyncio.run(w.evaluate(evaluation,renderer,sft_checkpoint,validation,'validation','sft',budget,plan['implementation']))
                splits={name:read(directory/'data'/f'{name}.json') for name in ('train','validation','test')}
                args=rl_args(seed)
                try:
                    with exclusive_run(args.output):
                        prepare_run(args,splits)
                        execute_run(args,splits)
                    rl_status={'status':'completed','report':'sft_rl/test_results.json'}
                except Exception as exc:
                    rl_status={'status':'failed','exception':type(exc).__name__,
                        'reason':str(exc),'report':None}
                    print(json.dumps({'seed':seed,'rl_failure':str(exc)}),flush=True)
                write(directory/'rl-status.json',rl_status)
                test=read(directory/'data/test.json')
                for arm,checkpoint in (('base',base_checkpoint),('sft',sft_checkpoint)):
                    with (directory/f'{arm}-test-attempt.json').open('x') as stream:
                        json.dump({'plan_hash':plan['plan_hash'],'seed':seed,
                            'checkpoint':asdict(checkpoint),'test_hash':content_hash(test)},stream)
                        stream.flush()
                        os.fsync(stream.fileno())
                    asyncio.run(w.evaluate(evaluation,renderer,checkpoint,test,'test',arm,budget,plan['implementation']))
        assert package_implementation()==plan['implementation']
        write(directory/'seed-result.json',{'seed':seed,'sft_updates':pointer['steps'],
            'sft_final_loss':pointer['final_loss'],'rl':rl_status,'eval_budget':budget.snapshot(),
            'base_test_passed':read(directory/'base-test.json')['passed'],
            'sft_test_passed':read(directory/'sft-test.json')['passed'],
            'rl_test_passed':read(directory/'sft_rl/test_results.json')['passed'] if rl_status['status']=='completed' else None})


def launch():
    from stateset_agents.remote.river_runtime import river_preflight
    plan=read(ROOT/'plan.json')
    assert read(ROOT/'data-check.json')['passed']
    key=getpass.getpass('River credential (hidden): ').strip()
    assert key
    os.environ['RIVER_API_KEY']=key
    preflight=river_preflight([MODEL],live=True,timeout_seconds=20)
    write(ROOT/'preflight-live.json',preflight)
    assert preflight['passed'],preflight['issues']
    environment={**os.environ,'PYTHONPATH':str(ROOT/'runtime'),'HF_HUB_DISABLE_PROGRESS_BARS':'1',
        'TOKENIZERS_PARALLELISM':'false','WANDB_MODE':'disabled','STATESET_RIVER_VERBOSE':'1',
        'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
    start=time.monotonic()
    def one(seed):
        directory=ROOT/f'seed-{seed}'
        proc=subprocess.Popen([sys.executable,str(ROOT/'runtime/study_runner.py'),'worker','--seed',str(seed)],
            cwd=ROOT/'runtime',env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        selector=selectors.DefaultSelector()
        selector.register(proc.stdout,selectors.EVENT_READ)
        began=time.monotonic()
        pending=b''
        timed_out=False
        with (directory/'live-run.txt').open('x',buffering=1) as log:
            while proc.poll() is None:
                if time.monotonic()-began>1200 or time.monotonic()-start>3600:
                    timed_out=True
                    os.killpg(proc.pid,signal.SIGINT)
                    try:
                        proc.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid,signal.SIGKILL)
                    break
                for registered,_ in selector.select(timeout=1):
                    pending+=os.read(registered.fileobj.fileno(),8192)
                    while b'\n' in pending:
                        line,pending=pending.split(b'\n',1)
                        clean=line.decode('utf-8',errors='replace').replace(key,'[REDACTED]')
                        log.write(clean+'\n')
                        print(f'[{seed}] {clean}',flush=True)
            tail=(pending+proc.stdout.read()).decode('utf-8',errors='replace').replace(key,'[REDACTED]')
            log.write(tail)
            if tail:
                print(f'[{seed}] {tail}',flush=True)
        proc.wait()
        summary={'seed':seed,'exit_code':proc.returncode,'timed_out':timed_out,
            'elapsed_seconds':round(time.monotonic()-began,1),'resubmitted':False}
        write(directory/'execution-summary.json',summary)
        print(json.dumps(summary),flush=True)
        return summary
    results=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(one,seed) for seed in SEEDS]
        for future in as_completed(futures):
            results.append(future.result())
            write(ROOT/'execution-progress.json',{'completed':len(results),'total':6,'results':sorted(results,key=lambda r:r['seed'])})
    write(ROOT/'execution-summary.json',{'elapsed_seconds':round(time.monotonic()-start,1),
        'results':sorted(results,key=lambda r:r['seed']),'credential_in_files':False})
    os.environ.pop('RIVER_API_KEY',None)
    key=''


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=['prepare','check','worker','launch'])
    parser.add_argument('--seed',type=int)
    args=parser.parse_args()
    if args.mode=='worker':
        worker(args.seed)
    else:
        {'prepare':prepare,'check':check,'launch':launch}[args.mode]()
