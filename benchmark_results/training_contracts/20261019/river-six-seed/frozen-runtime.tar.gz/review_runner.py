"""Source-matched offline audit and retention of the frozen River replication."""
import asyncio
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import tarfile
import xml.etree.ElementTree as ET

from stateset_agents.core.environments.json_action import parse_json_action
from stateset_agents.core.trajectory import ConversationTurn
from stateset_agents.evaluation.agent_runs import compare_runs,content_hash,validate_report
from stateset_agents.evaluation.implementation import package_implementation
from stateset_agents.evaluation.refund_trace import audit_refund_traces,select_replayed_validation_checkpoint

ROOT=Path('/home/dom/stateset-agents/outputs/river-six-seed-20261019')
read=lambda path:json.loads(Path(path).read_text())


async def audit():
    plan=read(ROOT/'plan.json')
    assert package_implementation()==plan['implementation']
    assert content_hash({k:v for k,v in plan.items() if k!='plan_hash'})==plan['plan_hash']
    reports={arm:{} for arm in plan['arms']}
    per_seed=[]
    family=defaultdict(lambda:Counter())
    formats={arm:Counter() for arm in plan['arms']}
    drift=[]
    for seed in plan['seeds']:
        directory=ROOT/f'seed-{seed}'
        cases=read(directory/'data/test.json')
        item={'seed':seed,'arms':{}}
        for arm,name in [('base','base-test.json'),('sft','sft-test.json'),('sft_rl','sft_rl/test_results.json')]:
            path=directory/name
            if not path.exists():
                item['arms'][arm]={'status':'missing_or_failed'}
                continue
            report=read(path)
            validate_report(report)
            assert report['seed']==seed
            assert report['implementation']==plan['implementation']
            replay=await audit_refund_traces(report,cases)
            assert replay['passed']
            reports[arm][seed]=report
            item['arms'][arm]={'passed':report['passed'],'total':report['total'],
                'violation_rate':report['violation_rate'],'truncation_rate':report['truncation_rate']}
            for outcome in report['outcomes']:
                counter=family[(arm,report['case_families'][outcome['case_id']])]
                counter['total']+=1
                counter['passed']+=int(outcome['success'])
                for step in outcome['environment_trace']['steps']:
                    formats[arm]['actions']+=1
                    try:
                        tool,args=parse_json_action(ConversationTurn(**step['action']))
                        formats[arm]['valid_json']+=1
                        if tool!='finish' and args.get('order_id')!=outcome['case_id']:
                            formats[arm]['wrong_order_id']+=1
                    except (ValueError,TypeError):
                        formats[arm]['invalid_json']+=1
            if arm=='sft_rl':
                validation=read(directory/'sft_rl/validation_results.json')
                selected=await select_replayed_validation_checkpoint(validation,steps=2,
                    cases={r['order_id']:r for r in read(directory/'data/validation.json')},environment='refund-policy-v2')
                assert selected['checkpoint']==report['selected_checkpoint']
                assert selected['step']==report['selected_validation_step']
                item['rl_selected_validation_step']=selected['step']
                item['rl_training_activity']=report['training_activity']
                indexed={v['step']:v for v in validation}
                metrics=read(directory/'sft_rl/training_metrics.json')
                for batch in metrics:
                    step=batch['step']
                    if batch['metrics'].get('train/updated')!=0 or step-1 not in indexed:
                        continue
                    before,after=indexed[step-1],indexed[step]
                    if before['checkpoint'].get('step')==after['checkpoint'].get('step') and before['metrics']['reward_mean']!=after['metrics']['reward_mean']:
                        drift.append({'seed':seed,'batch':step,
                            'reported_optimizer_step':after['checkpoint'].get('step'),
                            'before_reward_mean':before['metrics']['reward_mean'],
                            'after_reward_mean':after['metrics']['reward_mean'],
                            'cause':'Unconfirmed; no learning gain established by this score change'})
        per_seed.append(item)
    comparisons={}
    for left,right in plan['acceptance']['pairs']:
        seeds=sorted(reports[left].keys() & reports[right].keys())
        key=f'{right}_vs_{left}'
        if seeds:
            comparisons[key]=compare_runs([reports[left][s] for s in seeds],
                [reports[right][s] for s in seeds],min_seeds=6,min_gain=0.03,
                require_significance=True,alpha=0.05,comparisons=3)
        else:
            comparisons[key]={'passed':False,'reason':'No complete paired seed reports'}
    families={arm:{name:dict(values) for (member,name),values in family.items() if member==arm}
        for arm in plan['arms']}
    regressions=[]
    for left,right in plan['acceptance']['pairs']:
        for name in sorted(set(families[left]) & set(families[right])):
            a,b=families[left][name],families[right][name]
            if a['total']==b['total'] and b['passed']<a['passed']:
                regressions.append({'baseline':left,'candidate':right,'family':name,
                    'baseline_passed':a['passed'],'candidate_passed':b['passed'],'total':a['total']})
    complete=all(len(reports[arm])==6 for arm in plan['arms'])
    result={'schema_version':1,'kind':'six-seed-synthetic-paired-river-review','plan_hash':plan['plan_hash'],
        'complete':complete,'accepted_comparisons':all(c['passed'] for c in comparisons.values()),
        'quality_certification':False,'per_seed':per_seed,'comparisons':comparisons,
        'pooled':{arm:{'completed_seeds':len(rows),'passed':sum(r['passed'] for r in rows.values()),
            'total':sum(r['total'] for r in rows.values())} for arm,rows in reports.items()},
        'families':families,'family_regressions':regressions,'action_formats':{k:dict(v) for k,v in formats.items()},
        'zero_update_validation_score_changes':drift,
        'cost_usd':None,'dollar_cap_enforced':False,
        'scope':'Synthetic six-seed model learning replication; not reviewed real-world quality, backend parity, live crash recovery, or billing verification'}
    (ROOT/'review-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def retain(result):
    retained=Path('/home/dom/stateset-agents/benchmark_results/training_contracts/20261019/river-six-seed')
    retained.mkdir(exist_ok=False,parents=True)
    copied=[]
    for source in sorted(ROOT.rglob('*')):
        if not source.is_file() or 'runtime' in source.relative_to(ROOT).parts:
            continue
        relative=source.relative_to(ROOT)
        if source.name.startswith('.') or source.suffix not in {'.json','.jsonl','.txt','.xml'}:
            continue
        payload=source.read_bytes()
        assert re.search(rb'\brv_[A-Za-z0-9_-]{20,}',payload) is None,str(relative)
        destination=retained/(str(relative)+'.txt' if source.suffix=='.jsonl' else relative)
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(payload)
        copied.append(destination)
    with tarfile.open(retained/'frozen-runtime.tar.gz','w:gz') as archive:
        for path in sorted((ROOT/'runtime').rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
                archive.add(path,arcname=str(path.relative_to(ROOT/'runtime')),recursive=False)
    rows=[]
    for row in result['per_seed']:
        counts=[row['arms'].get(arm,{}).get('passed','failed') for arm in ('base','sft','sft_rl')]
        selected=row.get('rl_selected_validation_step','failed')
        rows.append(f"| {row['seed']} | {counts[0]} | {counts[1]} | {counts[2]} | {selected} |")
    pooled=result['pooled']
    compare_text='\n'.join(f"- {key}: passed={value['passed']}; mean gain={value.get('mean_success_gain','unavailable')}" for key,value in result['comparisons'].items())
    text=f'''# River six-seed synthetic replication — 2026-10-19

This frozen study compares base, expert SFT, and SFT followed by two native RL batches on six independent training seeds. Every seed uses 128 synthetic training cases, 64 validation cases, and 64 fresh held-out cases. The ordinary data generator, policy, rewards, and held-out 7/45-day windows are unchanged. Training coverage doubles the earlier warmup, including 16 boundary and 16 misleading-note examples per seed.

| Seed | Base test /64 | SFT test /64 | SFT+RL test /64 | RL selected batch |
| --- | --- | --- | --- | --- |
{chr(10).join(rows)}

Pooled descriptive counts: base {pooled['base']['passed']}/{pooled['base']['total']}; SFT {pooled['sft']['passed']}/{pooled['sft']['total']}; SFT+RL {pooled['sft_rl']['passed']}/{pooled['sft_rl']['total']}. Statistical comparisons use independent seeds as the units; pooled case counts do not create additional training seeds.

All six seeds complete across every arm: **{result['complete']}**. All prespecified comparison gates passed: **{result['accepted_comparisons']}**.

{compare_text}

The comparison rules require six seeds, at least 3 percentage points mean success gain, improvement in every seed, no violation/truncation regression per seed, and an exact seed-sign test with Bonferroni correction across three planned comparisons. Thresholds were fixed before provider calls. The JSON review includes per-family results and family regressions separately; successful transport does not certify model quality.

Validation score changes after a reported skipped update at the same optimizer step: {len(result['zero_update_validation_score_changes'])}. Their cause is unconfirmed; they are retained as a repeatability limitation and are not evidence of learning.

The 768 rule-based expert chats were replayed in fresh sandbox instances and checked with the real tokenizer. All 224 historical canary cases were excluded by ID and factual fingerprint. All study splits and seeds were mutually disjoint. Base and SFT checkpoints are fixed by the plan; the native RL arm chooses only on validation, with earliest-step ties. Each model's held-out test attempt is sealed before sampling, including uncertain attempts. Any failed or zero-update RL arm remains failed; no seed is resubmitted.

The bound is two concurrent seeds, 20 minutes per seed, 60 minutes for the study, 96 requested SFT updates, 12 requested RL batches, and at most 3,690,000 reserved rollout output tokens across the separate durable ledgers. These limits do not establish a dollar cap or verified billed cost. SFT automatic restarts are disabled; RL recovery remains limited by its durable admission ledger and execution deadline.

[Review summary](review-summary.json), [frozen plan](plan.json), and per-seed reports contain the evidence. The frozen-runtime.tar.gz archive includes the exact package files and runners needed for source-matched replay. JSONL exports and cost ledgers have an added .txt suffix; their bytes are unchanged. Dataset manifests retain original names and hashes. No credential is retained.

This remains a synthetic experiment rather than independent human-reviewed production-quality evidence. It does not establish live crash recovery, backend parity, provider inventory cleanup, or billing correctness. A+ readiness is not claimed. Preserve all exposed held-out cases.
'''
    (retained/'README.md').write_text(text)
    hashes={p.relative_to(retained).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(retained.rglob('*')) if p.is_file()}
    (retained/'artifacts.sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'evidence':str(retained),'files':len(hashes)+1,'complete':result['complete'],
        'pooled':result['pooled'],'comparison_gates_passed':result['accepted_comparisons']}))


if __name__=='__main__':
    result=asyncio.run(audit())
    retain(result)
