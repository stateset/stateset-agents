# Changelog

All notable changes to the StateSet RL Agent Framework will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

- Bind River SFT lineage and Fireworks uploads to captured source bytes, retain
  Fireworks source identities across restart/deletion, and keep legacy identities
  explicitly unknown instead of hashing changed files during fetch.
- Enforce declared dataset split roles in packaged SFT and industry training,
  rejecting held-out or ambiguous local SFT sources before compute-provider setup.
- Accept generated industry training data in Studio, retain declared synthetic
  provenance in inspection and snapshots, and reject held-out split declarations
  or duplicate JSON keys before launch.
- Generate and reconstruct synthetic ecommerce, logistics, and SaaS support
  datasets with replayed policies, balanced isolated splits, provenance, and
  compatibility with existing industry SFT previews.
- Polish the Ghostty terminal studio with searchable Ctrl+P commands, incremental
  Unicode-safe rendering, responsive Escape, contextual headers and paged settings.
- Add replay-verified, training-only refund boundary contrasts with canonical
  parent lineage, held-out overlap rejection, and independent reconstruction.
- Preflight local worker-thread wakeup sockets before River SDK CI checks so
  sandbox IPC restrictions fail clearly instead of appearing as cleanup hangs.
- Exclude confirmed skipped River optimizer batches from checkpoint selection,
  replay their validation traces, and audit selected-checkpoint update activity
  separately from whole-run activity.
- Show an executable JSON lookup action in refund-policy prompts, preserve full
  order IDs in examples, and keep policy facts private until the lookup executes.
- Validate dependency locks in temporary outputs, preserve working lock bytes
  across resolver failures and interruptions, and reject concurrent input edits.
- Require an explicit boolean checkpoint trust decision before unpickling, enable
  unsafe Torch-load scanning outside the audited gateway, and pin Nemotron remote
  code to its model revision. Queue pagination uses complete literal SQL statements
  with bound owner and status values.
- Raise the training dependency floor and development lock to Accelerate 1.15.0;
  retain the unresolved Semgrep/MCP dependency advisory as a release blocker.
- Add a Python 3.12 training/API dependency lock, an independent dependency-audit
  CI job, and installed-wheel coverage using that runtime lock.

- Persist evaluation metric mappings in auto-research logs and normalize measured
  NumPy scalars for native checkpoint diagnostics while retaining nonfinite guards.

- Bind native DDP admission and checkpoint restore to package/model code and
  runtime revisions. Reject mixed implementations before learner mutation;
  native DDP checkpoint v3 requires matching sources and rejects older formats.

- Admit each fine-tuning run once across supervisor and direct-worker entry,
  retaining uncertain ownership instead of silently retrying paid work.
- Keep cooperative local stop available after supervisor loss, with explicit
  execution uncertainty in the TUI, agent CLI and HTTP API.
- Preflight native local checkpoint learner state and quarantine late restore or
  rollout-publication failures until a complete reload succeeds. Model-only
  imports remain distinct from training recovery.

- Validate shared runtime checkpoint state before restore, contain late restore
  failures, preserve adaptive KL state and reject invalid runtime publication.
  Dedicated GSPO, GSPO-token, DAPO and GEPO convenience loops now reject explicit
  resume requests before setup rather than silently training from scratch.

- Replace fabricated PPO completions with token-exact online sampling, retained
  behavior likelihoods and critic values, bounded reward callbacks, rollout
  receipts and complete checkpoint continuation. Reject unsupported sampling
  modes and quarantine partial updates. External-text reference updates retain
  their sampling-provenance limits; online PPO remains experimental.
- Expose safe HTTP run metadata and the exact checksum needed for stop review,
  including queued and running jobs during unrelated artifact inspection.
- Keep TUI and agent metric inspection responsive when metric files are links,
  pipes, directories or growing snapshots; retain bounded regular-file reads.
- Pin studio remote jobs to the reviewed framework release and quote RunPod
  command arguments, preserving literal model names and paths. Release pinning
  does not attest remote source bytes or dependencies.

- Support phone-sized fine-tuning terminals from 32 columns by 16 rows with
  compact controls, numeric navigation outside text editors, visible backend
  selection and paused actions during unusably small resizes. Launches retain
  explicit Enter confirmation.

- Reopen saved checkpoint nominations from the fine-tuning studio (`h`) and
  agent JSON commands. Preserve unsaved editors, surface unavailable records,
  restore the selected receipt without duplication, and keep fresh test cases
  blank until explicitly selected and reviewed.

- Nominate a recommended intermediate checkpoint for a separately reviewed fresh
  test evaluation from the fine-tuning studio or JSON CLI. Retain exact selection
  lineage, rehash nominated weights, reject overlap with validation history and
  keep training completion and quality receipts unchanged.

- Compare completed checkpoint validations from the fine-tuning studio (`j`,
  then `b`) or agent JSON commands. Queue checkpoint hashing and judge replay,
  retain durable handles/progress, reconnect without resubmission, rank matching
  cohorts with case-level regression guards and earliest-step tie breaking, and
  retain the base recommendation when no safe improvement is recorded. Restore
  a recommendation into a separately reviewed validation form without changing
  training or promoting artifacts.

- Expose a retained training seed in the fine-tuning studio, agent JSON config
  and remote CLI. Apply it before local adapter initialization and to trainer,
  data and supported provider paths. Retain SFT seed provenance, advertise
  provider seed support, reject unsupported/conflicting values, and bind paired
  evidence to training seeds separately from evaluation randomness.
  Display valid zero-valued seeds, checkpoint intervals and GPU counts correctly
  in narrow and two-column configuration layouts.

- Configure periodic native RL checkpoints and evaluate a retained published
  adapter from the fine-tuning studio (`j` → `n` → `c`) or agent JSON commands.
  Keep validation separate from fresh-test study evidence, bind reviews to
  checkpoint receipts and bytes, preserve strict recovery rules, and cancel
  unlaunched evaluations immediately. Expose controlled partition diagnostics
  and explicit metadata-only target discovery.

- Run reviewed local base-versus-adapter evaluations from the fine-tuning TUI
  (`j`) or agent JSON commands. Queue sequential, cache-only policy and pinned
  judge inference, retain private transcripts and replayable two-pass scores,
  inspect durable queue handles, sampled wait/headroom and progress, and stop
  only the evaluation. Preserve existing multi-seed
  evidence and distinguish a single-run diagnostic from quality certification.
  Browse held-out JSON cases from the evaluation form (`f`) without reading
  contents, changing the training draft or bypassing the separate launch review.

- Add exact local checkpoint recovery to the fine-tuning studio (`z`) and agent
  commands. Publish plan-bound checkpoint receipts, privately snapshot complete
  model/optimizer state into a new run, preserve original training budgets and
  require a separate launch review. Restore native trainer state or an explicit
  SFT checkpoint without fresh-training fallback. Inspect recovery choices
  through the authenticated operator API.

- Add guided fine-tuning setup, artifact-bound paired quality evidence and
  confirmed cooperative local stopping to the TUI and versioned agent commands.
  Separate descriptive gains from reviewed multi-seed study gates. Add strictly
  authenticated operator HTTP routes with bounded uploads, shared schema,
  controlled errors, off-loop inspections and credential redaction. Bound
  workspace metadata reads and preserve stop/checkpoint outcomes.

- Locate malformed fine-tuning data with one-based line/column, example/field
  or encoding offsets, shared by the inspector and strict preparation parsers.
  Add safe structured diagnostics to agent CLI errors without reflecting source
  values. Update background scan status without overwriting later UI actions.

- Inspect fine-tuning datasets in the background (`u`) with character/turn
  distributions, recorded hashes and duplicate checks. Keep private examples
  hidden until `e` reveals bounded excerpts; expose the same statistics through
  `finetune inspect-data`, with explicit sample opt-in. Share bounded regular-file
  reads with preparation, including limits during concurrent file growth.

- Compare fine-tuning experiments with a session reference pin (`a`) and a
  scrollable snapshot report (`x`), also available to AI agents through
  `finetune compare`. Show changed settings, recorded dataset identities and
  finite latest-metric deltas without selecting a quality winner. Bound record
  reads, reject special files and preserve drafts and worker state.

- Add a full fine-tuning log viewer (`l`) with training/supervisor source
  selection, stable paused snapshots, wrapped lines and literal filtering.
  Bound concurrent reads, label truncated windows, reject special files and
  keep views bound to the selected run. Expose source and read-window metadata
  through agent JSON logs without changing workers or provider jobs.

- Add a shared configuration checklist to the fine-tuning studio (`v`) and
  agent JSON CLI (`finetune validate`). Report field-addressable problems
  together, jump to hidden invalid fields for repair, reject numeric booleans
  and preserve incomplete drafts. Validation never reads datasets, prepares
  jobs or contacts providers, and launch validation uses the same rules.

- Add a fine-tuning backend picker (`b`) for local CUDA, RunPod, Modal and
  River. Route remote SFT to the selected executor, expose RunPod/Modal GPU
  choices, and retain River hosted checkpoints without claiming local weights.
  Require explicit provider-billed policy where dollar caps are unenforced;
  extend agent JSON discovery, paid opt-in and readiness to the new backends.

- Review an AI-prepared run directly from the fine-tuning TUI with `r`, then
  launch its existing ID and retained data without changing the Configure draft.
  Bind new launch records and queued workers to the exact reviewed plan bytes;
  reject changes and duplicate submissions across human and agent workflows.

- Add a versioned JSON fine-tuning CLI for AI agents, sharing studio workspaces:
  discover schema/models, inspect readiness, prepare immutable data, launch an
  exact reviewed plan once, and read status/logs. Require explicit paid opt-in,
  reject changed reviews and workspace traversal, and redact known credentials
  from JSON. Run details expose the matching Python environment's status command.

- Record controlled fine-tuning failure diagnoses and recovery guidance for
  CUDA, dependencies, memory, storage, timeout, review and artifact failures.
  Preserve child causes when supervisors exit, record failures before worker
  startup, and show next steps in run details without automatically retrying.

- Add background local readiness checks to the fine-tuning studio, with no
  provider authentication or allocation. Search retained runs and filter by
  status. Retain private metric events and chart reported samples, showing SFT
  epochs or committed RL updates without estimating completion time or quality.

- Improve the fine-tuning studio for narrow Herdr splits with complete model
  IDs, terminal-cell-aware wrapping and visible shortcuts. Add cursor editing,
  a JSON/JSONL dataset picker, scrollable run details, stable run selection and
  hash-checked settings reuse for a new run. Save incomplete drafts, clear stale
  model pins when changing models, and let Ctrl+C exit any screen while keeping
  detached jobs running. Viewing, browsing and copying settings start no work.

- Add `stateset-agents tui`, a Herdr-compatible terminal fine-tuning studio with
  searchable model maturity, editable SFT/RL settings, free input/resource
  previews, reviewed launches and reconnectable run logs/metrics. Snapshot
  reviewed data, retain private run records, route local training through an
  installed Buildr queue and support bounded RunPod SFT. Reject CPU dry-run
  substitutions and missing weight artifacts; quitting preserves running jobs.

- Add a version-bound recovery profile, free preflight planner and native
  four-scenario/eight-generation recovery trainer. Fail when a requested
  reference cannot be created; check the live KL anchor, dropout and optimizer.
  Retain replayable judge inputs, prompts, raw replies and retries, and verify
  them before using a selected checkpoint. Use greedy validation while restoring
  training decoding settings on success or failure. This prepares a new study;
  it does not certify GPU execution or a policy-quality gain.

- Add PR #109's pinned support reward v3 and two-pass rubric judge, a
  retrospective paired reward audit, budgeted whole-conversation judge blending,
  and baseline-preserving validation checkpoint selection. Reject incomplete or
  unstable judgement and overlapping study cases; bind selection to checkpoint
  bytes. Document the RunPod regression and remaining evidence without claiming
  a new policy-quality gain or launching paid compute.

- Report committed optimizer updates from task-boundary and final accumulation
  flushes through an `optimizer_step` callback and the normal log/evaluation/save
  cadence. Receipts identify the committed interval and update source without
  fabricating loss or reward measurements for flushes. Avoid a duplicate final
  save after a successful final-flush cadence save; preserve early stopping at
  task boundaries. Native loop v3 agrees on receipt controls before callbacks.
  Allow GradScaler to skip overflowed pending windows at native task boundaries
  while retaining strict checkpoint validation of pending gradients.

- Retain validated diagnostic guard history in native trainer checkpoints and
  coordinate post-step diagnostic failures across live DDP workers. Full reload
  repairs stale monitor references and transient rollout telemetry; global empty
  batches preserve signal patience. Learner preflight v4 and native DDP checkpoint
  v2 bind guard controls before updates and during restore. Serial version-one
  learning state remains readable with fresh diagnostic history. Native DDP
  version-one checkpoint directories are rejected.

- Report native DDP episode rewards over all newly generated samples and
  training-log rollout statistics over all learner samples, including replay.
  Preserve sample/group weighting and exact global medians without gathering
  reward vectors or trajectories. Let W&B accept precomputed population metrics;
  retain older logger signatures and call logger bodies only once. Isolate
  callback metric mutations from subsequent logs; version loop admission as v2.

- Let native DDP token training workers contribute zero samples without
  discarding peers' data or changing the global objective. Reduce explicit
  policy/entropy gradient banks, retain absent gradients for globally unused
  parameters, and preserve all learning state on globally empty batches.
  Empty no-ops retain timing/cost measurements without consuming or resetting
  policy-signal diagnostic patience.
- Coordinate local native rollout, token-loss, backward, optimizer and ordinary
  loop callback failures across live workers; failed loops require a full
  checkpoint reload. Persist an explicit next-episode cursor so initial
  checkpoints resume episode zero; older snapshots retain their legacy rule.
  Trigger reporting/evaluation/saves on committed update boundary crossings.

- Consolidate native DDP task memory through unwrapped teacher/Fisher models,
  accepted-example-weighted global Fisher statistics and staged peer commits.
  Preserve pending learning state on staging failure; require reload after a
  partial flush/commit. Flush prior-task windows before capturing memory, budget
  scheduler updates from task segments, and retain receipts that prevent
  duplicate final consolidation after completed-run resume.
- Normalize temporary fast-tokenizer backend padding/truncation in checkpoint
  identity while retaining vocabulary/template bindings. Clear stale teachers
  when restoring generations without a reference model.

- Coordinate native DDP evaluation across unequal local partitions, including
  empty workers. Weight population metrics by actual sample counts, agree on
  best-checkpoint decisions, preserve training RNGs/modes/buffers and pending
  gradients, and propagate local errors/cancellation across live peers. Restore
  prior selection after a failed best save and require reload after a failed
  buffer restoration. Empty/incomplete evaluations do not consume patience.

- Replace native DDP's weights/counters-only writer with atomic collective
  checkpoints: shared model/optimizer/scheduler/reference state and rank-local
  pending gradient banks, buffers, RNGs and learning history. Validate every
  shard before applying, preserve prior generations on save failure, and block
  learning after partial restore failure until coordinated reload succeeds.
  Both native checkpoint APIs now require all DDP workers to participate.

- Check native DDP policy, optimizer-slot and reference parameter values on
  first learner admission and after checkpoint-load attempts, using bounded
  content hashes. Bind scheduler Python implementations and callable arguments,
  defaults, closures and globals that are absent from saved scalar state.
  Coordinate asymmetric invalidation and reject mixed admission protocols.

- Reject native DDP learner configuration, schedule, optimizer, layout and
  rollout-path disagreements before buffer synchronization or policy/reference
  scoring. Validate sampled metadata and preserve pending gradients, optimizer
  state and running baselines on admission failure; permit unequal chunks.

- Construct native DDP batch-normalized advantages from the global clipped
  reward population and synchronize legacy running reward baselines. Freeze
  the baseline across rollout inner updates, observe each batch once, and pass
  running state through KL-enhanced loss. Reject invalid rewards and divergent
  estimator/state settings coherently before token-loss model forward.

- Weight native DDP diagnostics by their actual policy/token counts, with global
  population variance, exact step counters, entropy measurement flags, and
  coordinated schema validation. Verify source and installed-wheel reports with
  real CPU peers, including nonzero KL and rejection/recovery cases.

- Correct native DDP token-path RL normalization across unequal worker batches
  and both policy/entropy gradient banks, including repeated inner updates.
  Enable manual CPU/Gloo setup and reject conflicting existing process groups;
  synchronize buffers at learner-step boundaries to permit unequal forward counts.
  Bound reduction payloads, preserve small FP16 gradients, and avoid overflowing
  finite means. Verify combined-batch agreement with two real CPU workers.

- Require source-bound input consensus across Muse/frontier SFT ranks before
  weight loading; retain agreed hashes and reject mismatches on every rank.
  Verify the fixed-size tensor handshake and recovery with actual CPU/Gloo peers.

- Bind Muse/frontier SFT dataset validation, hashes and training examples to one
  captured read per split, preventing file-replacement races in provenance.
- Enforce the Torch 2.7 distributed-loading minimum before backend imports;
  verify real local FP8 attention/expert dequantization and BF16 adapter updates.

- Add pinned frontier model readiness and distributed assistant-only text SFT
  for native GLM-5.3/Flash and Qwen3.8 2.4T/Flash-Next, with explicit FP8 to
  BF16 dequantization, exact language attention adapters and native loss masks.
- Replace provisional Kimi K3 targets with the released KDA/MLA specification;
  record MiMo RL/MOPD and DeepSeek V4.1 Flash identities and fail closed on
  unsupported packed/inference layouts. Full-size GPU training is unverified.

### Added

- Muse Spark Open revision-pinned distributed text LoRA SFT, native Transformers
  FSDP/expert-parallel loading through TRL, assistant-only masks, strict dataset
  validation, stable template options, adapter export, and a text GSPO preset.
  Checkpoint access is gated; full-size GPU conformance remains unverified.
- Nemotron 3.5 Super VL and Bolt BF16 image-conditioned LoRA SFT, with pinned
  model/processor revisions, local image/chat datasets, assistant-only masking,
  optional FSDP launch, CLI configuration, and adapter/processor export. The
  integration has CPU contract coverage; full-size GPU training is unverified.
- Checkpoint-pinned Super VL and Bolt River text/tool renderers, including
  River 0.11 image-token metadata compatibility without changing rollout IDs.
  Hosted model availability still requires an authenticated account check.
- Retain a live Super VL NVFP4 River smoke run with one reported optimizer
  update, finite nonzero gradient norm, hosted checkpoint, and audited evaluation.
  Validation tied the baseline; this does not establish a quality improvement.

- Add source-isolated temporal curation with baseline contact/credential
  redaction, duplicate grouping, held-out failure retention and split hashes.
- Add a callback-based trace-to-policy pipeline, a runnable local transformer
  example, stage profiling, and fatal learning-signal diagnostics.
- Bind production promotion to actual policy bytes, immutable lineage, reviewed
  provenance and recomputed six-seed paired quality/safety evidence. Production
  inference validates the selected model and content-addressed artifact path.
- Add an explicit CPU/CUDA logged-policy contract runner for real updates, exact
  checkpoint resume and reloaded inference, with installed-wheel CPU checks in CI.

### Improved

- Move durable training API database calls off the event loop and drain accepted
  submission transactions during cancellation and shutdown. Freeze request inputs
  before deferred writes so caller mutations cannot change admitted work.
- Filter and paginate training jobs in SQLite/PostgreSQL with consistent counts,
  stable ordering, and indexes; decode only the requested page's payloads.
- Return HTTP 409 for conflicting idempotency keys and HTTP 429 for a full
  durable queue, preserving accepted retries even at capacity.

### Fixed

- Isolate native quality-study evaluation from training RNGs, gradients and
  module modes, including cancellation. Bind per-case sampling seeds to exact
  case content so case order and earlier episode lengths do not shift paired
  evaluation streams. Reject invalid study protocols before model allocation.
- Reject renamed reviewed cases even when annotations differ; distinguish
  validation reports from test evidence and retain checkpoint-selection receipts.
  Refuse candidate testing without consistent committed optimizer updates.
- Make shared trainer evaluation fail on errors by default, propagate required
  reward and OOM failures, route executed reward context correctly, and drain
  concurrent episodes on failure. Diagnostic evaluation retains failed attempts
  in coverage and success-rate counts instead of silently dropping them.
- Replace random offline policy batches with aligned logged assistant actions
  and real IQL-weighted language-model updates. Include tool observations and
  terminal rewards, and mask only the current assistant action.
- Save and restore offline policy/IQL optimizers, pending gradients, RNGs and
  mid-epoch cursors; reject a changed dataset on resume and export reusable weights.
- Restore CUDA generator states as CPU byte tensors after device-mapped checkpoint
  loading, fixing a failure found by the live RunPod check.
- Weight accumulated offline gradients by logged action count, preserving the
  objective across uneven microbatches and partial windows. Persist pending counts
  and normalization, validate them before policy restore, and report final-window
  optimizer updates accurately. Legacy in-flight accumulation is rejected;
  completed optimizer checkpoints remain loadable.
- Reduce native token-path policy losses using global trajectory/token counts
  instead of equally weighted group means. Keep entropy's global token denominator,
  weight KL/ratio/clipping diagnostics by sampled tokens, and compute named
  batch-normalized advantages across all prompt groups after reward clipping.
- Weight native online GRPO accumulation by actual trajectory/token counts,
  with a separate entropy denominator for sequence objectives and normalized
  partial windows. Persist pending normalization and auxiliary gradients, and
  initialize restored AMP scalers before an immediate partial-window flush.
- Preserve global reward statistics, private replay RNGs, frozen LwF task
  references and EWC state through both checkpoint APIs. Validate learning state
  before loading policy weights; reject unrecoverable legacy global/LwF state.
- Average EWC Fisher statistics over valid examples, preserve task memory when
  none are scored, and restore module modes on all exits. Promote low-precision
  arithmetic, avoid sum overflow, reject partial nonfinite consolidation, and
  propagate OOM/interruptions while exposing accepted/skipped sample counts.
- Isolate mutable preset configuration and consume agent settings before
  forwarding trainer arguments.

- Preserve critical errors and evaluator-context requirements through nested
  composite and uncertainty-weighted rewards. Retain component evidence and
  reject invalid uncertainty instead of masking errors or amplifying rewards.
- Preserve final-outcome reward timing through composition and propagate
  required conversation step-reward errors instead of silently substituting zero.
- Carry the agent's model revision through online, offline, and hybrid training,
  and reject conflicting model identities before training starts. Apply API
  revision overrides when constructing embedded and durable worker agents.
- Detach nested policy observations from evaluator state so context mutations
  cannot fabricate executed tool evidence or alter the source scenario.

## [0.66.1] - 2026-10-14 — Harden training worker lease recovery

### Fixed

- Fence training leases using time read after acquiring the queue lock, with
  PostgreSQL server time shared by all worker hosts. Reject invalid lease
  durations before mutation and reject renewals at the expiry deadline.
- Keep durable workers running after losing an attempt's lease, and drain
  heartbeat threads before propagating repeated shutdown cancellation.
- Synchronize both running trainers in the shutdown regression before injecting
  a state-store failure, removing a scheduling race in the publish readiness gate.

## [0.66.0] - 2026-10-14 — Reliable training and durable workers

### Added

- Add strict rollout contracts and explicit sequence/sampler fallback options,
  shared pre-compute configuration validation, versioned native trainer state,
  RNG restoration, batched Hugging Face groups and memory-conscious token scoring.
- Add persistent SQLite/PostgreSQL training queues with independent workers,
  idempotency, global capacity, cancellation and fenced leases. Default API
  rewards use task outcomes; starter heuristics require explicit selection.
- Add sampled multi-turn learning/reload evidence and clean installed-wheel
  checks across package extras and minimum/latest/locked training dependencies.

- `train()` accepts `objective` and `objective_overrides`, and applies any
  other `TrainingConfig` field passed as a keyword (e.g. `learning_rate=1e-5`).
  Unknown keywords, conflicting duplicate settings, unknown objectives and
  unknown `training_mode` values now raise instead of being silently ignored.
- Add `river-preflight` and a Python report API for local prerequisites and
  opt-in live account model checks. Emit versioned JSON for CI, distinguish
  unchecked access from denied access, bound SDK requests without retries,
  and close clients without creating training sessions or sampling tokens.
- Support immutable model revisions for industry preparation, tokenizer and
  weight loading, adapter lineage, and paired evaluation. Add a reproducible
  CUDA pilot harness for Qwen3.5 2B/4B with synthetic-data labeling, saved
  adapter checks, reload-effect probes, and retained raw predictions.
- Add paired industry reference evaluation through `industry eval-export`,
  `industry evaluate`, and backend-independent Python prediction callbacks.
  Evaluate every assistant turn, preserve typed tool arguments and failed
  requests, bind reports to dataset/prediction hashes, and reject incomplete or
  incomparable evidence. Configurable quality and resource gates count source
  groups, detect per-case regressions, and refuse synthetic demonstrations.
- Add `industry` CLI commands and Python APIs for nine sector recipes, synthetic
  tool-calling examples, strict JSONL validation, grouped train/validation splits,
  dataset fingerprints, and explicit-preview or CUDA SFT execution. Holdout data
  remains separate for independent evaluation.
- Added `APIConfig.training_max_concurrent_jobs` (default `1`) and
  `API_TRAINING_MAX_CONCURRENT_JOBS` to bound active training jobs per API process.
  Excess submissions receive HTTP 429; cancelling jobs retain their slot until
  cleanup completes. The optional constructor argument is appended after all
  existing arguments, preserving positional calls, and is recorded in the stable
  v1 API contract.
- Added a v0.5 private product-use transfer set with seed-varying support
  conversations and a dependent ingest-to-grade task. Both static and
  interactive evaluators verify its actual tool results and generated files.

### Fixed

- Sequence-path GRPO now trains on assistant tokens only. Real tokenizers
  return a `BatchEncoding` with an `assistant_masks` key, which the old check
  (`dict` with `assistant_tokens_mask`) never matched, so prompts were silently
  supervised. Templates without `{% generation %}` markers (Qwen3, Qwen3.5,
  ChatML) now get assistant spans from prefix renders. Tokenizers without a
  chat template fall back to role-tagged spans instead of crashing.
- DAPO dynamic sampling no longer discards every group when no verifier is
  set (the default): groups are scored before filtering, and without a
  verifier only zero-signal groups (all rewards equal) are dropped. DAPO now
  accumulates every group into one optimizer step per inner update, so its
  token-level mean spans the whole batch as in the paper.
- VAPO computes GAE in the shifted action frame used by its log-probs, values
  and loss masks. The episode reward previously landed one token past the last
  action, so policy advantages depended on a never-trained value. Value warmup
  targets now use the same frame and discount.
- PPO places the scalar episode reward on the last response action instead of
  every response token, which inflated returns with length. Padding is now
  excluded from the response mask (with left padding handled), no longer
  bootstraps values, and is left out of advantage normalization.
- Native GRPO inner updates snapshot old-policy log-probs under the same
  autocast precision as the losses, so the first importance ratio is exactly 1.
- Sequence-path GRPO skips trajectories whose replies were truncated away
  instead of falling back to supervising the whole conversation, and its
  entropy bonus now reads the logits that predict the supervised tokens.
- GSPO and GSPO-token score responses against the untruncated rendered prompt.
  Prompts longer than `max_prompt_length` previously leaked their tail into the
  response mask (or, when very long, displaced the response entirely).
- GSPO's cosine LR schedule is sized by optimizer steps (one per outer
  iteration, not multiplied by `num_iterations`) and holds its final value past
  the end instead of oscillating between full and zero learning rate.
- With `rescore_old_log_probs=False`, GSPO's rollout-time old log-probs now
  cover exactly the tokens it scores: a trailing EOS is dropped, and HF or vLLM
  sampler log-probs are used only when the sampled ids round-trip to the scored
  text (otherwise the rollout is rescored). The EOS term previously biased the
  sequence ratio by about log p(EOS) / |y|, far outside GSPO's clip band.
- Batched group generation stops each row independently. The stop-string
  criterion read only row 0 and returned one flag for the whole batch, so one
  sample emitting `\n\n` or `User:` truncated all of its siblings while stop
  strings in other rows were ignored. Padding after a stop string is no longer
  recorded as a sampled EOS when `pad_token_id == eos_token_id`.
- Restoring a trainer checkpoint now syncs an attached rollout engine, which
  otherwise kept serving pre-resume weights until the next optimizer step.
- `CalibratedRewardFunction` normalizes against statistics frozen between
  `calibration_interval` refreshes (identity before the first one) instead of
  updating them on every call, which split ties and inverted rankings within
  a group.
- Over-long generation prompts are truncated from the left, keeping the latest
  user turn and the assistant cue, and a warning is logged.
- The per-token GRPO path honours `baseline_type="group_median"` and
  `"global_mean"` (with the trainer's running reward mean) through the same
  helper as the sequence path; it previously fell back to group normalization.
- CQL bootstraps from next-state actions: dataset `next_actions` when passed to
  `train_step`, otherwise a soft maximum over sampled actions. It previously
  evaluated `Q(s', a_t)` with the current action. The CQL penalty now scales
  `logsumexp(Q / tau)` by `tau`, as in CQL(H).
- River/Tinker SFT datums are the single full render of each conversation,
  weighted on assistant spans located in that render. Splicing separately
  tokenized prefix renders corrupted every multi-turn row for Qwen3/Qwen3.5
  (which add a `<think>` stub to the final assistant turn only). Tool-calling
  fields and row `tools` are now kept instead of being stripped or dropping
  the row. Assistant-span logic is shared in `stateset_agents.core.chat_masking`.
- Local and industry SFT label assistant tokens only (system prompts, user
  turns and tool results are context) and drop rows whose answer is truncated
  away at `max_length`, instead of training on every token.
- `ConversationDataset.split`, `filter_by_quality` and `filter_by_length` no
  longer re-normalize the shared trajectories in place (which changed the
  parent and rescaled each subset by its own statistics). `filter_by_quality`
  compares raw total rewards, and `split` no longer reseeds the global RNG.
- The Decision Transformer pairs each assistant action with the full
  conversation before it and the return-to-go at its own turn; states and
  returns were previously offset from their actions.
- `build_rl_batch` uses the same pre-shifted label layout as the live
  `build_group_rl_datums` path; its values were one position late.
- TRL-backed GRPO now honours `TrainingConfig.objective`: `grpo`, `bnpo`,
  `dapo`, `dr_grpo`, `cispo` and `gspo` map to TRL's `loss_type`, importance
  level, clip range and reward scaling; presets or overrides TRL cannot express
  raise. Settings the installed TRL no longer accepts (e.g. `max_prompt_length`
  on TRL 1.12) are logged instead of dropped silently.

- Publish cancelled synchronous River RL runs from validated committed state,
  retain token reservations on resume, and record cancellation in the cost
  ledger. Report or bookkeeping failures preserve the original interruption;
  partially completed provider operations never advance committed progress.
- Close executor-owned River clients after successful, failed, or interrupted
  submissions while preserving caller ownership of injected clients. Reject
  overlapping submissions on one executor, retain completed checkpoints when
  cleanup fails, and make early failures and interruptions terminal in job state.
- Check fresh River account model access before sessions or tokenizer/renderer
  loading, keep SFT tokenizer caches separate per model, and avoid constructing
  River clients during dry runs or completed RL resumes. Extend regression
  coverage for empty streams and thread-backed rollout replies.

- Size native GRPO learning-rate schedules for every configured token-path inner
  update instead of dividing those updates by gradient accumulation. Keep final
  partial windows in ordinary accumulation budgets, and align `TrainingConfig`
  step/warmup estimates with the native trainers. Mixed fallback paths use the
  token-path budget as an upper bound; only committed optimizer steps advance it.

- Separate pending GRPO accumulation from token-path inner updates: flush the
  pending window with its actual mean, clear its counter, and rebuild subsequent
  losses against the frozen pre-flush policy. Multi-turn metrics count the flush
  separately as `accumulation_flush_updates` and include it in total committed
  `optimizer_updates`. Single-turn inner updates now retain the continual-learning
  EWC penalty on every recomputed loss.

- Average the final partial accumulation window over its actual batches in both
  native GRPO trainers. Apply the correction after AMP unscaling and before
  clipping, including when flushing restored gradients without another episode.
  Initialize restored AMP scale state before that flush without advancing its
  growth tracker or rescaling saved gradients.

- Validate native GRPO scalar losses and optimizer gradients before updates.
  Reject invalid clipping limits and non-finite gradient norms, clear rejected
  accumulation windows, and let real AMP overflows reduce their scale without
  advancing optimizer-step counters, learning-rate schedules, or rollout sync.
  Multi-turn step metrics now report committed `optimizer_updates`, including
  mixed successful/skipped inner updates; single-turn simulation or missing
  gradients no longer fabricate optimizer progress.

- Propagate single-turn GRPO loss and environment errors instead of silently
  substituting heuristic progress. Bind legacy environment call signatures before
  invocation so an internal `TypeError` cannot repeat a side effect. Discard
  pending gradients on cancellation or failure, skip success finalization, and
  drain an exposed tracking `finish_run` hook through repeated cancellation.
  Use the packaged W&B logger's `log_metrics` interface while retaining support
  for simple `log`-only trackers.

- Stage and sync GRPO checkpoint artifacts before publication, retain the prior
  checkpoint through replacement, and recover interrupted directory renames on
  the next trainer access. Serialize cooperating reads and writes with a local
  filesystem lock and verify new checkpoints' complete SHA-256 file inventories
  before loading weights. Failed saves no longer overwrite a usable checkpoint
  with partially written model or training state.

- Share checkpoint state handling between single-turn and multi-turn GRPO:
  restore pending gradients, AMP state, and sharded/tied model weights in both
  trainers. Propagate single-turn artifact write failures without a saved
  callback, and close the final accumulation window to prevent duplicate
  optimizer updates after resuming a completed run.

- Reject unconfirmed explicit checkpoint resumes in single-turn and multi-turn
  GRPO before starting callbacks or rollouts, instead of silently starting a
  fresh run after a missing or unusable checkpoint.
- Restore multi-turn checkpoints from indexed PyTorch and safetensors shards,
  including omitted tied weights in Hugging Face saves. Validate shard paths,
  index coverage, shard contents, and tied values without loading all shards
  into memory at once.
- Persist multi-turn GRPO pending gradients and AMP scaler state for checkpoint
  recovery. Validate accumulation compatibility before loading weights, reject
  incomplete legacy windows, and fail explicitly on missing or incompatible
  model, optimizer, or scheduler state in new checkpoints.
- Prevent multi-turn GRPO cancellation, interrupts, and unexpected errors from
  flushing pending gradients or running success finalization. Propagate final
  checkpoint failures, close tracking through cancellation, and clear completed
  accumulation windows so resumed runs cannot flush them twice.
- Preserve observed API training progress when a trainer returns early or emits
  no episode callbacks. Expose completion scope in job status and list responses
  instead of unconditionally claiming 100% episode progress.
- Stop native River runs after a configurable streak of confirmed skipped
  optimizer updates (default five), preserving diagnostics and the sealed test
  split. Bind the threshold to run/study plans and enforce it after recovery
  and in study audits; unknown activity never counts as skipped updates.
- Serialize native River validation writes with other callbacks and recovery,
  and drain active writes when evaluators are cancelled during shutdown.
- Close native River training and rollout iterators before releasing provider
  resources when step persistence or trajectory validation fails; drain in-flight
  iteration and cleanup through repeated caller cancellation without prefetching.
- Distinguish River's completed batches from observed optimizer updates in
  training-activity reports, preserve unknown activity after recovery, and keep
  the held-out test split sealed when every completed batch is known to have
  skipped the optimizer. Study audits recompute activity from the recorded
  batches and require matching summaries before accepting RL evidence.
- Report actual group-advantage signal in native GSPO trainers and avoid false
  zero-signal aborts when metrics are missing. Reject invalid rewards, losses,
  and gradients before advancing optimizer or scheduler state.
- Average GSPO-token loss across processed prompt groups, including KL, and honor
  `rescore_old_log_probs` with the same score-gap diagnostic as GSPO.
- Made `SecureConfig` fail closed when encrypted secrets lack a configured key
  or the `cryptography` dependency; explicit plaintext storage remains available
  through `encrypt=False`.
- Rejected expired `AuthService` sessions during authorization and made security
  timestamps timezone aware while accepting older naive UTC timestamps.
- Capped the in-memory `SecurityMonitor` event history at 10,000 entries by
  default, so repeated authentication failures cannot grow it without bound;
  both security monitors now reject invalid event limits.
- Bounded the API authentication failure tracker to 10,000 credential keys by
  default. It prunes expired records and rejects new invalid credentials when
  full without evicting active lockouts.
- Made healthy Redis misses authoritative in the hybrid cache, so a key deleted
  by another instance cannot reappear from stale local memory. Redis read
  failures still use the local availability fallback.
- Retry a configured Redis connection after a hybrid cache starts in memory
  fallback mode, allowing the cache to recover when Redis becomes available.
- Isolate API cache decorator keys by fully qualified function name and full
  SHA-256 argument digests to prevent cross-function cache collisions.
- Keep real-model streaming off the event loop, preserve inference mode, stop
  cleanly across chunk boundaries, and surface generation worker failures.
- Validate rollout backend batch counts, prompt identity, token alignment, and
  finite log-probabilities before handing samples to trainers. Invalid batches
  use one native fallback and retain the backend error on each turn.
- Require exact sampled-token log-probabilities from vLLM generation and exact
  prompt-aligned response-token probabilities from vLLM rescoring; missing data
  now raises instead of silently substituting unrelated values or zero.
- Reject duplicate prompt keys, invalid group sizes, incomplete groups, and
  misattributed responses in vLLM/HuggingFace group generation and the GSPO
  and DAPO training paths.

## [0.56.0] - 2026-09-23 — Formal verification foundations

### Added

- Added bounded TLA+ models for rollout admission, asynchronous policy
  publication, auto-research selection, checkpoint replacement, and recovery
  after a crash between checkpoint installation and experiment logging.
- Added Lean proofs for clipped objectives and reward composition, plus a
  pinned CI workflow and Python refinement tests for the modeled behaviors.

### Fixed

- Fenced stale rollout submissions at admission, rejected missing strict
  policy artifacts, and kept accepted counters consistent across cancellation
  and timeout boundaries.
- Recovered interrupted best-checkpoint swaps and rejected non-finite research
  scores before promotion; made experiment-log appends durable before the
  checkpoint is finalized.
- Rejected invalid reward weights and treated non-finite component scores as
  failed components.
- Updated the development lock to NLTK 3.10.3 after the security scan
  identified advisories against the previous version.

## [0.55.0] - 2026-09-11 — Evidence-backed A+ release gates

- Made schema-v2 release evidence fail closed on retained security contents:
  the A+ gate now rejects Bandit execution errors and medium-or-higher findings,
  plus any known Safety vulnerability, after verifying report hashes.
- Added direct wheel/sdist structure and metadata validation to the A+ release
  gate, including unsafe member, duplicate member, project identity, version,
  packaged-module, wheel metadata/record, and source build-metadata checks
  without archive extraction.
- Upgraded provider-canary evidence to schema v2 with exact framework version,
  clean-checkout status, and Git commit identity; the A+ gate now rejects
  legacy, dirty, or cross-commit provider reports while retaining schema-v1
  readability for historical diagnostics.
- Made provider publication evidence semantic: the validator now requires the
  adapter-specific health, inventory, authorization, authentication, and
  zero-leftover observations instead of trusting a generic passed status.
- Hardened provider evidence file boundaries and result schemas against
  symlinks, invalid UTF-8/JSON, negative or non-integer durations, invalid
  statuses, malformed cleanup/error fields, and duplicate provider identities.

### Changed

- Added a dedicated distributed-scaling image build path that requires an
  immutable CUDA/PyTorch base, labels the exact source revision and package
  version, requests maximal BuildKit provenance and an SBOM, and records the
  pushed registry digest in a machine-readable attestation. It reads the
  registry's SLSA, SPDX, image-label, and manifest views back after the push;
  the A+ gate verifies them and binds every Kubernetes or RunPod scaling
  lifecycle record to that digest.
- Added raw provider billing attribution for Kubernetes scaling. Each Job now
  records an exact UTC lifecycle; the A+ gate requires an exactly matched
  CoreWeave/Nebius billing envelope, re-hashes its retained export, verifies
  billing-window and line-item arithmetic, rejects duplicated allocations, and
  reports matrix cost per measured optimizer step.
- Upgrade publish-readiness summaries to portable schema v2 evidence. The gate
  installs the built wheel into a fresh offline virtual environment rather
  than importing the source checkout, and retains SHA-256/size identities for
  the wheel, source archive, coverage XML, Bandit report, and Safety report.
  The A+ gate re-hashes those artifacts, checks the package version and complete
  readiness roster, parses security JSON, and enforces the repository coverage
  threshold from the retained XML.
- Refreshed the README and evidence docs against the `v0.54.0` release,
  including the
  corrected-but-incomplete 1.5B comparison, current provider/publication
  blockers, and the measured gates required before an A+ leadership claim.
- Extended release automation and regression coverage so README stable-install
  commands and its current Python release declaration cannot lag the package
  version again.

### Fixed

- Made the flagship publication runner reject placeholder or stale-version
  manifests before measured execution, and cryptographically bound reported
  judge scores to the declared judge model, revision, and rubric revision.
- Made local scaling and fault-recovery collectors derive provenance from a
  clean checkout and reject caller-supplied harness commits that do not equal
  the code actually executing.
- Require every external-backend conformance record in a roster to declare the
  same canonical dataset-content digest, while retaining independent physical
  file hashes for JSONL/Parquet transport integrity.
- Make measured τ³-bench/BFCL/SWE collection reject template commands, zero
  model/suite/artifact revisions, stale StateSet versions, and dirty harness
  checkouts before invoking an official evaluator, and require explicit proof
  that the evaluator receives the pinned model revision or loads a checkpoint
  carrying an exact local revision marker. The standalone official pipeline
  now independently enforces immutable model and suite revisions, verifies the
  upstream checkout's exact commit, and rejects partially bound multi-command
  pipelines.
- Make the agent-quality publication gate resolve portable retained-artifact
  paths inside their evidence bundle and re-hash every raw file, rejecting
  missing, tampered, symlinked, or escaping artifacts. This is emitted as
  evidence schema v3; older rows cannot silently satisfy the stronger gate.
- Bound resumed framework-shootout evidence to the exact manifest digest,
  implementation version, and harness commit. Stale runs that merely share a
  framework name and seed can no longer enter a corrected matrix, and the
  RunPod launcher uploads only exact-match evidence during resume.
- Emit framework-comparison evidence schema v2 with portable raw-artifact
  paths and verification-time re-hashing. Legacy schema-v1 rows remain
  readable for historical reports but cannot mix with or resume into v2 runs;
  RunPod resume now restores each verified raw run directory as well as JSON.
  The reporting CLI requires re-verifiable schema v2 by default and exposes a
  named opt-in only for reproducing historical schema-v1 reports.
- Add the corrected `stateset-trl-gspo-shootout-v4` 1.5B, three-seed manifest;
  its non-billable dry run validates the exact six-pair rotated matrix. Both
  sides now declare sequence-level importance ratios, 3e-4/4e-4 GSPO clipping,
  group reward normalization, and sequence-mean aggregation; the TRL adapter
  fails before model loading if TRL is not exactly 1.12.0 or cannot express
  those objective-critical fields.
- Bind schema-v2 framework comparisons to the exact shootout-manifest digest.
  The publication CLI can now require and total every RunPod lifecycle record,
  rejecting mismatched manifests or harnesses, duplicate pods, inconsistent
  rate-times-lifetime arithmetic, and unconfirmed cleanup before cost appears
  in the machine-readable and Markdown reports.
- Made `stateset-agents version --json` inspect optional dependency metadata
  without importing accelerator runtimes, preventing vLLM/CUDA initialization
  logs from corrupting machine-readable output.
- Treat an installed but locally unusable vLLM build as an unavailable optional
  backend during import, preserving the Hugging Face fallback instead of
  crashing on driver, operator-registration, or platform initialization errors.
- Replace GPT-2 Hub downloads in tiny GSPO/GEPO tests with an in-memory,
  character-stable tokenizer, making those tests independent of network and
  user cache state. Correct the cross-trainer invariant so GEPO is checked
  against its actual probability-weighted on-policy coefficient rather than an
  inapplicable likelihood-ratio-equals-one assumption.
- Align the executable distributed-scaling publication gate with the A+
  leadership scorecard: the default minimum is now 70% rather than 50%, and
  generated JSON/Markdown reports record the exact enforced threshold and
  monotonic-throughput policy.
- Upgrade flagship benchmark output to portable schema-v2 evidence with
  independent `--validate-existing` revalidation. Retained policy artifacts
  are re-hashed and must remain inside the evidence bundle without symlinks;
  the matrix also rejects mixed harnesses, manifests, and reused artifact
  paths.
- Expand the provider publication gate from the legacy River/RunPod/Fireworks
  trio to include CoreWeave and Nebius by default. Historical three-provider
  reports remain inspectable only with an explicit reduced roster and cannot
  satisfy the current A+ provider gate. Publication also rejects canaries older
  than 30 days or materially future-dated.
- Add one top-level, fail-closed A+ publication gate. It revalidates every raw
  domain bundle, requires native StateSet GSPO plus TRL/verl/NeMo RL/OpenRLHF,
  enforces throughput within 10% of the fastest, 70% strong scaling across at
  least two nodes, zero-loss recovery, the 12-hour soak, five fresh provider
  canaries, agent-quality and flagship results, and publish readiness all bound
  to one immutable commit.
- Add a shell-free physical multi-node strong-scaling launcher contract and
  protocol-v4 evidence. Distributed ranks now contribute hashed DMI node IDs and
  ranks-per-node, each row retains a re-verifiable policy artifact, and both
  the collector and A+ gate reject declared/observed topology drift, legacy
  scaling protocols, or single-node evidence.
- Extend the RunPod REST adapter with official global-networking and
  datacenter-pinning fields even when no network volume is attached, enabling
  deterministic private pod-to-pod rendezvous for distributed collectors.
- Add a concrete, budget-bounded RunPod multi-node scaling adapter with
  private-DNS torchrun rendezvous, distinct-machine attestation, authoritative
  aggregate price checks, per-pod recovery leases/watchdogs, unconditional
  partial-cluster cleanup, and retained pod-level lifetime/cost records.
- Add a provider-neutral high-bandwidth Kubernetes scaling adapter for
  CoreWeave CKS and Nebius clusters. It uses an anti-affined Indexed Job and
  headless-Service DNS, requires a digest-pinned image and schedulable fabric
  resource, attests scheduled nodes and Pods, retrieves rank-zero evidence,
  and unconditionally deletes both Kubernetes resources.
- Bind the top-level A+ scaling decision to an exact lifecycle record for
  every topology/seed row. The gate now verifies commit/config/output identity,
  Kubernetes image/fabric/node/Pod cleanup attestations, or RunPod
  machine/termination and rate-times-lifetime cost arithmetic.

## [0.54.0] - 2026-09-08 — Rollouts sample in inference mode

### Fixed

- **Rollouts were sampled in train mode.** Trainers put the policy in
  `train()` for the loss and backward pass, and agent-based generation
  (native GSPO, the GRPO trainers) then sampled in that state; with LoRA and
  gradient checkpointing active a PEFT model emits garbage (observed live on
  Qwen2.5-1.5B: 34-character non-answers against correct 700-character
  solutions from the same weights in eval mode), so every retained
  native-GSPO rollout was garbage and its reward zero even after the prompt
  and log-prob fixes. `MultiTurnAgent` now wraps every `generate` in
  `core.generation_mode.inference_mode` (eval mode with the KV cache, the
  trainer's mode restored afterwards); DAPO, VAPO and GEPO already generated
  in eval mode.
- `training.callbacks.ZeroSignalGuard` aborts a run whose reward is
  identically zero for five consecutive steps, and the phase0 harness arms it
  for native GSPO so a mis-wired run fails within minutes (recorded as
  `train_failed` with the reason) instead of burning hours of GPU.

### Fixed

- The same placeholder-prompt query derivation fixed for GSPO in `0.53.0`
  also lived in `train_with_gspo_token` and in the auto-research loop's DAPO
  and VAPO paths (`scenario.get("context", "Hello")`, first few scenarios
  only, no scenario fields for the reward). All three now use
  `queries_from_scenarios` (real prompt field, whole scenario as reward
  context, rotation through every scenario); the token trainer accepts
  `{"prompt", "context"}` queries and forwards the context to the reward.

## [0.53.0] - 2026-09-08 — GSPO trains on the task, and evidence fails closed on zero signal

### Added

- `MultiTurnAgent.generate_turns(messages, n)`: sample a whole group in one
  batched generate (HF `num_return_sequences`, or one batch of `n` prompts to
  a rollout backend), every turn carrying the same exact token ids and
  sampler log-probs as `generate_turn`. Native GSPO's HF path now generates
  its group this way and takes the rollout-time sequence log-prob from the
  sampler instead of a second forward pass per response.

### Fixed

- **Native GSPO trained on a placeholder prompt with a blind reward.**
  `train_with_gspo` derived its queries from `scenario["context"]` (falling
  back to the literal prompt "Hello"), used only the first
  `generations_per_iteration` scenarios, and passed the reward no scenario
  fields; GSM8K-shaped scenarios (`user_query`/`gold_answer`) therefore
  trained on "Hello" with a reward that never saw the gold answer —
  identically zero reward and loss at every step. Queries now come from the
  real prompt field with the whole scenario as reward context, rotate
  through every scenario, and a scenario without prompt text is an error.
  The trainer reports `reward_std`, warns after five zero-signal iterations,
  and the phase0 harness passes GSPO the same task prompts the TRL path uses.
  The retained v2 native-GSPO rows and the first v3 native-GSPO run are
  withdrawn (`benchmark_results/framework_comparison_v2/RETRACTION.md`).
- **Native GSPO gated ~90% of on-policy samples to zero gradient.** The
  old-policy log-prob came from a separate unbatched forward per response;
  its numerical gap to the batched current pass (~4e-3 nats per token) exceeds
  GSPO's clip band (3e-4 / 4e-4), so the trust-region gate zeroed most
  samples even when the reward was correct (v3 seed 42: clipping fraction
  0.93 with ratio 1.004). With `rescore_old_log_probs` (default) the old
  log-probs are now the current forward pass, detached (the TRL convention:
  a fresh rollout batch is exactly on-policy), and the generator's gap is
  reported as `generation_log_prob_gap`; `rescore_old_log_probs=False` keeps
  using the generator's numbers (importance correction against a lagging
  engine).
- Evidence is fail-closed on learning signal: adapters record
  `train_reward_mean`, `train_reward_std_mean`, `train_reward_zero_fraction`
  and `train_reward_steps` (StateSet trainers via the attached reward
  history, TRL via `log_history`), and both `benchmarks/shootout.py` and
  `benchmarks/framework_comparison.py` reject a run whose training reward was
  identically zero at every step.

## [0.52.0] - 2026-09-08 — On-policy engine rollouts, proven live

### Added

- `VLLMGenerator` finds the engine's in-process model through any vLLM
  layout (breadth-first over the attribute names V0/V1 have used, recorded as
  `engine_model_path`); `VLLMConfig.in_process_weight_sync` (default on)
  keeps the V1 engine core in-process so `sync_weights` can reach it;
  `VLLMGenerator.token_logprobs_for_ids` reports the engine's current
  log-probs of given token ids. `benchmarks/vllm_rollout_check.py` proves the
  loop live on a GPU: engine rollouts, real GRPO token-path steps with
  sampler-corrected ratios, the engine-vs-policy gap before the step, after
  it (stale), and after `sync_weights`, with a pass/fail verdict.

- Engine rollouts stay on-policy: both GRPO trainers call
  `MultiTurnAgent.sync_rollout_backend()` after every optimizer step
  (`TrainingConfig.rollout_sync`), which pushes the policy's weights into the
  attached rollout backend's `sync_weights(model)` hook.
  `VLLMGenerator.sync_weights` merges a PEFT adapter for the read, strips
  wrapper prefixes, and streams weights into the engine's `load_weights`
  (`weight_loader` adapts unfamiliar engine layouts). Turns record
  `rollout_backend_version` and `rollout_backend_stale`; a backend that cannot
  take weights is reported once as stale instead of silently sampling from an
  old policy.
- `TrainingConfig.old_logprobs_source="sampler"` makes the GRPO token path use
  the log-probs recorded at sampling time as the old policy, so the importance
  ratio corrects for a stale or numerically different rollout engine; the loss
  dict reports `old_logprobs_source` (`recompute`, `sampler`, `snapshot`).

### Changed

- `benchmarks/shootout.py` streams each run's stdout/stderr into its run
  directory while the run is in progress and prints a flushed, timestamped
  line per run start/finish; `benchmarks/runpod_shootout.py` runs the remote
  shootout unbuffered and prints a status line per poll (elapsed, evidence
  landed, runs started, newest run output), so a paid run is observable from
  the launcher log instead of only after it exits.
- `benchmarks/runpod_shootout.py --resume` finishes a matrix cut short by
  the pod lifetime: the completed evidence files in `--output-dir` are
  uploaded first and `benchmarks/shootout.py` skips seed-and-framework pairs
  whose validated evidence is already present (accounted as `skipped`), so
  only the missing runs are paid for again.
- `benchmarks/shootout_manifest_v3.json` and its L40S launcher envelopes: the
  200-step Qwen2.5-1.5B-Instruct GSM8K protocol (800 prompts, 256-problem
  eval, three seeds, native GSPO vs direct TRL 1.9.1) and the resume envelope
  pinned to a harness that keeps `framework_version` matched across seeds.
  Each pod records its own `runpod-provider[-n].json`, and a resumed download
  moves the earlier pod's `runs/` and `_accounting/` aside instead of
  replacing them.
- The `npm-publish` job now says exactly why `@stateset/agents` cannot be
  published by trusted publishing (the package does not exist on the
  registry yet; the first version needs an npm automation token) instead of a
  generic 404.

### Fixed

- `from stateset_agents.training import train` returned the
  `stateset_agents.training.train` *module* once anything had imported that
  submodule (the API service and CLI do), failing with "'module' object is not
  callable". The package now keeps the public `train()` export when importlib
  binds the submodule; the module stays reachable by its dotted path.

## [0.51.0] - 2026-09-08 — Evidence-safe benchmarking and engine rollouts

### Added

- `MultiTurnAgent.set_rollout_backend(engine)`: route generation through any
  engine exposing `generate_with_logprobs` (e.g. `VLLMGenerator`); turns carry
  the engine's exact token ids and per-token log-probs for the GRPO per-token
  path, with fallback to native generation on engine failure.
- `benchmarks/runpod_shootout.py` runs the remote shootout detached and
  downloads every finished seed-and-framework evidence file incrementally, so
  a dropped launcher session cannot lose completed runs.

- Retained the validated 48-step three-seed A40 comparison of StateSet's
  TRL-backed GRPO, native GSPO, and direct TRL (`benchmark_results/framework_comparison_v2/`):
  throughput parity, no learning-quality signal at 0.5B/48 steps.
- `benchmarks/framework_comparison.py` skips launcher provider and accounting
  records (by `kind`) when validating an evidence directory.

### Changed

- Import-time module stubs in the test suite are scoped to the file that
  installs them (`tests/_module_stubs.py` plus an autouse fixture), removing
  cross-file leakage of fake `vllm`, `trl`, and `peft` modules.

## [0.50.0] - 2026-09-05 — Per-token GRPO and starter specs

### Changed

- The twelve packaged model-family starters (`training/*_starter.py`) are
  now built from one `StarterSpec` each by `training/starter_factory.py`
  instead of ~400 hand-written lines apiece (5,067 → ~2,000 lines). Every
  public constant, function, config dataclass (name, field order, defaults),
  and family-specific validation rule is unchanged; a contract test
  (`tests/unit/test_starter_factory.py`) pins the per-family surface, and
  adding a starter is now a spec plus its validation rules.

### Added

- Per-token GRPO: `MultiTurnAgent.generate_turn` returns the assistant turn
  with the exact prompt token ids, sampled response ids, and the model's
  log-probs of those ids; both GRPO trainers request turns; and
  `compute_grpo_loss` / `compute_enhanced_grpo_loss` take a batched token
  path (one padded forward per group, per-token ratios, any token-level
  objective preset, k3 KL and entropy on the same logits) when a group carries
  token metadata, falling back to the sequence-level path otherwise
  (`docs/OBJECTIVES.md`). Previously the GRPO trainers recorded no log-probs
  and therefore trained as unclipped REINFORCE on re-tokenised text.
- `TrainingConfig.num_gradient_updates` (default 1) on the GRPO trainers'
  token path: PPO/DAPO-style inner updates against the frozen old-policy
  log-probs (`loss_computation.compute_token_old_logprobs`), so the trust
  region engages from the second update; metrics report `inner_updates`,
  `ratio_mean`, `ratio_mean_last`, and `clip_fraction`. Reviewed additive v1
  API contract change (one appended keyword parameter).

## [0.49.0] - 2026-09-05 — Declarative policy objectives

### Added

- `stateset_agents.training.objectives`: a declarative, frozen
  `PolicyObjective` (advantage × ratio × clip × aggregation × KL) with eleven
  presets (`grpo`, `dr_grpo`, `bnpo`, `dapo`, `gspo`, `gspo_token`, `gepo`,
  `rloo`, `reinforce_pp_baseline`, `cispo`, `ppo`) and the pure functions
  `compute_advantages` and `policy_loss`, exported lazily from
  `stateset_agents.training`. Verified three ways: explicit-loop references,
  Hypothesis property tests, and a numeric pin against TRL 1.12's GRPO loss
  (`docs/OBJECTIVES.md`).
- Golden regression pins for every native trainer's objective
  (`scripts/capture_objective_goldens.py`, `tests/unit/test_objective_goldens.py`).
- Objective selection: `TrainingConfig.objective` (a preset name) and
  `objective_overrides` are honoured by DAPO, VAPO, GSPO, GSPO-token, GEPO,
  PPO, and the GRPO trainers via `objectives.resolve_objective`, including the
  preset's advantage estimator; incompatible presets are rejected at
  construction with the compatible names. `stateset-agents train --objective`
  / `--list-objectives`, `--objective` on every per-model starter command, and
  matching `objective` fields on the starter configs.
  Reviewed additive change to the stable v1 API contract: `TrainingConfig`
  gains the two keyword parameters `objective` and `objective_overrides`
  (appended, defaults `None`; `contracts/public_api_v1.json` regenerated).

### Changed

- DAPO, VAPO, GSPO, GSPO-token, GEPO, PPO, and GRPO (plain and enhanced)
  trainers evaluate their objective through `objectives.policy_loss`.
  Numerics are unchanged except as listed below; `DAPOTrainer` gains
  `compute_dapo_loss_from_log_probs`, and `GSPOTrainer`, `GSPOTokenTrainer`,
  and `GEPOTrainer` expose `compute_gspo_loss`, `compute_gspo_token_loss`,
  and `compute_gepo_loss`.
- GSPO-token reports the clipped-surrogate value as `policy_loss` (the same
  quantity GSPO reports) instead of the log-prob-weighted sum; gradients are
  unchanged and pinned.

### Fixed

- PPO's KL penalty uses the k3 estimator (the previous `log π − log π_ref`
  mean had a zero-expectation gradient and never pulled the policy toward the
  reference) and clamps the log-ratio before exponentiating. On the golden
  fixture the PPO `kl` moved from −0.0320 to +0.0060; the policy loss is
  unchanged.

## [0.48.0] - 2026-09-01 — Flagship evidence pipeline

### Added

- Added a fail-closed 7–9B flagship benchmark collector with immutable
  model/data/judge revisions, a complete three-seed roster, external timing,
  provider-derived cost ceilings, artifact hashing, paired significance, judge
  stability, and explicit non-publishable preflight evidence.

## [0.47.2] - 2026-09-01 — Distributed evidence collection

### Added

- Added a publication-grade distributed asynchronous evidence collector with
  exact topology validation, three-seed scenario rotation, independently
  measured wall time, retained failure artifacts, cost-source verification,
  and automatic enforcement of the existing 12-hour soak/fault matrix gate.

### Fixed

- Scoped npm runtime tests to the JavaScript client suite so Node 24 cannot
  execute TypeScript compile fixtures and make unintended network requests
  during tagged publication; the separate TypeScript compiler gate remains.

## [0.47.1] - 2026-09-01 — Modal production transport

### Added

- Added fail-closed publication gates for multi-node asynchronous RL and
  standard agent-quality benchmarks, including soak/fault matrices, policy and
  artifact invariants, statistical improvement, tail latency, and cost.

### Changed

- Updated npm release automation to use Node 24 and an OIDC-capable npm CLI,
  with trusted publishing preferred and a scoped-token fallback.
- Refreshed the roadmap and release-evidence ledger for v0.47.0, including the
  successful Python release and the visible npm, Fireworks, Docker, and merge
  blockers.

## [0.47.0] - 2026-08-31 — Distributed rollout control plane

### Added

- Added a transport-neutral distributed rollout control plane with renewable
  worker leases, restart generation fencing, exact policy assignments, bounded
  capacity, safe health snapshots, and explicit rejection counters.
- Added combined worker/coordinator checkpoint recovery that preserves rollout
  deduplication and generation history while dropping leases that expire during
  controller downtime.
- Added deterministic coverage for registration replacement, heartbeat renewal,
  capacity reclamation, stale/expired worker rejection, policy mismatch,
  secret-free observability, and restart behavior.
- Added an authenticated FastAPI rollout transport with principal-scoped worker
  identities, worker/admin roles, typed registration/heartbeat/submission
  routes, fleet health, stable error mapping, and strict request schemas.
- Enforced the existing `API_MAX_REQUEST_SIZE_MB` setting before body parsing
  for both fixed-length and chunked gateway requests.
- Added immutable policy artifact descriptors, streaming SHA-256 verification,
  bounded artifact history, artifact-aware checkpoint recovery, and atomic
  artifact-before-policy-version publication.
- Bound artifact-required rollout records to the SHA-256 of their assigned
  weights and exposed the exact URI, digest, size, and publication timestamp in
  authenticated registration and heartbeat responses.

### Changed

- Clarified the async evidence boundary: the distributed safety contract and
  HTTP transport are implemented, while retained multi-node GPU throughput,
  measured weight-sync, process-recovery, and soak evidence remain pending.

## [0.46.0] - 2026-08-31 — Policy-safe asynchronous RL runtime

### Added

- Added a native policy-versioned asynchronous rollout coordinator with
  bounded backpressure, explicit staleness eviction, rollout deduplication,
  restart-safe state, auditable counters, and log-space importance correction.
- Added a failure-safe multi-producer/serialized-learner runtime with ordered
  policy publication, bounded collection and shutdown, worker failure
  propagation, validated learner metrics, and deterministic run evidence.
- Added comprehensive behavioral tests and documentation covering queue
  invariants, checkpoint restore, cancellation, publication ordering, and
  cancellation-resistant producers.

### Changed

- Updated framework comparisons, backend documentation, and the roadmap to
  distinguish the proven in-process async runtime from pending multi-node GPU
  throughput and recovery evidence.

## [0.45.0] - 2026-08-31 — Managed training provider expansion

### Added

- Added Tinker remote-autograd SFT with first-class Inkling-Small catalog
  coverage and hosted sampler/training-state artifacts.
- Added Prime Intellect Lab RL config and CLI execution for verifiers/OpenEnv
  environments, Hugging Face GPU Jobs and Inference Endpoints, and Together AI
  managed fine-tuning.
- Added all four providers to capability discovery, credential-aware canaries,
  optional dependency groups, CLI mode/provider options, documentation, and
  deterministic lifecycle tests.

## [0.44.0] - 2026-08-31 — CoreWeave and Nebius cloud providers

### Added

- Added first-class CoreWeave CKS and Nebius Serverless AI remote SFT
  executors with durable handles, S3-compatible artifact transport, secret
  references, cancellation, cleanup, and non-billable authentication canaries.
- Added a provider-neutral managed-inference lifecycle plus CoreWeave
  Dedicated Inference and Nebius endpoint adapters, CLI deploy/status/delete
  commands, provider guides, and an approval-gated live certification workflow.
- Added a dependency-free, strictly typed `@stateset/agents` Node.js client
  for Messages, OpenAI-compatible chat completions, model discovery, health,
  and SSE streaming, with runtime, declaration, and package-contract tests.
- Added npm testing and provenance publication to CI and tagged releases.

### Changed

- Made GitHub Release creation repository-explicit so artifact-only jobs no
  longer fail from the absence of a checked-out `.git` directory.
- Added a tested, project-scoped PyPI token fallback while trusted-publisher
  configuration remains unavailable, and synchronized Python/npm version bumps.

## [0.43.0] - 2026-08-31 — Model and provider certification

### Added

- Added a machine-readable, tiered model catalog with explicit certification
  stages and measured-versus-estimated RunPod resource recommendations.
- Added a genuinely non-billable `train-remote --plan-only` path and
  approval-gated live workflows for frontier models, Modal transport, and the
  complete Fireworks train/deploy/infer/undeploy lifecycle.
- Added provider compute-model and verification metadata to capability output.

- Added durable, commit-bound GPU verification evidence with dataset, wheel,
  adapter, and evaluation hashes, measured cost and duration, confirmed
  cleanup, and a strict observed-CUDA requirement for the live RL probe.
- Added a public, versioned training-backend protocol with canonical experiment
  digests, capability negotiation, a registry, secret-free serialization, and
  a shell-free command adapter for external training engines.
- Added an executable, version-pinned OpenRLHF adapter for PPO, GRPO, and GSPO
  with strict config translation, immutable model resolution, verified dataset
  bytes, content-pinned Python reward/agent code, and reusable-artifact checks.
- Added an executable, version-pinned verl adapter for PPO and GRPO with strict
  Hydra translation, verified Parquet/reward inputs, cross-worker seed
  propagation, explicit topology/rollout selection, and forced checkpoints.
- Added an executable, version-pinned NeMo RL adapter for distributed math GRPO
  with verified JSON/JSONL data, immutable models, exact built-in reward and
  environment semantics, strict Hydra overrides, and forced checkpoints.
- Added a strict live-GPU backend conformance runner that records immutable
  manifest/experiment/artifact digests, exact NVIDIA hardware identity,
  runtime and backend versions, wall time, and non-overwriting success or
  failure evidence.
- Added a full external-backend conformance suite gate that rehashes every
  checkpoint, requires exactly one NeMo RL, OpenRLHF, and verl record, and
  rejects mixed harnesses, versions, seeds, models, algorithms, or tasks.
- Added schema-v2 conformance execution envelopes for digest-pinned images,
  exact provider/GPU topology, workload timeouts, positive spend ceilings, and
  manifest-bound failure accounting.
- Added schema-v3 conformance manifests that bind container disk and total
  billable lifetime, plus a fail-closed RunPod launcher with zero-cost catalog
  planning, explicit spend confirmation, authoritative post-allocation price
  enforcement, remote self-destruct, crash-recovery leases, cost accounting,
  and portable evidence retrieval.
- Added full-roster enforcement, one-seed preflight mode, and machine-readable
  attempt accounting to the neutral cross-framework benchmark runner.
- Added GitHub artifact attestations for tag-built Python distributions and
  automatic GitHub Releases sourced from the already verified wheel and sdist.
- Enabled maximal build provenance and SBOM generation for both published
  container images.

### Changed

- RunPod now fills omitted GPU count and disk settings from measured model
  profiles, while estimated frontier and unknown-model runs require an
  explicit cost ceiling.
- Modal now deletes every executor-created persistent Volume on success,
  dry-run completion, transport failure, or training failure, and requires an
  SDK version with the supported deletion API.
- Fireworks now automatically rolls back a newly created deployment when LoRA
  loading fails instead of leaving billing cleanup to the caller.

- Bound the live RunPod GPU verification workflow to one concurrent run,
  explicit disk/runtime/spend ceilings, authoritative price checks, and a
  remote self-destruct backstop for its custom RL pod.
- Increased RunPod API resilience to five bounded exponential attempts for
  rate limits and transient provider failures, while preserving immediate
  failure for permanent client errors and ambiguous transport failures.
- Made conformance artifact references evidence-relative and independently
  movable, and bound saved experiment digests back to their embedded manifest
  instead of validating only their hexadecimal shape.
- Made conformance runs reject GPU topology and CLI/manifest timeout drift
  before invoking an external engine, while keeping live provider price
  enforcement an explicit launcher responsibility.
- The framework shootout now continues after individual adapter failures,
  retains every outcome, and returns failure only after attempting the
  remaining framework/seed matrix.
- Updated competitive positioning to reflect current multi-turn and tool-use
  support in TRL, verl, NeMo RL, and OpenRLHF without claiming unmeasured wins.
- Upgraded GitHub-maintained workflow actions to their current Node-runtime
  majors and added regression coverage preventing deprecated action pins from
  returning.
- Made tag pushes the single production publication event so publishing the
  generated GitHub Release cannot launch a duplicate package release.

## [0.42.6] - 2026-08-27 — Cross-platform release hardening

### Changed

- Raised the enforced coverage floor from 61% to a stable 61.9% cross-version
  baseline and added targeted coverage for remote jobs, ledgers, generated CLI
  presets, release policy, and River submission artifacts.
- Pinned the GSM8K loader to its validated immutable dataset revision and
  rejected mutable or malformed revision identifiers.
- Stabilized the development and API dependency surfaces with explicit
  pytest-timeout, PyJWT, and isort constraints.

### Fixed

- Made the full test suite portable across Linux and Windows, including path
  normalization, UTF-8 subprocess capture, MCP timeout handling, executable-bit
  expectations, and a training-router test that could repeatedly kill and
  recycle Windows workers by starting a real background training job.
- Stabilized CodeQL, W&B-optional imports, security scanning, publish readiness,
  and the Windows CI job ceiling. The final pull-request matrix passed on Python
  3.10–3.13 and Windows 3.10/3.13 with every security and release gate green.

### Security

- Updated `cryptography` to 50.0.1, `pyo3`/`numpy` to 0.29, Prometheus to
  0.14 with protobuf 3.7.2, and the affected `h2`, `bytes`, `rand`, `anyhow`,
  `chacha20`, and `crossbeam-epoch` lock entries. RustSec audits now report
  zero vulnerabilities for both Rust workspaces.
- Replaced raw API-key identifiers in rate-limit state with domain-separated
  fingerprints and constant-time WebSocket credential comparisons.
- Streamed RunPod self-destruct credentials directly into root-only remote
  files, removed them before teardown requests, and avoided plaintext local
  staging files.

## [0.42.5] - 2026-08-27 — Five-algorithm live evidence

### Added

- Added a fail-closed five-algorithm shootout orchestrator and ready-to-run
  GRPO/GSPO/DAPO/VAPO/GEPO manifest with rotated seed order, shared and
  objective-specific config attestations, exact completion counting, external
  wall time, normalized policy hashing, and strict hardware provenance.

### Fixed

- Phase-0 now executes VAPO and GEPO, applies the declared shared protocol to
  DAPO and GSPO, supplies DAPO/VAPO correctness verifiers, preserves native
  checkpoints while emitting one normalized policy artifact, and counts DAPO
  filtered groups plus VAPO warmup generations instead of estimating work.
- The first retained five-algorithm CUDA preflight also fixed VAPO mixed-dtype
  value-head execution and removed GEPO's unconditional W&B dependency when
  experiment logging is disabled.
- A complete three-seed CUDA attempt exposed deterministic VAPO graph-retention
  OOMs at the matched batch shape. VAPO now accumulates the same mean gradient
  prompt by prompt, releasing each forward graph before the next while keeping
  one actor/critic optimizer step per update.

## [0.42.4] - 2026-08-27 — Validated scaling and release evidence

### Added

- Added executable, provenance-complete scaling and recovery harnesses. The
  scaling publication gate requires monotonic 1/2/4/8-GPU throughput and at
  least 50% efficiency; recovery injects worker exit, controller SIGKILL, and
  a live TCP control-plane interruption with fail-safe cleanup.
- Retained a passing three-seed 1/2/4/8-GPU weak-scaling matrix on eight RTX
  5080s (`8.080×` throughput and `101.0%` efficiency at 8 GPUs) and a nine-run
  CUDA recovery matrix with zero lost or duplicate updates.
- Retained the failed fixed-global-batch strong-scaling matrix (`2.9%`
  efficiency at 8 GPUs) and scope weak-scaling claims separately.
- Added a corrected fixed-work strong-scaling mode that partitions one
  `196,608`-sample effective batch exactly across ranks. Its retained
  three-seed matrix reached `6.642×` throughput and `83.0%` efficiency at eight
  RTX 5080s; the validator recomputes work from execution shape and wall time.
- Hardened competitive framework and algorithm gates to require identical seed
  sets and CUDA environments. Framework comparisons additionally bind the
  canonical config, while repeatable required-roster flags fail closed when
  verl, NeMo RL, OpenRLHF, TRL, StateSet, or a prescribed algorithm is absent.
- Refreshed non-billable River and RunPod authentication/cleanup canaries;
  Fireworks remains explicitly skipped because credentials are unavailable.

## [0.42.3] - 2026-08-26 — Publication-grade RL evidence

- Hardened benchmark provenance and TRL interoperability: Phase 0 publication
  gates now reject synthetic evidence, unpinned source/model revisions,
  incomplete hardware/stability measurements, duplicate-seed inflation, and
  empty result sets; whitepaper packaging is strict by default; TRL GRPO now
  requires a version that actually exposes GRPO and adapts safely to its current
  `processing_class` API.
- Added an independent upstream-TRL GRPO shootout adapter, immutable GSM8K
  dataset revision support, canonical shared-config attestation, exact runtime
  framework-version checks, and a ready-to-fill three-seed shootout manifest.
- Changed the default attention backend from optional `flash_attention_2` to
  built-in PyTorch SDPA after the clean RunPod shootout exposed a default model
  load failure on images without the `flash-attn` wheel; FlashAttention remains
  available as an explicit optimization.
- Fixed the real Phase-0 baseline path to instantiate `MultiTurnAgent` instead
  of the abstract `Agent` base class, as exposed by the clean RunPod shootout.
- Fixed TRL's synchronous reward callback inside async StateSet training by
  executing reward coroutines in a worker thread when an event loop is already
  active; this removes the live `Cannot run the event loop while another loop
  is running` failure.
- Fixed the trained-agent lifecycle so TRL-produced models receive a tokenizer
  and generation configuration before post-training inference.
- Removed the upstream TRL adapter's dependency on the non-packaged `scripts`
  module, keeping the comparison path runnable from an isolated checkout.
- Fixed TRL seed propagation, short-run warmup calculation, and forwarding of
  optimizer/scheduler settings. Measured framework runs now use the declared
  seed instead of silently retaining 42 and warm up against `max_steps` rather
  than the unrelated episode-derived estimate.
- Added one shared raw-model evaluation protocol for both shootout adapters,
  preventing chat templating and stopping criteria from changing only the
  StateSet side of a framework comparison.
- Release readiness now excludes unrelated hidden agent worktrees from import
  sorting and runs pytest through the same selected Python interpreter used by
  typing and builds.

### Fixed

- Publication-facing algorithm and framework comparisons no longer generate
  simulated competitor timings, reward curves, memory figures, or subjective
  winner scores. They now fail closed unless supplied with real, matched,
  provenance-complete evidence from at least three seeds per implementation.
- Benchmark documentation no longer presents unsupported GPU scaling,
  framework-performance, or total-cost figures as measured results.

### Added

- Measured comparison schemas and validators enforce immutable model/data and
  algorithm revisions, exact hardware matching, artifact SHA-256 provenance,
  unique seeds, and explicit interpretation boundaries.
- A distributed scaling validator requires matching 1/2/4/8-GPU topology
  matrices and reports measured speedup and scaling efficiency against the
  single-GPU baseline.
- A framework-neutral shootout orchestrator rotates implementation order,
  measures wall time outside adapters, retains failure logs, hashes artifacts,
  and emits strict evidence from a shared multi-seed manifest.
- Trainer and agent configs can pin `model_revision`; the same revision now
  reaches tokenizer, policy, reference-model, vLLM rollout, and evaluation
  loading. Phase-0 can emit the neutral measured adapter result directly.
- A fault-injection evidence gate requires matching worker-exit,
  controller-restart, and network-interruption runs with exact checkpoint
  replay, no duplicate updates, bounded lost work, completion, and cleanup.
- Benchmark-smoke CI and policy tests prevent synthetic comparison claims from
  returning to publication-facing entry points.
- Retained a validated three-seed StateSet 0.42.3 versus direct TRL 1.9.1
  RunPod comparison on one NVIDIA A40. The exact four-step protocol shows
  semantic and resource parity, while its null/negative GSM8K deltas are
  explicitly retained as unsuitable for a learning-quality claim.

### Changed

- Tag, release, TestPyPI, and PyPI workflows now require the complete publish
  readiness suite and retain its coverage/security reports; readiness is no
  longer an optional non-blocking manual-dispatch step.

## [0.42.2] - 2026-08-26 — Live release evidence

### Fixed

- Scheduled and manually dispatched GPU verification now fails when the
  RunPod credential is absent instead of producing a false-green run in which
  every live step was skipped.
- The SFT and RL GPU lanes run serially so they do not race each other for the
  same scarce low-cost Community Cloud capacity.

### Changed

- Provider canaries run automatically for release tags as well as weekly and
  manual schedules, retaining River, RunPod, and Fireworks evidence with the
  exact tagged revision.
- Release evidence now records the exact source revision, default-suite result,
  live provider canaries, bounded GPU jobs, cleanup result, and external
  publication blockers without promoting partial checks into success claims.

## [0.42.1] - 2026-08-26 — Reliability and verification hardening

### Added

- `stateset-agents model-support` reports the verification level, result, and
  evidence for each newly supported model/provider path in human-readable or
  JSON form.

### Fixed

- Redis cache and rate-limit startup now fails fast when Redis is absent or
  unreachable, uses bounded operation timeouts, and closes failed connection
  pools before falling back to in-memory enforcement.
- API authentication regression tests no longer depend on blocking portal
  threads, and unauthenticated training WebSockets close portably with code
  4401 after accepting the connection.
- Synchronous health checks use an isolated executor so event-loop teardown
  cannot stall the test process.
- Release image tags and wheel examples are consistent across Helm,
  Kubernetes, and deployment documentation.

### Changed

- CI uses four deterministic pytest workers, per-test timeouts, and 30-minute
  job ceilings to prevent silent hangs from consuming the full runner window.

## [0.42.0] - 2026-08-26 — Bounded multi-GPU RunPod serving

### Added

- **Multi-GPU day-zero serving on RunPod.** `serve-remote` can start a
  provider/model-specific prebuilt vLLM image directly with `--vllm-image`,
  attach `--gpu-count N`, pass repeatable `--vllm-arg` values, and enforce a
  `--max-cost` ceiling. Direct-image pods use RunPod's injected pod-scoped key
  for their independent self-destruct; the user's account key is not copied.
- **Persistent direct-image model cache.** `serve-remote
  --network-volume-id` attaches an existing datacenter-scoped RunPod volume at
  `/workspace` and directs the Hugging Face cache there. StateSet deliberately
  does not create or delete the independently billed volume.
- **Authenticated startup diagnostics.** Direct-image pods expose a separate
  Bearer-protected endpoint containing only the final 64 KiB of the vLLM log.
  Startup failures include its token-redacted tail before pod cleanup, turning
  an opaque proxy 502 into actionable evidence.
- Direct-image watchdog and diagnostics use `python3`, the executable
  guaranteed by dedicated inference images, instead of assuming a `python`
  compatibility symlink.
- `serve-remote --ready-timeout` independently bounds model startup and log
  collection; it can be set below the on-pod `--max-hours` watchdog.

### Fixed

- RunPod provisioning failures are translated into sanitized StateSet errors;
  the CLI no longer renders a framework traceback whose locals can contain an
  ephemeral serving token.
- RunPod `costPerHr` is now treated as the effective whole-Pod rate instead of
  being multiplied by `gpu_count` a second time. A live 4x H100 run reported
  `$13.16/hr` total and confirmed the provider's field semantics.
- Base-only `serve-remote` examples now address the base model rather than the
  nonexistent `adapter` model.

### Live evidence

- A bounded Qwen3.8-Flash-Next-FP8 cold-start used the official dedicated
  vLLM image on 4x H100. The 172.78 GiB checkpoint did not become ready within
  the 25-minute SLO (HTTP 502), so no inference claim is made. StateSet
  terminated the pod immediately, verified zero remaining serve pods, and
  recorded `$5.52` spend.
- A follow-up 8-minute diagnostic run recorded `$1.77` and returned proxy 502
  before its container-side log endpoint became reachable. Two controls with
  a 0.5B model in the same image returned RunPod-level 404 for both ports after
  three minutes (`$0.04`) and ten minutes (`$0.12`), isolating image
  pull/container startup as the first unresolved bottleneck. Every cleanup
  check found zero remaining StateSet serve pods.

## [0.41.0] - 2026-08-26 — Next-model and provider evidence

### Added

- **Day-one Qwen3.8-Flash-Next support.** The unified GSPO registry now
  includes `Qwen/Qwen3.8-Flash-Next` with Gated DeltaNet and Qwen Sparse
  Attention LoRA targets verified against the official weight index, a
  `qwen38next` dependency extra, and explicit text-RL/multimodal boundaries.
- **Day-one GLM-5.3-Flash support.** The unified GSPO registry now includes
  `zai-org/GLM-5.3-Flash` with LoRA targets verified against the official
  hybrid linear/sparse-attention weight map. Shared agent, SFT, and flagship
  RL loaders recognize native multimodal conditional-generation checkpoints,
  the `glm53` extra pins the required Transformers 5.16 generation, and the
  docs keep text-only RL distinct from native image/video inference.
- **Credential-aware River, RunPod, and Fireworks canaries** plus scheduled
  provider and bounded slow/E2E workflows. Strict CI fails on missing secrets,
  provider errors, or leaked `stateset-canary-*` resources while creating no
  billable resources itself.

## [0.40.0] - 2026-08-26 — Durable remote execution and provider safety

### Added

- **A behavioural golden over every `RiverExecutor.submit` mode** —
  `tests/unit/test_river_submit_golden.py` plus `tests/unit/data/river_submit_golden.json`
  record, for 27 offline scenarios across all five submit paths, the exact SDK call
  sequence with every keyword argument, the job status, the full log list, the cost,
  every artifact written, and the ledger line. This closes a real coverage hole: the
  two multi-turn *episode* paths (`_submit_episode_rl`, `_submit_episode_harvest`)
  import `river_client.renderers` unconditionally, which no existing test stubbed, so
  neither had ever been executed by the suite.

### Fixed

- **The two River harvest modes no longer report progress differently.** Four
  behaviours had drifted apart between `_submit_harvest` and
  `_submit_episode_harvest`: the episode mode never logged what checkpoint it was
  sampling from and said nothing at all on a dry run, the single-turn mode computed
  its greedy eval score and never logged it, and `harvest_summary.json`'s `best_of`
  was integer-coerced in one mode but written raw in the other (so a spec carrying
  `best_of: "4"` produced a *string* in the artifact). All four are now aligned; the
  behavioural golden shows the change.

### Changed

- **The four River submit paths are now two implementations, not four.**
  `_submit_rl`/`_submit_episode_rl` share one `_run_rl_rounds`, and
  `_submit_harvest`/`_submit_episode_harvest` share one `_run_harvest_attempts`;
  each mode contributes only what actually differs (how to sample and grade a
  round, how to score the eval set, its labels) through a small `_RlMode` /
  `_HarvestMode` adapter. The rounds loop, the retry-with-backoff policy, the
  artifact writes and the failure/ledger handling now exist once each — which is
  the point, since the four drift bugs fixed above were all caused by them
  existing twice. Behaviour is unchanged, proven by the golden.

- **`stateset_agents/training/__init__.py` shrunk from 1679 to 144 lines** — the
  ~1200-line lazy-export string map now lives in `stateset_agents/training/_registry.py`
  as the plain data constants `OPTIONAL_EXPORTS` and `PUBLIC_NAMES`. Public surface,
  `__all__`, `TRL_AVAILABLE` and the submodule fallback are unchanged; new meta-tests
  in `tests/unit/test_training_lazy_exports.py` keep the registry and `__all__` from drifting.

- **`stateset_agents/cli.py` shrunk from 1515 to 839 lines** — the 468-line `init`
  scaffolding wizard and the 208-line `evaluate` command moved into
  `stateset_agents/cli_init.py` and `stateset_agents/cli_evaluate.py`, following the
  existing `cli_*.py` sibling pattern. `init`'s ten near-identical per-preset branches
  are now one `STARTER_PRESETS` table. Command names, flags, help text and every
  emitted message are unchanged: `init --help`, `evaluate --help` and the root
  `--help` listing are byte-identical, as is the output of all 12 presets × 2 formats.

## [0.39.0] - 2026-08-25 — Real trust regions, no silent NaNs, CI that tells the truth

### Added

- **`num_gradient_updates` on the GEPO and VAPO configs** (default `1`).
  With the default the on-policy path computes exactly the same formula as
  before; opting into more than one update per rollout batch genuinely
  changes the dynamics, because the importance ratios are no longer
  identically 1.

- **`logprob_dtype` on the DAPO and VAPO configs** (`"bf16"` / `"fp16"` /
  `"fp32"`, default unchanged) — controls the precision of the log-softmax
  in the token log-prob gather, which is the memory peak of the step.

- **`response_mask` argument on `VAPOTrainer.compute_token_log_probs`**
  (default `None` = previous whole-sequence behaviour). Passing the
  response mask scores only response positions, which is both what the loss
  wants and materially cheaper on long prompts.

- **`tests/unit/test_docs_version_freshness.py`** — every
  `stateset_agents-<ver>-py3-none-any.whl` mention under `docs/` and
  `README.md` must name the current package version. `scripts/release.py`
  rewrites the files in `PLAIN_FILES` on release; this test is the tripwire
  for anything that drifts anyway. Lines and files marked
  `<!-- historical: do not bump -->` are exempt (run logs record the wheel
  that was actually used).

### Fixed

- **GEPO and VAPO had no trust region at all.** Both trainers recomputed
  their "old" log-probs from the *current* model inside the same step, so
  the importance ratio was identically 1 and clipping could never fire.
  They now snapshot the sampler's log-probs (and VAPO's value estimates) at
  rollout time and use those as the old policy. Scheduler and `global_step`
  cadence is now identical across DAPO, GEPO and VAPO.

- **Silent NaN steps from `exp` overflow.** Every per-token and
  per-sequence importance ratio now goes through
  `rl_losses.safe_exp_ratio`, which clamps the log-ratio to `±20` (GEPO
  uses `±30`) before `exp` — `exp(88)` overflows to `inf` in fp32 and one
  `inf` poisons every gradient in the batch. Note the clamp zeroes the
  gradient outside its bounds *including on the unclipped branch*; samples
  that far outside the trust region contribute no signal by design.

- **`0 * inf` in the GSPO-token trust-region gate.** The gate now selects
  between the two branches with `torch.where` instead of multiplying by a
  0/1 mask, so a non-finite masked-out branch can no longer produce NaN.

- **`GSPOTrainer.compute_group_advantages` on degenerate groups.** A group
  with zero reward variance returned NaN advantages; it now returns zeros
  and reports `std_reward: 0.0`.

- **`rl_losses.gather_token_logprobs` builds its mask in fp32**, so masked
  token counts are exact rather than accumulated in a low-precision dtype.

- **Benchmarks were silently not running in CI.** `pytest-benchmark` is
  incompatible with the repo's xdist default and was being skipped
  wholesale; the benchmark job now runs with `-n0` and collects real
  numbers again.

### Changed

- **The PyPI upload is its own `pypi-publish` job.** `docker-publish` and
  `docs-publish` depend on `publish` (build + twine check) only, so the
  standing PyPI trusted-publisher misconfiguration can no longer block a
  Docker or docs release.

- **Coverage floor raised to 61** (`fail_under`, measured 61.62%).

- **bandit skips B614 globally.** Flagging every individual
  `torch.save`/`torch.load` call site is noise: the real control is
  `core/checkpoint_io.py` plus the AST guard in
  `tests/unit/test_checkpoint_trust.py`, which asserts no module bypasses
  that loader. `pyproject.toml`'s `[tool.bandit]` is the single bandit
  config (pre-commit and the Makefile both pass `-c pyproject.toml`).

- **`docs/FLYWHEEL_EXPERIMENT.md` is treated as a historical run log** —
  removed from `release.py`'s `PLAIN_FILES` and exempted from the freshness
  test, since rewriting the wheel it actually ran on every release would
  make the record false.

- **The starter-script tests stopped spawning 30 interpreters.** Ten
  `test_script_is_a_forwarder` tests each burned ~9 s proving, via a real
  `python examples/finetune_<model>_gspo.py --dry-run`, a property that is
  purely structural. They now read it out of the AST
  (`tests/unit/forwarder_asserts.py`): the script must import the unified
  driver's `main`, print a notice naming itself and its preset to stderr, and
  end — as its last top-level statement — in
  `sys.exit(main(["--model", <preset>, *sys.argv[1:]]))`. The helper
  has its own tests proving it rejects a non-forwarder, a wrong preset, a
  silent shim, and one that swallows the caller's flags.

  The remaining subprocess dry-runs keep exactly one real spawn per starter
  script — enough to catch import-path and argv breakage a fresh process
  would see — and the duplicates are marked `slow` (deselected by default,
  run with `-m slow`). Their assertions about profile values were already
  covered in-process.

### Removed

- **Two dead modules.** `utils/advanced_dashboard.py` (464 lines) and
  `api/services/request_batcher.py` (162 lines) had zero references anywhere
  in the package, tests, or examples — neither was exported, imported, or
  reachable. Deleted, along with their Sphinx `automodule` stanzas. The
  supported monitoring surface is `utils/monitoring.py`.

- **The two bottom-of-file imports in `core/agent.py`.** The re-exports they
  fed are now served lazily by a module-level `__getattr__`, so the module
  no longer depends on import order to load. `test_layering.py` enforces the
  rule for everything under `core/`, including imports hidden in top-level
  `if`/`try` bodies.

- `GSPOTokenTrainer.mask_prompt_tokens` — the token-level loss now builds its
  response mask inline and hands it to `rl_losses.gather_token_logprobs`, so
  the helper had no production callers. Its shifted-index semantics
  (first response token at `max(prompt_length - 1, 0)`) are unchanged.

- `docs/IMPROVEMENTS_TO_10.md` — a superseded aspiration list whose items
  either shipped or were re-scoped; the live roadmap is the changelog.

## [0.38.0] - 2026-08-25 — One loss spine, trusted checkpoints, torch-free doors — the hardening release

### Added

- **Shared RL loss primitives (`training/rl_losses.py`).** One place where
  the policy-gradient maths lives: masked mean, per-token log-prob gather,
  sequence ratios, the clipped surrogate, clip fraction, the k3 KL
  estimator, and NaN-safe group advantages. GSPO, GRPO, DAPO, GEPO and
  VAPO now call into it instead of each re-deriving the same expressions
  slightly differently — which is how the four bugs below were found.

- **NSR verifier reward (`rewards/nsr_verifier.py`).** Grade a response by
  whether a neuro-symbolic verifier can actually *prove* it, not by whether
  it reads well. Registered as an improve-loop reward, so
  `stateset-agents improve run --reward nsr` curates on machine-checkable
  correctness.

- **`python -m stateset_agents` runs the CLI.** A `__main__.py` mirroring
  the console-script entry point, for environments where the script isn't
  on `PATH`.

- **The README's own commands are now tested.** Every
  `stateset-agents ...` snippet in `README.md` and `QUICKSTART.md` is
  executed as `--help` against the real parser, and each flag it uses must
  exist — including a check that boolean toggles aren't handed a value.
  It caught one broken example on its first run.

- **The suite runs in parallel by default** (`pytest-xdist`, `-n auto`),
  with a regression guard that a plain `pytest` still exits cleanly.


- **Fireworks AI provider (`train-remote --provider fireworks`).** A fifth
  compute provider, and the first managed fine-tuning service with a
  genuinely asynchronous job: upload dataset -> create supervised
  fine-tuning job -> poll -> the tuned LoRA addon lives on Fireworks, with
  the weights downloaded locally when the account allows it (the pointer's
  `weights_downloaded` says which happened, so no run claims a
  `serve --checkpoint` that would fail). `--deploy` additionally rents
  on-demand hardware and loads the addon onto it, printing an
  OpenAI-compatible base URL; `stateset-agents undeploy` tears it down,
  because it bills until deleted. Machine-shaped spec fields are ignored
  with a log line rather than rejected, so the same spec still runs
  anywhere. Costs come from Fireworks' own `estimatedCost` or are recorded
  as `null` — never a guessed zero. Written against the real `fireworks-ai`
  1.x SDK but **not yet live-verified**; the assumptions most likely to be
  wrong, each with its symptom, are in `docs/FIREWORKS_PROVIDER.md`.

- **Multi-turn RL, live — and the wall confirmed from the second
  direction.** Episode-level RL (rollouts capturing per-turn prompt ids
  and sampler logprobs; shaped episode rewards; group-relative advantages
  broadcast across every assistant turn; clipped-IS training) ran its
  first real campaign at the rung-5 wall: flat 9/12 across four rounds,
  mean reward pinned at 1.70/2.0, most groups zero-variance. Where
  imitation REGRESSED at this difficulty (9→7, auto-discarded), RL held
  stable; neither climbed. Verdict: a genuine 9B capability ceiling at
  five-turn/60%-refusal difficulty, now mapped by both methods — the
  honest boundary of this model on this ladder.

- **The curriculum curve, complete — including its wall.** Rung 5
  (five turns, 60% refusals): the rung-4 adapter still transferred
  (9/12 baseline) but with an 83% harvest rate the trained gen-2 scored
  7/12 and the plateau stop kept rung 4 — the correct call, made
  autonomously. Four rungs now pin the flywheel's operating regime with
  unusual precision: it lifts when harvest rates sit near ~60% with
  greedy headroom (rungs 3, 4 → both 12/12), and stalls when temperature
  success is too common to carry information (rungs 2, 5). Total cost of
  the entire five-rung curriculum study: API tokens only.

- **The ladder is a curriculum — proven by climbing it.** The
  rung-3-trained adapter transferred UPWARD: 11/12 at rung 4 (four
  turns, 50% refusals, final-turn summary of three prior actions) —
  above the untrained model's score at the easier rung 3 — and one more
  wheel-turn reached 12/12. Two rungs, two perfect scores, one
  transferable skill: train → transfer → top off → repeat, zero machines
  rented throughout.

### Changed

- **DAPO/VAPO `use_token_level_loss=False` is a per-row mean, not a sum.**
  Summing made the loss scale with sequence length, so long rollouts
  dominated the gradient for reasons unrelated to their quality.

- **Group advantages use the population standard deviation everywhere.**
  Some paths used the sample std and some the population std, which made
  otherwise-identical algorithms disagree about advantage magnitude.
  **Behaviour change:** paths that previously used the sample std (DAPO,
  GEPO) now produce advantages larger by √(G/(G−1)) — about 15% at a
  group size of 4 — which is an effective learning-rate change.

- **`gather_token_logprobs` computes its log-softmax in fp32.** Better
  numerics than a bf16 softmax, at the cost of a full-vocab fp32 tensor:
  peak memory rises for large-vocab bf16 models in DAPO/VAPO. Pass
  `dtype=torch.bfloat16` to get the old memory profile back.

- **The five `Planning*` names moved to
  `stateset_agents.experimental.long_term_planning`** and were removed from
  `stateset_agents.__all__`, so `from stateset_agents import *` no longer
  provides them. An explicit `from stateset_agents import PlanningConfig`
  still works for one release, now with a `DeprecationWarning`.

- **On-disk checkpoint `config` is a plain dict.** Checkpoints no longer
  carry pickled config objects, which is what makes the `weights_only`
  load below possible without losing information.

- `create_gspo_trainer(**kwargs)` now builds the canonical `GSPOConfig`
  (no `gamma`).
- `stateset_agents.core.TrainingConfig` now resolves to
  `training.config.TrainingConfig`.

### Fixed

- **GSPO: the k3 KL penalty and the clip gate for GSPO-token.**
  (`training/gspo_trainer.py`) The KL term used a naive estimator and
  GSPO-token clipped on the wrong quantity, so the trust region wasn't the
  one the algorithm describes.

- **GRPO: removed a 1/L² length bias, and the clip now actually binds.**
  (`training/loss_computation.py`) Normalising twice by length quietly
  penalised long completions. The clip is now taken on the per-token-mean
  *sequence* ratio against `seq_clip_ratio` — a fixed ±3e-4 bound that does
  **not** scale with sequence length. **Behaviour change:** for GRPO runs
  that supply `log_probs`, the clip was previously never active and now
  binds, so effective step sizes shrink; retune the learning rate.
  `clip_ratio` no longer sets the GRPO bound — its value is only an
  on/off switch for whether clipping happens at all.

- **DAPO/GEPO produced NaN on a group of size 1.** (`training/dapo_trainer.py`,
  `training/gepo_trainer.py`, `training/vapo_trainer.py`) A zero-variance group divided by zero;
  advantages are now NaN-safe.

- **`DistributedGRPOTrainer` was a 0.0-loss placeholder.**
  (`training/distributed_trainer.py`) It computed a real GRPO loss for a
  release, then was deprecated rather than left to look like working
  distributed training — and it no longer fabricates training data.

- **`stateset-agents chat --help` takes ~0.6 s instead of ~3 s.**
  (`stateset_agents/cli.py`) `stateset_agents.data` and
  `sentence_transformers` are imported lazily, so asking the CLI a
  question no longer loads an embedding stack.

### Security

- **Checkpoint loads are `weights_only=True`, with `trusted=True` as the
  explicit opt-in** (`core/checkpoint_io.py`). Loading a checkpoint used to
  mean executing whatever it contained; the shared helper now refuses
  arbitrary pickles by default, and a trusted load is a deliberate,
  greppable choice. An AST guard keeps new `torch.load` calls from
  regressing past it.

- **`SECURITY.md` states the real trust boundaries** — which inputs are
  assumed hostile (checkpoints, datasets, transcripts) and which are not —
  alongside an accurate supported-versions table.

## [0.37.0] - 2026-08-19 — Rent wisdom, deploy cheap — distillation, the rarity thermostat, and verified tool use

### Added

- **Unchecked turns are not unconstrained — a new failure mode, found and
  fenced.** Live: episode turns carrying no tool requirement emitted
  invented tools and malformed multi-object json; 113 such episodes were
  harvested (59% — the rarity controller working perfectly) and the model
  trained on them stopped emitting valid actions entirely (5/12 → 0/12
  greedy). Episodes now declare `known_tools`, and **any** json block that
  fails to parse or names an unknown tool fails the whole episode. The
  harvest must reject junk in dimensions the per-turn checks don't cover.
  **Verified by rerun**: the same starting model held 5/12 instead of
  collapsing to 0/12, with the harvest tightening to 51% clean episodes
  — the degradation is fixed, and the loop honestly plateau-stopped
  rather than claiming a win it didn't earn.
- **Rarity controller live-verified**: `--target-harvest-rate 0.6` probed
  three temperatures, chose 0.7, and the harvest landed at 59%.
- **Tool verification live-verified**: a ladder-trained 9B scored 5/12 on
  tool-gated episodes — prose claiming an action never passes.

### Added

- **Distillation breaks walls self-training cannot: 9/12 → 11/12.**
  `flywheel --teacher-base-model/--teacher-adapter`: a FIXED teacher
  harvests, the student trains on its successes, and the student's evals
  drive the stops. Live: the 9B that walled at 9/12 under both its own
  SFT and RL reached 11/12 in one generation on the 35B teacher's 97%
  harvest — patterns the student never samples at any temperature,
  bought once at big-model prices, owned forever at small-model cost.
  Gen-2 (9/12, seed variance) honestly discarded.
- **The rarity controller** (`--target-harvest-rate`): per-generation
  temperature probes keep the harvest inside the measured ~60% operating
  window — the discovered regime as autopilot.
- **Tool-use episodes**: ladder Issues declare `{tool, args}` actions;
  training rows teach emitting fenced json blocks; episode scoring
  verifies them deterministically (parse + tool name + args subset) —
  prose claiming the action fails. The seam the NSR verifier extends.

## [0.36.1] - 2026-08-19 — The wall falls to scale — and the field guide for training with zero machines

### Added

- **The wall, cleared by scale: 2/12 → 11/12 → 12/12.** The rung-5
  difficulty that stopped the curriculum-trained 9B at 9/12 under both
  SFT and RL fell to the 35B MoE in two flywheel turns from an
  episode-naive start — including the refusal episode every smaller model
  left standing. The capacity study is complete: the ladder finds each
  model's ceiling, the flywheel drives to it, and scale moves it. The run
  also survived a full River outage mid-experiment via an auto-resuming
  serving probe, and streamed every step live through the new
  instrumentation.

## [0.36.0] - 2026-08-18 — The curriculum climbed, the wall mapped from both sides, and runs you can watch

### Added

- **Multi-turn RL, live — and the wall confirmed from the second
  direction.** Episode-level RL (rollouts capturing per-turn prompt ids
  and sampler logprobs; shaped episode rewards; group-relative advantages
  broadcast across every assistant turn; clipped-IS training) ran its
  first real campaign at the rung-5 wall: flat 9/12 across four rounds,
  mean reward pinned at 1.70/2.0, most groups zero-variance. Where
  imitation REGRESSED at this difficulty (9→7, auto-discarded), RL held
  stable; neither climbed. Verdict: a genuine 9B capability ceiling at
  five-turn/60%-refusal difficulty, now mapped by both methods — the
  honest boundary of this model on this ladder.

### Added

- **The curriculum curve, complete — including its wall.** Rung 5
  (five turns, 60% refusals): the rung-4 adapter still transferred
  (9/12 baseline) but with an 83% harvest rate the trained gen-2 scored
  7/12 and the plateau stop kept rung 4 — the correct call, made
  autonomously. Four rungs now pin the flywheel's operating regime with
  unusual precision: it lifts when harvest rates sit near ~60% with
  greedy headroom (rungs 3, 4 → both 12/12), and stalls when temperature
  success is too common to carry information (rungs 2, 5). Total cost of
  the entire five-rung curriculum study: API tokens only.

### Added

- **The ladder is a curriculum — proven by climbing it.** The
  rung-3-trained adapter transferred UPWARD: 11/12 at rung 4 (four
  turns, 50% refusals, final-turn summary of three prior actions) —
  above the untrained model's score at the easier rung 3 — and one more
  wheel-turn reached 12/12. Two rungs, two perfect scores, one
  transferable skill: train → transfer → top off → repeat, zero machines
  rented throughout.

## [0.35.1] - 2026-08-18 — The founding promise, closed: multi-turn memory trained by the flywheel, 8/12 to 12/12

### Added

- **The multi-turn ceiling-raise: 8/12 → 12/12 in one generation.**
  N-turn episode scripts (`build_episode_ladder(turns=N)`) where the
  final turn demands a summary of everything done — every earlier
  resolution token plus the never-repeated reference must reappear.
  At rung 3 (three turns, 40% refusals) the single-turn-trained 9B
  scored 8/12 with a 60% episode harvest; one flywheel turn on the 115
  passing conversations produced a **perfect 12/12** — the first
  multi-turn ceiling-raise, confirming the rarity doctrine from both
  sides (rung 2's 65%-harvest plateau, rung 3's lift).

## [0.35.0] - 2026-08-18 — Conversations enter the flywheel: multi-turn episodes, scored for carryover

### Added

- **The episode flywheel's first live run — machinery verified, doctrine
  confirmed.** On two-turn energy episodes (turn 2 never repeats the
  account reference; a third decline a remedy), the single-turn-trained
  9B already scores 9/12 greedy with a 65% episode harvest rate — and
  gen-2 trained on 93 passing conversations scored 8/12, so the loop
  plateau-stopped and kept gen-1. The honest lesson is the flywheel's own
  doctrine seen from the other side: the mechanism amplifies RARE
  successes, and a 65% harvest rate means there was little latent
  capability left to convert at this difficulty. Every new piece worked
  live: batched branch rollouts, per-turn carryover scoring, episode-wide
  forbids, multi-turn training rows, episode-aware evals — the next lift
  needs a harder rung (three-turn scripts, more refusals).

### Added

- **The multi-turn episode flywheel.** The loop now learns CONVERSATIONS:
  `build_episode_ladder` generates two-turn scripts where the user's
  second turn raises a new issue and asks for confirmation of the first
  — **without ever repeating the account reference** — so context
  carryover is objectively scored (turn 2's checks demand the reference
  from turn 1; refusal variants forbid the declined remedy across the
  whole episode). River rollouts branch best-of-N per script, batched per
  turn (a T-turn rollout costs T sample calls); passing episodes become
  multi-turn chat rows the SFT batcher already weights turn-by-turn, and
  both harvest and post-train evals speak episodes end to end.

## [0.34.2] - 2026-08-18 — Goodhart, observed: a live reward hack caught, diagnosed, and fixed by A/B

### Added

- **A reward hack, caught and fixed live — the objective/eval separation
  doing its job.** On a fresh ladder-generated domain (GreenGrid Energy,
  Qwen3.5-9B — gen-1 3/3 on held-out accounts), the RL flywheel's v1
  graded reward Goodharted: mean reward climbed 0.67 → 0.84 while the
  all-or-nothing greedy eval FELL 6/12 → 4/12, the failure anatomy
  showing the exploit exactly — resolve one issue confidently, drop the
  rest, because partial credit out-earned rare full passes. A +1.0
  completeness bonus (full pass strictly dominant) fixed the collapse on
  an immediate A/B rerun from the same checkpoint: 6/12 → 7/12 by round
  4, mean reward 1.48/2.0, no degenerate policy. Both trajectories are
  retained in the `rl_report.json` files; the incident lives in the
  reward function's docstring.

## [0.34.1] - 2026-08-18 — RL verified, honestly: parity with SFT on the refusal ladder, zero infrastructure

### Added

- **The RL flywheel is live-verified — with an honest verdict.** First
  real run (35B MoE, depth-3 refusal kit, zero infrastructure): 7/12 →
  10/12 by round 1, mean graded reward monotone 0.72 → 0.89 across 4
  rounds. The head-to-head on the identical kit from the identical start:
  SFT on the 171-row harvest reached 11/12. So RL works and optimizes its
  objective, but with untuned knobs it lands at rough parity, not
  superiority — and BOTH methods retain exactly one refusal violation.
  The ladder's rung-2 result stands as its own headline: the
  depth-2-perfect model scored 7/12 at depth-3 + refusals, and one SFT
  wheel-turn restored 11/12. Harvest now retries River transients like
  training does (a live outage killed a finished generation's run).

## [0.34.0] - 2026-08-18 — Difficulty as a parameter, and RL joins the flywheel

### Added

- **The RL flywheel: `flywheel --algorithm cispo` — GRPO-style RL with
  zero infrastructure.** Instead of imitating harvest winners, each round
  samples best-of-N per prompt through River, grades EVERY sample
  (fraction of expected resolutions, minus a full point for violating a
  refusal), computes group-relative advantages, and trains with River's
  clipped importance-sampling losses on their own sampler logprobs
  (never recomputed) in their pre-shifted RL datum layout. Failures push
  probability mass away instead of being discarded; zero-variance groups
  are skipped as pure waste. Per-round greedy eval trajectory lands in
  `rl_report.json`; the final checkpoint and sft-shaped
  `eval_results.json` drop out like any other run.

### Added

- **The eval difficulty ladder** (`stateset_agents.training.eval_ladder`,
  `python -m ... --spec domain.json --depth 3 --refusal-fraction 0.5`).
  A 35B MoE saturated the hand-written depth-2 compound eval in one
  flywheel turn — from that point it measured nothing. Difficulty is now
  a parameter: a declarative `DomainSpec` (issues with phrasings,
  canonical resolutions, proof tokens) generates train/harvest/eval kits
  at any compound depth, with **refusal prompts** — the user raises one
  more issue but declines its remedy, whose proof token becomes a
  `forbid`. That punishes template-spraying, the reward-hack that
  resolution-token checks otherwise invite. Deterministic per seed,
  disjoint eval/harvest references, same `{prompt, expect, forbid}` shape
  every consumer already speaks.

## [0.33.1] - 2026-08-18 — First perfect score: the 35B MoE maxes the eval in one wheel-turn

### Added

- **First perfect score: 7/12 → 12/12 in ONE generation.** A new domain
  (Starlight Travel concierge) on a new model class — Qwen3.6-35B-A3B-FP8,
  a mixture-of-experts — trained and flywheeled entirely through River
  with zero machines rented: gen-1 persona training passed 3/3 held-out
  bookings verbatim, and one wheel-turn on compound requests (harvest
  177/240) hit 12/12, firing the perfect-score stopping rule in the wild
  for the first time. Fourth model/substrate/domain combination for the
  ceiling-raise; the mechanism's strength scales with the model.

## [0.33.0] - 2026-08-18 — Nothing rented, nothing unverified: the zero-infrastructure flywheel and self-verifying serving

### Added

- **`serve-remote --merge` live-verified: hybrid fine-tunes actually
  serve now.** The merged Qwen3.5-0.8B + TechNest adapter answered greedy
  training-format tickets in full persona over the RunPod proxy — the
  capability the DISPROVEN row documented is restored through merging.
  Six live attempts found five real defects, each now fixed with tests:
  the release wheel predating the merge module, vLLM's deps clobbered by
  the training-stack install (merge now runs in an isolated venv),
  missing processor artifacts for composite checkpoints, the composite
  loaded as its text extraction (config `architectures: None` — vLLM
  guessed and died), and text-trained adapter keys silently no-opping on
  the composite (probe delta exactly 0.0; keys are remapped, measured
  372/372 with real deltas). RunPod REST 5xx flakes now retry instead of
  killing runs, and readiness-failure evidence tails the engine's ERROR
  block instead of decapitating it.

### Added

- **The zero-infrastructure flywheel: `flywheel --provider river`.** The
  harvest step now runs entirely through River's sampling API — create a
  model from the previous generation's `river://` checkpoint, sample
  best-of-N in-session, filter by checks, write the same
  `harvest.jsonl`/`harvest_summary.json` the pod harvest writes — and
  training scores itself greedily in-session, writing `eval_results.json`
  in the sft shape. No pods, no SSH, no disks: the whole loop is an API
  key and a laptop. `run_flywheel` cannot tell the providers apart.

### Added

- **Weekly flywheel smoke** (`.github/workflows/flywheel-smoke.yml`): one
  real turn of the wheel on rented hardware every Monday — harvest, train,
  score, verify the audit trail — so the flagship claim re-proves itself.
  Skips politely until the `RUNPOD_API_KEY` secret is configured. The
  River provider's Python ≥3.12 side-venv recipe is documented in
  `docs/RIVER_PROVIDER.md`.

### Added

- **`flywheel --repeats N` — 'reproduced' becomes a distribution.** Runs
  the whole loop N times under one shared budget and reports per-run best
  scores with min/mean/max (`flywheel_repeats_report.json`). Motivated by
  the live spread: two identical runs scored 7/12 and 11/12.

### Added

- **Judge-gated harvests — the step toward real-data flywheels.** Harvest
  prompt specs accept `judge` + `min_judge_score` (default 0.7) alongside
  or instead of `expect`/`forbid`: substring checks run first and cheap,
  then the domain-reward judge gates semantically. An unavailable judge
  REJECTS rather than waving samples through — a broken gate must not
  harvest noise with a green checkmark on it.

### Added

- **Serving is self-verifying.** After readiness, `serve-remote` probes
  every served adapter with a greedy base-vs-adapter completion through
  the live endpoint: byte-identical output — the silent no-op that once
  survived a "successful" verification — warns loudly, or fails and
  terminates the pod with `--strict`. `--merge` verifies itself the same
  way on the pod (pre-vs-post-merge greedy probe, recorded in
  `merge_probe.json`) and refuses to serve a merge with no observable
  effect. The probe is best-effort on transport, never on verdicts.

### Added

- **`serve-remote --merge` — hybrid fine-tunes now actually serve.** Folds
  the adapter into full base weights on the pod (peft `merge_and_unload`)
  and serves the merged checkpoint, sidestepping vLLM's LoRA mapping —
  which loads hybrid-Qwen3.5 adapters without error and silently serves
  the base weights (the DISPROVEN row in `docs/PROOFS.md`). The merged
  model still answers as model name `adapter`, so callers are unchanged.

## [0.32.1] - 2026-08-17 — River training effect verified: 3/3 held-out tickets from a river:// checkpoint

### Added

- **River: training effect verified, not just mechanics.** A second run
  trained the 140-row TechNest persona on Qwen3.5-9B via
  `train-remote --provider river` (3 epochs, 210 steps), and sampling the
  `river://` checkpoint answered **3/3 held-out tickets** with the exact
  canonical resolutions, the persona signature, and the ticket numbers
  echoed — the same objective standard the RunPod training path cleared.

## [0.32.0] - 2026-08-17 — The flywheel is a product: replicated ceiling-raise, River live, honest serving

### Added

- **River AI: live-verified.** `river-client` appeared on PyPI (0.6.2,
  2026-08-17, Python ≥3.12, gRPC) and the first real run worked through
  `RiverExecutor` essentially unchanged: 2 chat rows tokenized to their
  prediction-position wire contract (our blind-written shape matched
  exactly — `target_tokens` even turns out to be optional), session →
  LoRA model on Qwen/Qwen3.5-9B → training step → durable
  `river://.../sampler_weights/...` checkpoint with pointer + lineage
  manifest, and `chat_complete_from_checkpoint` answered from the
  trained weights. First contact also hardened the executor per the
  SDK's own recovery taxonomy: transient errors back off and rebuild
  the session (3 attempts), `train_step` is preferred with the
  `loss_mean` metric, auth/model errors fail fast. Notes: the SDK needs
  Python ≥3.12 (this repo runs 3.10 — use a separate venv for River
  runs), and checkpoint sampling cold-starts can exceed 5 minutes.

- **Correction, from a live A/B probe: vLLM does NOT apply LoRA adapters
  for hybrid Qwen3.5 models — it loads them without error and silently
  serves the base weights.** Greedy completions from the served adapter
  are byte-identical to the base model on training-format prompts, on an
  endpoint whose `/v1/models` listed the adapter and whose logs said
  "Loaded new LoRA adapter". The hybrid architecture's `linear_attn`
  target modules (`in_proj_qkv` etc.) never match vLLM's LoRA mapping.
  Consequences, stated plainly: v0.31.0's "serve-remote --adapter
  verified" claim holds for the transport (auth, proxy, multi-adapter
  registration, SSE streaming — all re-verified live) but NOT for the
  fine-tune's effect on hybrid models; the earlier "visibly different"
  adapter answers were sampling noise at default temperature.
  `chat-remote` (transformers+peft) remains the verified way to talk to
  hybrid fine-tunes. Standard-architecture adapters are untested in vLLM
  and now labelled as such.

- **The flywheel replicates — as a product**
  ([`docs/FLYWHEEL_DOMAIN2.md`](docs/FLYWHEEL_DOMAIN2.md)). A single
  `stateset-agents flywheel` invocation took an IT-helpdesk agent on
  Qwen3.5-0.8B from 0/12 to 6/12 to 7/12 on out-of-distribution compound
  tickets, with the harvest rate rising 5.8% → 42.7% between generations,
  for $2.60 — the headroom mechanism reproduced in a second domain, at 35×
  smaller scale, through the shipped command instead of hand-driven
  scripts. Getting there surfaced and fixed three live-only bugs (wheel
  seam, CPU-bound harvest, artifact salvage) — all in this log.

- **`stateset-agents flywheel` — the improvement loop as one unattended
  command.** Harvest the current generation's rare successes (best-of-N
  rejection sampling against objective `expect`/`forbid` checks), train the
  next generation on nothing but those, measure it, repeat — stopping on
  plateau, a dry harvest (no signal to train on), a perfect score, or when
  the next rental's worst case would break `--max-cost`. Every generation
  leaves its harvest set, summary, adapter with lineage manifest, and a
  `flywheel_report.json` with pass rates and dollars. This is
  `docs/FLYWHEEL_HEADROOM.md` (2/12 → 10/12 for $3.32) as a product. Under
  the hood: a new `job_kind="harvest"` on `RemoteJobSpec` runs
  `stateset_agents.training.harvest` through the same executors as training
  (prompts ride the dataset upload; the current adapter ships as a tarball),
  and a FAILED training job WITH eval artifacts is read as a score (10/12
  fails an all-assertions gate while being the whole point), not an error.

- **`serve-remote` grows up: multiple adapters on one endpoint, and
  `deploy`.** `--adapter` is now repeatable as `[name=]path` — each adapter
  is served under its own model name beside the base, so a champion and a
  challenger can be A/B'd through one URL by switching the `model` field.
  `stateset-agents deploy --dataset ... --base-model ...` is the
  zero-to-API story as one command: rent, train, release the hardware,
  serve the fresh adapter, print the URL and token. (Streaming rides
  vLLM's native `"stream": true`; live verification over the RunPod proxy
  is queued for the next serve run.)

## [0.31.0] - 2026-08-17 — The serve claim becomes a receipt: endpoint verified, flywheel raises a ceiling

### Added

- **`serve-remote`'s endpoint is live-verified — the platform's last unproven
  headline claim is now a receipt.** After nine failed attempts across five
  distinct failure modes, an authenticated `POST /v1/chat/completions` to
  `https://<pod-id>-8000.proxy.runpod.net` returned a real completion from
  Qwen3.5-0.8B under vLLM on a rented H100 (secure cloud), with the pod
  terminated cleanly on exit and the cost recorded. The blocking bug was in
  neither our code nor RunPod's: current flashinfer annotates with
  `array.array[int]`, a TypeError at import on the image's Python 3.11 that
  kills the vLLM engine before it listens. `serve-remote` now strips that
  annotation after the vLLM install (a no-op once flashinfer fixes it).
  The shipped CLI path is verified too — `serve-remote --adapter` brought up
  base + LoRA and both the fine-tuned adapter and the base model answered
  authenticated chat completions over the proxy URL, with the pod stopped by
  `serve-remote --stop` afterwards. Running it for real surfaced one more
  live-only bug: the self-destruct arm command's `&` backgrounded the whole
  `chmod && nohup` chain, whose subshell then held the ssh session open for
  the script's full hour — the client hung 28 minutes on `echo armed` before
  diagnosis. `(nohup ... &)` scopes the background correctly (verified at
  2.9s round-trip), stdin is redirected on every detached launch, and a test
  pins both.

- **River executor aligned to the published docs while the SDK stays
  uninstallable.** `_open_session` now prefers the docs' canonical
  `with client.session(project=...)` context manager (closing it), degrading
  through a plain `session()` return, `create_session()`, and the
  client-as-session seam. `build_sft_batch(shift_targets=False)` emits the
  docs' `cross_entropy` field shape (`input_ids` + `weights`, unshifted) so
  the one unverified assumption — who performs the causal shift — is now a
  single argument rather than an edit.

- **The flywheel raises a ceiling: 2/12 → 10/12**
  ([`docs/FLYWHEEL_HEADROOM.md`](docs/FLYWHEEL_HEADROOM.md)). On compound
  requests provably outside gen-1's training distribution (two issues per
  message; every training reply resolved exactly one), gen-1 passes 2/12 —
  it answers one issue and silently drops the other. Best-of-8 rejection
  sampling harvested gen-1's occasional successes (58/240 samples), and
  training gen-2 on only those took the same eval to **10/12, reproduced
  across two independent trainings with the same two failures** (both
  near-misses of the token whitelist, so 10/12 is a lower bound). Untuned
  base: 0/12. Cost: $3.32. Limitations are in the report — this is
  self-distillation of a latent capability, not acquisition of a new one.

### Fixed

- **A failed eval gate no longer destroys the adapter it just judged.** The
  gate deliberately fails a job *after* saving the adapter and
  `eval_results.json`, but the executor fetched artifacts only on success —
  so a failed-assertion adapter died with the pod (observed live: the 10/12
  run had to be retrained). `wait()` now attempts a best-effort fetch on
  failure too.

### Security

- **A vulnerable `mcp` pin lived in our dev lock file.** `semgrep` pulls the
  MCP SDK transitively, and every release before 1.173.0 resolves it to
  `mcp 1.23.3` — SFTY-20260716-62811, improper access control from
  insufficient session validation. It never shipped in the wheel (the `[mcp]`
  extra users install is correctly pinned `>=1.25.0`), so an ignore rule
  would have been defensible; the semgrep floor was raised to 1.173.0
  instead, which requires `mcp==1.29.0` and removes the package rather than
  annotating it. Caught by CI's `safety` hook, which installs from the lock —
  local runs passed because the developer machine had 1.29.0 already.

### Fixed

- `gym/mappers.py` returned `Any` under CI's numpy stubs after an earlier fix
  removed a cast that *this* machine's numpy called redundant. Rewritten as
  an annotated local, which satisfies both.

## [0.30.0] - 2026-08-16 — River AI provider (code complete, not live-verified)

### Added

- **River AI provider (`train-remote --provider river`), not live-verified.**
  River is a remote autograd service: you drive `forward_backward` /
  `optim_step` yourself. The valuable half of this integration is the pure
  tokenization layer (`remote/river_batches.py`) that turns our chat rows
  into River's `{input_ids, target_tokens, weights}` with prompt tokens
  weighted 0.0, plus the RL batch shape their `ppo`/`cispo` losses take —
  which is where our trainers' advantages would plug in. The SDK is not
  installable from PyPI and our account has no credits, so nothing has been
  trained; the client is injectable and every assumption (notably the causal
  target shift) is documented in one place. Probing the live API did confirm
  Bearer auth, a REST surface the docs do not mention, and the exact
  `Billing: insufficient_funds` envelope — which the executor now surfaces
  as a named, actionable error instead of a generic failure.

### Added

- **River AI provider (`train-remote --provider river`) — NOT LIVE-VERIFIED.**
  River is a remote autograd/optimizer service rather than a machine you rent:
  the training loop stays on your side and River supplies the gradients
  (`create_model` → N × `forward_backward`/`optim_step` → `save_weights`).
  `stateset_agents/remote/river_batches.py` holds the SDK-free, pure batch
  construction — prompt tokens weighted `0.0`, assistant tokens `1.0`, so loss
  is computed only on what the model should say — plus LoRA-rank (1–32) and
  base-model validation. `stateset_agents/remote/river.py` adds `RiverExecutor`
  implementing the standard provider contract, with the client and tokenizer as
  injectable seams.

  Stated plainly: **this was written from River's public documentation and has
  never been run against the live service.** No River API key was available and
  `river-client` is not installable from PyPI here, so every call name, keyword
  and response shape is an informed guess, exercised only against fakes. The
  most consequential guess is that the *caller* performs the next-token target
  shift; if River shifts internally, loss will be flat and the fix is one line.
  See `docs/RIVER_PROVIDER.md` for the full assumption list and what to check
  on the first real run.

  Because River hosts the weights, `fetch()` writes a `river_checkpoint.json`
  pointer and a lineage manifest rather than pretending to download
  safetensors, and the cost ledger records `cost_usd: null` (River bills per
  token and quotes no price) rather than a misleading `0`. Machine-shaped spec
  fields (`gpu`, `gpu_count`, `container_disk_gb`, `cloud_type`,
  `network_volume_id`) are ignored with a log line, not an error.

## [0.29.0] - 2026-08-14 — Qwen3.8-27B, fine-tuned the week it shipped

### Added

- **Qwen3.8 27B first-class starter.** `stateset-agents qwen3-8-27b` targets
  `Qwen/Qwen3.8-27B` — Alibaba's multimodal hybrid-attention model (released
  2026-08-05, Apache-2.0; 27.8B params, 64 text layers, 256K context) — with
  the standard balanced/memory/quality QLoRA profiles, `init --preset
  qwen3.8-27b`, a `qwen3.8-27b` preset in the unified finetune driver, and
  `docs/qwen3_8_starter.rst`. `Qwen/Qwen3.8-27B-FP8` is listed as a supported
  variant with a validation warning that it is inference-oriented. At ~56GB
  BF16 the checkpoint wants ~160GB of disk and an 80GB card (or
  `--gpu-count 2`). Not yet trained on hardware.

### Fixed

- **LoRA silently under-adapted hybrid linear-attention models.**
  `infer_lora_target_modules` only recognised llama/GPT-style projection
  names, so on a model like Qwen3.8-27B — whose weight map shows 432
  Mamba-style `linear_attn` tensors against just 96 standard `self_attn`
  ones — it adapted the minority attention layers and skipped the majority
  entirely, with no error to show for it. The candidate list now includes
  `in_proj_qkv`, `in_proj_a`, `in_proj_b`, `in_proj_z`, and `out_proj`. The
  existing two-pass vision exclusion is unchanged and still correct here:
  `out_proj` exists in both the text stack and the vision tower and is kept,
  while vision-only names are dropped.

### Changed

- Coverage floor 56 → 57: the ratchet fired again, this time on the work
  added since v0.27.0.

### Fixed

- Two new tests assumed POSIX path separators and failed on the Windows
  matrix (a printed `ingest` command and a lineage directory name). Both now
  compare on path components rather than on `/`.

### Fixed

- **v0.28.0 shipped with a red CI; this is the fix and the guard.** Two
  typing errors in recovered agent work (`customer_support_bench.py`,
  `gpu_verify_rl.py`) and a missing executable bit on `scripts/release.py`
  failed the full-repo type gate and every test-matrix entry — none of it
  visible to the allowlisted mypy gate or the release's guard tests. Both
  defects are fixed, and `make release` now runs `pre-commit --all-files`
  and the full-repo type check before it will tag anything: a release must
  not be able to outrun the checks CI runs on it.

## [0.28.0] - 2026-08-14 — adapter lineage, verified multi-GPU, and serve-remote's real bugs

### Fixed

- **`serve-remote`: the five-attempt mystery, solved.** Verification kept
  failing with pods that reached RUNNING and never published networking. The
  cause was ours, not RunPod's: we requested the model port as `8000/tcp` and
  waited for a TCP mapping on a public IP, but RunPod serves **http** ports
  through its proxy at `https://<pod-id>-8000.proxy.runpod.net` — no public
  IP, no mapping, ever. The port is now requested as `8000/http` and the
  endpoint URL is the proxy URL; the wait blocks only on ssh, which genuinely
  needs a TCP mapping. `create_pod` also sends `supportPublicIp`, since a
  community-cloud pod "might not have a public IP address" without it.
- **Long installs survive a dropped link.** With networking fixed, the next
  attempt reached `pip install vllm` and died when the ssh transport dropped
  mid-install. Long steps now run detached with their exit code polled from
  a marker file — the pattern already used for the vLLM server and the
  self-destruct — so a lost connection costs a poll rather than the run. A
  launch that cannot start, and a step that exits non-zero, both fail loudly
  with the remote log attached.

### Fixed

- **`chat-remote` and `serve-remote` pods now reach the cost ledger too.**
  The documentation claimed every remote pod recorded its spend; only
  training did, so `stateset-agents costs` under-reported — and serve pods,
  the ones that stay alive, were the most expensive omission. Both sessions
  now record on teardown. A serve pod reaped by its own `--max-hours`
  self-destruct records nothing (this machine never sees it end); that limit
  is documented, and `serve-remote --list` remains the live view.

### Fixed

- **`serve-remote` stops paying to wait for networking that is not coming.**
  A pod can reach RUNNING and never publish an IP or port mappings — observed
  four times against real RunPod hosts. That wait shared the (necessarily
  long) vLLM-load timeout, so such a pod billed for 30 minutes before anyone
  found out. Networking now has its own short deadline, and a pod that misses
  it is terminated and replaced with a different host, bounded by
  `max_provision_attempts`. Both pods are always terminated: a retry never
  doubles the bill.

### Added

- **Two guides written from verified runs.**
  [`docs/GETTING_STARTED_API.md`](docs/GETTING_STARTED_API.md) goes from raw
  logs to calling your own fine-tuned model over an OpenAI-compatible
  `chat/completions` or Anthropic-style `messages` endpoint;
  [`docs/RUNPOD_GUIDE.md`](docs/RUNPOD_GUIDE.md) covers renting GPUs in
  detail — the 2.5x disk rule and the exact error a too-small disk produces,
  a GPU/model sizing table, capacity behaviour, spot pricing, network
  volumes and their monthly billing hazard, multi-GPU sharding, a
  troubleshooting table mapping each failure this project actually hit to
  its fix, and a table of configurations verified on real hardware.

  Every number in both guides comes from a run that happened. Where
  something is not yet proven — `serve-remote`'s endpoint bring-up — the
  guides say so and point at the path that is.

### Changed

- **`--gpu-count` is now hardware-proven.** A 63GB checkpoint
  (`meta-models/Muse-Glimmer-30B`) trained across two 48GB L40S cards, which
  it cannot fit on singly: `Model sharded across devices: 0=24 module(s),
  1=36 module(s)`, adapter returned, $0.35, no pods left behind. The first
  attempt looked like a pass but proved nothing — capacity forced a fallback
  to cards large enough to hold the model whole, so nothing made
  `device_map="auto"` actually split it. The retry used a model too large for
  any single card available.
- **Device placement is logged.** `log_device_map_summary` now reports the
  per-device module split (and the single-device case) and returns the
  counts, so a multi-GPU run leaves permanent evidence in its own logs
  instead of depending on someone watching `nvidia-smi` at the right second.

### Added

- **Adapter provenance and lineage.** Every training run now writes
  `stateset_manifest.json` beside its adapter — base model, dataset path and
  **content hash**, hyperparameters, eval outcome, package version, and the
  adapter it descends from (`--parent-adapter`). `stateset-agents adapters`
  reads them back and reconstructs the family tree, resolving links by path
  and then by directory name so a manifest written on a rented pod still
  links up after the adapter is fetched elsewhere. Adapters trained before
  manifests existed are listed as carrying no provenance rather than hidden.

## [0.27.0] - 2026-08-13 — cost accounting, a grader that rewards resolutions, durable checkpoints

### Added

- **Cost ledger and budget ceilings.** Every remote run now appends what it
  cost — model, hardware, pod lifetime, dollars — to a per-user ledger, read
  back with `stateset-agents costs`. `train-remote --max-cost` refuses to run
  when a pod's worst case (its full `--timeout` at the provider's quoted rate)
  would exceed the ceiling, checked before any work starts; a pod the provider
  will not price is refused rather than rented. `RemoteJobResult` carries
  `duration_s`/`cost_usd`, and unknown costs stay unknown rather than
  rendering as free.

  Building this immediately caught a real defect: the unit suite had been
  writing zero-cost rows into the user's own ledger via the fake providers.
  Tests now get an isolated ledger (autouse fixture).

### Changed

- **`--network-volume-id` is now live-verified.** A durable 25GB volume was
  created, attached to a rented pod at `/workspace`, trained against, and the
  adapter fetched back — then the volume was deleted and both pods and volumes
  confirmed at zero. (It took four GPU types to find capacity in the volume's
  datacenter; the executor reported each `500` honestly and moved on.)

### Added

- **Multi-GPU pods: shard a checkpoint bigger than one card.**
  `RemoteJobSpec.gpu_count` (CLI: `--gpu-count`, RunPod `gpuCount`) rents N
  GPUs of the requested type, and the SFT job now loads the base model with
  `device_map="auto"` whenever more than one CUDA device is visible —
  accelerate shards the checkpoint across all of them, and HF `Trainer`
  treats the multi-device `hf_device_map` as model parallelism (no
  DataParallel wrap, no blanket `.to("cuda")`, which would collapse the
  shards onto `cuda:0` and OOM). Single-GPU and CPU behavior is byte-for-byte
  unchanged. Verified live on a 2x H100 80GB SECURE pod: Muse-Glimmer-30B
  (~62GB BF16) sharded across both cards, trained, and passed its eval
  assertions. DeepSeek-V4-Flash — the one starter tier never proven on
  hardware — was checked first and ruled out with numbers: 160GB of fp8/fp4
  safetensors (291B params) exceeds even a 2x H100 pod before activations,
  and quantized-expert LoRA is unsupported territory.

- **Cross-pod checkpoint resume on RunPod via network volumes.**
  `RemoteJobSpec.network_volume_id` (CLI: `--network-volume-id`) attaches an
  existing RunPod network volume at `/workspace`, so checkpoints land on
  durable storage that outlives the pod. The pod-died-mid-job retry path
  then re-runs **with `--resume`** — an interruption costs at most one
  epoch instead of the whole run (previously it always restarted from
  scratch, the documented v1 gap). Volumes are datacenter-scoped, so pod
  creation is pinned to the volume's `dataCenterId` (REST fields verified
  live: `networkVolumeId` + `volumeMountPath` + `dataCenterIds` on pod
  create; `name`/`size`/`dataCenterId` on volume create). Added
  `RunPodApi.list_network_volumes()` and `RunPodApi.get_network_volume()`.
  Behavior without a volume is unchanged. The volume is caller-managed and
  bills monthly until deleted. Verified end-to-end on live hardware
  (RTX A4000 + Qwen3.5-0.8B with a 20GB volume attached).

## [0.26.0] - 2026-08-13 — the flywheel closes — assertions, GPU-verified RL, spot pods, serve-remote

### Added

- **`serve-remote`: a persistent vLLM OpenAI-compatible endpoint on a
  RunPod pod, with cost controls.** `stateset-agents serve-remote
  --base-model X [--adapter DIR]` rents a pod (ports 22 + 8000), installs
  vLLM, loads the base model (+ LoRA adapter as served-model `adapter`),
  and prints the endpoint URL (from RunPod's port-8000 mapping), a
  generated Bearer token (vLLM `--api-key`), an example `curl`, and the
  stop command. The pod deliberately outlives the CLI, so every run arms
  an **on-pod self-destruct**: a `nohup`-ed script sleeps `--max-hours`
  (default 1.0) then calls the RunPod DELETE endpoint on its own pod id —
  it fires even if the launching machine is gone, at the documented cost
  of copying the API key to the pod (`chmod 600`). `--stop <name-or-id>`
  terminates immediately and `--list` shows serve pods with age and $/hr.
  Startup failures terminate the pod before the error propagates. New
  module `stateset_agents.remote.serve_session`; `RunPodApi.list_pods()`
  added.

- **Eval prompts can now assert, turning the post-train comparison into a
  pass/fail gate.** `--eval-prompts` file lines (and `RemoteJobSpec.
  eval_prompts` entries) may be JSON objects `{"prompt", "expect",
  "forbid", "judge", "min_judge_score"}` alongside plain prompt strings.
  `expect`/`forbid` substrings are matched case-insensitively against the
  finetuned completion; results land per-row in `eval_results.json` as
  `"checks": {"expect_hits", "forbid_hits", "passed"}`. The optional
  `judge` scores the completion with `create_domain_reward(<name>)` into
  `"judge_score"` when the reward stack is importable on the worker
  (degrading to a logged warning otherwise), and `min_judge_score` gates
  on it. When any assertion fails the job exits non-zero **after** saving
  the adapter and `eval_results.json`, so a red run never destroys the
  training artifacts. The weekly `gpu-verify` workflow now gates on
  completion content (`expect: ["number"]`), not just adapter tensors.

- **`chat-remote` transcripts close the improvement loop.** Every
  `stateset-agents chat-remote` conversation is now saved on exit (every
  exit path, aborted sessions included) as an OpenAI chat-format JSONL
  transcript — default `./chat_transcripts/chat_<timestamp>.jsonl`, tunable
  with `--save-transcript PATH`, opt out with `--no-save`. The file is
  exactly what `stateset-agents ingest --format openai --input <file>`
  accepts, so chat -> ingest -> improve -> train-remote is a flywheel; the
  command prints the next step on save. `RemoteChatSession` grew a
  client-side conversation mirror and a `transcript` property (messages +
  session metadata: base model, adapter, GPU, start time); only
  successfully answered turns are recorded, matching the on-pod history.

## [0.25.0] - 2026-08-12 — chat-remote: converse with your fine-tuned model

### Added

- **`stateset-agents chat-remote`** — an ephemeral interactive chat session
  with a fine-tuned model on a rented RunPod GPU. Rents a pod, loads the
  base model plus a local LoRA adapter there, chats over one persistent SSH
  channel (JSON-lines protocol, full multi-turn history kept on the pod),
  and **terminates the pod on every exit path** — no open ports, no idle
  billing. `--prompt` (repeatable) gives a non-interactive scripted mode
  for verification. New modules: `stateset_agents.remote.chat_session`
  (local orchestration) and `stateset_agents.remote.chat_repl` (the on-pod
  server).

## [0.24.0] - 2026-08-12 — train-remote: eval prompts, disk sizing, effective vision exclusion

### Added

- **`train-remote --container-disk-gb`** — sets the RunPod pod's container
  disk from the CLI (previously only reachable by constructing
  `RunPodExecutor(container_disk_gb=...)` in Python). Size it at roughly
  2.5x the model download; verified live where a 63GB checkpoint dies on
  the old fixed 40GB.
- **`train-remote --eval-prompts FILE`** — post-train base-vs-tuned
  comparison. A local text file of prompts (one per line); each is answered
  greedily by the base model before LoRA is applied and again by the trained
  adapter, and the pairs are written to `output_dir/eval_results.json`. The
  prompts travel inside the job spec (as `--eval-prompts-json` on the
  packaged `stateset_agents.training.sft` CLI), so remote pods need no
  second file upload. Dry runs are unaffected.

### Fixed

- **Vision-tower exclusion now actually works on real multimodal models.**
  Verified live on the published 0.23.1: peft matches `target_modules` by
  leaf name across the whole model, so skipping vision modules during
  inference was insufficient — and Muse Glimmer's `vision_adapter` /
  `vision_projection` weren't in the marker list. Inference is now two-pass
  (names existing only in non-text stacks are dropped from the list) and
  the marker set carries the names observed on the real weight map.

## [0.23.1] - 2026-08-12 — train-remote fixes verified live on Muse Glimmer 30B

### Fixed

- **`train-remote` now handles large multimodal checkpoints** — three fixes
  found by training `meta-models/Muse-Glimmer-30B` on live RunPod hardware
  (verified end-to-end on an H100 80GB: 63GB BF16 download, LoRA on the text
  stack, 258MB adapter returned, pod terminated):
  - `sft.py` falls back to `AutoModelForImageTextToText` when
    `AutoModelForCausalLM` rejects a composite multimodal architecture
    (transformers registers `muse_glimmer` only under image-text-to-text).
  - `RunPodExecutor(container_disk_gb=...)` is now configurable — the fixed
    40GB default killed the 63GB download mid-stream with an opaque HF-cache
    "File reconstruction error".
  - `TrainingArguments` construction filters kwargs against the installed
    transformers' signature — 5.x removed `warmup_ratio`, which crashed the
    job after the full model download.
  - `infer_lora_target_modules` skips vision-tower/projector modules on
    multimodal composites — their fc1/fc2 layers matched decoder-MLP names
    and were adapted despite receiving no gradient from text-only SFT.

## [0.23.0] - 2026-08-11 — Qwen3 Coder, gpt-oss, DeepSeek V4 starters

### Added

- **Three new first-class model starters** — packaged thin starter modules
  with the full standard surface (CLI command, `init --preset`,
  `examples/finetune_gspo.py` preset + thin forwarder, balanced/memory/quality
  profiles, docs, and unit/integration tests) for:
  - **Qwen3 Coder 30B A3B** (`stateset_agents/training/qwen3_coder_starter.py`,
    `stateset-agents qwen3-coder`) — `Qwen/Qwen3-Coder-30B-A3B-Instruct`,
    Alibaba's open coding MoE (30B total / ~3B active, 128 experts / 8 active,
    256K ctx, Apache-2.0). Attention-only LoRA targets: the 128-expert MoE
    MLPs are impractical LoRA targets.
  - **gpt-oss 20B** (`stateset_agents/training/gpt_oss_starter.py`,
    `stateset-agents gpt-oss`) — `openai/gpt-oss-20b`, OpenAI's open-weight
    reasoning MoE (32 experts / 4 active, 131K ctx, Apache-2.0; adjustable
    reasoning effort, harmony format). `openai/gpt-oss-120b` is listed as a
    variant with a multi-GPU validation warning. Attention-only LoRA targets
    verified against the checkpoint weight map.
  - **DeepSeek V4 Flash** (`stateset_agents/training/deepseek_v4_starter.py`,
    `stateset-agents deepseek-v4`) — `deepseek-ai/DeepSeek-V4-Flash`, a large
    MoE with MLA attention (256 routed experts / 6 active, up to 1M positions,
    MIT). Modeled on the GLM large-MoE starters: QLoRA-only, vLLM-backed
    generation, memory warnings. LoRA targets use the checkpoint's actual MLA
    projection names (`wq_a`/`wq_b`/`wkv`/`wo_a`/`wo_b`, verified against the
    safetensors weight map — llama-style `q_proj`/`k_proj`/`v_proj` do not
    exist in this architecture).

## [0.22.0] - 2026-08-11 — Architecture consolidation + Nemotron 3.5 Lightning

### Added

- **First-class Nemotron 3.5 Lightning starter** — packaged
  `stateset_agents/training/nemotron_3_5_starter.py` for
  `nvidia/NVIDIA-Nemotron-3.5-Lightning-30B-A3B-BF16` (NVIDIA's hybrid
  Mamba-2/attention/MoE open model, Aug 2026; 30B total / ~3B active params,
  256K practical context, OpenMDW-1.1), with the standard thin-starter
  surface: `stateset-agents nemotron-3-5` CLI command, `init --preset
  nemotron-3-5`, `examples/finetune_gspo.py --model nemotron-3-5` preset
  (plus the thin forwarder `examples/finetune_nemotron_3_5_gspo.py`),
  balanced/memory/quality profiles, docs (`docs/nemotron_3_5_starter.rst`),
  and unit/integration tests. LoRA targets attention plus Mamba-2
  `in_proj`/`out_proj`; presets target QLoRA post-training of the BF16
  checkpoint (the NVFP4 variant is inference-only).
- **`benchmarks/improvement_loop.py` + `make benchmark-loop`** — measurable
  benchmark of the closed improvement loop. Generates a seeded synthetic
  OpenAI-format corpus with a planted good/bad mix, runs the real
  ingest → grade → curate pipeline (`run_improve`), and reports curation
  precision/recall/F1, dataset yield, and grade distribution against the
  planted ground truth (JSON + human table). Exits non-zero below
  configurable floors (defaults `--min-precision 0.75`, `--min-recall 0.95`;
  measured 0.818 / 1.0 on the default corpus — the precision gap is the
  documented `deflection` false positive of context-free rule-based
  grading). Covered by `tests/unit/test_improvement_loop_benchmark.py`.

### Changed

- **Research modules moved to `stateset_agents.experimental`.**
  `neural_architecture_search`, `multimodal_processing`, `long_term_planning`,
  `few_shot_adaptation`, `intelligent_orchestrator` (+ `_logic`/`_models`),
  `adaptive_learning_controller`, and `multi_agent_coordination` relocated
  from `stateset_agents.core` to the new `stateset_agents.experimental`
  namespace, which carries no API-stability guarantees. The old
  `stateset_agents.core.<module>` import paths still work for one deprecation
  cycle via shims that emit a `DeprecationWarning`.

- **`dashboard/` and `mobile/` extracted to their own repositories**
  ([stateset-agents-dashboard](https://github.com/stateset/stateset-agents-dashboard),
  [stateset-agents-mobile](https://github.com/stateset/stateset-agents-mobile),
  full history preserved via `git subtree split`). They were demo clients
  with no deployment path whose lockfiles and CI repeatedly cost this repo
  maintenance (36 of the 45 security findings cleared this release came from
  `mobile/`'s lockfile). Their workflows are retired here.

- **Starter modules deduplicated onto `training/starter_common.py`.** The seven
  `*_starter.py` modules were near-verbatim copies (4,452 lines total); shared
  config-file IO, profile plumbing, preview/run scaffolding, and the
  `StarterConfigMixin` dataclass base now live in one module, and each starter
  is a thin definition layer (2,902 lines total). Public API, error strings,
  and test patch targets are unchanged — the full starter test suite passes
  unmodified. `docs/SUPPORTED_MODELS.md` documents the new thin-module pattern
  for adding starters.
- **Security workflow actually enforces.** CodeQL action v2 → v3 (v2 is
  retired and failing), dependency-review-action v3 → v4, TruffleHog pinned to
  v3.96.0, Trivy installed via its official installer (it was previously
  `pip install trivy`, which is not a real package, silently masked by
  `|| true`). The high-severity gate now runs on every trigger — not just
  pull requests — and fails when an expected scanner report is missing instead
  of silently passing.
- **Deployment images pinned.** All 14 vLLM manifests move from
  `vllm/vllm-openai:nightly` to `v0.27.1`; the legacy `grpo-framework:latest`
  deployment is pinned to the release version, and `deploy.sh` now tags images
  with the version from `pyproject.toml`.
- **`[dev]` extra completeness enforced.** `[dev]` had drifted from
  `[training]`/`[api]` (missing `gymnasium` and `redis`); the missing packages
  are restored and a new guardrail test
  (`tests/unit/test_pyproject_extras.py`) asserts `[dev]` stays a superset of
  both. (Self-referential extras would make this structural, but they send
  pip-compile into `ResolutionTooDeepError`, so the duplication is deliberate
  and documented in-line.) Dev lock file regenerated.

### Added

- **Self-moving quality ratchets.** CI now fails when measured coverage
  exceeds the `fail_under` floor by a full point ("raise the floor"), and
  `tests/unit/test_mypy_allowlist_ratchet.py` stops the mypy typed-surface
  allowlist from ever shrinking — making both floors monotonic instead of
  policy-only.
- **Weekly GPU verification (`gpu-verify.yml`).** Rents a RunPod GPU via the
  same `train-remote` path users run, trains a real QLoRA adapter on
  Qwen3.5-0.8B from the current checkout's wheel, and fails unless adapter
  tensors come back. Skips cleanly when the `RUNPOD_API_KEY` secret is
  absent. Turns "verified on live hardware" into a standing weekly property.
- **CLI reference completeness guardrail.** `docs/CLI_REFERENCE.md` gained the
  12 undocumented commands (`improve`, `ingest`, `mcp`, `chat`, `benchmark`,
  `recipe`, `starter`, `tour`, `fine-tune`, `auto-research`, `init-config`,
  `gemma-4-31b`), generated from the live Typer app, and a new meta-test
  (`tests/unit/test_cli_reference_complete.py`) fails CI whenever a command is
  added, renamed, or removed without updating the reference.

## [0.21.0] - 2026-08-10 — Muse Glimmer 30B starter + RunPod hardening

### Added

- **Muse Glimmer 30B first-class starter.** `meta-models/Muse-Glimmer-30B`
  (Meta's open agentic model, Aug 2026: dense 30B, 131K+ ctx, Apache-2.0) now
  ships a packaged starter (`stateset_agents.training.muse_glimmer_starter`),
  a `stateset-agents muse-glimmer` CLI command, an `init --preset muse-glimmer`
  scaffold, a `muse-glimmer` preset in the unified `examples/finetune_gspo.py`
  driver, and `docs/muse_glimmer_starter.rst`.

- **RunPod provider for `train-remote`.** `--provider runpod` rents a GPU pod,
  runs the same packaged job every other provider runs, and copies the adapter
  back. Needs `RUNPOD_API_KEY`, an SSH keypair, and `ssh`/`scp` on PATH — no
  extra Python dependency.

  ```bash
  export RUNPOD_API_KEY=...
  stateset-agents train-remote --provider runpod --gpu "NVIDIA RTX A4000" \
      --dataset improved/curated.jsonl --base-model Qwen/Qwen3.5-0.8B
  ```

  RunPod rents a machine rather than a function, so there is no managed
  filesystem like Modal's Volumes: the pod is created with TCP 22 exposed and
  the caller's public key injected, and files move over `scp`. **The pod is
  terminated on every exit path** — success, non-zero job exit, transport
  exception, and never-became-reachable — because an orphaned pod bills by the
  hour. No network volume is created, so there is no storage cost after a run.

- **`RunPodExecutor(wheel=...)`.** Installs a locally built wheel on the pod
  instead of resolving the pinned version from PyPI, which is the only way to
  verify an unreleased change on real hardware.

  Verified end-to-end on live hardware: RTX A4000, `Qwen/Qwen3.5-0.8B`, LoRA
  r=8, ~5.5 minutes wall clock, returning a 12.8 MB adapter (192 tensors) to
  local disk with the pod terminated afterwards.

### Changed

- **`RemoteJobSpec.gpu` no longer hard-codes `"A10G"`.** GPU names are provider
  vocabulary ("A10G" on Modal, "NVIDIA RTX A4000" on RunPod), so a shared
  default silently sent an invalid id to whichever provider did not coin it.
  The field is now `None` by default and each executor supplies its own.

### Fixed

- **LoRA `target_modules` are now passed explicitly.** `run_sft` previously
  relied on peft inferring them from the architecture, which only works for
  models in peft's built-in mapping — anything else (Qwen3.5, for one) died
  with "Please specify `target_modules`". The failure needs a real model on a
  GPU to reproduce, so the CPU dry-run path never reached it. New
  `stateset_agents.training.sft.infer_lora_target_modules()` inspects the
  loaded model and selects the standard projection layers actually present
  (separate q/k/v/o, fused `c_attn`, and MLP projections), excluding the
  output head. Pre-existing: it affected `scripts/sft_from_curated.py` too.

## [0.20.0] - 2026-07-31 — train-remote: run the fine-tune step without a GPU

### Added

- **`stateset-agents train-remote`.** Runs the SFT job from `improve run` on
  local or rented compute, closing the last gap in the improvement loop —
  `ingest` and `improve` are CPU-only and cheap, but the fine-tune that
  consumes `curated.jsonl` needs a GPU. New `stateset_agents.remote` package:
  a provider-agnostic `RemoteJobSpec`, a five-method stateless `RemoteExecutor`
  contract, a `LocalExecutor` (subprocess), and a `ModalExecutor`. New extras:
  `remote` and `modal` (`pip install "stateset-agents[modal]"`).

  ```bash
  stateset-agents train-remote --provider modal --gpu A100 \
      --dataset improved/curated.jsonl --base-model Qwen/Qwen3.5-0.8B
  ```

  Remote runs install a pinned published `stateset-agents[training]` rather
  than syncing the local working tree, so a run is reproducible; the tradeoff
  is that testing an unreleased change remotely needs a dev release. A run
  succeeds only if it actually produces an adapter — a container that exits
  cleanly having written nothing is reported as a failure, not as success with
  an empty output directory.

  **Known limitation:** the Modal network transport is written against the
  documented SDK API but has not yet been verified against a live Modal
  account. `--provider local` is verified end-to-end. See
  `docs/superpowers/specs/2026-07-30-remote-executor-design.md`.

- **Five-minute onboarding demo.** `examples/five_minute_demo.sh` — a
  self-contained, offline, no-GPU script that writes sample customer-support
  conversation logs, ingests them with `stateset-agents ingest`, grades +
  curates them with `stateset-agents improve run --reward customer_support`,
  and prints the graded report — the fastest path from `pip install
  stateset-agents` to a curated training set. Colab equivalent:
  `notebooks/improve_your_agent_5min.ipynb`.

### Changed

- **The SFT job moved into the installed package** as
  `stateset_agents.training.sft`, runnable via `python -m
  stateset_agents.training.sft`. `scripts/` is excluded from the wheel, so a
  remote worker that installs the package could not have run the job from
  there. `scripts/sft_from_curated.py` is now a thin CLI that re-exports every
  public name it previously defined — existing callers and imports are
  unaffected.

## [0.19.0] - 2026-07-28 — MCP server: the improvement loop as tools for any MCP client

### Added

- **MCP server.** `stateset-agents mcp` (new optional `mcp` extra —
  `pip install stateset-agents[mcp]`) exposes the grade → curate → retrain
  "improve" loop as MCP tools (`list_rewards`, `ingest_transcripts`,
  `grade_transcript`, `improve_run`, `improve_status`, `list_model_presets`,
  `dry_run_finetune`) so any MCP client (Claude Code/Desktop, other agents)
  can drive the loop directly. Thin wrappers only — no grading/curation/
  training logic reimplemented; `improve_run` shares the same orchestration
  function (`cli_improve.run_improve`) as the CLI's `improve run` command.
  v1 scope: no tool starts real GPU training (`dry_run_finetune` is
  dry-run only). See `docs/MCP_SERVER.md` for setup and Claude Code
  registration (`claude mcp add stateset-agents -- stateset-agents mcp`).

## [0.18.0] - 2026-07-28 — Bring-your-own-agent: trajectory ingestion + one-command improve loop

### Added — `stateset-agents improve`: the grade -> curate -> retrain loop in one command

- New CLI subcommand `stateset-agents improve run --transcripts DIR --reward
  NAME --output DIR [--threshold F] [--format transcripts|openai|langchain]`.
  Thin orchestrator over existing, tested pieces — `stateset_agents.data.
  trajectory_ingest` (only when `--format openai/langchain`), `scripts/
  grade_transcript.py`'s grading + curation functions, and generates
  `next_steps.md` with the exact `scripts/sft_from_curated.py` /
  `examples/finetune_gspo.py` commands to train on the curated set. Writes
  machine-readable `improve_summary.json` (mean score, per-reward-component
  breakdown, curated count) alongside `curated.jsonl`.
- `stateset-agents improve status --output DIR` prints a previous run's
  summary without re-grading.
- Offline-friendly: only the rule-based rewards (`gsm8k`, `customer_support`,
  `tool_calling`) are supported; an LLM-judge reward name fails with a clear
  message instead of silently requiring an API key.
- See docs/COOKBOOK.md "The improvement loop in one command".

### Added — trajectory ingestion for logs from any agent framework

- `stateset_agents.data.trajectory_ingest`: `from_openai_messages`/`from_openai_jsonl`
  and `from_langchain_json` convert OpenAI chat-completions logs and
  LangChain/LangGraph message dumps into `MultiTurnTrajectory` — tool calls
  preserved in turn metadata, multimodal content flattened to text (skipped
  parts recorded, not dropped), optional per-conversation `reward`/`score`
  carried through. `to_grading_history()` emits the `{"role", "content"}`
  dicts `scripts/grade_transcript.py` already reads, so logs from any agent
  plug straight into the existing grade -> curate -> retrain loop.
- New CLI subcommand `stateset-agents ingest --format openai|langchain
  --input PATH --output PATH`.
- Exported from `stateset_agents.data`; see docs/COOKBOOK.md Recipe 2b
  ("Bring your own agent's logs").

## [0.17.3] - 2026-07-28 — Green CI: toolchain pinning, Windows/utf-8 correctness, packaging pipeline repair

## [0.17.2] - 2026-07-27 — Packaging A-grade: PyPI pipeline repair, rust_core 0.1.1, JS auth + CI

### Fixed — dashboard/mobile JS surface (A-grade pass)

- `dashboard/src/api.ts`: `BASE` now reads `VITE_API_BASE_URL` (falling
  back to the same-origin `/api/lab` default) instead of being hardcoded;
  requests send an `X-API-Key` header and the WebSocket connection sends
  `api_key` as a query param, sourced from `VITE_API_KEY` (build-time) or
  a new runtime `setApiKey()`/`getApiKey()` pair persisted to
  `localStorage` under `stateset.apiKey`. `connectWs()` derives its
  `ws(s)://` origin from `BASE` when it's an absolute URL, otherwise keeps
  the previous same-origin behavior. Added `dashboard/.env.example` and a
  `src/vite-env.d.ts` typing the two env vars.
- `dashboard/package.json`: added `engines.node >=20.19.0`; added
  `dashboard/.nvmrc` (`20.20.0`) to mirror `mobile/.nvmrc`.
- `mobile/lib/api.ts`: requests now send `X-API-Key` from a new
  `EXPO_PUBLIC_API_KEY` env var, mirroring the dashboard's auth pattern.
- `mobile/components/ui/DemoDataBanner.tsx`: new component making the
  existing mock-data fallback (`useTrainingData().isMockData`) visible in
  the UI, not just the console; wired into the dashboard tab screen
  (`mobile/app/(tabs)/dashboard/index.tsx`) as the reference pattern for
  the other screens.
- Added `.github/workflows/mobile.yml`: path-filtered CI on `mobile/**`
  running `npm ci` + `npm run typecheck` on Node 20 — mobile previously had
  no CI at all.
- `.github/workflows/dashboard.yml`: bundle artifact retention extended
  7 → 30 days; added a comment noting the deploy target is still an open
  decision (no deploy step added).

### Fixed — Rust/Cargo packaging surface (A-grade pass)

- Root `Cargo.toml`: removed two `[[example]]` stanzas pointing at
  `examples/multi_agent_orchestration.rs` and `examples/fulfillment_agent.rs`,
  which don't exist (`examples/` is the Python examples dir) — this made
  `cargo check --all-targets` fail outright.
- Root `Cargo.toml`: added `publish = false` — the root crate is an internal
  StateSet commerce daemon that needs a sibling `stateset-api` repo to build
  meaningfully, and its crates.io name would collide with the unrelated PyPI
  package `stateset-agents`.
- Added `docs/RUST_CRATES.md` clarifying the two unrelated Rust crates in
  this repo (`rust_core`/`stateset-rl-core`, the pyo3 accelerator, vs. the
  root crate, the internal commerce daemon), linked from the README
  installation section.
- `rust_core/Cargo.toml`: made `pyo3`/`numpy` optional dependencies gated
  behind a new `python` feature (which also enables
  `pyo3/extension-module`), so plain `cargo check`/`cargo test` and
  docs.rs work without libpython. `rust_core/src/lib.rs` moved all pyo3
  bindings into a `#[cfg(feature = "python")] mod python_bindings` block;
  the pure-Rust algorithm modules (`advantage`, `gae`, `trajectory`,
  `rewards`) remain unconditionally available. `rust_core/pyproject.toml`'s
  `[tool.maturin] features` now points at `["python"]`. Verified with
  `cargo check`/`cargo test` (default and `--features python`) and
  `maturin build --release`.
- Bumped `rust_core` 0.1.0 → 0.1.1 (`Cargo.toml` + `pyproject.toml`, kept
  in lock-step per the publish workflow's tag assertion) to ship the
  feature-gating fix.
- Added `.github/workflows/rust-ci.yml`: `cargo check --all-targets` +
  `cargo clippy -D warnings` (scoped with `-A dead_code -A
  unused_variables -A unused_imports -A unused_mut` to avoid a mass
  cleanup of the commerce daemon's WIP scaffolding) for the root crate,
  plus `cargo check`/`clippy`/`cargo test` (17 unit tests) for `rust_core`.
  Two small genuine clippy hits (`manual_is_multiple_of` in
  `rust_core/src/advantage.rs` and `rewards.rs`, a nested `format!` in
  `src/agents/customer_service.rs`) were fixed rather than allowed.
- `pyproject.toml`: added `pyyaml>=6.0` to core `dependencies` — the wheel
  ships runtime-loaded YAML presets that a bare `pip install
  stateset-agents` previously couldn't read (it was only pulled in by the
  `auto-research` extra).

## [0.17.1] - 2026-07-27 — Convergence e2e test + honest demo labeling

### Changed — Honest status labeling for dashboard/mobile; mock-data fallback surfaced (A+ final wave, Task 5)

- `dashboard/README.md` and `mobile/README.md` now lead with an explicit
  "demo, not deployed" status: both apps are real, working code, but
  neither has a deployment path — the `/api/lab/*` router they talk to is
  simulator-backed and gated behind auth + `API_ENABLE_TRAINING_LAB`
  (off by default). Both READMEs document how to run locally and what
  productionizing would require.
- `README.md` gained a short "Dashboard and mobile app (demo, not
  deployed)" section under Supported models, linking to the two READMEs.
- `dashboard/src/api.ts` gained a header comment stating it targets the
  simulator-backed `/api/lab` router and requires auth plus
  `API_ENABLE_TRAINING_LAB`.
- `mobile/hooks/useTrainingData.ts` now exposes `isMockData: boolean`
  alongside the existing `source: 'live' | 'mock'` field, and logs one
  `console.warn` per app session the first time it silently falls back to
  bundled mock data (unreachable API, auth failure, or empty response) —
  previously this fallback was invisible.

## [0.17.0] - 2026-07-27 — Unified finetune driver, rate-limiter hardening, grpo untangling

### Changed — Rate limiter moved out of the deprecated `grpo` package; deprecation warning scoped (A+ final wave, Task 3)

- `UnifiedRateLimiter` (and `RateLimitResult`, `get_rate_limiter`,
  `reset_rate_limiter`, `MAX_BUCKETS`) moved from
  `stateset_agents.api.grpo.rate_limiter` to `stateset_agents.api.rate_limiter`,
  reflecting that it is shared infrastructure used by `middleware.py` on the
  normal app path, not something specific to the secondary GRPO app.
  `stateset_agents.api.grpo.rate_limiter` remains as a thin re-export for
  backward compatibility.
- `stateset_agents.api.grpo`'s `DeprecationWarning` no longer fires on
  package import (previously it fired on every normal app startup via
  `middleware.py`'s rate-limiter import). It now fires lazily, only when
  the deprecated app-surface submodules (`service`, `service_routes`,
  `router_v1`, `auth`) are actually accessed.

### Changed — Unified finetune driver absorbs shared flags (A+ final wave, Task 1)

- `examples/finetune_gspo.py` now supports the full set of flag families
  shared by the packaged-starter per-model scripts:
  `--use-lora/--no-lora`, `--use-4bit`, `--use-8bit`, `--use-vllm`,
  `--wandb`/`--wandb-project`, `--export-merged`, `--learning-rate`,
  `--epochs`, `--steps`, and, for presets with a packaged starter
  (`ModelPreset.starter_module`), `--starter-profile
  {balanced,memory,quality}`, `--config PATH`, `--write-config PATH`, and
  `--list-profiles`. `--dry-run` now defaults to `True` (use `--no-dry-run`
  for a real run), matching the safe-by-default behavior of the starter
  scripts it now covers.
- **Fixed:** the driver's non-dry-run ("real run") mode used to be a
  no-op — it logged "wire this into your training entry point" and
  exited 0 without training anything. It now actually invokes the real
  training entry point: the packaged starter's own `run_<name>_config`
  coroutine for starter-backed presets, or
  `stateset_agents.training.gspo_entrypoints.train_with_gspo` for the rest.
  The dry-run exit message now explicitly says "pass --no-dry-run to
  train", and every doc/docstring example of a real run now shows
  `--no-dry-run` explicitly.
- **Fixed:** `--wandb`/`--wandb-project` were parsed but never reached
  `GSPOConfig` for non-starter presets (silent no-op even on real runs).
  `build_gspo_config` now sets `report_to="wandb"` plus `wandb_project`/
  `wandb_tags` when `--wandb` is passed (and `report_to="none"` otherwise),
  on both the starter and non-starter paths.
- **Fixed:** `--export-merged` was parsed but wired to nothing (silent
  no-op). It now calls `export_merged_model_for_serving` after a real,
  non-starter-backed training run (skipping with a warning if LoRA is
  disabled, since there is nothing to merge), and exits with a clear error
  for starter-backed presets, since none of the packaged starters currently
  expose a merge-export path.
- **Fixed:** the forwarder scripts silently dropped the old `--iterations`
  flag (the driver had no such flag, so passing it errored with
  "unrecognized arguments" instead of doing the thing the old script did).
  The driver now accepts `--iterations`, mapping it to a starter's
  `num_outer_iterations` override for starter-backed presets, and exiting
  with a clear error for non-starter presets ("use --epochs or --steps
  instead") rather than either silently dropping it or hard-failing with a
  generic argparse error.
- `ModelPreset` gained a `starter_module: str | None` field naming the
  packaged `stateset_agents.training.*_starter` module backing a preset's
  `--starter-profile` delegation, set for `kimi-k3`, `kimi-k2.6`,
  `glm5.1`, `glm5.2`, `gemma4-31b`, and `qwen3.5-0.8b`.
- Converted `examples/finetune_kimi_k3_gspo.py`,
  `examples/finetune_kimi_k2_6_gspo.py`,
  `examples/finetune_gemma4_31b_gspo.py`, and
  `examples/finetune_qwen3_5_0_8b_gspo.py` into thin (<=15 line) deprecated
  forwarders onto `examples/finetune_gspo.py --model <preset>`, now that
  the driver reproduces their entire CLI. The remaining per-model scripts
  (GLM's serving-only flags, the multi-size branching family scripts, and
  the already-forwarding `finetune_kimi_k2_5_gspo.py`) are kept; see
  `examples/README.md` for why each one still carries unique logic.

### Changed — CI + deferred cleanup (surface consolidation, Plan 3 Task 4)

- CI now runs `examples/getting_started/smoke.sh` against the checked-out
  source tree (via the editable install already used for tests), in
  addition to the existing PyPI-based `make getting-started-smoke` target
  used for release checks.
- Tightened `tests/unit/test_advanced_trainers.py::test_compute_gepo_coefficient`
  to pass sequence *log*-probs (matching the real call signature) and to
  assert the coefficients against the linear-space formula
  `coef_i = p_i / (sum(q^2) / sum(q))`, not just "greater than zero".
- Fixed `GSPOTokenTrainer.train_step_token_level`'s per-response token loss
  to normalize by the actual response length instead of the full padded
  sequence width, matching the sequence-level normalization used
  elsewhere in GSPO/GSPO-token.
- Corrected the comment on `_estimate_policy_entropy = compute_entropy_bonus`
  in `stateset_agents/training/loss_computation.py`: it is not a drop-in
  "backwards-compatible alias" (the signatures differ — the old estimator
  and `compute_entropy_bonus` are not interchangeable); it exists only
  because the one known external caller does `callable(_estimate_policy_entropy)`
  rather than calling it with the old signature.
- **Operational note:** `GSPOConfig.rescore_old_log_probs` now defaults to
  `True` (see prior GSPO hardening). This means even vLLM-based rollout
  deployments still require a local HF agent model + tokenizer at train
  time — the rollout log-probs are always rescored against the current
  policy before use, so a vLLM-only deployment with no HF model loaded
  will fail. Set `rescore_old_log_probs=False` explicitly if you
  intentionally want to trust the vLLM-reported log-probs instead (not
  recommended; see `gspo_generation.py` for the numerical-stability
  rationale).

### Changed — docs consolidation (surface consolidation, Plan 3 Task 3)

- Merged `docs/COMPARISON_TRL.md`, `docs/COMPARISON_LLM_FRAMEWORKS.md`,
  `docs/COMPARISON_TRADITIONAL_RL.md`, and the prior `docs/COMPARISONS.md`
  overview into a single `docs/COMPARISONS.md` with three clearly-headed
  sections ("StateSet Agents vs Hugging Face TRL",
  "StateSet Agents vs Traditional RL Frameworks",
  "StateSet Agents vs LLM Orchestration Frameworks").
- Archived the three superseded comparison files plus the dev-journal
  artifacts `docs/ENHANCEMENTS_SUMMARY.md`,
  `docs/FRAMEWORK_ENHANCEMENT_SUMMARY.md`, and root
  `GYM_INTEGRATION_COMPLETE.md` to `docs/archive/`. No other doc, README,
  or Sphinx toctree referenced these paths (verified by repo-wide grep
  before moving), so no link fixes were required beyond the merged
  `docs/COMPARISONS.md` itself.
- Added `tests/unit/test_docs_structure.py` to keep the archived files out
  of their old top-level paths and to assert `docs/COMPARISONS.md`
  contains all three merged section headers.

### Changed — examples cleanup (surface consolidation, Plan 3 Task 2)

- `examples/finetune_kimi_k2_5_gspo.py` is now a deprecated forwarder to
  `examples/finetune_kimi_k25_gspo.py` (a strict superset of its flags,
  plus `--system-prompt`, `--use-vllm`, `--export-merged`, `--iterations`).
  It will be removed in a future release.
- `examples/README.md` now documents every top-level example script; a new
  `tests/unit/test_examples_readme_complete.py` enforces this going
  forward.
- The other `examples/finetune_*_gspo.py` scripts and `examples/*_config.py`
  files were evaluated for collapsing into `examples/finetune_gspo.py` /
  `examples/model_presets.py` (from the prior "unified GSPO finetune
  driver" change) but were kept as-is: each carries model-specific CLI
  behavior (starter profiles, `--list-profiles`, `--write-config`, vLLM
  export, FP8 serving, model-size branching) that the unified driver
  intentionally does not reproduce, and the `*_config.py` files are
  imported by dedicated unit tests and docs (e.g.
  `tests/unit/test_kimi_k3_config.py`, `docs/glm5_1_starter.rst`).
  `examples/finetune_gspo.py --model <preset> --dry-run` remains available
  as a quick cross-model preview.

### Archived

- Moved `examples/enhanced_framework_demo.py`,
  `examples/enhanced_framework_showcase.py`,
  `examples/ultimate_customer_service_demo.py`,
  `examples/enhanced_customer_service.py`, and
  `examples/enhanced_grpo_demo.py` to `examples/archive/` — each was a
  redundant variant of a canonical example already documented in
  `examples/README.md` (`production_ready_customer_service.py`,
  `grpo_showcase.py`). References in `docs/ENHANCEMENTS_SUMMARY.md` and
  `docs/FRAMEWORK_ENHANCEMENT_SUMMARY.md` were updated to the new paths.

### Fixed — misplaced/duplicated Kimi-K2.5 test files

- `examples/test_kimi_k25.py` (a live, network-dependent smoke-check
  script, not a pytest suite despite its name) moved to
  `examples/kimi_k25/live_smoke_checks.py`.
- `tests/test_kimi_k25_integration.py` (misplaced at the `tests/` root,
  with test coverage that did not overlap
  `tests/integration/test_kimi_k25_integration.py`) moved to
  `tests/integration/test_kimi_k25_extended.py`.
- `examples/kimi_k25/README.md` updated to reference the new paths.

## [0.16.0] - 2026-07-27 — RL-core correctness + API hardening

### Fixed — RL training core correctness

- **DAPO**: old-policy token log probs are now frozen at rollout time (computed
  once under `no_grad` in `collect_samples_with_dynamic_sampling`) instead of
  being recomputed from the current model inside `train_step`, and
  `num_gradient_updates` (µ) is honored instead of being hard-capped at 1 —
  Clip-Higher and the PPO-style `min(unclipped, clipped)` objective can now
  actually fire on inner updates.
- **GEPO**: group-expectation importance weights are computed in log space via
  `logsumexp` (previously `exp()` of summed sequence log probs underflowed to 0
  for realistic responses, yielding NaN/zero coefficients), and the response
  mask off-by-one vs. the shifted-label convention is fixed
  (`build_response_mask`, `max(P-1, 0)`).
- **GSPO**: generation and scoring now share one tokenization convention —
  the chat-template-rendered prompt (including `system_prompt` when set) is
  scored via `build_scoring_text(rendered_prompt, response)` with no injected
  space; the trainer's current-policy and reference-KL log probs use the same
  convention, removing a systematic importance-ratio bias. Accumulated loss is
  normalized by the number of processed query groups. vLLM rollouts are
  rescored at T=1 by default (`rescore_old_log_probs=True`; requires the HF
  agent model/tokenizer even in vLLM deployments — set it to `False` to keep
  raw sampling-temperature `cumulative_logprob` with a one-time warning).
  Removed the fake-parameter injection for parameterless models
  (`GSPOTrainer` now raises `ValueError`).
- **GSPO-token**: restored the gradient path (token log probs were computed
  under `torch.no_grad()`, making `backward()` a no-op), masked prompt tokens
  out of the objective, fixed the reward call to use `compute_turn_reward`,
  and replaced `self.model.device` with `_get_model_device` (PEFT/sharded-safe).
- **GRPO loss path** (`loss_computation.py`): PPO ratios are length-normalized
  (`exp((new−old)/token_count)`) instead of `exp()` of raw log-prob sums; the
  entropy bonus is now differentiable (computed from the grad-enabled forward's
  logits); `LOSS_EXCEPTIONS` narrowed to `(RuntimeError, ValueError, OSError)`
  so programming errors propagate; `compute_enhanced_grpo_loss` gained ratio
  clipping and skips the full-vocab `log_softmax` when `beta == 0`.
- **VAPO**: value clipping compares fresh values against rollout-time
  predictions (was clipping values against themselves — a no-op); scalar
  rewards are placed on the terminal response token only before GAE (was
  broadcast across every token, inflating returns); `critic_advantages` is
  wired into the value target (`returns = critic_advantages + old_values`,
  decoupled GAE); the optimizer steps once per `train_step` over the
  prompt-averaged loss. VAPO's GAE uses the Rust kernel
  (`stateset_rl_core`) when installed, with a byte-identical Python fallback.

### Added — behavioral trainer tests

- Cross-trainer invariant suite `tests/integration/test_trainer_ratio_invariants.py`
  (DAPO/GEPO/GSPO on a tiny real GPT-2: on-policy first-update ratio ≈ 1,
  ratio ≠ 1 after a parameter update, finite loss, nonzero grads) plus
  per-trainer behavioral tests and a Rust/Python GAE parity test —
  the previous algorithm tests re-derived the math inline and could not catch
  any of the defects above.

### Security

- **Training Lab API gated behind auth + feature flag**: `/api/lab/*` (22 REST
  endpoints + metrics WebSocket) previously had no authentication and was
  mounted unconditionally. It is now opt-in via `enable_training_lab`
  (env `API_ENABLE_TRAINING_LAB`, default `true` in development, `false`
  otherwise) and, when mounted, every HTTP endpoint requires auth via
  `Depends(require_auth_if_enabled)`. The metrics WebSocket authenticates
  explicitly using an `api_key`/`token` query param (or `X-API-Key`/
  `Authorization` header), closing with code `4401` on missing/invalid
  credentials.
- **Training Lab in-memory state is now bounded**: `/api/lab` previously kept
  unbounded module-level dicts for experiments, episodes, and logs, and could
  leak untracked background training tasks. Experiments are now capped at
  `MAX_EXPERIMENTS = 100` (oldest created/completed/failed experiment is
  evicted to make room; a `429` is returned if every experiment is
  running/paused). Episodes and logs are bounded per-experiment via
  `collections.deque` (`MAX_EPISODES_PER_EXPERIMENT = 1000`,
  `MAX_LOGS_PER_EXPERIMENT = 5000`). Stopping or deleting an experiment now
  cancels its background training task.
- **`config.validate()` is now enforced at startup**: `create_app()` logs
  every configuration warning (e.g. missing API keys while auth is required)
  at `WARNING` level, and fails closed in production — raising
  `ConfigurationError` — when auth is required but no credential source at
  all (no API keys and no JWT secret) is configured.
- **Rate limiting now keys on identity, not shared IP**: `RateLimitMiddleware`
  previously bucketed by raw client IP (or a raw bearer/API key), so requests
  behind a shared NAT/proxy could exhaust one another's quota, and credential
  values leaked into limiter state. The bucket key is now the SHA-256 hash
  (first 16 hex chars, matching `auth.py`'s identity derivation) of the
  presented `Authorization`/`X-API-Key` credential when one is present,
  otherwise the client IP. `X-Forwarded-For`'s first hop is honored only when
  the new `trust_proxy_headers` flag (env `API_TRUST_PROXY_HEADERS`, default
  `false`) is enabled — previously the raw `request.client.host` was always
  used with no way to see through a trusted proxy, and there was no equivalent
  spoofing protection to disable it. Added an optional Redis-backed limiter
  (`API_RATE_LIMIT_BACKEND=redis` + `API_RATE_LIMIT_REDIS_URL`) for multi-pod
  deployments, using a fixed-window INCR/EXPIRE approximation; it falls back
  to the existing in-memory limiter (logged once) if `redis` isn't installed
  or the connection fails. `redis` is now listed under the `api` extra as an
  optional dependency.
- **Constant-time API key comparison**: `auth.py`'s API-key lookup used plain
  dict membership (`api_key in config.security.api_keys`), which is a
  short-circuiting `==` under the hood and vulnerable to timing side-channels
  against configured keys. It now compares the presented key against every
  configured key with `hmac.compare_digest`.

### Removed

- **Legacy GRPO service shims**: deleted
  `stateset_agents/api/ultimate_grpo_service.py` and
  `stateset_agents/api/enhanced_ultimate_grpo_service.py` — unmaintained
  duplicate FastAPI apps that shadowed `stateset_agents.api.main` and had no
  internal callers. Added `tests/api/test_no_legacy_shims.py` to guard
  against reintroduction; removed their Sphinx `automodule` entries.
- **Root `Dockerfile`**: moved to
  `deployment/docker/Dockerfile.rust-commerce-agent` with a header comment
  clarifying it builds the unrelated Rust commerce daemon (`src/main.rs`),
  not the Python FastAPI gateway (`deployment/docker/Dockerfile`). Updated
  `docker-compose.yml` and the `Makefile`'s `docker-build`/`docker-run`
  targets to the new path.

### Changed

- **Helm vLLM image tag pinned**: `deployment/helm/stateset-agents/values.yaml`
  used `vllm/vllm-openai:nightly`, a moving target with no reproducibility
  guarantee. Pinned to `v0.18.2` (matching the `vllm>=0.18.2` pin in
  `pyproject.toml`'s `vllm` extra) with a `# pin by digest in production
  overrides` comment for stricter deployments.
- **`stateset_agents.api.grpo` deprecated**: importing the package now emits
  a module-level `DeprecationWarning` pointing at `stateset_agents.api.main`
  as the supported entry point; this starts the deprecation cycle ahead of
  its eventual removal.

### Fixed

- `main.py` used `datetime.utcnow()` (deprecated, naive datetime) for the
  `/live` and `/circuits` timestamps; switched to
  `datetime.now(timezone.utc)`.
- `main.py` imported `CORSMiddleware` from the deprecated
  `fastapi.middleware.cors` re-export path; now imports from
  `starlette.middleware.cors` directly.

### Added — Kimi-K3 starter path

- **`stateset_agents/training/kimi_k3_starter.py`** — packaged GSPO starter for
  `moonshotai/Kimi-K3` (provisional ID — HF weights, model card, and license not
  yet published as of 2026-07-16), mirroring the Kimi-K2.6 surface: `KimiK3Config`,
  `get_kimi_k3_config`, profile matrix (balanced/memory/quality), JSON/YAML config
  round-trip, and lazy exports from `stateset_agents.training`.
- **`stateset-agents kimi-k3`** CLI command (`cli_train.py`) and
  `stateset-agents init --preset kimi-k3` scaffold preset (`cli.py`).
- Examples: `examples/finetune_kimi_k3_gspo.py`, `examples/kimi_k3_config.py`.
- Docs: `docs/kimi_k3_starter.rst`, CLI reference section, SUPPORTED_MODELS row,
  README starter section.
- Tests: `tests/unit/test_kimi_k3_config.py`, `tests/unit/test_kimi_k3_module_exports.py`,
  `kimi-k3` command + init-preset tests in `tests/unit/test_cli.py`.

### Added — GLM 5.2 starter path

- **`stateset_agents/training/glm5_2_starter.py`** — packaged GSPO starter for
  `zai-org/GLM-5.2` (754B MoE, `glm_moe_dsa` architecture), mirroring the GLM 5.1
  surface: `Glm52Config`, `get_glm5_2_config`, profile matrix
  (balanced/memory/quality), `get_glm5_2_serving_recommendations`, JSON/YAML
  config round-trip, and `finetune_glm5_2`. Exported lazily from
  `stateset_agents.training`.
- **`examples/finetune_glm5_2_gspo.py`** and **`examples/glm5_2_config.py`** —
  dedicated CLI starter + re-export helper.
- **`scripts/render_glm5_2_helm_values.py`** — renders Helm values from a GLM 5.2
  `serving_manifest.json`.
- Deployment: `values-glm5-2{,-fp8,-finetuned}.yaml` Helm overrides and
  `glm5-2-vllm{,-fp8,-finetuned,-finetuned-gcs}.yaml` + `glm5-2-training-job.yaml`
  Kubernetes manifests.
- Docs: `docs/glm5_2_starter.rst`, `docs/GLM5_2_HOSTING_PLAN.md`, plus
  `SUPPORTED_MODELS.md` / README / Sphinx toctree entries.

## [0.15.3] - 2026-05-24 — A+ polish: inference observability, honest coverage gate, Rust wheel pipeline

### Added — Rust accelerator on PyPI

- `rust_core/pyproject.toml` — maturin-backed Python packaging metadata for
  the `stateset-rl-core` crate. abi3-py310 means one wheel per (OS, arch)
  covers Python 3.10–3.13. Verified locally: `maturin build --release`
  produces a working manylinux_2_31 wheel, installs cleanly, and
  `stateset_agents.core.rust_accelerator.is_rust_available()` returns
  True. Crate version stays in lock-step with Cargo.toml (asserted by
  the publish workflow).
- `.github/workflows/rust-wheels.yml` — builds wheels for Linux
  x86_64/aarch64, macOS x86_64/arm64, and Windows x86_64; builds sdist;
  smoke-imports the host wheel; uploads each as an artifact. Publishes
  to PyPI when a `rust-core-v*` tag is pushed (gated on `PYPI_API_TOKEN`
  + `pypi-rust-core` environment for review). Decoupled from
  `stateset-agents` tags so the two release cadences don't interfere.
- New `[rust]` optional extra: `pip install "stateset-agents[rust]"` now
  pulls `stateset-rl-core>=0.1.0`. Added to `full` as well.
- `rust_core/Cargo.toml` — enabled `pyo3/abi3-py310` feature.
- `rust_core/README.md` install section updated: PyPI install is now
  primary, source build is "development" path.
- `docs/ARCHITECTURE.md` — added Rust accelerator entry under Technical
  Specifications.

### Added — Inference observability

- **`stateset_agents/api/inference_metrics.py`** — model-level Prometheus
  metrics complementing the HTTP-level metrics in `api/middleware.py`:
  `stateset_inference_requests_total`, `_duration_seconds`, `_ttft_seconds`,
  `_tokens_per_second`, `_tokens_total` (split by `prompt`/`completion`),
  and `_inflight` gauge. Labels: `model`, `route` (one of
  `openai_response`, `openai_stream`, `anthropic_response`,
  `anthropic_stream`), and `status` where applicable. Mirrors the optional-
  import pattern from the HTTP middleware so `prometheus_client` stays an
  optional dependency.
- `InferenceService.create_openai_response`, `stream_openai`,
  `stream_anthropic`, and `create_anthropic_response` are now instrumented
  via `track_request` / `track_inflight`. TTFT is captured on the first
  data line of each stream; per-request throughput is computed from
  completion tokens / total duration.
- **Grafana serving row** (`deployment/monitoring/grafana-dashboard.json`,
  panel IDs 100–106): inference RPS by model/route, error rate, end-to-end
  latency (P50/P95/P99), TTFT (P50/P95), output throughput (P50/P95),
  in-flight gauge, and token-volume by direction. Also corrects existing
  HTTP panels to use the real `stateset_http_*` metric prefix (was
  `http_*`, which never matched anything emitted by the app).
- 8 new unit + integration tests in `tests/unit/test_inference_metrics.py`
  covering the helper API and end-to-end recording against the stub
  backend.

### Fixed

- **Coverage gate honesty.** v0.15.1 set
  `[tool.coverage.report] fail_under = 70` aspirationally, but measured
  coverage on the post-CLI-decomp tree is 54.50%, which was silently
  failing the CI test step (and the duplicate `--cov-fail-under=70` in
  `scripts/publish_readiness.sh`). Gate dropped to 54 to match the
  measured floor; ratchet policy documented inline. Removed the
  duplicate `--cov-fail-under` flag so pyproject.toml is the single
  source of truth.
- **`docs/ARCHITECTURE.md`** refreshed from "Version 0.5.0 / Dec 2024 /
  ~50K LOC" to the actual v0.15.2 state (~104K LOC across 243 modules,
  full algorithm roster, observability section). Added a doc-versioning
  disclaimer mirroring the whitepaper's.

## [0.15.2] - 2026-05-20 — cli.py decomposition + deployment-version sync

Internal restructure. No public API change — all `stateset_agents.cli` imports, the `stateset-agents` entry point, the `python -m stateset_agents.cli` invocation, and every CLI subcommand behave exactly as before.

### Changed

- **`stateset_agents/cli.py` split from 3,118 → 1,150 LOC** (a 63% reduction in the worst-offender file). Twenty-three subcommands moved into focused sibling modules:
  - `cli_train.py` (998 LOC) — `train`, `qwen3-5-0-8b`, `kimi-k2-6`, `gemma-4-31b`
  - `cli_meta.py` (353 LOC) — `doctor`, `preflight`, `publish-check`
  - `cli_research.py` (360 LOC) — `auto-research`, `fine-tune`
  - `cli_chat.py` (272 LOC) — `chat`
  - `cli_benchmark.py` (172 LOC) — `benchmark` sub-app + four subcommands
  - Existing `cli_advanced.py` (390 LOC) untouched
- The remaining `cli.py` keeps the helpers, exception tuples, profile constants, `app` instance, and the small commands (`version`, `serve`, `evaluate`, `validate-config`, `init`, `init-config`, `starter`, `recipe`, `tour`).
- Test patches on `stateset_agents.cli._collect_dependency_status` and `_collect_import_status` continue to work — the meta module accesses these via late binding (`_cli._collect_…`) rather than locally rebinding them.
- `python -m stateset_agents.cli` keeps working via a one-line `sys.modules.setdefault("stateset_agents.cli", sys.modules[__name__])` alias at the top of `cli.py` that prevents a duplicate module load (and a second orphan `app` instance) when invoked as `__main__`.

### Fixed

- **Helm/K8s/docs version drift.** `deployment/helm/stateset-agents/values.yaml`, `Chart.yaml`, three Kubernetes training-job manifests, the Helm chart README, and `docs/KIMI_K25_GKE_AUTOPILOT.md` were pinned to image tag `0.11.6` (the last release that updated them). All bumped to `0.15.2` in lock-step with the package version. Closes the pre-existing `test_helm_values_use_current_package_version` and `test_selected_kubernetes_and_docs_refs_use_current_package_version` failures.
- **`test_cli_version_outputs_version`** asserted on the pre-v0.12.0 output format (`stateset-agents version X.Y.Z`); aligned with the actual current format (`stateset-agents X.Y.Z`, set in v0.12.0).

## [0.15.1] - 2026-05-20 — CI/release hardening: reproducible installs, nightly perf alerts, full Helm coverage

Infrastructure-only patch. No public API change. Tightens four CI/release dimensions to A+: coverage is now enforced from a single source of truth, installs are reproducible from committed lock files, performance regressions are caught on a nightly schedule with PR comments, and every published Helm values profile is rendered in CI.

### Added

- **`requirements-lock.txt` + `requirements-dev-lock.txt`** — pip-compile output committed to the tree, giving fully-pinned reproducible installs (`make install-locked`). `pip-tools` added to the `[dev]` extra. `make lock` regenerates; `make lock-check` is wired into `ci.yml` and fails the build if either lock drifts from `pyproject.toml`.
- **`.github/workflows/benchmark-nightly.yml`** — cron `0 7 * * *` runs the full `benchmarks/` + `tests/performance/` suites via `pytest-benchmark`, with `benchmark-action/github-action-benchmark` configured for `fail-on-alert: true`, `alert-threshold: 150%`, and PR comments on regression. Raw JSON archived for 30 days. The existing per-PR `benchmark.yml` and Phase-0 `benchmark-smoke.yml` are unchanged.

### Changed

- **Coverage gate moved to `pyproject.toml`** (`[tool.coverage.report] fail_under = 70`) — `pytest-cov` reads it automatically, so `pytest --cov` enforces the same floor locally and in CI. Redundant `--cov-fail-under=70` CLI flag removed from `ci.yml`. Added `precision = 2`, `show_missing = true`, and standard `exclude_lines` (`raise NotImplementedError`, `if TYPE_CHECKING:`).
- **Helm CI now renders every published profile** (`ci.yml` `helm` job) — was 4 (default + A100/H100/B200/Kimi-finetuned), now all 13 `values-*.yaml` including GKE staging/prod, vllm-A100, the full GLM5.1 trio (base/fp8/finetuned), and the full Qwen3.5-27B trio (base/minimal/finetuned). Profile count is asserted; rendered manifests uploaded as a 7-day artifact.

## [0.15.0] - 2026-05-20 — Onboarding & scenario coverage: 5 examples, 5 test patterns, 3 scenario notebooks

Triples the surface area of runnable onboarding content. Adds five new GPU-free `examples/getting_started/` scripts that smoke-test in <5s, a five-file `examples/testing/` directory (56 passing pytest cases in ~4s) covering the patterns most useful when writing tests against the framework, and three new Colab-ready training notebooks for scenarios the existing notebooks didn't cover (multi-turn × tool-calling, judge-driven RLHF loop, RAG grounding).

### Added

- **`examples/getting_started/` 06–10** (all GPU-free, all run via `smoke.sh`):
  - `06_multi_turn_episode.py` — drives `env.reset()` → loop `env.step()` against the stub backend; same shape as a real trainer rollout.
  - `07_tool_calling.py` — `ToolAgent` + bundled `ToolCallReward`, scoring well-formed, wrong-tool, and malformed responses.
  - `08_eval_driven_loop.py` — the §11.7 dev rhythm (baseline → change → measure) with two policies.
  - `09_curate_dataset.py` — chat → grade → curate, writes an SFT-ready JSONL.
  - `10_scenario_testing.py` — must-acknowledge / must-avoid / rubric-floor assertions; non-zero exit on regression.

- **`examples/testing/`** — new directory with 56 passing pytest cases (~4s on CPU) across five patterns:
  - `test_custom_reward.py` (table-driven), `test_stub_integration.py` (no-mock integration), `test_hypothesis_properties.py` (property-based, uses `stateset_agents.testing` strategies), `test_env_smoke.py` (parametrized over every bundled scenario), `test_judge_stability.py` (judge noise-floor + 2σ-separation gate from §11.7).
  - `README.md` documents the "which pattern when" matrix and the explicit anti-patterns (no mocking the model, no `time.sleep`, no asserting on free-form text).

- **Three scenario notebooks** (all pinned, seeded, lint-clean, `train_with_gspo` + `attn_implementation='sdpa'` + `use_reference_model=True, beta=0.05`):
  - `ecommerce_returns_agent.ipynb` (~2h on A100) — multi-turn × tool-calling under a 60% rubric / 40% tool composite reward.
  - `judge_driven_training_loop.ipynb` (~90 min) — closed-loop `train → judge → retrain` with a local Qwen2.5-1.5B-Instruct judge.
  - `rag_agent_finetune.ipynb` (~75 min) — BM25 retriever + 10-doc KB + `GroundingReward` that penalizes uncited claims.

### Changed

- `scripts/lint_notebooks.py` — added the three new notebooks to `BUNDLED_NOTEBOOKS`; CI now lints 13 notebooks (was 10).
- `examples/getting_started/README.md` — expanded to a 10-row table (was 5).
- `examples/getting_started/smoke.sh` — runs all 8 GPU-free examples (was 3).
- `notebooks/README.md` — "thirteen core notebooks" (was ten), with three new rows and three new "when to use what" entries.

## [0.14.1] - 2026-05-19 — Docs canonicalization

Tightened the documentation surface by consolidating overlapping guides into a single canonical set, removing the "which guide do I read?" ambiguity.

### Changed

- **Canonical guide picks:** `/QUICKSTART.md` (15-min), `docs/RL_FRAMEWORK_GUIDE.md` (usage), `/OVERVIEW.md` + `docs/FRAMEWORK_OVERVIEW.md` (overview), `docs/COOKBOOK.md` (recipes).
- **Archived under `docs/archive/`** (with redirect stubs at the original paths so inbound links don't 404): `QUICKSTART_5MIN.md`, `USAGE_GUIDE.md`, `COMPREHENSIVE_USAGE_GUIDE.md`, `STATESET_RL_AGENTS_OVERVIEW.md`. The first two used stale "GRPO Agent Framework" branding; `RL_FRAMEWORK_GUIDE.md` supersedes them with current branding plus the CLI reference, GRPO-vs-GSPO comparison, and HPO coverage.
- **Cross-refs updated** in `README.md`, `QUICKSTART.md`, and `docs/API_EXAMPLES.md` to point at the canonical guide.

### Tests

- Removed `tests/unit/test_usage_guide.py` and `tests/unit/test_comprehensive_usage_guide.py` (asserted against archived files).
- Added `tests/unit/test_rl_framework_guide.py` consolidating the surviving regressions (stub-quickstart flow present, old package name absent) against the canonical guide.
- Patched `tests/unit/test_advanced_docs_alignment.py` to drop archived targets and point at the canonical.

## [0.14.0] - 2026-05-19 — Dashboard A+ pass: build/lint/test/CI green, accessibility, external-store notifications

A focused quality push on `dashboard/`. The lab UI previously had a broken `tsc -b` (30+ TS errors), 13 lint errors, 0 tests, no CI coverage, and the default Vite README. This release fixes all of that, hardens accessibility, and trims runtime overhead.

### Fixed

- **Build.** `useToast` API mismatch (`toast.success` / `error` / `info` called everywhere but never exposed) was the dominant error class — eliminated by splitting `toast-context.ts` (context), `useToast.ts` (hook), and `components/ToastProvider.tsx` (provider) with a 4-method API. `verbatimModuleSyntax` violations resolved with `import type`. Recharts 3 `ValueType | undefined` narrowed in `MetricsCharts` and `RewardHistogram`. Invalid `fractionalSecondDigits: 0` removed from `TrainingConsole`.
- **Lint.** 13 errors → 0. Dead imports (`Zap`, `X`, `BarChart3`, `StatCard`, `Card`, `Filter`) removed across 6 files. `react-hooks/set-state-in-effect` resolved in `LiveMonitor` (form state initialized in click handler), `ExperimentDrawer` (React 19 "adjust state on prop change" pattern), and `NotificationCenter` (rewritten to consume a module-level store via `useSyncExternalStore`; status-transition diffing moved to a new `useTrackExperimentNotifications` hook that dispatches to the external store).
- **WS + polling overlap.** `LiveMonitor` now only polls REST when `connected === false`.

### Added

- **CI.** `.github/workflows/dashboard.yml` runs lint → typecheck → test → build on every PR touching `dashboard/` and uploads the bundle.
- **Tests.** Vitest + jsdom + Testing Library. Three suites (`useToast`, `notifications-store`, `App` smoke), 7 passing tests. `npm test` and `npm run typecheck` scripts added.
- **Accessibility.** Command palette is now a focus-trapped `role="dialog"` with `aria-modal`, `aria-activedescendant`, `aria-controls`, `role="listbox"` / `role="option"`, `aria-selected`, `Home`/`End` keys, scroll-into-view on the active item, and focus restoration on close. Dashboard icon buttons gained `aria-label`. Toast region is `aria-live="polite"`.
- **README.** Replaced the Vite boilerplate with a real architecture doc (feature matrix, run instructions, data-flow notes, code-quality bar).

### Notes

- Library/API code in `stateset_agents/` is unchanged in this release. The minor version bump reflects the dashboard hardening as a deliberate UX milestone.

## [0.13.4] - 2026-05-18 — Fourth-reviewer round: factual fixes + PDF rendering + reproducibility re-run

A fourth reviewer graded v0.13.3 at A−, primarily citing factual inconsistencies in §5.2 (clip-range "symmetric" vs the actual 3e-4/4e-4 values; "three orders of magnitude" vs the actual 2.8), a stale PyPI-lag note still claiming PyPI was at 0.7.1, and Mermaid diagrams rendered as fenced code in the PDF. This release lands those fixes plus three smaller asks. Items map 1:1 to the reviewer's numbered list.

### Fixed (factual)

- **WP §5.2 GSPO clip range.** Was: "the shipped defaults are symmetric — Clip-Higher asymmetry is reserved for DAPO and VAPO" with defaults `3e-4 / 4e-4`. Now correctly describes the defaults as **mildly asymmetric** with a slight upside bias, contrasted against DAPO's deliberate 40% Clip-Higher asymmetry. Also fixes the "three orders of magnitude tighter than 0.2" claim — the actual ratio is `0.2 / 3e-4 ≈ 667× = 2.8 orders of magnitude`.

- **WP front-matter PyPI callout + §"Versioning and Reproducibility".** Both still said PyPI was at 0.7.1 — stale since we shipped 0.13.2 to PyPI in this same release line. Updated to the current state: PyPI is at 0.13.2, source ahead by a patch, lag-window closed.

- **WP §5.6 comparative summary table.** The "Reported AIME score" row had empty cells for GRPO/GSPO/GEPO that highlighted the gap rather than mitigated it. Replaced with two rows: "Source-paper reasoning benchmark" (cites the paper-reported numbers with links) and "First-party (this framework)" (only GSPO has an entry, all others honestly marked "pending §5.6 v1.1"). Also added explicit "design-intent map, not a head-to-head benchmark" framing at the top of the section.

- **WP §6.7 Continual Learning.** Reviewer flagged this as "shaped like a feature list, not a guide." Demoted from a full subsection with a strategy table to a single paragraph explicitly labeled "primitive, evaluation harness pending."

### Added

- **`make whitepaper-pdf` Mermaid rendering.** The build script now fetches SVG from `mermaid.ink` (no install required, no JS execution) with on-disk caching at `/tmp/mermaid_svg_cache/`. The two diagrams in §2.1 and §3 now render as actual SVG in the PDF instead of fenced code blocks. Falls back to the code-block placeholder if the service is unreachable.

- **WP §C.7 audit-trail update.** Added the missing reproduction command for the §11.7 canonical result — both the Colab notebook URL and the headless `jupyter nbconvert --execute` invocation.

- **WP §10.3 rubric-blindness audit note.** One-line acknowledgment that the other bundled rubrics (`GSM8KReward`, `PartialCreditGSM8KReward`, `ToolCallingReward`) were audited for similar blindness patterns; tool-calling has its own structural failure mode (well-formed JSON for the wrong tool) that the §11.7 LLM-judge protocol would catch.

- **`benchmark_results/whitepaper_v1/customer_support_3seed_judge_qwen25_05b_instruct_rerun.json`** — independent re-run of the canonical §11.7 result on a fresh Colab session ~7 hours after the original. `trained_metrics` are bitwise-identical to four decimals across both runs — empirical evidence of seed-determinism, not just claimed.

- **`docs/WHITEPAPER.pdf`** rebuilt at this version (v0.13.4). 60 pages, ~390 KB. Cover page, header/footer pagination, Charter serif body / Inter sans headings / JetBrains Mono code, rendered Mermaid diagrams.

### Still pending (Colab-bound — explicit in the docs)

The fourth reviewer's "what would push it to A" list:
- **Head-to-head trainer benchmark.** `whitepaper_v1_comparative_trainers.ipynb` is ready; needs ~$1.30 of Colab time. Fills the new "First-party" row in §5.6.
- **Cross-family judge sanity check.** `CROSS_FAMILY_JUDGE_MODEL` knob is shipped; needs ~$0.85 of Colab time. Validates §11.7's in-family bound.
- **Framework-vs-framework benchmark.** Optional A+ target — TRL on the same customer-support task. Not currently scheduled.

## [0.13.3] - 2026-05-18 — Third-reviewer polish + README refresh (A → unblocking-to-A+)

The third reviewer round graded the v0.13.2 whitepaper at **A (up from A−)** with three small polish items and two Colab-bound run asks. This release lands the three polish items and refreshes the README to reflect the PyPI parity from v0.13.2.

### Changed

- **WP §14 trimmed.** The five-principles block in the conclusion was duplicated nearly verbatim from §1.0 (Design Philosophy preface). §14 now ends with a one-line reference back to §1.0 — saves ~150 words and gives the conclusion more punch.
- **WP §6.8 reordered.** The "<1% end-to-end" honest framing now appears *above* the kernel-speedup table, not below. The table also gains an explicit "End-to-end §11.7 impact" column (all <1%) so skimmers can't pick up the 26–72× number without the calibration. Pre-empts the misread the reviewer flagged.
- **WP §11.3 decision-tree caveat.** Added a parallel caveat to §11.7's "what this result does not support": the trainer-selection decision tree summarizes literature + implementation experience, but **first-party head-to-head numbers are pending** — the harness exists in `whitepaper_v1_comparative_trainers.ipynb`, the result row hasn't landed in §5.6 yet. Closes the last unsupported-authority surface in the document.

### Documentation

- **README.md substantial refresh:**
  - Header badges: replaced `badge.fury.io` with `shields.io/pypi/v` (auto-updates from PyPI), added Whitepaper version badge and §11.7 first-party-result badge.
  - New top-of-doc "What's new in v0.13.2" section listing the six headline changes since v0.13.0.
  - Install section now reflects the PyPI parity: `pip install stateset-agents` gets v0.13.2, no longer stuck at v0.7.1. Old PyPI lag callout retained as historical context.
  - Benchmark notebook table expanded from 2 rows to 6, headed by `customer_support_3seed_judge.ipynb` as the canonical §11.7 notebook. Pointer to the lint script and issue #16.
  - "Start here" section bumped: whitepaper + errata + benchmark_results/whitepaper_v1/ now linked above the cookbook/platform-tour entries. CHANGELOG version reference: v0.12.1 → v0.13.2.

### Still pending (Colab-bound — explicit in the docs, not in this release)

Two runs would move the grade from **A** to **A+**:

- **Head-to-head trainer comparison.** The notebook (`whitepaper_v1_comparative_trainers.ipynb`) is in v0.13.1; the run is a few hours of Colab compute. Output JSON fills §5.6's comparative table.
- **Cross-family judge sanity check.** Set `CROSS_FAMILY_JUDGE_MODEL='meta-llama/Meta-Llama-3-8B-Instruct'` in `customer_support_3seed_judge.ipynb` (the knob is shipped in v0.13.2). Re-run on the same 24 generations. The third reviewer was explicit: "either direction is more important than not knowing."

## [0.13.2] - 2026-05-18 — Second PhD-reviewer round (calibration + scoping fixes)

Addresses every item from the second reviewer pass. Patch bump: no API removed, additions are doc clarifications, one framework warning, and a notebook extension. Items map 1:1 to the reviewer's numbered list.

### Added

- **§1.0 Design Philosophy preface** — the five principles previously only in §14 now lead §1, anchoring the rest of the document. §14 retains the detailed treatment.
- **§11.7 in-family-judge-bias disclosure** — explicit acknowledgment that Qwen-trainee + Qwen-judge has known in-family bias. Points readers at the new `CROSS_FAMILY_JUDGE_MODEL` knob in the reference notebook.
- **`CROSS_FAMILY_JUDGE_MODEL` constant** in `notebooks/customer_support_3seed_judge.ipynb` — opt-in second judge (Llama-3-8B-Instruct or similar) for the cross-family sanity check. Disabled by default (saves ~6 GB VRAM + ~5 min wall clock); set to enable. Evaluate() function now reports `cross_judge_mean` alongside the primary `judge_mean` when enabled.
- **§6.8 end-to-end framing** — explicit caveat that the 26–72× kernel speedup translates to <1% of end-to-end step time at typical §11.7 configurations. Pre-empts "framework is 26× faster" misreading.
- **§3.6 memory algorithm pin-down** — replaces the vague "configurable triggers" with the actual `add_turn` sequence (append → extract entities → extract facts → maybe summarize → decay → trim) plus the retrieval order. Flags semantic-tier embedding-similarity as v1.1 pending work.
- **§8.1 maturity-inversion acknowledgment** — one paragraph explaining why serving is `Stable` while trainers are `Beta`/`Experimental` (the operational layer hardened first against StateSet's commercial deployments).
- **§5.3 GEPO math clarification** — names $E_q[q]$ as the self-normalized importance-sampling denominator, connecting the symbol to particle-filter/population-Monte-Carlo primitives.
- **§11.5 token-soup callout** — promotes the issue #16 failure mode from a table row to a prose callout that reminds readers never to accept a rubric improvement without spot-checking generations.
- **"Skim on first read" labels** on §3.6, §6.7, §6.9, §11.6 — improves navigation for readers using the document as reference.

### Changed

- **`NeuralRewardModel` constructor** in `stateset_agents/training/neural_reward_trainer.py` now takes an `encoder=None` parameter and emits a `WARNING` when the default hash-based smoke-test encoder is used without `suppress_smoke_encoder_warning=True`. The hash encoder cannot learn useful rewards (deterministic pseudo-random per string); the warning quotes the fix and the smoke-test rationale. §4.4 prose updated accordingly: the default path is now explicitly framed as "smoke-test the training loop only."
- **§13.2 prose** — softened from "no other framework ships all three" to "no other framework in the matrix treats all three as first-class concerns in a single deployable package," with concrete examples of which competitors treat which subset as first-class.
- **§1.2 BUSL framing** — trimmed the positioning paragraph to a one-line license declaration; the four-year rationale moves to a footnote.

### Documentation

- All eleven reviewer items above plus the smaller notes (BUSL trim, dense Mermaid diagram in §3 — flagged but not yet split; "skim" labels; principles preface).

### Still pending (Colab-bound, for v1.0/v1.1 first-party results)

- Comparative trainer benchmark run (`whitepaper_v1_comparative_trainers.ipynb` — authored in v0.13.1, awaiting Colab execution).
- vLLM speedup measurement run (`vllm_speedup_benchmark.ipynb` — authored in v0.13.1, awaiting Colab execution).
- Cross-family judge result on the §11.7 generations (notebook supports it in this release; needs a run).

## [0.13.1] - 2026-05-18 — Whitepaper PhD-reviewer round + comparative-trainer notebook + notebook-lint

Closes the v1.0 whitepaper review feedback (A− → unblocking-to-A): comparative trainer notebook, vLLM-speedup notebook, related-work feature matrix, Rust-core measured speedup, §5.7 KL note promotion with TRL line citation, notation consistency, and the issue #16 CI smoke ask.

### Added

- **`notebooks/whitepaper_v1_comparative_trainers.ipynb`** — TRL GRPO vs GSPO vs DAPO on the §11.7 customer-support protocol. Three trainers × three seeds = nine training runs, same baseline, same rubric + LLM-judge eval. Fills the §5.6 comparative trainer table that's been empty since v0.11.6. Skips GEPO (async-oriented) and VAPO (experimental warmup) per the reviewer's recommendation.
- **`notebooks/vllm_speedup_benchmark.ipynb`** — HF generate vs vLLM throughput sweep over `prompt_batch_size ∈ {1, 8, 32, 128}` × `num_generations=4` × `max_tokens=512` on `Qwen2.5-0.5B-Instruct`. Produces the §6.4 "Validated configuration" number with sweep data so readers see the speedup-grows-with-batch claim is verifiable.
- **`scripts/lint_notebooks.py`** + **`make notebook-lint`** — codifies issue #16's lessons into a CI-friendly lint. Checks all ten bundled notebooks for: `asyncio.run()` in Jupyter, `Agent(config=...)` (abstract base), `attn_implementation='flash_attention_2'` (Colab incompatibility). Wired into `make smoke` and `.github/workflows/benchmark-smoke.yml`. Trigger paths simplified to `notebooks/**`.
- **`benchmark_results/whitepaper_v1/rust_vs_python_microbenchmark.json`** — first-party measurement backing §6.8's Rust-core speedup claim. `batch_compute_gae` runs 26-72× faster than the equivalent Python loop across three batch sizes; vectorizable kernels (`compute_group_advantages`) don't see the same benefit. Honestly characterized.

### Fixed

- **`stateset_agents/training/trl_grpo_trainer.py:604`** — mirror of the `gspo_trainer.py` canonical-signature fix from `a2bdde4`. TRL GRPO's reward call was using `compute_reward(trajectory=None, turn=turn, ...)`, only accepted by `MultiObjectiveRewardFunction`. Now uses `compute_reward(turns=[turn], context=...)` so any `RewardFunction` subclass works — required by the new comparative-trainer notebook.
- **`notebooks/quickstart_first_finetune.ipynb`** — three `asyncio.run()` calls in the test-prompt loop converted to top-level await (caught by `notebook-lint`).
- **`notebooks/grade_and_curate_demo.ipynb`** — `asyncio.run()` over scenarios refactored to an `async def` + top-level await.
- **`notebooks/sft_from_curated_demo.ipynb`** — two `asyncio.run()` in inline generate/eval calls converted to top-level await.
- **`.github/workflows/benchmark-smoke.yml`** — notebook validation step now lints all ten bundled notebooks (was six) via `python scripts/lint_notebooks.py` in addition to JSON validity.

### Documentation (PhD reviewer round)

- **§13 Related Work** — replaced the prose paragraph with a 15-capability × 6-framework feature matrix (StateSet Agents vs TRL, OpenRLHF, TRLX, NeMo-Aligner, Verl). New "Distinguishing position" subsection naming the three column-pairs where the framework adds something the others don't.
- **§5.7 "Exact Forward KL"** — promoted from "A Note on KL Divergence" with a three-way comparison (analytical / Schulman k1 / Schulman k3) and TRL line citations (`trl/trainer/ppo_trainer.py:517` and `rloo_trainer.py:436` — both use k1 `0.5 * (logprobs_diff**2).mean()`). Closes the "is that really true of all open implementations?" loophole.
- **§3.1 Tool-call semantics** — new paragraph documenting the four behavior decisions: tool call is part of assistant turn (not separate), credit assignment is per-turn (not per-call), tool errors are reward's responsibility, tool outputs excluded from policy gradient.
- **§6.8 Rust Acceleration Core** — replaces the unbacked performance claim with a measured speedup table: 26-72× on `batch_compute_gae`. Explicit that vectorizable kernels don't see the same benefit; the Rust core is included for recurrence-heavy paths, not as a blanket NumPy replacement.
- **§6.4 vLLM speedup** — adds a "Validated configuration" paragraph naming the specific (model, batch, seq-len, hardware) tuple the integration is validated against, pointing at `vllm_speedup_benchmark.ipynb`.
- **PyPI install-path warning** moved from §"Versioning and Reproducibility" body to a prominent callout immediately after the abstract, with a concrete `pip install git+...` command.
- **Notation consistency** — `ε_R` → `ε_H` throughout §5.2 (GSPO) to match §5.0 notation table and §5.4 (DAPO).
- **§4.4 "Bitter Lesson"** — Sutton citation (new reference [20]) plus a caveat about neural-reward failure modes (reward hacking, judge gaming, calibration drift).
- **§1.2** now cross-references §8.1 Component Maturity so new readers encounter the experimental/beta/stable classification before §8.
- **§1.2 BUSL→Apache 2.0** transition gets a rationale paragraph (no-hosted-derivative protection during the 4-year window, always-permitted use for individual/academic/customer cases, binding contractual conversion in 2029).
- **§2.1 layered-design diagram** upgraded from ASCII to Mermaid (matches the §3 class diagram's quality).
- **§7.4 dashboard** description points readers at `dashboard/README.md` for screenshots and `make dashboard` for the live UI.
- **Appendix C.4 test-count verification** — changed from `pytest --collect-only` (counts but doesn't verify green) to `pytest tests/unit -q --no-header | tail -2` (counts AND confirms pass).

## [0.13.0] - 2026-05-18 — First-party canonical benchmark + KL-anchor safety

The release that lands the v1.0 whitepaper's first canonical first-party benchmark result and codifies a previously-undocumented training foot-gun as a runtime warning. Driven by [issue #16](https://github.com/stateset/stateset-agents/issues/16) — a multi-day debugging session running the bundled benchmarks end-to-end on Colab A100.

### Added

- **`PartialCreditGSM8KReward`** in `stateset_agents.data.gsm8k` — dense-reward variant of `GSM8KReward` with four tiers (`0.0` unparseable / `0.2` parseable / `0.5` within 10% / `1.0` correct). Eliminates the all-zero-groups pathology where the binary reward gives no gradient signal on weak base models. 8 new unit tests covering all four tiers and edge cases.
- **`train_with_gspo` runtime warning** — emits a loud warning when `use_reference_model=False` AND `beta=0.0` AND `len(train_queries) < 100`. This combination destabilizes the policy to gibberish output (see whitepaper §10.5 and `benchmark_results/whitepaper_v1/customer_support_qwen3_5_0_8b_gspo.json`). Warning quotes the safe-default fix and points to the artifact.
- **`notebooks/whitepaper_v1_gsm8k_benchmark_v2.ipynb`** — dense-reward A/B variant of the GSM8K benchmark notebook.
- **`notebooks/customer_support_3seed_judge.ipynb`** — the canonical whitepaper §11.7 publication-gate notebook. Three seeds (42 / 1337 / 2026), both rubric and LLM-judge eval (local `Qwen2.5-1.5B-Instruct` judge — no API key), KL anchor enabled.
- **First-party benchmark artifacts** under `benchmark_results/whitepaper_v1/` (un-ignored via `.gitignore` negation): 5 result files spanning the full headroom spectrum — proof-of-life GSM8K, dense-reward A/B, gibberish KL-anchor-absent failure, near-ceiling stability finding, and the canonical positive result (`customer_support_3seed_judge_qwen25_05b_instruct.json`: judge improvement +0.079, 3-seed agreement).
- **Whitepaper §11.7 "First-Party Reproduction"** — methodology, result table, publication-gate verification, cross-references to §5.1 / §10.5 / §B.1.

### Fixed

- **`gspo_trainer.py:594`** now calls `reward_model.compute_reward(turns=[turn], context=...)` — the canonical `RewardFunction` API documented in §4.1 of the whitepaper. The previous call shape (`trajectory=None, turn=turn, ...`) was only accepted by `MultiObjectiveRewardFunction`'s compatibility shim; every other `RewardFunction` subclass raised `TypeError`. 35/35 `tests/unit/test_gspo_trainer.py` pass; 248/248 `-k "gspo or reward"` sweep passes.
- **`notebooks/customer_support_4h.ipynb`** — eight bug patterns from the GSM8K v1 debug session pre-applied: stale commit pin, missing `transformers/peft/torchao` upgrade, `asyncio.run` in Jupyter, abstract `Agent` base used instead of `MultiTurnAgent`, missing `attn_implementation='sdpa'`, no explicit `train_queries` (rubric context dropped), gradient-checkpointing-incompatible bf16 conv1d backward on Qwen3.5's hybrid layer, and the unsafe default GSPOConfig.
- **Whitepaper §B.1 hyperparameter table** — `beta=0.0` and `use_reference_model=False` defaults carry a "See warning below" flag with an inline warning block.
- **Whitepaper §10.3 "Reward gaming"** — adds the inverse case from the canonical run: rule-based rubric scoring a qualitatively better trained policy *lower* than baseline because the trained model pivots to clarifying questions.
- **Whitepaper §10.5 "Reference-model drift"** — adds documented evidence across the full headroom spectrum (no anchor → gibberish; anchor + ceiling → stable; anchor + headroom → positive transfer).
- **Whitepaper §11.5 failure-modes table** — new row for "trained model emits token soup; rubric score still nonzero".
- **Whitepaper §8.1 maturity matrix** — GSPO trainer entry references the first-party result.
- **Whitepaper anchor** rebased twice this release: `c0dbd68` → `a2bdde4` → `4744c76`. `docs/WHITEPAPER_ERRATA.md` records both re-anchorings.

### Changed

- **`notebooks/customer_support_4h.ipynb`** ships with safe defaults: `use_reference_model=True`, `beta=0.05`, `num_epochs=1`.
- **`.gitignore`** — `benchmark_results/` rule changed from whole-tree-ignore to selective: tracks `whitepaper_v1/**` plus the schema/README/summary files, still ignores ad-hoc local dumps.
- **`docs/WHITEPAPER.md`** front-matter — "experimental results absent" caveat replaced with a concrete summary of §11.7.
- **`notebooks/README.md`** — eight core notebooks (was six in 0.12.0).
- **Whitepaper test-suite count** refreshed in §3.2 and §9 — 2,438 collected (was 1,624 in the v0.11.6 anchor).
- **Whitepaper §9 exception-tuple list** — fixed double-listed `SERIALIZATION_EXCEPTIONS` and removed non-existent `ENVIRONMENT_EXCEPTIONS`; correct names from `stateset_agents/exceptions.py` substituted.

### Documentation

- **`docs/WHITEPAPER_ERRATA.md`** — net-new errata document tracking three anchor rebases (`14c0e65` → `c0dbd68` → `a2bdde4` → `4744c76`) and the v0.11.6 → v0.12.2 corrections.

## [0.12.2] - 2026-05-15 — Docs polish

### Documentation
- **README "Start here" section** now links `CHANGELOG.md` alongside `PLATFORM_TOUR.md`, `COOKBOOK.md`, and `notebooks/README.md` — four discoverability entry points.
- **`docs/PLATFORM_TOUR.md` FAQ** version-upgrade hint bumped from "0.11.7" to "0.12.0" (was stale after the 0.12.x releases).
- **`docs/COOKBOOK.md` Recipe 6** example `stateset-agents version --json` output now shows `version: 0.12.1` (was `0.11.8`). The other fields (git_commit, dependencies) remain illustrative and don't depend on the release.

No functional changes; no test changes; pure docs maintenance from a grep audit of "0.11" references across the repo.

## [0.12.1] - 2026-05-15 — Batch evaluation + sample eval set

### Added
- **`stateset-agents evaluate --scenarios <jsonl> --reward <name>`** — batch-evaluation mode against a saved checkpoint. Scores every row in the JSONL with the named reward (`gsm8k` / `customer_support` / `tool_calling`) and emits a markdown report: mean ± std, pass rate at `--threshold`, per-scenario table with ✅/⚠️/❌ markers. The single-message mode is preserved. Suitable for nightly / PR-blocking evaluation in CI.
- **`examples/sample_eval_set.jsonl`** — 10 bundled customer-support scenarios across 4 intents (refund / technical / billing / general). Drop-in input for the new batch-evaluate mode. See [Cookbook Recipe 5](./docs/COOKBOOK.md).
- **`make smoke-fast`** — runs only the 15 platform-pipeline unit test modules (~60s, ~222 tests, no integration tests, no CLI subprocess overhead). Inner-loop alternative to the full `make smoke`.
- **`notebooks/README.md`** — map of the 6 bundled Colab notebooks with an ASCII flowchart for "which notebook to open for which goal" + a stage/runtime/cost table.

### Fixed
- CHANGELOG 0.12.0 entry claimed "7 self-contained recipes" — Recipe 5 (batch evaluation) brought the count to 8. Updated the 0.12.0 entry to reflect what actually shipped.
- `tests/unit/test_recipe_cli.py::test_list_default_with_no_args` checked for "7 recipes" via a 7-keyword list; updated to 8 with the new `batch` keyword. Also `test_by_short_substring` updated since "debug" now matches Recipe 6 (not 5).

## [0.12.0] - 2026-05-15 — Developer experience + discoverability

### Added
- **`stateset-agents recipe <name>`** — open a cookbook recipe in `$PAGER`. Supports `list`, numeric (`recipe 1`), full slug, and substring match. Sources from `docs/COOKBOOK.md`.
- **`docs/COOKBOOK.md`** — 8 self-contained, copy-paste recipes covering: first fine-tune, iterating from production logs, reproducing a whitepaper number, building a tool-using agent, running a batch evaluation, debugging a stuck reward, handing off to a colleague, running the demos. Sphinx-integrated via `docs/cookbook.rst`. The bundled `examples/sample_eval_set.jsonl` (10 scenarios across 4 intents) gives users a ready-to-run input for the batch-evaluate recipe.
- **`notebooks/quickstart_first_finetune.ipynb`** — Colab mirror of Cookbook Recipe 1. The 6th bundled notebook; covers install → scaffold → train → REPL sanity-check → provenance hand-off.
- **Chat REPL `readline` integration** — up-arrow recalls previous commands; input history persists across sessions at `${XDG_STATE_HOME:-$HOME/.local/state}/stateset-agents/chat_input_history`. Linux/macOS automatic; Windows users can `pip install pyreadline3`.
- **`make smoke-cli`** — verify every CLI subcommand's `--help` loads cleanly. Catches argument-parsing regressions across the now-15 commands.
- **`make health`** — comprehensive platform health check: version + provenance + CHANGELOG entry + CLI smoke + doctor + end-to-end GSM8K pipeline smoke. ~10 seconds, the one-command answer to "is everything wired correctly?"
- **`make demo-all`** — runs `demo` → `demo-curation` → `demo-full-loop` in sequence with section dividers. ~12 seconds total. Screen-share / asciinema friendly.
- **`make new-version VERSION=x.y.z`** — atomically bumps `pyproject.toml` + `stateset_agents/__init__.py` and prepends a CHANGELOG draft with today's date + TODO placeholders.
- **`make changelog-check`** — fails if the version in `pyproject.toml` doesn't have a corresponding `## [x.y.z]` section in `CHANGELOG.md`. Wired into CI so version bumps without CHANGELOG entries fail the build.
- **PLATFORM_TOUR.md** — new tour stop 10 ("Close the loop: curate → SFT → iterate") covering the full curation pipeline; new FAQ entries on `make health`, `recipe`, readline, and the diagnostic surface.
- **CI workflow** — extended to gate `make changelog-check`, `make smoke-cli`, `make health`, all 6 notebooks, and per-template scaffold smoke.

### Fixed
- Two earlier-pass notebooks (`whitepaper_v1_gsm8k_benchmark.ipynb`, `customer_support_4h.ipynb`) called `GSPOTrainer(config, agent, environment)` which would `TypeError` at runtime — the actual constructor requires `(config, model, tokenizer, agent, environment, reward_model)`. Both notebooks now use the canonical `train_with_gspo()` high-level entry point.
- Silent gpt2 fallback in the `/agents/converse` router when `STATESET_DEFAULT_CHECKPOINT` was set but the startup hook failed — now logs a diagnostic warning naming the env var so users see what happened.

## [0.11.8] - 2026-05-14 — Human-in-the-loop curation

### Added
- **`stateset-agents chat`** — interactive in-process REPL against an agent. Flags:
  - `--model` / `--checkpoint` / `--system` / `--max-new-tokens` — agent configuration
  - `--history` — append every turn to JSONL
  - `--replay` — preload from a saved transcript
  - `--grade <reward>` — show live composite-reward scores per turn (✅/⚠️/❌ markers)
- **`stateset-agents tour`** — opens `docs/PLATFORM_TOUR.md` in `$PAGER` or stdout.
- **`AgentConfig.peft_path`** field — loads a pre-trained LoRA adapter from disk. Wired through `MultiTurnAgent.initialize()` via `PeftModel.from_pretrained()`. Closes the `--checkpoint` flow.
- **`AgentService.register_default_checkpoint_agent()`** — at API startup, the lifespan hook reads `STATESET_DEFAULT_CHECKPOINT` / `STATESET_DEFAULT_BASE_MODEL` env vars and registers a usable agent under id `"default"`. Routable via `/agents/default/messages`.
- **`scripts/grade_transcript.py`** — score a JSONL chat transcript with the same reward functions used during training (`gsm8k`, `customer_support`, `tool_calling`). Optional `--output-curated` flag writes high-scoring (prompt, response) tuples to a deduplicated JSONL for use as next-pass training data.
- **`scripts/summarize_graded_batch.py`** — cross-transcript umbrella summary (grand mean, per-transcript table sorted by score).
- **`scripts/prepare_sft_dataset.py`** — converts curated JSONL into three SFT dataset formats (`hf-trainer`, `chat`, `axolotl`). Filters: `--min-score`, repeatable `--source`, `--dedup` by prompt. Stats summary.
- **`scripts/sft_from_curated.py`** — supervised fine-tune on the prepared chat-format JSONL via `transformers.Trainer` + PEFT LoRA. Stub-aware: dry-run on CPU, full training on GPU. Saves a LoRA adapter directory consumable by `AgentConfig.peft_path`. Completes the human-in-the-loop cycle entirely in-framework.
- **`stateset-agents version`** — extended to report git commit hash + key dependency versions (`torch`, `transformers`, `peft`, `trl`, `datasets`, `fastapi`, `vllm`) with ✓/— markers. Single source of truth for provenance.
- **`make full-loop`** umbrella — runs prepare-sft → sft-from-curated as one command, closing the loop in a single invocation.
- **Makefile targets:** `grade-transcript`, `grade-batch` (with optional `CURATED=` / `THRESHOLD=`), `grade-batch-summary`, `prepare-sft`, `sft-from-curated`, `full-loop`, `changelog-check`, `serve-trained`, `release-prep`, `demo`, `demo-curation`, `starter-test`, `smoke`.
- **`docs/PLATFORM_TOUR.md`** — canonical 10-stop guided walk from `pip install` to published v1.0 whitepaper, plus a FAQ answering the 7 questions that come up in practice. Sphinx-integrated via `docs/platform_tour.rst`.
- **Tool-calling benchmark** — `stateset_agents.data.tool_calling_bench` (bundled 8-scenario corpus + 3 sample tools + `ToolCallReward` composite). Completes the three-pillar coverage (math, dialogue, function calling).
- **Tool-calling Colab notebook** — `notebooks/tool_calling_agent_demo.ipynb` parallels the GSM8K and customer-support notebooks.
- **Doctor command enhancements** — surfaces `STATESET_DEFAULT_CHECKPOINT` / `STATESET_DEFAULT_BASE_MODEL`, validates the path exists, warns when base model is unset.
- **`docs/figures/`** convention + the v1.0 release packager (`scripts/release_v1_whitepaper.py`) generates publication figures and the §11.7 markdown snippet in one command.
- **40+ new unit + integration tests.** Total test count now 195+ across the benchmark / scaffolding / chat / grading pipelines, all passing in ~75 s with no GPU.

### Fixed
- Earlier Colab notebooks called `GSPOTrainer(config, agent, environment)` which would `TypeError` at runtime — the actual `GSPOTrainer.__init__` requires `(config, model, tokenizer, agent, environment, reward_model)`. Switched both notebooks to the canonical `train_with_gspo()` high-level entry point.
- The `--checkpoint` CLI flag set `STATESET_DEFAULT_CHECKPOINT` but nothing read it — now wired all the way through the API lifespan + the new `AgentConfig.peft_path` field + the LoRA-from-disk loader.
- Silent gpt2 fallback in the agents-converse router when `STATESET_DEFAULT_CHECKPOINT` was set but the startup hook failed — now logs a diagnostic warning so users see what happened.

### Documentation
- README sections "Chat with your fine-tune locally", "Curate good examples", "Scaffold a fine-tuning project", "Benchmark your fine-tune" document the new developer journey.
- CHANGELOG promoted from `[Unreleased]` to `[0.11.7]` for the empirical-results pipeline, then to `[0.11.8]` for the curation work.

## [0.11.7] - 2026-05-14 — Platform empirical-results pipeline

### Added
- **`stateset_agents.utils.reproducibility`** — central `set_all_seeds()` that seeds Python `random`, NumPy, PyTorch (CPU + CUDA), and Transformers in one call. Singleton `REPRODUCIBILITY_STATE` records what was seeded.
- **`stateset_agents.data.gsm8k`** — GSM8K loader (`load_gsm8k`), gold/predicted answer parsers, and a `GSM8KReward` verifier reward function for single-turn verifiable-reward training.
- **`stateset_agents.data.customer_support_bench`** — bundled 24-scenario multi-turn customer-support corpus across 4 intents (refund / technical / billing / general). `SupportRewardComposite` ships a three-signal rule-based reward (intent ack + brand voice + safety multiplier).
- **`stateset_agents.data.tool_calling_bench`** — bundled 8-scenario tool-calling corpus, 3 sample tools (weather / calculator / search), and a `ToolCallReward` composite (tool selection 40% + parameter correctness 30% + outcome substring 30%). Completes the framework's three-pillar benchmark coverage.
- **`stateset_agents.scaffolding`** — `scaffold_project()` and 4 starter templates (`customer-support`, `gsm8k-math`, `tool-calling-agent`, `minimal`) with full file scaffolds: config.yaml, scenarios.jsonl, reward.py, train.py, eval.py, serve.sh, README.md. `--client-name` flag slugifies into output_dir paths and the W&B project name throughout.
- **CLI subcommands** — `stateset-agents starter <template> <output>` and `stateset-agents benchmark {smoke,phase0,plot,aggregate}`. `stateset-agents serve` gained `--checkpoint` and `--base-model` flags to close the train→serve loop.
- **`scripts/run_phase0_benchmark.py`** — runner with `TaskAdapter` interface (`GSM8KAdapter`, `CustomerSupportAdapter`, `ToolCallingAdapter`). Records baseline + config in schema-compliant JSON per `benchmark_results/SCHEMA.md`.
- **`scripts/aggregate_phase0_results.py`** — reads JSONs, groups by (trainer, model), applies publication gates (3 seeds, σ < 0.10, +0.03 improvement, single commit), emits `summary.md` + `summary.csv` + `passes_gates.json`. Returns exit 1 under `--strict` if any group fails.
- **`scripts/plot_phase0_results.py`** — produces two publication PNGs (pass@1 per trainer with seed-variance error bars, improvement ranking with publication-gate line). Graceful matplotlib-less fallback to a markdown text table.
- **`scripts/release_v1_whitepaper.py`** — one-shot v1.0 release packager. Aggregates → plots → generates the whitepaper §11.7 markdown snippet → copies figures into `docs/figures/` → writes a provenance manifest.
- **Three Colab notebooks** under `notebooks/`:
  - `whitepaper_v1_gsm8k_benchmark.ipynb` — GSM8K + GSPO showcase (~45min on A100)
  - `customer_support_4h.ipynb` — multi-turn customer-support showcase (~3h on A100)
  - `tool_calling_agent_demo.ipynb` — tool-calling showcase (~2h on A100)
- **Makefile targets** — `smoke` (umbrella), `benchmark-smoke`, `benchmark-phase0`, `benchmark-phase0-all`, `benchmark-aggregate`, `benchmark-aggregate-strict`, `benchmark-plot`, `benchmark-publish`, `release-whitepaper-v1`, `release-whitepaper-v1-strict`, `serve-trained`, `starter-test`.
- **CI workflow** — `.github/workflows/benchmark-smoke.yml` runs the full unit-test suite, end-to-end benchmark smoke, scaffold-smoke per template, notebook JSON validation, and `make starter-test` on every relevant PR. ~3 min, no GPU.
- **134 new unit tests** across `test_gsm8k.py`, `test_reproducibility.py`, `test_aggregate_phase0_results.py`, `test_customer_support_bench.py`, `test_tool_calling_bench.py`, `test_task_adapters.py`, `test_scaffolding.py`.

### Fixed
- Earlier Colab notebooks called `GSPOTrainer(config, agent, environment)` but the trainer's actual `__init__` requires `(config, model, tokenizer, agent, environment, reward_model)`. Switched both notebooks to the canonical `train_with_gspo()` high-level entry point.

### Documentation
- README sections "Scaffold a fine-tuning project in 30 seconds" and "Benchmark your fine-tune" document the new developer journey from clone → train → benchmark → serve.
- `benchmark_results/SCHEMA.md` — canonical result JSON schema + publication gates.
- `benchmark_results/README.md` — practitioner-facing pipeline reference.
- Whitepaper appendix C ("Reproducibility Commands") gained the full benchmark-pipeline command list.

## [0.11.6] - 2026-04-20

### Changed
- Expanded the blocking mypy surface from 14 to 35 files, enforcing `disallow_untyped_defs` + `disallow_incomplete_defs` across the highest-traffic core and training modules: `agent`, `agent_backends`, `agent_config`, `trajectory`, `reward_base`, `basic_rewards`, `domain_rewards`, `reward_factories`, `environment`, `environment_base`, `conversation_environment`, `multiturn_agent`, `input_validation`, `memory`, `errors`, `base_trainer`, `trl_grpo_trainer`, `gspo_trainer`, `dapo_trainer`, `gepo_trainer`, and `vapo_trainer`.
- Fixed ~64 strict-mode type violations across the newly gated modules (missing return annotations, untyped `*args`/`**kwargs`, bare `Callable`/`list` generics, `Any | None` declarations for lazy-loaded transformers/peft globals, and `None`-callable narrowing around the optional PEFT loader).

### Fixed
- Realigned deployment artifacts (helm chart, Kubernetes training/production manifests, README, benchmark/autopilot docs) with the released package version so `test_helm_values_use_current_package_version` and `test_selected_kubernetes_and_docs_refs_use_current_package_version` pass on `master`.

## [0.11.1] - 2026-04-02

### Added
- First-class `gemma-4-31b` starter support across packaged training helpers, CLI entrypoints, presets, examples, and regression tests.
- Repo hygiene checks for generated artifacts, backup files, and local tool state, enforced in local workflows and CI.
- A canonical-import regression test to prevent new code from depending on deprecated top-level shim modules.

### Changed
- Bumped the package version to `0.11.1` in package metadata and runtime exports.
- Removed tracked backup files and local autoresearch state from the repository, and tightened contributor guidance around maintenance policy.

## [0.11.0] - 2026-04-02

### Added
- Expo-powered mobile training console under `mobile/` with dashboard, runs, datasets, models, and run-detail screens tailored to RL fine-tuning workflows.
- Mobile data layer that reads live training-lab endpoints when available and falls back to curated mock runs, datasets, models, algorithms, and environments for preview mode.
- Auto-research workflow support for tracking recent training-quality search iterations and benchmark outcomes.

### Changed
- Bumped the package version to `0.11.0` in package metadata and runtime exports.
- Scoped `.gitignore` patterns for `lib/`, `models/`, and `runs/` to the repository root so mobile source files can be tracked and released normally.

## [0.5.0] - 2025-10-19

### Added
- Unit coverage for CLI stub mode, monitoring health checks, and stub backend factories to protect critical workflows.

### Changed
- Extracted stub tokenizer/model scaffolding into `core.agent_backends`, keeping `core.agent` focused on orchestration.
- Modernised test fixtures and README/RELEASE_NOTES to document the new backend module and verification steps.

### Fixed
- Hardened optional dependency guards in performance optimisers and monitoring utilities so imports fail gracefully with actionable guidance.
- Replaced deprecated `asyncio.coroutine` usage in health checks with loop-aware execution that supports sync or async callables.

## [0.4.0] - 2025-10-05

### Added
- End-to-end stub mode surfaced in CLI and examples for fast demos and CI validation.
- Regression coverage ensuring stub responses flow through the computational engine and raw prompt paths.

### Changed
- Standardised all internal and external imports on the `stateset_agents.*` namespace to smooth integration.
- Refreshed documentation and CLI messaging to highlight the stub workflow.

## [0.3.3] - 2025-09-04

## [0.3.4] - 2025-09-22

### Fixed
- Made `stateset_agents.core` proxy resilient to missing optional dependencies by wrapping `async_pool` import in a safe try/except. This prevents import-time failures when `aiohttp` is not installed and allows tests and consumers to import the package without optional extras.

### Changed
- Bumped package version to `0.3.4` in `pyproject.toml` and `stateset_agents/__init__.py` to keep versions in sync.

### Notes
- No API changes; this release improves import robustness and packaging hygiene only.

### Changed
- Refactored `training` package imports to absolute paths (`core.*`, `utils.*`, `rewards.*`) so `import training` works directly from installed packages
- CI publish workflow hardened: idempotent uploads (`twine upload --skip-existing`), resilient tag creation, and Docker/docs jobs also run on GitHub release events

### Fixed
- Resolved import errors when using `training` modules from PyPI install
- Ensured packaged distribution includes all required top-level modules used by `stateset_agents`

### Publishing
- Released `stateset-agents==0.3.3` to PyPI

## [0.3.2] - 2025-09-04

### Added
- Packaged top-level implementation modules with the library: `core`, `rewards`, `utils`, `api`, `environments`, and a lightweight `grpo_agent_framework` proxy

### Fixed
- Added proxy module for `stateset_agents.core` to forward to top-level `core` package to avoid duplication while enabling stable imports

### Publishing
- Released `stateset-agents==0.3.2` to TestPyPI and PyPI

## [0.3.1] - 2024-12-XX

### Added
- **Code Quality Tools**: Comprehensive code quality setup with Black, isort, Ruff, mypy, and pre-commit hooks
- **CI/CD Pipeline**: GitHub Actions workflows for automated testing, linting, security scanning, and publishing
- **Development Tools**: Makefile with common development tasks and comprehensive pyproject.toml configuration
- **Documentation**: Code of Conduct and Contributing guidelines for community standards
- **Security**: Bandit security linting and dependency vulnerability scanning
- **Benchmarking**: Automated performance benchmarking with historical tracking
- **Dependency Management**: Dependabot configuration for automated dependency updates

### Changed
- **Package Consistency**: Standardized all imports to use `stateset_agents` namespace consistently
- **Documentation**: Updated all examples and documentation to use correct import paths
- **Testing**: Enhanced pytest configuration with coverage thresholds and better markers
- **Project Structure**: Improved .gitignore and development file organization

### Fixed
- Import inconsistencies between `grpo_agent_framework` and `stateset_agents` packages
- Missing development dependencies and tools
- Inconsistent code formatting and style

### Developer Experience
- Added comprehensive Makefile for common tasks (`make help` to see all commands)
- Pre-commit hooks for automated code quality checks
- Enhanced testing with coverage reporting and multiple test categories
- Improved documentation with clear contribution guidelines

## [0.3.0] - 2024-01-XX

### Added
- **Enhanced Error Handling & Resilience**
  - Comprehensive exception hierarchy for training, model, data, network, and resource errors
  - Configurable async retry with exponential backoff and jitter
  - Circuit breaker pattern for automatic failure detection and recovery
  - Rich error context with stack traces, categories, and recovery suggestions

- **Performance Optimization**
  - Real-time memory monitoring with automatic cleanup and optimization
  - Dynamic batch sizing based on resource availability
  - PyTorch 2.0 compilation support for faster inference
  - Mixed precision training with automated FP16/BF16 optimization

- **Type Safety & Validation**
  - Runtime type checking for all framework components
  - Type-safe configuration with detailed error reporting
  - Reliable serialization/deserialization with type preservation
  - Clear protocol interfaces for extensible components

- **Advanced Async Resource Management**
  - High-performance async resource pools with health checking
  - Sophisticated async task scheduling with resource limits
  - Automatic resource cleanup and scaling
  - Real-time monitoring of resource utilization

- **Production Monitoring**
  - Comprehensive performance tracking and reporting
  - Automated system health monitoring and alerting
  - Dynamic optimization recommendations
  - Advanced debugging and profiling capabilities

### Changed
- Enhanced production-ready configuration and deployment
- Improved async resource management patterns
- Better error handling and recovery mechanisms
- More comprehensive monitoring and observability

## [0.2.0] - 2023-11-XX

### Added
- Multi-turn conversation support with trajectory tracking
- Domain-specific reward functions (Customer Service, Technical Support, Sales)
- Neural reward models that learn from trajectory data
- Distributed training capabilities
- Advanced data processing pipeline
- TRL GRPO integration for large model fine-tuning

### Changed
- Enhanced training infrastructure with better stability
- Improved reward modeling system
- Better environment abstractions

## [0.1.0] - 2023-08-XX

### Added
- Initial GRPO training framework
- Basic agent and environment classes
- Core reward functions
- Simple training pipeline
- Documentation and examples

### Changed
- Initial release with core functionality
