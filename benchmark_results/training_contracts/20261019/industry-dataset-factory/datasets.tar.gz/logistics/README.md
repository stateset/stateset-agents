# Synthetic logistics policy dataset

These are fictional, mechanically checked tool-workflow examples, not reviewed customer data.
Train only on train.jsonl. validation.jsonl is for selection; test.jsonl stays reserved.
cases/ contains private synthetic simulation facts and family annotations.
Messages teach lookup, a policy-grounded resolution, and explicit finish.

Preview through the existing industry trainer without loading a model:

    stateset-agents industry train ./logistics --dry-run

For generic remote SFT, pass train.jsonl to train-remote. No provider jobs are launched by generation.
The existing industry evaluator checks reference agreement on validation; its synthetic-data gate remains a failure.
The strict text-only Studio dataset picker does not accept these provenance-rich rows. Use the industry or remote CLI.
Replace or supplement training examples with reviewed, permissioned conversations before production claims.
