"""Retain a credential-free, byte-verified archive of the completed comparison."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
TARGET = REPO / "benchmark_results/training_contracts/20261020/river-delegation-pilot"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    review = read(ROOT / "review-summary.json")
    assert review["passed"]
    assert read(ROOT / "execution-summary.json")["exit_code"] == 0
    TARGET.mkdir(parents=True, exist_ok=False)
    inputs = [
        p
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    ]
    secret_pattern = re.compile(rb"rv_[A-Za-z0-9_-]{32,}")
    for path in inputs:
        assert not secret_pattern.search(
            path.read_bytes()
        ), "Credential-like content cannot be retained"
    archive = TARGET / "run.tar.gz"
    with tarfile.open(archive, "w:gz") as output:
        for path in inputs:
            output.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(archive) as saved:
        members = saved.getmembers()
        assert len(members) == len(inputs)
        for member in members:
            assert member.isfile()
            data = saved.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == sha(ROOT / member.name)
    for name in (
        "plan.json",
        "execution-summary.json",
        "result.json",
        "review-summary.json",
        "validation-decision.json",
        "test-decision.json",
        "rollout-budget.json",
        "preflight-live.json",
        "prior-evidence-verified.json",
        "unit-tests.xml",
        "protocol-gate-tests.xml",
        "resource-comparison.json",
    ):
        if (ROOT / name).exists():
            shutil.copyfile(ROOT / name, TARGET / name)
    archived_inputs = {str(p.relative_to(ROOT)): sha(p) for p in inputs}
    (TARGET / "archive-inputs.json").write_text(
        json.dumps(archived_inputs, indent=2, sort_keys=True) + "\n"
    )
    result = read(ROOT / "result.json")
    lines = [
        "# River refund delegation comparison — October 20, 2026",
        "",
        "Exploratory inference-only comparison of the same fixed Qwen/Qwen3.5-9B",
        "arithmetic-candidate checkpoint under raw-model and delegated-tool protocols.",
        "This measures agent-system behavior; tool-selected policy and arithmetic",
        "do not establish model learning. No training or model promotion occurred.",
        "",
        "| Split | Raw | Delegated | Raw violation rate | Delegated violation rate |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for split in ("validation", "test"):
        if f"raw-{split}" not in review["summaries"]:
            continue
        raw, delegated = (
            review["summaries"][f"{arm}-{split}"] for arm in ("raw", "delegated")
        )
        lines.append(
            f"| {split} | {raw['passed']}/{raw['total']} | {delegated['passed']}/{delegated['total']} | {raw['violation_rate']:.2%} | {delegated['violation_rate']:.2%} |"
        )
    lines.extend(
        [
            "",
            f"Declared safety/nonregression gates passed: **{result['accepted']}**.",
            f"Independent replay checked **{review['replayed_outcomes']} outcomes** and reconstructed",
            "all 244 fresh input cases. Both intent and actual tool execution evidence",
            "were checked, including receipts, observations, metrics, and terminal states.",
            "",
            "Both arms used greedy sampling, four model turns, and 1,024 output tokens",
            "per trajectory. Prompts and tools differ intentionally. Validation gates",
            "cover overall, family, suite, and suite-family cells. Both arm attempts",
            "were sealed before each split's sampling; test required validation success.",
            "",
            "The run allowed one attempt, disabled provider retries, bounded worker time",
            "to 20 minutes, and reserved at most 499,712 output tokens. This is an output",
            "admission bound, not a dollar cap. Actual billed cost was unavailable.",
            "",
            f"All **{review['prior_artifacts_unchanged']} earlier retained artifacts** matched their",
            "published hashes. The prior arithmetic pilot's 308 test cases were excluded",
            "from this study and remain unattempted.",
            "",
            "Local verification: 1,024 unit/regression checks passed, one skipped;",
            "Eight additional protocol gate checks passed. Also, 20 native River SDK",
            "checks passed with scripted transport and no paid",
            "clients; type checking passed for 451 packaged source files. The archive",
            "includes the full frozen runtime, exact inputs, attempt seals, outcome",
            "traces, offline audit scripts, and the unit-test XML report.",
            "",
            f"Archive byte verification checked **{len(inputs)} files**. Local hashes",
            "provide consistency checks, not independent provider attestation.",
            "",
            "This single-checkpoint study uses fictional synthetic policies. It does",
            "not establish production A+ quality, independently reviewed merchant",
            "generalization, live payment idempotency, or optimizer recovery.",
            "",
        ]
    )
    if (ROOT / "test-decision.json").exists():
        resources = read(ROOT / "resource-comparison.json")["test"]
        lines.extend(
            [
                "## Observed test efficiency",
                "",
                f"Output tokens fell from **{resources['raw_generated_tokens']:,}** to",
                f"**{resources['delegated_generated_tokens']:,}** ({resources['generated_token_reduction']:.1%} fewer).",
                f"Median trajectory time was **{resources['raw_median_case_seconds']:.2f} s** for raw",
                f"and **{resources['delegated_median_case_seconds']:.2f} s** for delegated.",
                "Timing reflects this concurrent provider run, not a controlled latency benchmark.",
                "",
                "Model-requested tool turns fell from three to two per case; both",
                "protocols still executed three backend actions per case (lookup,",
                "resolution, finish). Both arms passed every case, so this run shows",
                "an observed output-efficiency gain and no measured accuracy gain.",
                "",
            ]
        )
    (TARGET / "README.md").write_text("\n".join(lines))
    artifacts = {p.name: sha(p) for p in sorted(TARGET.iterdir()) if p.is_file()}
    (TARGET / "artifacts.sha256.json").write_text(
        json.dumps(artifacts, indent=2, sort_keys=True) + "\n"
    )
    for name, digest in artifacts.items():
        assert sha(TARGET / name) == digest
    print(
        json.dumps(
            {
                "retained": str(TARGET.relative_to(REPO)),
                "artifacts": len(artifacts),
                "archive_files_verified": len(inputs),
            }
        )
    )


if __name__ == "__main__":
    main()
