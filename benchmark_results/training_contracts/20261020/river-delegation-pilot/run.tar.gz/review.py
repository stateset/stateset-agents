"""Independently check the fixed-checkpoint comparison without provider calls."""

import asyncio
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

import experiment as study
from stateset_agents.core.environments.refund_policy_environment import (
    RefundPolicyEnvironment,
    refund_policy_benchmark,
)
from stateset_agents.data.refund_arithmetic_stress import refund_arithmetic_stress_cases
from stateset_agents.data.refund_stress import refund_policy_stress_cases
from stateset_agents.evaluation.agent_runs import content_hash, validate_report
from stateset_agents.remote.river_rl import atomic_json


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


async def main():
    plan = study.validate(ROOT)
    history = read(ROOT / "historical-sources.json")
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in history.items():
        assert sha(REPO / name) == digest
        rows = read(REPO / name)
        if isinstance(rows, list):
            excluded.extend(
                r for r in rows if isinstance(r, dict) and "return_window_days" in r
            )
    fingerprint = RefundPolicyEnvironment.case_fingerprint
    ids = {r["order_id"] for r in excluded}
    facts = {fingerprint(r) for r in excluded}
    working = list(excluded)
    for split, count, window, quantum in (
        ("validation", 32, 18, 10),
        ("test", 128, 25, 100),
    ):
        ordinary = refund_policy_benchmark(split, count=count, seed=plan["case_seed"])
        working.extend(ordinary)
        windows = refund_policy_stress_cases(
            split, seed=plan["case_seed"], windows=(window,), excluded=working
        )
        working.extend(windows)
        arithmetic = refund_arithmetic_stress_cases(
            split,
            seed=plan["case_seed"],
            windows=(window,),
            quantum=quantum,
            excluded=working,
        )
        working.extend(arithmetic)
        rows = read(ROOT / f"{split}.json")
        assert content_hash(rows) == content_hash(
            sorted(ordinary + windows + arithmetic, key=lambda r: r["order_id"])
        )
        assert (
            len({r["order_id"] for r in rows})
            == len({fingerprint(r) for r in rows})
            == len(rows)
        )
        assert not ids & {r["order_id"] for r in rows}
        assert not facts & {fingerprint(r) for r in rows}
        ids.update(r["order_id"] for r in rows)
        facts.update(fingerprint(r) for r in rows)
    execution = read(ROOT / "execution-summary.json")
    assert execution["exit_code"] == 0 and execution["timed_out"] is False
    result = read(ROOT / "result.json")
    expected_splits = (
        ("validation", "test") if result["test_attempted"] else ("validation",)
    )
    summaries, replayed = {}, 0
    for split in expected_splits:
        cases = read(ROOT / f"{split}.json")
        by_id = {row["order_id"]: row for row in cases}
        reports = {arm: read(ROOT / f"{arm}-{split}.json") for arm in study.ARMS}
        for arm, report in reports.items():
            expected_environment = (
                "refund-delegation-v1" if arm == "delegated" else "refund-policy-v2"
            )
            assert report["environment"] == expected_environment
            assert report["case_families"] == {
                key: row["family"] for key, row in by_id.items()
            }
            summary = validate_report(report, expected_split=split)
            assert all(report[key] == value for key, value in summary.items())
            assert report["implementation"] == plan["implementation"]
            assert report["settings"] == plan["evaluation"]
            assert report["selected_checkpoint"]["path"] == plan["checkpoint"]
            await study.audit_report(report, cases)
            replayed += len(report["outcomes"])
            seal = read(ROOT / f"{arm}-{split}-attempt.json")
            assert seal["plan_hash"] == plan["plan_hash"]
            assert seal["case_sha256"] == plan["input_sha256"][f"{split}.json"]
            summaries[f"{arm}-{split}"] = {
                key: summary[key]
                for key in (
                    "total",
                    "passed",
                    "violation_rate",
                    "truncation_rate",
                    "generated_tokens",
                    "tool_calls",
                    "trajectory_seconds",
                )
            }
            summaries[f"{arm}-{split}"]["executed_tool_calls"] = sum(
                o["executed_tool_calls"] for o in report["outcomes"]
            )
        # Recompute each declared cell independently of the runner's gate code.
        recorded = read(ROOT / f"{split}-decision.json")
        cells = {"overall": list(by_id)}
        for key, row in by_id.items():
            suite = (
                "arithmetic"
                if "arithmetic_stress" in row
                else "window" if "stress" in row else "ordinary"
            )
            for cell in (
                f"family:{row['family']}",
                f"suite:{suite}",
                f"suite-family:{suite}:{row['family']}",
            ):
                cells.setdefault(cell, []).append(key)
        outcomes = {
            arm: {o["case_id"]: o for o in reports[arm]["outcomes"]}
            for arm in study.ARMS
        }
        independently_passed = True
        assert set(recorded["cells"]) == set(cells)
        for name, keys in cells.items():
            raw = sum(outcomes["raw"][key]["success"] for key in keys)
            delegated = sum(outcomes["delegated"][key]["success"] for key in keys)
            violations = sum(
                outcomes["delegated"][key]["policy_violations"] > 0 for key in keys
            )
            truncated = sum(
                outcomes["delegated"][key]["truncated"] is not None for key in keys
            )
            expected = {
                "total": len(keys),
                "raw_passed": raw,
                "delegated_passed": delegated,
                "delegated_violations": violations,
                "delegated_truncated": truncated,
                "passed": delegated >= raw and violations == truncated == 0,
            }
            assert recorded["cells"][name] == expected
            independently_passed &= expected["passed"]
        assert recorded["passed"] == independently_passed
    budget = read(ROOT / "rollout-budget.json")
    resources = read(ROOT / "resource-comparison.json")
    for split in expected_splits:
        reports = {arm: read(ROOT / f"{arm}-{split}.json") for arm in study.ARMS}
        raw, delegated = reports["raw"], reports["delegated"]
        expected = {
            "raw_generated_tokens": raw["generated_tokens"],
            "delegated_generated_tokens": delegated["generated_tokens"],
            "generated_token_reduction": 1
            - delegated["generated_tokens"] / raw["generated_tokens"],
            "raw_model_tool_calls": raw["tool_calls"],
            "delegated_model_tool_calls": delegated["tool_calls"],
            "raw_trajectory_seconds": raw["trajectory_seconds"],
            "delegated_trajectory_seconds": delegated["trajectory_seconds"],
            "raw_median_case_seconds": statistics.median(
                o["elapsed_seconds"] for o in raw["outcomes"]
            ),
            "delegated_median_case_seconds": statistics.median(
                o["elapsed_seconds"] for o in delegated["outcomes"]
            ),
            "backend_tool_calls": {
                arm: sum(o["executed_tool_calls"] for o in report["outcomes"])
                for arm, report in reports.items()
            },
        }
        assert content_hash(expected) == content_hash(resources[split])
    assert budget["fingerprint"] == plan["plan_hash"]
    assert budget["admitted_trajectories"] == replayed
    assert (
        budget["reserved_generated_tokens"]
        == replayed * 1024
        <= plan["limits"]["reserved_output_tokens"]
    )
    assert read(ROOT / "validation-decision.json")["passed"] == result["test_attempted"]
    final_gate = read(ROOT / f"{expected_splits[-1]}-decision.json")["passed"]
    assert final_gate == result["accepted"]
    if not result["test_attempted"]:
        assert not any(
            (ROOT / f"{arm}-test-attempt.json").exists() for arm in study.ARMS
        )
    prior = REPO / "outputs/river-arithmetic-pilot-20261020"
    assert len(read(prior / "data/test.json")) == 308
    assert not any(
        (prior / f"{arm}-test-attempt.json").exists()
        for arm in ("control", "arithmetic")
    )
    preserved = {}
    for index in sorted(
        (REPO / "benchmark_results/training_contracts").rglob("artifacts.sha256.json")
    ):
        if (
            index.parent
            == REPO
            / "benchmark_results/training_contracts/20261020/river-delegation-pilot"
        ):
            continue
        for name, digest in read(index).items():
            path = index.parent / name
            assert sha(path) == digest
            preserved[str(path.relative_to(REPO))] = digest
    atomic_json(ROOT / "prior-evidence-verified.json", preserved)
    review = {
        "passed": True,
        "plan_hash": plan["plan_hash"],
        "replayed_outcomes": replayed,
        "reconstructed_fresh_cases": 244,
        "previous_unattempted_test_cases": 308,
        "historical_source_files": len(history),
        "prior_artifacts_unchanged": len(preserved),
        "training_updates": 0,
        "provider_calls_during_review": 0,
        "cost_usd": None,
        "summaries": summaries,
        "accepted": result["accepted"],
    }
    atomic_json(ROOT / "review-summary.json", review)
    print(json.dumps(review), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
