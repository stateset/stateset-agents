"""Frozen six-seed replication of the one-update River recovery RL pilot."""

import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from dataclasses import asdict
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from stateset_agents.core.environments.refund_policy_environment import (
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import refund_recovery_cases
from stateset_agents.evaluation.agent_runs import content_hash
from stateset_agents.evaluation.implementation import package_implementation
from stateset_agents.evaluation.replication import paired_seed_case_summary
from stateset_agents.remote.river_rl import atomic_json, exclusive_run
from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget

MODEL = "Qwen/Qwen3.5-9B"
SEEDS = tuple(range(2026110001, 2026110007))
STAGES = (
    ("greedy-validation", 80, 1),
    ("stochastic-validation", 20, 4),
    ("test", 40, 4),
)
ARMS = ("parent", "rl")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def support(root, name):
    spec = importlib.util.spec_from_file_location(
        "six_seed_" + name, root / "runtime" / (name + ".py")
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def seal(root, name, value):
    support(root, "controller").seal(root / name, value)


def seed_root(root, seed):
    assert seed in SEEDS
    return root / "seeds" / str(seed)


def phase_plan(root, plan, seed):
    return {
        "plan_hash": plan["plan_hash"],
        "parent_checkpoint": plan["parent_checkpoint"],
        "settings": plan["settings"],
        "seed": seed,
    }


def parent_checkpoint(plan):
    from river_client import Checkpoint

    return Checkpoint(
        path=plan["parent_checkpoint"], step=10, checkpoint_type="inference"
    )


async def prepare(root, repo):
    assert not (root / "plan.json").exists()
    previous = repo / "outputs/river-recovery-rl-pilot-20261020"
    retained = (
        repo / "benchmark_results/training_contracts/20261020/river-recovery-rl-pilot"
    )
    assert all(
        sha(retained / name) == digest
        for name, digest in read(retained / "artifacts.sha256.json").items()
    )
    assert read(previous / "review-summary.json")["accepted"]
    old_plan = read(previous / "plan.json")
    assert sha(previous / "plan.json") == sha(retained / "plan.json")
    assert (
        content_hash(
            {key: value for key, value in old_plan.items() if key != "plan_hash"}
        )
        == old_plan["plan_hash"]
    )
    for name, digest in old_plan["input_sha256"].items():
        assert sha(previous / name) == digest
    assert (
        sha(previous / "runtime/experiment.py")
        == old_plan["runner_sha256"]["experiment"]
    )
    root.mkdir(exist_ok=True)
    for name in ("train.json", "train-source.json", "train-selection.json"):
        shutil.copyfile(previous / name, root / name)
    shutil.copytree(previous / "parent", root / "parent")
    assert sha(root / "parent/river_checkpoint.json") == sha(
        retained / "parent-checkpoint.json"
    )
    history = read(previous / "historical-sources.json")
    for stage, _, _ in STAGES:
        path = previous / f"{stage}.json"
        history[str(path.relative_to(repo))] = sha(path)
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in history.items():
        assert sha(repo / name) == digest
        rows = read(repo / name)
        if isinstance(rows, list):
            excluded.extend(
                row
                for row in rows
                if isinstance(row, dict) and "return_window_days" in row
            )
    rejected = []
    for attempt in range(100):
        case_seed = 2026110101 + 100 * attempt
        working, proposed = list(excluded), {}
        try:
            for index, (stage, count, _) in enumerate(STAGES):
                rows = refund_recovery_cases(
                    "test" if stage == "test" else "validation",
                    count=count,
                    seed=case_seed + index,
                    excluded=working,
                )
                proposed[stage] = rows
                working.extend(rows)
        except ValueError as exc:
            if "overlap" not in str(exc).lower():
                raise
            rejected.append({"seed": case_seed, "reason": str(exc)})
            continue
        break
    else:
        raise ValueError("No disjoint prospective dataset among 100 input seeds")
    atomic_json(root / "historical-sources.json", history)
    for stage, rows in proposed.items():
        atomic_json(root / f"{stage}.json", rows)
    runtime = root / "runtime"
    implementation = package_implementation()
    assert {
        name: digest
        for name, digest in implementation["files"].items()
        if name != "evaluation/replication.py"
    } == old_plan["implementation"]["files"]
    for name, digest in implementation["files"].items():
        source, target = (
            repo / "stateset_agents" / name,
            runtime / "stateset_agents" / name,
        )
        assert sha(source) == digest
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    shutil.copyfile(__file__, runtime / "experiment.py")
    shutil.copyfile(previous / "runtime/experiment.py", runtime / "pilot.py")
    for name in ("recovery", "diagnostics", "controller"):
        shutil.copyfile(previous / "runtime" / (name + ".py"), runtime / (name + ".py"))
    inputs = [
        "parent/river_checkpoint.json",
        "parent/stateset_manifest.json",
        "train.json",
        "train-source.json",
        "train-selection.json",
        "historical-sources.json",
    ]
    inputs.extend(f"{stage}.json" for stage, _, _ in STAGES)
    for seed in SEEDS:
        directory = seed_root(root, seed)
        (directory / "runtime").mkdir(parents=True)
        shutil.copyfile(root / "train.json", directory / "train.json")
        inputs.append(str((directory / "train.json").relative_to(root)))
        for name in ("recovery", "diagnostics", "controller"):
            target = directory / "runtime" / (name + ".py")
            shutil.copyfile(runtime / (name + ".py"), target)
            inputs.append(str(target.relative_to(root)))
    plan = {
        "schema_version": 1,
        "kind": "prespecified-six-seed-recovery-rl-replication",
        "base_model": MODEL,
        "seeds": list(SEEDS),
        "case_seed": case_seed,
        "parent_checkpoint": old_plan["parent_checkpoint"],
        "implementation": implementation,
        "training": old_plan["training"],
        "settings": old_plan["settings"],
        "stages": old_plan["stages"],
        "required_server_features": old_plan["required_server_features"],
        "input_sha256": {name: sha(root / name) for name in inputs},
        "runner_sha256": {
            name: sha(runtime / (name + ".py"))
            for name in ("experiment", "pilot", "recovery", "diagnostics", "controller")
        },
        "dataset_protocol": "One shared fresh case set across all seeds; same cases and rollout seeds paired within each parent/RL arm. All prior train/prepared/evaluated facts and IDs excluded. Training cases unchanged; no prior rollout replay.",
        "cohort_protocol": [
            "Six fixed seed attempts, each from the same SFT parent with a fresh optimizer; no new SFT",
            "One native training batch per seed, at most one optimizer update; no replacement for zero-signal, failed, or uncertain attempts",
            "All six training/validation attempts run even if another seed fails; never exclude a seed to report success",
            "All six seeds require one acknowledged update plus both original validation gates before ANY test arm is sealed",
            "Freeze all six final checkpoints and seal all twelve test arms before ANY test sampling",
            "Once admitted, attempt every seed's test without selection or stopping on another seed's scores",
            "No automatic production promotion or best-seed nomination from test",
        ],
        "analysis": {
            "primary": "Paired test success-rate difference conditional on shared synthetic cases",
            "analysis_seed": 2026110201,
            "bootstrap_replicates": 10000,
            "exact_test": "Two-sided sign flips of six training-seed paired deltas, all 64 patterns; ties retained",
            "p_threshold": 0.05,
            "interval": "95% percentile bootstrap over training seeds and shared cases resampled within each family; four within-case rollouts aggregated first",
            "bootstrap_lower_must_exceed": 0.0,
            "required": "All six seeds must pass the unchanged pilot test gate, plus exact p<=0.05 and bootstrap lower bound>0; no skipped/missing seeds",
        },
        "limits": {
            "wall_seconds": 4200,
            "phase_worker_wall_seconds": 1500,
            "max_parallel_seed_workers": 3,
            "request_timeout_seconds": 180,
            "max_optimizer_updates": 6,
            "max_trajectories": 4296,
            "trajectories_per_seed": 716,
            "reserved_output_tokens": 4296 * 1024,
            "reserved_output_tokens_per_seed": 716 * 1024,
            "provider_retries": False,
            "attempts_per_phase": 1,
            "sampler_concurrency_per_arm": 6,
        },
        "rejected_input_seeds": rejected,
        "quality_certification": False,
        "cost_usd": None,
        "dollar_cap_enforced": False,
        "scope": "Replication conditional on one fixed SFT parent and synthetic case generator. Neither independent merchants nor reviewed production data. Missing reviewed industry data cannot be replaced by fixtures.",
    }
    plan["plan_hash"] = content_hash(plan)
    atomic_json(root / "plan.json", plan)
    return {
        "prepared": True,
        "plan_hash": plan["plan_hash"],
        "seeds": plan["seeds"],
        "limits": plan["limits"],
        "analysis": plan["analysis"],
    }


def validate(root):
    plan = read(root / "plan.json")
    assert (
        content_hash({key: value for key, value in plan.items() if key != "plan_hash"})
        == plan["plan_hash"]
    )
    assert (
        plan["seeds"] == list(SEEDS)
        and package_implementation() == plan["implementation"]
    )
    assert sha(__file__) == plan["runner_sha256"]["experiment"]
    for name, digest in plan["input_sha256"].items():
        assert sha(root / name) == digest
    for name, digest in plan["runner_sha256"].items():
        assert sha(root / "runtime" / (name + ".py")) == digest
    for name, digest in plan["implementation"]["files"].items():
        assert sha(root / "runtime/stateset_agents" / name) == digest
    return plan


async def evaluation_arm(
    root, plan, directory, seed, session, renderer, checkpoint, budget, arm, stage
):
    from dataclasses import asdict

    pilot, helper, diagnostic = (
        support(root, name) for name in ("pilot", "recovery", "diagnostics")
    )
    helper.SEED = seed
    rows = read(root / f"{stage}.json")
    size = 1 if stage == "greedy-validation" else 4
    output = directory / f"{arm}-{stage}"
    output.mkdir(exist_ok=False)
    result = await helper.collect(
        output, plan, session, renderer, checkpoint, rows, budget, probe=size == 4
    )
    groups = [[o] for o in result] if size == 1 else result
    cases = {row["order_id"]: row for row in rows}
    ds = [
        [
            await diagnostic.diagnose(cases[o["case_id"]], o["environment_trace"])
            for o in group
        ]
        for group in groups
    ]
    settings = {
        **plan["settings"],
        "temperature": 0 if size == 1 else 1.0,
        "group_size": size,
        "top_p": 1.0,
        "top_k": -1,
    }
    report = {
        "plan_hash": plan["plan_hash"],
        "environment": "refund-recovery-v1",
        "stage": stage,
        "seed": seed,
        "arm": arm,
        "checkpoint": asdict(checkpoint),
        "implementation": plan["implementation"],
        "group_size": size,
        "temperature": settings["temperature"],
        "settings": settings,
        "case_hashes": {key: content_hash(row) for key, row in cases.items()},
        "groups": groups,
        "diagnostics": ds,
        "summary": pilot.summarize(groups, rows, ds),
    }
    atomic_json(directory / f"{arm}-{stage}.json", report)
    return report


def arm_seal(plan, checkpoint, stage):
    return {
        "plan_hash": plan["plan_hash"],
        "checkpoint": asdict(checkpoint),
        "case_sha256": plan["input_sha256"][f"{stage}.json"],
    }


async def evaluate_stage(
    root, plan, directory, seed, session, renderer, checkpoints, budget, stage
):
    for arm in ARMS:
        expected = arm_seal(plan, checkpoints[arm], stage)
        path = directory / f"{arm}-{stage}-attempt.json"
        if stage == "test":
            assert read(path) == expected
        else:
            seal(root, str(path.relative_to(root)), expected)
    values = await asyncio.gather(
        *(
            evaluation_arm(
                root,
                plan,
                directory,
                seed,
                session,
                renderer,
                checkpoints[arm],
                budget,
                arm,
                stage,
            )
            for arm in ARMS
        )
    )
    reports = dict(zip(ARMS, values, strict=True))
    decision = support(root, "pilot").gate(
        reports, read(root / f"{stage}.json"), stage=stage
    )
    atomic_json(directory / f"{stage}-decision.json", decision)
    print(
        json.dumps(
            {
                "seed": seed,
                "stage": stage,
                "passed": decision["passed"],
                "counts": {arm: r["summary"]["passed"] for arm, r in reports.items()},
            }
        ),
        flush=True,
    )
    return decision


def validation_cohort(root, plan):
    records = {}
    for seed in SEEDS:
        directory = seed_root(root, seed)
        path = directory / "train-validation-execution.json"
        execution = read(path) if path.exists() else None
        result_path = directory / "train-validation-result.json"
        result = read(result_path) if result_path.exists() else None
        records[str(seed)] = {
            "execution": execution,
            "result": result,
            "qualified": bool(
                execution
                and execution["exit_code"] == 0
                and not execution["timed_out"]
                and result
                and result["status"] == "validation_passed"
                and result["rl_updates"] == 1
            ),
        }
        if records[str(seed)]["qualified"]:
            assert (
                execution["plan_hash"] == plan["plan_hash"]
                and execution["seed"] == seed
                and execution["phase"] == "train-validation"
            )
            activity = read(directory / "training-activity.json")
            assert activity == {
                "consumed_batches": 1,
                "acknowledged_optimizer_updates": 1,
                "sft_updates": 0,
            }
            pointer = read(directory / "rl-checkpoint.json")
            initial, final = read(directory / "initial-model.json"), read(
                directory / "final-model.json"
            )
            assert pointer["step"] == final["step"] == 1 and initial["step"] == 0
            assert initial["parent_checkpoint"] == plan["parent_checkpoint"]
            assert pointer["policy_version"] == final["policy_version"]
            assert (
                final["policy_version"]["parent_id"] == initial["policy_version"]["id"]
            )
            assert (
                final["policy_version"]["step"] == initial["policy_version"]["step"] + 1
            )
            evidence_files = [
                "training-activity.json",
                "training-steps.json",
                "rl-checkpoint.json",
                "initial-model.json",
                "final-model.json",
            ]
            steps = read(directory / "training-steps.json")
            assert len(steps) == 1 and steps[0]["batch"] == steps[0]["model_step"] == 1
            assert (
                steps[0]["metrics"]["train/updated"] == 1
                and steps[0]["metrics"]["train/datums"] > 0
            )
            for stage, _, size in STAGES[:2]:
                reports = {arm: read(directory / f"{arm}-{stage}.json") for arm in ARMS}
                rows = read(root / f"{stage}.json")
                for arm, report in reports.items():
                    assert (
                        report["plan_hash"] == plan["plan_hash"]
                        and report["seed"] == seed
                    )
                    assert report["checkpoint"] == (
                        asdict(parent_checkpoint(plan)) if arm == "parent" else pointer
                    )
                    assert report["case_hashes"] == {
                        row["order_id"]: content_hash(row) for row in rows
                    }
                    assert report["settings"] == {
                        **plan["settings"],
                        "temperature": 0 if size == 1 else 1.0,
                        "group_size": size,
                        "top_p": 1.0,
                        "top_k": -1,
                    }
                measured = support(root, "pilot").gate(reports, rows, stage=stage)
                assert (
                    measured == read(directory / f"{stage}-decision.json")
                    and measured["passed"]
                )
                evidence_files.extend(
                    [f"{arm}-{stage}.json" for arm in ARMS] + [f"{stage}-decision.json"]
                )
            records[str(seed)]["evidence_sha256"] = {
                name: sha(directory / name) for name in evidence_files
            }
    return {
        "plan_hash": plan["plan_hash"],
        "seeds": records,
        "passed": all(row["qualified"] for row in records.values()),
    }


def seal_test_cohort(root, plan):
    decision = validation_cohort(root, plan)
    assert decision["passed"], "Every planned seed must qualify before any test attempt"
    atomic_json(root / "validation-cohort.json", decision)
    checkpoints = {
        str(seed): read(seed_root(root, seed) / "rl-checkpoint.json") for seed in SEEDS
    }
    seal(
        root,
        "test-cohort-attempt.json",
        {
            "plan_hash": plan["plan_hash"],
            "validation_cohort_hash": content_hash(decision),
            "checkpoints": checkpoints,
        },
    )
    from river_client import Checkpoint

    for seed in SEEDS:
        for arm in ARMS:
            checkpoint = (
                parent_checkpoint(plan)
                if arm == "parent"
                else Checkpoint(**checkpoints[str(seed)])
            )
            path = seed_root(root, seed) / f"{arm}-test-attempt.json"
            seal(root, str(path.relative_to(root)), arm_seal(plan, checkpoint, "test"))


def verify_test_cohort(root, plan):
    decision = validation_cohort(root, plan)
    assert decision["passed"] and decision == read(root / "validation-cohort.json")
    binding = read(root / "test-cohort-attempt.json")
    assert binding["plan_hash"] == plan["plan_hash"] and binding[
        "validation_cohort_hash"
    ] == content_hash(decision)
    from river_client import Checkpoint

    for seed in SEEDS:
        pointer = read(seed_root(root, seed) / "rl-checkpoint.json")
        assert pointer == binding["checkpoints"][str(seed)]
        for arm in ARMS:
            expected = arm_seal(
                plan,
                parent_checkpoint(plan) if arm == "parent" else Checkpoint(**pointer),
                "test",
            )
            assert read(seed_root(root, seed) / f"{arm}-test-attempt.json") == expected


def phase_worker(root, seed, phase):
    import river_client as river
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_runtime import (
        require_model_access,
        require_native_runtime,
    )

    plan = validate(root)
    directory = seed_root(root, seed)
    require_native_runtime()
    with exclusive_run(directory / "worker"):
        seal(
            root,
            str((directory / f"{phase}-worker-attempt.json").relative_to(root)),
            {"plan_hash": plan["plan_hash"], "seed": seed, "phase": phase},
        )
        if phase == "test":
            verify_test_cohort(root, plan)
        budget = RolloutAdmissionBudget(
            directory / "rollout-budget.json",
            limit=plan["limits"]["reserved_output_tokens_per_seed"],
            trajectory_tokens=1024,
            fingerprint=plan["plan_hash"],
            create=phase == "train-validation",
        )
        with closing(
            river.Client(
                api_key=os.environ["RIVER_API_KEY"], timeout=180, enable_retries=False
            )
        ) as client:
            require_model_access(client, MODEL)
            caps = client.get_server_capabilities(model_name=MODEL)
            caps.require(*plan["required_server_features"])
            atomic_json(
                directory / f"{phase}-server-capabilities.json",
                {
                    "features": sorted(caps.features),
                    "supported_models": list(caps.supported_models),
                },
            )
            renderer = get_river_renderer(MODEL, thinking=False)
            if phase == "train-validation":
                seal(
                    root,
                    str((directory / "training-attempt.json").relative_to(root)),
                    {
                        "plan_hash": plan["plan_hash"],
                        "seed": seed,
                        "parent_checkpoint": plan["parent_checkpoint"],
                        "training": plan["training"],
                    },
                )
                pilot = support(root, "pilot")
                pilot.SEED = seed
                with client.session(
                    experiment="stateset-recovery-six-seed", role=f"train-{seed}"
                ) as session:
                    model = session.create_model(
                        base_model=MODEL,
                        tokenizer=renderer.tokenizer,
                        lora=river.LoraConfig(rank=16, seed=seed, train_unembed=False),
                        checkpoint=river.Checkpoint(
                            path=plan["parent_checkpoint"],
                            step=0,
                            checkpoint_type="inference",
                        ),
                    )
                    checkpoint = asyncio.run(
                        pilot.train(
                            directory,
                            phase_plan(root, plan, seed),
                            model,
                            renderer,
                            budget,
                        )
                    )
                if checkpoint is None:
                    atomic_json(
                        directory / "train-validation-result.json",
                        {
                            "status": "no_update_observed",
                            "rl_updates": 0,
                            "sft_updates": 0,
                            "test_attempted": False,
                        },
                    )
                    return
                stages = ("greedy-validation", "stochastic-validation")
            else:
                checkpoint = river.Checkpoint(**read(directory / "rl-checkpoint.json"))
                stages = ("test",)
            checkpoints = {"parent": parent_checkpoint(plan), "rl": checkpoint}
            with client.session(
                experiment="stateset-recovery-six-seed", role=f"{phase}-{seed}"
            ) as session:
                for stage in stages:
                    decision = asyncio.run(
                        evaluate_stage(
                            root,
                            plan,
                            directory,
                            seed,
                            session,
                            renderer,
                            checkpoints,
                            budget,
                            stage,
                        )
                    )
                    if not decision["passed"] and phase == "train-validation":
                        atomic_json(
                            directory / "train-validation-result.json",
                            {
                                "status": "validation_blocked",
                                "blocked_stage": stage,
                                "rl_updates": 1,
                                "sft_updates": 0,
                                "test_attempted": False,
                            },
                        )
                        return
            atomic_json(
                directory / f"{phase}-result.json",
                {
                    "status": (
                        "validation_passed"
                        if phase == "train-validation"
                        else "test_passed" if decision["passed"] else "test_failed"
                    ),
                    "rl_updates": 1,
                    "sft_updates": 0,
                    "test_attempted": phase == "test",
                },
            )


def run_child(root, plan, seed, phase):
    directory = seed_root(root, seed)
    seal(
        root,
        str((directory / f"{phase}-execution-attempt.json").relative_to(root)),
        {"plan_hash": plan["plan_hash"], "seed": seed, "phase": phase},
    )
    started, timed_out = time.monotonic(), False
    with (directory / f"{phase}-run.txt").open("x") as log:
        process = subprocess.Popen(
            [
                sys.executable,
                "-u",
                str(root / "runtime/experiment.py"),
                "seed-worker",
                "--output",
                str(root),
                "--seed",
                str(seed),
                "--phase",
                phase,
            ],
            cwd=root / "runtime",
            env=os.environ.copy(),
            stdout=log,
            stderr=subprocess.STDOUT,
        )
        try:
            code = process.wait(timeout=plan["limits"]["phase_worker_wall_seconds"])
        except subprocess.TimeoutExpired:
            timed_out = True
            process.terminate()
            try:
                code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                code = process.wait(timeout=10)
    result = {
        "plan_hash": plan["plan_hash"],
        "seed": seed,
        "phase": phase,
        "exit_code": code,
        "timed_out": timed_out,
        "elapsed_seconds": time.monotonic() - started,
    }
    atomic_json(directory / f"{phase}-execution.json", result)
    print(json.dumps(result), flush=True)
    return result


def analysis(root, plan):
    cases = read(root / "test.json")
    runs = {}
    for seed in SEEDS:
        reports = {
            arm: read(seed_root(root, seed) / f"{arm}-test.json") for arm in ARMS
        }
        counts = {
            arm: {
                g[0]["case_id"]: sum(o["success"] for o in g)
                for g in reports[arm]["groups"]
            }
            for arm in ARMS
        }
        runs[seed] = {
            row["order_id"]: (
                counts["parent"][row["order_id"]],
                counts["rl"][row["order_id"]],
            )
            for row in cases
        }
    return paired_seed_case_summary(
        runs,
        expected_seeds=SEEDS,
        case_families={r["order_id"]: r["recovery"] for r in cases},
        group_size=4,
        analysis_seed=plan["analysis"]["analysis_seed"],
        bootstrap_replicates=plan["analysis"]["bootstrap_replicates"],
    )


def worker(root):
    plan = validate(root)
    with exclusive_run(root / "coordinator"):
        seal(root, "worker-attempt.json", {"plan_hash": plan["plan_hash"]})
        with ThreadPoolExecutor(
            max_workers=plan["limits"]["max_parallel_seed_workers"]
        ) as pool:
            list(
                pool.map(
                    lambda seed: run_child(root, plan, seed, "train-validation"), SEEDS
                )
            )
        cohort = validation_cohort(root, plan)
        atomic_json(root / "validation-cohort.json", cohort)
        activity = {}
        for seed in SEEDS:
            path = seed_root(root, seed) / "training-activity.json"
            activity[str(seed)] = (
                read(path)["acknowledged_optimizer_updates"] if path.exists() else None
            )
        result = {
            "plan_hash": plan["plan_hash"],
            "sft_updates": 0,
            "acknowledged_rl_updates": sum(
                value for value in activity.values() if value is not None
            ),
            "update_activity_by_seed": activity,
            "quality_certification": False,
        }
        if not cohort["passed"]:
            atomic_json(
                root / "result.json",
                {
                    **result,
                    "status": "validation_cohort_blocked",
                    "accepted": False,
                    "test_attempted": False,
                },
            )
            return
        seal_test_cohort(root, plan)
        with ThreadPoolExecutor(
            max_workers=plan["limits"]["max_parallel_seed_workers"]
        ) as pool:
            completed = list(
                pool.map(lambda seed: run_child(root, plan, seed, "test"), SEEDS)
            )
        if any(item["exit_code"] != 0 or item["timed_out"] for item in completed):
            atomic_json(
                root / "result.json",
                {
                    **result,
                    "status": "incomplete_test_attempt",
                    "accepted": False,
                    "test_attempted": True,
                },
            )
            return
        statistics = analysis(root, plan)
        atomic_json(root / "replication-statistics.json", statistics)
        individual = all(
            read(seed_root(root, seed) / "test-decision.json")["passed"]
            for seed in SEEDS
        )
        inferential = (
            statistics["exact_two_sided_seed_sign_flip_p"]
            <= plan["analysis"]["p_threshold"]
            and statistics["seed_and_family_case_bootstrap_95"][0] > 0
        )
        atomic_json(
            root / "result.json",
            {
                **result,
                "status": "completed",
                "accepted": individual and inferential,
                "individual_test_gates_passed": individual,
                "statistical_gate_passed": inferential,
                "test_attempted": True,
            },
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("prepare", "validate", "launch", "worker", "seed-worker")
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--seed", type=int, choices=SEEDS)
    parser.add_argument("--phase", choices=("train-validation", "test"))
    args = parser.parse_args()
    root = args.output.resolve()
    if args.command == "prepare":
        result = asyncio.run(prepare(root, args.repo.resolve()))
    elif args.command == "validate":
        result = {"valid": True, "plan_hash": validate(root)["plan_hash"]}
    elif args.command == "launch":
        controller = support(root, "controller")
        controller.validate = validate
        result = controller.launch(root)
    elif args.command == "seed-worker":
        assert args.seed is not None and args.phase is not None
        phase_worker(root, args.seed, args.phase)
        return
    else:
        worker(root)
        return
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
