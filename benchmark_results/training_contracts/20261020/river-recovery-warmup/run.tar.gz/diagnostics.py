"""Replay-first classification of formatting and recovery protocol mistakes."""

import json

from stateset_agents.core.environments.json_action import parse_json_action
from stateset_agents.core.trajectory import ConversationTurn
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace

CATEGORIES = (
    "format",
    "tool_contract",
    "completion_outcome",
    "unsafe_retry",
    "reconciliation",
    "premature_finish",
)


async def diagnose(case, trace):
    replay = await replay_recovery_trace(case, trace)
    phase, events = "ready", []
    for turn, step in enumerate(trace["steps"], 1):
        observation = json.loads(step["observations"][0]["content"])
        if "error" in observation:
            message = step["action"]
            try:
                tool, args = parse_json_action(
                    ConversationTurn(
                        role="assistant",
                        content=message.get("content", ""),
                        tool_calls=message.get("tool_calls"),
                    )
                )
            except (ValueError, TypeError):
                category = "format"
            else:
                if (
                    tool == "finish"
                    and set(args) == {"outcome"}
                    and isinstance(args["outcome"], str)
                    and args["outcome"] in {"resolved", "unauthorized", "handoff"}
                ):
                    category = (
                        "completion_outcome"
                        if phase in {"applied", "unauthorized", "handoff"}
                        else "premature_finish"
                    )
                elif tool == "resolve_refund" and args == {"intent": "resolve_refund"}:
                    category = "unsafe_retry"
                elif tool == "reconcile" and not args:
                    category = "reconciliation"
                else:
                    category = "tool_contract"
            events.append(
                {
                    "turn": turn,
                    "category": category,
                    "prior_phase": phase,
                    "error": observation["error"],
                    "action": step["action"],
                }
            )
        elif observation.get("status") in {"pending", "unavailable"}:
            phase = "handoff"
        elif observation.get("status") == "outcome_unknown":
            phase = "unknown"
        elif observation.get("status") == "not_applied":
            phase = "retryable"
        elif "status" in observation:
            phase = observation["status"]
    counts = {
        category: sum(event["category"] == category for event in events)
        for category in CATEGORIES
    }
    assert sum(counts.values()) == replay["policy_violations"]
    return {
        "case_id": case["order_id"],
        "case_hash": replay["case_hash"],
        "success": replay["success"],
        "error_counts": counts,
        "events": events,
    }


def summarize(diagnostics):
    return {
        category: sum(item["error_counts"][category] > 0 for item in diagnostics)
        for category in CATEGORIES
    }
