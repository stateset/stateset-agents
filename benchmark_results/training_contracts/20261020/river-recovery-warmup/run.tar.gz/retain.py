"""Publish one credential-free, byte-verified recovery warmup evidence bundle."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
TARGET = REPO / "benchmark_results/training_contracts/20261020/river-recovery-warmup"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    review = read(ROOT / "review-summary.json")
    assert review["passed"] and read(ROOT / "execution-summary.json")["exit_code"] == 0
    TARGET.mkdir(parents=True, exist_ok=False)
    inputs = [
        p
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    ]
    secret = re.compile(rb"rv_[A-Za-z0-9_-]{32,}")
    assert all(
        not secret.search(path.read_bytes()) for path in inputs
    ), "Credential-like material cannot be retained"
    with tarfile.open(TARGET / "run.tar.gz", "w:gz") as archive:
        for path in inputs:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(TARGET / "run.tar.gz") as archive:
        assert len(archive.getmembers()) == len(inputs)
        for member in archive.getmembers():
            assert member.isfile()
            assert hashlib.sha256(
                archive.extractfile(member).read()
            ).hexdigest() == sha(ROOT / member.name)
    for name in (
        "plan.json",
        "result.json",
        "review-summary.json",
        "execution-summary.json",
        "validation-decision.json",
        "test-decision.json",
        "training-result.json",
        "rollout-budget.json",
        "training-source-audit.json",
        "probe-selection.json",
        "diagnostic-reference-check.json",
        "prior-evidence-verified.json",
        "study-tests.xml",
        "contract-tests.xml",
        "runtime-versions.json",
        "verification-source.json",
    ):
        if (ROOT / name).exists():
            shutil.copyfile(ROOT / name, TARGET / name)
    for arm in ("parent", "warmup"):
        shutil.copyfile(
            ROOT / arm / "river_checkpoint.json", TARGET / f"{arm}-checkpoint.json"
        )
    (TARGET / "archive-inputs.json").write_text(
        json.dumps(
            {str(p.relative_to(ROOT)): sha(p) for p in inputs}, sort_keys=True, indent=2
        )
        + "\n"
    )
    result = read(ROOT / "result.json")
    pointer = read(ROOT / "warmup/river_checkpoint.json")
    lines = [
        "# River recovery SFT warmup — October 20, 2026",
        "",
        "Fixed one-epoch SFT continuation from the retained Qwen/Qwen3.5-9B",
        "arithmetic candidate on 160 unchanged, audited recovery training transcripts.",
        "Ten optimizer updates were acknowledged. Starting weights were loaded",
        "with a fresh optimizer; this is not optimizer-state resume.",
        "",
        "| Split | Parent | Warmup | Warmup violation rate | Warmup truncation rate |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for split in ("validation", "test"):
        if f"parent-{split}" not in review["evaluations"]:
            continue
        parent, warmup = (
            review["evaluations"][f"{arm}-{split}"] for arm in ("parent", "warmup")
        )
        lines.append(
            f"| {split} | {parent['passed']}/{parent['total']} | {warmup['passed']}/{warmup['total']} | {warmup['violation_rate']:.1%} | {warmup['truncation_rate']:.1%} |"
        )
    lines.extend(
        [
            "",
            f"Declared pilot acceptance: **{result['accepted']}**. Test attempted: **{result['test_attempted']}**.",
            "No automatic production promotion occurred.",
            "",
            "| Paired split | Both passed | Warmup only | Parent only | Neither passed |",
            "| --- | ---: | ---: | ---: | ---: |",
        ]
    )
    for split, paired in review["paired_outcomes"].items():
        lines.append(
            f"| {split} | {paired['both_passed']} | {paired['warmup_only']} | {paired['parent_only']} | {paired['neither_passed']} |"
        )
    lines.extend(
        [
            "",
            "Paired counts describe this fixed checkpoint comparison; passing the",
            "pilot gate does not establish a statistically reliable learning gain.",
            "",
            "## Formatting and completion semantics",
            "",
            "Each outcome passed exact environment replay before diagnosis. Error",
            "classes distinguish malformed JSON, invalid tool contracts, incorrect",
            "completion outcomes, unsafe retries, reconciliation misuse, and premature",
            "finish. A denial/escalation confirmed applied is a resolved workflow,",
            "not a caller-authorization failure. The original scorer remains unchanged.",
            "",
            "| Split / category | Parent cases | Warmup cases |",
            "| --- | ---: | ---: |",
        ]
    )
    for split, decision in review["decisions"].items():
        errors = decision["diagnostic_cases"]
        for category in (
            "format",
            "completion_outcome",
            "tool_contract",
            "unsafe_retry",
        ):
            lines.append(
                f"| {split} / {category} | {errors['parent'][category]} | {errors['warmup'][category]} |"
            )
    lines.extend(
        [
            "",
            "## Residual training-probe signal",
            "",
            f"The post-warmup train-only probe succeeded on **{review['probe_passed']}/{review['probe_total']}**",
            f"rollouts. **{review['nonzero_variance_groups']}/{review['probe_groups']} groups** had nonzero within-group",
            "reward variance, with four rollouts per group at temperature 1.",
            "Its cases were chosen before provider calls: first case ID per recovery",
            "family and public terminal receipt type. Coverage includes applied",
            "refunds, denials, escalations, unauthorized outcomes, and handoffs where",
            "present in the training set. This expanded probe is not directly paired",
            "with the earlier pilot's smaller ten-case probe.",
            "",
            "Probe case error counts: `"
            + json.dumps(review["probe_diagnostic_cases"], sort_keys=True)
            + "`.",
            "The probe performed **zero RL optimizer updates**. Later RL requires",
            "fresh on-policy samples with native token/logprob evidence.",
            "",
            "## Protocol and provenance",
            "",
            "The only training input was the prior canonical train split. No held-out",
            "cases or validation-derived demonstrations were added. All 160 teachers",
            "were replayed, and their exact file bytes matched the audited source.",
            "The final checkpoint was fixed at ten updates, one epoch, batch size 16,",
            "rank 16, learning rate 2e-5, and training seed 2026109401.",
            f"Final provider-reported loss: `{pointer['final_loss']}`; loss alone is not quality evidence.",
            "",
            "The frozen fresh evaluation contains 80 validation and 160 test cases per",
            "arm. Order IDs and fact fingerprints were excluded against all historical",
            "training, prepared, and evaluated inputs before sampling. Both arms use",
            "identical agent prompts/tools and greedy sampling with six model turns,",
            "1,024 output tokens, 256 tokens per turn, and an 8,192-token context limit.",
            "",
            "Validation requires every warmup case to succeed without violations or",
            "truncation. Test additionally requires a strict success gain over parent",
            "and no family or error-category regression. Both arms' attempts were",
            "sealed before sampling each split. No test-based checkpoint selection",
            "or retry of sealed stages was allowed.",
            "",
            "Limits: ten SFT updates, at most 556 sampled trajectories and 569,344",
            "reserved output tokens, no provider retries, 25 minutes of worker time.",
            "Actual billed cost was unavailable; the token reservation is not a dollar cap.",
            "",
            f"Independent review replayed **{review['replayed_outcomes']} model outcomes** and **160 teachers**.",
            f"All **{review['prior_artifacts_unchanged']} earlier retained artifacts** matched their hashes.",
            "The previous recovery pilot's 80 test cases and arithmetic pilot's 308",
            "test cases were excluded and remain unattempted.",
            "",
            "Local verification: **192 relevant contract tests passed**, including",
            "12 study gate/diagnostic tests. The frozen 455-source package is unchanged",
            "from the preceding validated recovery implementation. The archive includes",
            "runtime sources, controller, exact inputs, attempt seals, training receipts,",
            "full traces, diagnostics, and independently executable review scripts.",
            "",
            f"Archive byte verification checked **{len(inputs)} files**. Local hashes provide",
            "consistency checks, not independent provider attestation.",
            "",
            "This single-parent synthetic pilot does not establish production A+",
            "quality, independent merchant generalization, durable payment idempotency,",
            "optimizer continuity across recovery, or an RL learning improvement.",
            "",
        ]
    )
    (TARGET / "README.md").write_text("\n".join(lines))
    artifacts = {p.name: sha(p) for p in sorted(TARGET.iterdir()) if p.is_file()}
    (TARGET / "artifacts.sha256.json").write_text(
        json.dumps(artifacts, sort_keys=True, indent=2) + "\n"
    )
    assert all(sha(TARGET / name) == digest for name, digest in artifacts.items())
    print(
        json.dumps(
            {
                "retained": str(TARGET.relative_to(REPO)),
                "artifacts": len(artifacts),
                "archive_files_verified": len(inputs),
            }
        )
    )


if __name__ == "__main__":
    main()
