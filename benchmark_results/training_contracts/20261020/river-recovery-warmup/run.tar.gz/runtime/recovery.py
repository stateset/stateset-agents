"""One bounded recovery evaluation and a train-only reward-variance probe."""

import argparse
import asyncio
from contextlib import closing
from dataclasses import asdict
import importlib.util
import json
import os
from pathlib import Path
import shutil
import statistics

from stateset_agents.core.environments.refund_policy_environment import (
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import (
    prepare_refund_recovery_data,
    audit_refund_recovery_data,
)
from stateset_agents.evaluation.agent_runs import (
    content_hash,
    evaluation_report,
    validate_report,
)
from stateset_agents.evaluation.implementation import package_implementation
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace
from stateset_agents.remote.river_environment import (
    trajectory_case_identity,
    trajectory_truncation,
)
from stateset_agents.remote.river_refund_recovery import (
    river_refund_recovery_factory,
    trajectory_recovery_trace,
)
from stateset_agents.remote.river_rl import atomic_json, exclusive_run
from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget
from stateset_agents.utils.async_calls import closing_async_generator

MODEL = "Qwen/Qwen3.5-9B"
SEED = 2026109201
TOKEN_LIMIT = 160 * 1024
SETTINGS = {
    "max_turns": 6,
    "max_generated_tokens": 1024,
    "max_context_tokens": 8192,
    "max_turn_tokens": 256,
    "temperature": 0,
    "thinking": False,
    "truncation_reward": -1.0,
}


def read(path):
    return json.loads(Path(path).read_text())


def controller(root):
    spec = importlib.util.spec_from_file_location(
        "bounded_controller", root / "runtime/controller.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


async def prepare(root, repo):
    assert not (root / "plan.json").exists()
    previous = repo / "outputs/river-delegation-pilot-20261020"
    helper_spec = importlib.util.spec_from_file_location(
        "prepared_controller", previous / "runtime/experiment.py"
    )
    helper = importlib.util.module_from_spec(helper_spec)
    helper_spec.loader.exec_module(helper)
    history = read(previous / "historical-sources.json")
    for split in ("validation", "test"):
        path = previous / f"{split}.json"
        history[str(path.relative_to(repo))] = helper.sha(path)
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in history.items():
        assert helper.sha(repo / name) == digest
        rows = read(repo / name)
        if isinstance(rows, list):
            excluded.extend(
                r for r in rows if isinstance(r, dict) and "return_window_days" in r
            )
    rejected = []
    for attempt in range(100):
        case_seed = 2026109101 + attempt * 100
        try:
            manifest = await prepare_refund_recovery_data(
                root / "data",
                seed=case_seed,
                train_count=160,
                validation_count=40,
                test_count=80,
                excluded=excluded,
            )
        except ValueError as exc:
            if "overlap" not in str(exc).lower():
                raise
            assert not (root / "data").exists()
            rejected.append({"seed": case_seed, "reason": str(exc)})
            continue
        break
    else:
        raise ValueError("No fresh input seed among 100 prospective candidates")
    audit = await audit_refund_recovery_data(root / "data")
    atomic_json(root / "data-audit.json", audit)
    atomic_json(root / "historical-sources.json", history)
    pointer = (
        repo
        / "outputs/river-arithmetic-pilot-20261020/arithmetic/river_checkpoint.json"
    )
    shutil.copyfile(pointer, root / "checkpoint.json")
    train = read(root / "data/train.json")
    probe_ids = [
        min(r["order_id"] for r in train if r["recovery"] == family)
        for family in sorted({r["recovery"] for r in train})
    ]
    assert len(probe_ids) == 10
    atomic_json(root / "probe-case-ids.json", probe_ids)
    implementation = package_implementation()
    runtime = root / "runtime"
    for name, digest in implementation["files"].items():
        source = repo / "stateset_agents" / name
        assert helper.sha(source) == digest
        target = runtime / "stateset_agents" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    shutil.copyfile(Path(__file__), runtime / "experiment.py")
    shutil.copyfile(previous / "runtime/experiment.py", runtime / "controller.py")
    plan = {
        "schema_version": 1,
        "kind": "synthetic-recovery-evaluation-and-train-variance-probe",
        "base_model": MODEL,
        "seed": SEED,
        "case_seed": case_seed,
        "checkpoint": read(pointer)["checkpoint"],
        "implementation": implementation,
        "manifest_hash": content_hash(manifest),
        "settings": SETTINGS,
        "input_sha256": {
            name: helper.sha(root / name)
            for name in (
                "checkpoint.json",
                "historical-sources.json",
                "probe-case-ids.json",
                "data-audit.json",
                "data/manifest.json",
                "data/train.json",
                "data/train.jsonl",
                "data/validation.json",
                "data/test.json",
            )
        },
        "runner_sha256": helper.sha(runtime / "experiment.py"),
        "controller_sha256": helper.sha(runtime / "controller.py"),
        "probe": {
            "split": "train",
            "cases": 10,
            "group_size": 4,
            "temperature": 1.0,
            "selection": "Lexically first case ID per recovery family, frozen before sampling",
        },
        "counts": {
            "train_teachers": 160,
            "probe_trajectories": 40,
            "validation": 40,
            "test": 80,
        },
        "acceptance": "Validation must be 40/40 with zero violations/truncations before the test attempt is sealed. Test must be 80/80 with zero violations/truncations.",
        "limits": {
            "wall_seconds": 900,
            "request_timeout_seconds": 180,
            "reserved_output_tokens": TOKEN_LIMIT,
            "provider_retries": False,
            "attempts": 1,
            "concurrency": 6,
        },
        "rejected_input_seeds": rejected,
        "training_updates": 0,
        "quality_certification": False,
        "dollar_cap_enforced": False,
        "cost_usd": None,
        "scope": "Deterministic injected synthetic faults; neither real payment recovery nor durable idempotency is established. The stochastic train probe observes reward variance but performs no RL updates.",
    }
    plan["plan_hash"] = content_hash(plan)
    atomic_json(root / "plan.json", plan)
    return {
        "prepared": True,
        "case_seed": case_seed,
        "counts": plan["counts"],
        "plan_hash": plan["plan_hash"],
    }


def validate(root):
    helper = controller(root)
    plan = read(root / "plan.json")
    assert (
        content_hash({k: v for k, v in plan.items() if k != "plan_hash"})
        == plan["plan_hash"]
    )
    assert package_implementation() == plan["implementation"]
    assert helper.sha(Path(__file__)) == plan["runner_sha256"]
    assert helper.sha(root / "runtime/controller.py") == plan["controller_sha256"]
    for name, digest in plan["input_sha256"].items():
        assert helper.sha(root / name) == digest
    for name, digest in plan["implementation"]["files"].items():
        assert helper.sha(root / "runtime/stateset_agents" / name) == digest
    return plan


async def collect(
    root, plan, session, renderer, checkpoint, cases, budget, *, probe=False
):
    from river_client import rl

    async def reserve():
        await asyncio.to_thread(budget.reserve)

    engine = rl.RolloutEngine(
        rl.CheckpointSampler(
            session,
            base_model=MODEL,
            checkpoint=checkpoint,
            tokenizer=renderer.tokenizer,
        ),
        env=river_refund_recovery_factory(before_reset=reserve),
        renderer=renderer,
        budget=rl.Budget(**{k: v for k, v in SETTINGS.items() if k.startswith("max_")}),
        schedule=rl.Schedule(concurrency=6),
        temperature=1.0 if probe else 0,
        top_p=1.0,
        top_k=-1,
        seed=SEED,
    )
    by_id = {r["order_id"]: r for r in cases}
    outcomes, groups, size = [], [], 4 if probe else 1
    async with closing_async_generator(
        engine.rollout(
            cases,
            group_size=size,
            completion=rl.GroupCompletion(mode="wait", min_members=size),
        )
    ) as stream:
        async for group in stream:
            members = []
            for traj in group:
                outcome = {
                    **trajectory_case_identity(traj, cases=by_id),
                    "environment_trace": trajectory_recovery_trace(traj),
                    "reward": traj.reward,
                    "success": traj.metrics.get("task_success", 0) == 1,
                    **{
                        key: traj.metrics.get(key, 0)
                        for key in (
                            "policy_violations",
                            "tool_calls",
                            "backend_calls",
                            "resolution_count",
                            "refunded_cents",
                            "duplicate_attempts",
                            "reconciliations",
                        )
                    },
                    "generated_tokens": traj.generated_tokens,
                    "elapsed_seconds": traj.elapsed,
                    "truncated": trajectory_truncation(traj),
                }
                replay = await replay_recovery_trace(
                    by_id[outcome["case_id"]], outcome["environment_trace"]
                )
                for key in (
                    "case_hash",
                    "reward",
                    "success",
                    "policy_violations",
                    "tool_calls",
                    "backend_calls",
                    "resolution_count",
                    "refunded_cents",
                    "duplicate_attempts",
                    "reconciliations",
                    "truncated",
                ):
                    assert outcome[key] == replay[key]
                members.append(outcome)
            assert len(members) == size and len({o["case_id"] for o in members}) == 1
            groups.append(members)
            outcomes.extend(members)
            atomic_json(
                root / ("probe-progress.json" if probe else "evaluation-progress.json"),
                {"completed": len(outcomes), "expected": len(cases) * size},
            )
    assert len(groups) == len(cases) and {g[0]["case_id"] for g in groups} == set(by_id)
    return groups if probe else outcomes


async def evaluations(root, plan, session, renderer, checkpoint, budget):
    helper = controller(root)
    train = {r["order_id"]: r for r in read(root / "data/train.json")}
    probe_cases = [train[key] for key in read(root / "probe-case-ids.json")]
    helper.seal(
        root / "probe-attempt.json",
        {"plan_hash": plan["plan_hash"], "checkpoint": asdict(checkpoint)},
    )
    groups = await collect(
        root, plan, session, renderer, checkpoint, probe_cases, budget, probe=True
    )
    probe = {
        "split": "train",
        "group_size": 4,
        "temperature": 1.0,
        "groups": groups,
        "variances": {
            g[0]["case_id"]: statistics.pvariance(o["reward"] for o in g)
            for g in groups
        },
        "training_updates": 0,
    }
    probe["nonzero_variance_groups"] = sum(v > 0 for v in probe["variances"].values())
    atomic_json(root / "train-probe.json", probe)
    print(
        json.dumps(
            {
                "probe_completed": 40,
                "nonzero_variance_groups": probe["nonzero_variance_groups"],
            }
        ),
        flush=True,
    )
    for split in ("validation", "test"):
        cases = read(root / f"data/{split}.json")
        helper.seal(
            root / f"{split}-attempt.json",
            {
                "plan_hash": plan["plan_hash"],
                "checkpoint": asdict(checkpoint),
                "case_sha256": plan["input_sha256"][f"data/{split}.json"],
            },
        )
        outcomes = await collect(
            root, plan, session, renderer, checkpoint, cases, budget
        )
        report = evaluation_report(
            environment="refund-recovery-v1",
            base_model=MODEL,
            seed=SEED,
            cases={r["order_id"]: r for r in cases},
            settings=SETTINGS,
            checkpoint=asdict(checkpoint),
            outcomes=outcomes,
            case_families={r["order_id"]: r["recovery"] for r in cases},
            implementation=plan["implementation"],
            split=split,
        )
        atomic_json(root / f"{split}-report.json", report)
        passed = (
            report["passed"] == len(cases)
            and report["violation_rate"] == report["truncation_rate"] == 0
        )
        atomic_json(
            root / f"{split}-decision.json",
            {"passed": passed, "successes": report["passed"], "total": len(cases)},
        )
        print(
            json.dumps(
                {
                    "split": split,
                    "passed": passed,
                    "successes": report["passed"],
                    "total": len(cases),
                }
            ),
            flush=True,
        )
        if split == "validation" and not passed:
            atomic_json(
                root / "result.json",
                {
                    "status": "validation_blocked_test_not_attempted",
                    "test_attempted": False,
                    "accepted": False,
                    "training_updates": 0,
                    "nonzero_variance_groups": probe["nonzero_variance_groups"],
                },
            )
            return
    atomic_json(
        root / "result.json",
        {
            "status": "completed",
            "test_attempted": True,
            "accepted": passed,
            "training_updates": 0,
            "nonzero_variance_groups": probe["nonzero_variance_groups"],
            "quality_certification": False,
        },
    )


def worker(root):
    import river_client as river
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_runtime import (
        require_model_access,
        require_native_runtime,
    )

    plan = validate(root)
    require_native_runtime()
    with exclusive_run(root / "worker"):
        controller(root).seal(
            root / "worker-attempt.json", {"plan_hash": plan["plan_hash"]}
        )
        budget = RolloutAdmissionBudget(
            root / "rollout-budget.json",
            limit=TOKEN_LIMIT,
            trajectory_tokens=1024,
            fingerprint=plan["plan_hash"],
            create=True,
        )
        with closing(
            river.Client(
                api_key=os.environ["RIVER_API_KEY"], timeout=180, enable_retries=False
            )
        ) as client:
            require_model_access(client, MODEL)
            renderer = get_river_renderer(MODEL, thinking=False)
            checkpoint = river.Checkpoint(
                path=plan["checkpoint"], step=44, checkpoint_type="inference"
            )
            with client.session(
                experiment="stateset-recovery-pilot",
                role="fixed-checkpoint-probe-and-evaluation",
            ) as session:
                asyncio.run(
                    evaluations(root, plan, session, renderer, checkpoint, budget)
                )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "validate", "launch", "worker"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    args = parser.parse_args()
    root = args.output.resolve()
    if args.command == "prepare":
        result = asyncio.run(prepare(root, args.repo.resolve()))
    elif args.command == "validate":
        result = {"valid": True, "plan_hash": validate(root)["plan_hash"]}
    elif args.command == "launch":
        helper = controller(root)
        helper.validate = validate
        result = helper.launch(root)
    else:
        worker(root)
        return
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
