"""
Training Router Module

API endpoints for training job management.
"""

from datetime import datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field

from ..dependencies import (
    AuthenticatedUser,
    get_current_user,
    get_training_service,
    require_role,
)
from ..errors import InternalError, TrainingConfigError, TrainingJobNotFoundError
from ..models import PaginatedResponse
from ..schemas import ErrorResponse, TrainingRequest, TrainingResponse
from ..services.training_service import TrainingService

router = APIRouter(prefix="/training", tags=["training"])

TRAINING_API_EXCEPTIONS = (
    AttributeError,
    KeyError,
    RuntimeError,
    TypeError,
    ValueError,
)


def _is_admin_user(user: AuthenticatedUser) -> bool:
    return "admin" in user.roles


# ============================================================================
# Response Models
# ============================================================================


class TrainingJobDetail(BaseModel):
    """Detailed training job information."""

    training_id: str = Field(..., description="Training job identifier")
    status: str = Field(..., description="Current status")
    created_at: datetime = Field(..., description="Creation timestamp")
    started_at: datetime | None = Field(None, description="Start timestamp")
    completed_at: datetime | None = Field(None, description="Completion timestamp")
    completion_scope: (
        Literal[
            "final_episode_reported", "partial_episode_progress", "no_episode_progress"
        ]
        | None
    ) = Field(
        None,
        description="Episode progress observed when the trainer returned normally; not proof of optimizer updates or saved artifacts",
    )
    progress: float = Field(0.0, ge=0.0, le=100.0, description="Progress percentage")
    current_episode: int = Field(0, description="Current training episode")
    total_episodes: int = Field(0, description="Total episodes")
    metrics: dict[str, Any] = Field(
        default_factory=dict, description="Training metrics"
    )
    error: str | None = Field(None, description="Error message if failed")
    config: dict[str, Any] = Field(
        default_factory=dict, description="Training configuration"
    )


class TrainingJobListResponse(PaginatedResponse):
    """Paginated list of training jobs."""

    items: list[TrainingJobDetail] = Field(
        default_factory=list, description="List of training jobs"
    )


class TrainingCancelResponse(BaseModel):
    """Response for training cancellation."""

    training_id: str = Field(..., description="Training job identifier")
    status: str = Field(
        ..., description="Current job status after cancellation request"
    )
    message: str = Field(..., description="Status message")


# ============================================================================
# Training Endpoints
# ============================================================================


@router.post(
    "",
    response_model=TrainingResponse,
    status_code=202,
    summary="Start Training",
    description="Start a new training job with the specified configuration.",
    responses={
        202: {
            "description": "Training started successfully",
            "model": TrainingResponse,
        },
        400: {"description": "Invalid configuration", "model": ErrorResponse},
        401: {"description": "Authentication required", "model": ErrorResponse},
        403: {"description": "Insufficient permissions", "model": ErrorResponse},
        409: {"description": "Idempotency key conflict", "model": ErrorResponse},
        429: {
            "description": "Training concurrency limit reached",
            "model": ErrorResponse,
        },
        500: {"description": "Internal server error", "model": ErrorResponse},
        503: {
            "description": "Training service is shutting down",
            "model": ErrorResponse,
        },
    },
)
async def start_training(
    request: TrainingRequest,
    svc: TrainingService = Depends(get_training_service),
    user: AuthenticatedUser = Depends(require_role("trainer")),
    idempotency_key: str | None = Header(None, max_length=256),
) -> TrainingResponse:
    """
    Start a new training job.

    Requires the 'trainer' role. The training runs asynchronously in the background.

    Args:
        request: Training configuration including prompts, strategy, and parameters.
        user: Authenticated user with trainer role.

    Returns:
        TrainingResponse with job ID and initial status.

    Raises:
        TrainingConfigError: If the configuration is invalid.
        InternalError: If training fails to start.
    """
    try:
        # Validate training configuration
        if request.num_episodes < 1:
            raise TrainingConfigError("num_episodes must be at least 1")

        if not request.environment_scenarios:
            raise HTTPException(
                status_code=422,
                detail="environment_scenarios must contain at least one scenario",
            )

        if idempotency_key is not None:
            training_id = await svc.start_training(
                request, user_id=user.user_id, idempotency_key=idempotency_key
            )
        else:
            training_id = await svc.start_training(request, user_id=user.user_id)

        persisted = (
            await svc.aget_training_status(training_id, user_id=user.user_id)
            if svc.queue is not None
            else None
        )
        accepted_status = (
            persisted["status"] if isinstance(persisted, dict) else "running"
        )
        return TrainingResponse(
            training_id=training_id,
            status=accepted_status,
            message="Training request accepted",
            estimated_time=request.num_episodes * 30,  # Rough estimate: 30s per episode
        )

    except TrainingConfigError:
        raise
    except HTTPException:
        raise
    except ValueError as e:
        raise TrainingConfigError(str(e)) from e
    except TRAINING_API_EXCEPTIONS as e:
        raise InternalError("Failed to start training", internal_error=e) from e


@router.get(
    "",
    response_model=TrainingJobListResponse,
    summary="List Training Jobs",
    description="Get a paginated list of training jobs.",
    responses={
        200: {"description": "List of training jobs", "model": TrainingJobListResponse},
        401: {"description": "Authentication required", "model": ErrorResponse},
    },
)
async def list_training_jobs(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    status: str | None = Query(None, description="Filter by status"),
    svc: TrainingService = Depends(get_training_service),
    user: AuthenticatedUser = Depends(get_current_user),
) -> TrainingJobListResponse:
    """
    Get a paginated list of training jobs.

    Args:
        page: Page number (1-indexed).
        page_size: Number of items per page (max 100).
        status: Optional filter by job status.
        user: Authenticated user.

    Returns:
        Paginated list of training job details.
    """
    page_jobs, total = await svc.list_training_jobs(
        page=page,
        page_size=page_size,
        status=status,
        user_id=None if _is_admin_user(user) else user.user_id,
    )

    items = [
        TrainingJobDetail(
            training_id=job_id,
            status=job.get("status", "unknown"),
            created_at=job.get("created_at", datetime.utcnow()),
            started_at=job.get("started_at"),
            completed_at=job.get("completed_at"),
            completion_scope=job.get("completion_scope"),
            progress=job.get("progress", 0.0),
            current_episode=job.get("current_episode", 0),
            total_episodes=job.get("total_episodes", 0),
            metrics=job.get("metrics", {}),
            error=job.get("error"),
            config=job.get("config", {}),
        )
        for job_id, job in page_jobs
    ]

    return TrainingJobListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        has_next=page * page_size < total,
        has_prev=page > 1,
    )


@router.get(
    "/{training_id}",
    response_model=TrainingJobDetail,
    summary="Get Training Status",
    description="Get detailed status of a specific training job.",
    responses={
        200: {"description": "Training job details", "model": TrainingJobDetail},
        401: {"description": "Authentication required", "model": ErrorResponse},
        404: {"description": "Training job not found", "model": ErrorResponse},
    },
)
async def get_training_status(
    training_id: str,
    svc: TrainingService = Depends(get_training_service),
    user: AuthenticatedUser = Depends(get_current_user),
) -> TrainingJobDetail:
    """
    Get detailed status of a training job.

    Args:
        training_id: The training job's unique identifier.
        user: Authenticated user.

    Returns:
        Detailed training job information including metrics.

    Raises:
        TrainingJobNotFoundError: If the training job doesn't exist.
    """
    job = await svc.aget_training_status(training_id, user_id=user.user_id)

    if not job:
        raise TrainingJobNotFoundError(training_id)

    return TrainingJobDetail(
        training_id=training_id,
        status=job.get("status", "unknown"),
        created_at=job.get("created_at", datetime.utcnow()),
        started_at=job.get("started_at"),
        completed_at=job.get("completed_at"),
        completion_scope=job.get("completion_scope"),
        progress=job.get("progress", 0.0),
        current_episode=job.get("current_episode", 0),
        total_episodes=job.get("total_episodes", 0),
        metrics=job.get("metrics", {}),
        error=job.get("error"),
        config=job.get("config", {}),
    )


@router.delete(
    "/{training_id}",
    response_model=TrainingCancelResponse,
    summary="Cancel Training",
    description="Cancel a running training job.",
    responses={
        200: {
            "description": "Cancellation requested or job already terminal",
            "model": TrainingCancelResponse,
        },
        401: {"description": "Authentication required", "model": ErrorResponse},
        403: {"description": "Insufficient permissions", "model": ErrorResponse},
        404: {"description": "Training job not found", "model": ErrorResponse},
    },
)
async def cancel_training(
    training_id: str,
    svc: TrainingService = Depends(get_training_service),
    user: AuthenticatedUser = Depends(require_role("trainer")),
) -> TrainingCancelResponse:
    """
    Cancel a running training job.

    Requires the 'trainer' role. Active jobs receive a cancellation request;
    terminal jobs retain their existing result.

    Args:
        training_id: The training job's unique identifier.
        user: Authenticated user with trainer role.

    Returns:
        Confirmation of cancellation.

    Raises:
        TrainingJobNotFoundError: If the training job doesn't exist.
    """
    if not await svc.acancel_training(training_id, user_id=user.user_id):
        raise TrainingJobNotFoundError(training_id)

    # Status reads are snapshots: fetch the result after requesting cancellation.
    job = await svc.aget_training_status(training_id, user_id=user.user_id)
    if not job:
        raise TrainingJobNotFoundError(training_id)
    status = job["status"]
    return TrainingCancelResponse(
        training_id=training_id,
        status=status,
        message=(
            "Cancellation requested; training is still stopping"
            if status == "cancelling"
            else f"Training job is already {status}"
        ),
    )
