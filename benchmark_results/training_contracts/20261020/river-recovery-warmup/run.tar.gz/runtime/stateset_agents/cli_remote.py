"""``stateset-agents train-remote`` — run the fine-tune step on rented compute.

Thin orchestrator over ``stateset_agents.remote``. No training logic lives
here: the command builds a :class:`RemoteJobSpec`, hands it to the executor
registered under ``--provider``, and renders the result.

Picks up where ``improve`` leaves off::

    stateset-agents improve run --transcripts sessions/ -o improved/
    stateset-agents train-remote --provider modal \\
        --dataset improved/curated.jsonl --base-model Qwen/Qwen3.5-0.8B
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import typer

from stateset_agents import cli as _cli
from stateset_agents.cli import app
from stateset_agents.core.errors import StateSetError
from stateset_agents.remote.job import RemoteJobSpec
from stateset_agents.remote.registry import available_providers, get_executor

_echo = _cli._echo


def _save_transcript(
    session: object, path: Path | None, *, now: Callable[[], float]
) -> None:
    """Persist a chat session as one ingest-ready JSONL line, best-effort.

    Runs on the ``finally`` path of ``chat-remote`` so aborted chats persist
    too — every conversation is training data for the ingest -> improve ->
    train-remote flywheel. Nothing is written for an empty conversation, and
    a disk error is reported but never masks the session's own outcome.
    """
    import json
    import time

    transcript = session.transcript  # type: ignore[attr-defined]
    if not transcript["messages"]:
        return
    if path is None:
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(now()))
        path = Path("chat_transcripts") / f"chat_{stamp}.jsonl"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(transcript) + "\n")
    except OSError as exc:
        _echo(f"Could not save transcript to {path}: {exc}", err=True)
        return
    _echo(f"Transcript saved to {path}")
    _echo("Feed it back into training with:")
    _echo(
        f"  stateset-agents ingest --format openai --input {path} --output graded.jsonl"
    )


@app.command("chat-remote")
def chat_remote(
    base_model: str = typer.Option(
        ..., "--base-model", help="Hugging Face base model (e.g. Qwen/Qwen3.5-0.8B)."
    ),
    adapter: Path | None = typer.Option(
        None,
        "--adapter",
        help="Local LoRA adapter directory (e.g. outputs/sft_v1) to load on "
        "top of the base model. Uploaded to the pod for the session.",
    ),
    gpu: str = typer.Option(
        "NVIDIA H100 80GB HBM3",
        "--gpu",
        help="RunPod GPU type to rent, in RunPod's own vocabulary.",
    ),
    container_disk_gb: int = typer.Option(
        160,
        "--container-disk-gb",
        help="Container disk in GB for the model download — size it at "
        "roughly 2.5x the checkpoint.",
    ),
    max_turns: int = typer.Option(
        50,
        "--max-turns",
        help="Safety cap on interactive turns; the pod bills while you type.",
    ),
    prompt: list[str] = typer.Option(
        [],
        "--prompt",
        help="Non-interactive mode: send this prompt (repeatable, in order), "
        "print each reply, and exit. Skips the input() loop entirely.",
    ),
    save_transcript: Path | None = typer.Option(
        None,
        "--save-transcript",
        help="Where to save the conversation transcript (OpenAI chat-format "
        "JSONL, ready for `stateset-agents ingest --format openai`). "
        "Defaults to ./chat_transcripts/chat_<timestamp>.jsonl.",
    ),
    save: bool = typer.Option(
        True,
        "--save/--no-save",
        help="Save the transcript on exit (default: on). Every chat is "
        "training data — the transcript feeds ingest -> improve -> "
        "train-remote.",
    ),
) -> None:
    """Chat with a fine-tuned model on a rented RunPod GPU, ephemerally.

    Rents a pod, loads the base model plus your LoRA adapter there, and
    opens a REPL over SSH. The pod is terminated when the session ends —
    no open ports, no idle billing. Type ``exit``/``quit`` or Ctrl+D/Ctrl+C
    to leave. On exit the conversation is saved as an ingest-ready
    transcript (disable with ``--no-save``).
    """
    import time as _time

    from stateset_agents.remote import chat_session

    if adapter is not None and not adapter.exists():
        _echo(f"Adapter directory does not exist: {adapter}", err=True)
        raise typer.Exit(code=2)

    session = chat_session.RemoteChatSession(container_disk_gb=container_disk_gb)
    exit_code = 0
    try:
        _echo(f"Renting a {gpu} pod and loading {base_model}…")
        if adapter is not None:
            _echo(f"With adapter: {adapter}")
        session.start(base_model=base_model, adapter_dir=adapter, gpu=gpu)
        _echo("Model ready. The pod bills until you exit.")

        if prompt:
            for text in prompt:
                _echo(f"you> {text}")
                _echo(f"agent> {session.ask(text)}")
        else:
            turns = 0
            while turns < max_turns:
                try:
                    user_input = input("\nyou> ").strip()
                except (EOFError, KeyboardInterrupt):
                    print()
                    break
                if not user_input:
                    continue
                if user_input in ("exit", "quit"):
                    break
                _echo(f"agent> {session.ask(user_input)}")
                turns += 1
            else:
                _echo(f"Reached --max-turns ({max_turns}); ending the session.")
    except StateSetError as exc:
        _echo(str(exc), err=True)
        exit_code = 1
    finally:
        # Close first — the pod bills until it dies; the transcript can wait.
        _echo("Terminating the pod…")
        session.close()
        if save:
            _save_transcript(session, save_transcript, now=_time.time)

    if exit_code:
        raise typer.Exit(code=exit_code)
    _echo("Session ended; pod terminated.")


def _parse_adapters(entries: list[str]) -> dict[str, Path]:
    """``[name=]path`` entries -> ``{name: Path}``; bare path -> 'adapter'.

    Duplicate names are refused loudly — vLLM would otherwise register one
    adapter and silently shadow the other.
    """
    adapters: dict[str, Path] = {}
    for entry in entries:
        name, sep, raw = entry.partition("=")
        if not sep:
            name, raw = "adapter", entry
        name = name.strip()
        if not name or "/" in name:
            raise typer.BadParameter(
                f"adapter name {name!r} must be a plain identifier"
            )
        if name in adapters:
            raise typer.BadParameter(f"duplicate adapter name {name!r}")
        adapters[name] = Path(raw.strip())
    return adapters


@app.command("serve-remote")
def serve_remote(
    base_model: str | None = typer.Option(
        None,
        "--base-model",
        help="Hugging Face base model to serve (e.g. Qwen/Qwen3.5-0.8B). "
        "Required unless --stop or --list is given.",
    ),
    adapter: list[str] = typer.Option(
        [],
        "--adapter",
        help="Local LoRA adapter directory to serve on top of the base "
        "model, as '[name=]path' — repeatable, so several fine-tunes can "
        "ride one endpoint for A/B comparison. A bare path serves under "
        "the name 'adapter'.",
    ),
    gpu: str = typer.Option(
        "NVIDIA RTX A4000",
        "--gpu",
        help="RunPod GPU type, in RunPod's own vocabulary. The default's "
        "16 GB VRAM fits ~7B fp16 models; go bigger for bigger models.",
    ),
    gpu_count: int = typer.Option(
        1,
        "--gpu-count",
        min=1,
        help="Number of identical GPUs to attach to the serving pod.",
    ),
    vllm_image: str | None = typer.Option(
        None,
        "--vllm-image",
        help="Prebuilt vLLM image for day-zero models. Starts directly "
        "without SSH or an in-pod PyPI installation.",
    ),
    vllm_arg: list[str] = typer.Option(
        [],
        "--vllm-arg",
        help="One additional argument for `vllm serve` in a prebuilt image; "
        "repeat this option for flags and values.",
    ),
    container_disk_gb: int = typer.Option(
        60,
        "--container-disk-gb",
        help="Container disk in GB — must fit the vLLM install (~10 GB) plus "
        "roughly 2.5x the model checkpoint.",
    ),
    ready_timeout_s: int = typer.Option(
        1800,
        "--ready-timeout",
        min=1,
        help="Seconds to wait for vLLM readiness before collecting startup "
        "diagnostics and terminating the pod.",
    ),
    max_hours: float = typer.Option(
        1.0,
        "--max-hours",
        help="Cost control: a self-destruct armed ON THE POD terminates it "
        "after this many hours, even if this machine goes away. The RunPod "
        "API key is copied to SSH-managed pods; direct images use RunPod's "
        "automatically injected pod-scoped key.",
    ),
    max_cost_usd: float | None = typer.Option(
        None,
        "--max-cost",
        min=0.0,
        help="Refuse a direct-image serve when price × max-hours exceeds "
        "this dollar ceiling.",
    ),
    network_volume_id: str | None = typer.Option(
        None,
        "--network-volume-id",
        help="Attach an existing RunPod network volume at /workspace and "
        "cache Hugging Face weights there. The volume is not created or "
        "deleted by StateSet and keeps billing after the pod stops.",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Fail (and terminate the pod) if the adapter-effect probe finds "
        "the adapter's greedy completion byte-identical to the base "
        "model's — the silent no-op vLLM produces for hybrid families. "
        "Without --strict the probe warns loudly instead.",
    ),
    merge: bool = typer.Option(
        False,
        "--merge",
        help="Fold the (single) adapter into full base weights on the pod "
        "and serve the merged checkpoint. REQUIRED for hybrid models "
        "(Qwen3.5/3.8 families): vLLM loads their LoRA adapters without "
        "error and silently serves the base weights (docs/PROOFS.md). The "
        "merged model still answers as model name 'adapter'. Needs disk "
        "for a second full copy of the weights.",
    ),
    stop: str | None = typer.Option(
        None,
        "--stop",
        help="Terminate a running serve pod by name or id, then exit.",
    ),
    list_pods: bool = typer.Option(
        False,
        "--list",
        help="List running serve pods (name, id, status, age, $/hr), then exit.",
    ),
) -> None:
    """Serve a model as a persistent OpenAI-compatible endpoint on RunPod.

    Rents a pod, installs vLLM, loads the base model (plus your adapter),
    and prints the endpoint URL and a generated Bearer token. The pod KEEPS
    RUNNING after this command exits — that is the point — so every run arms
    an on-pod self-destruct at ``--max-hours``, and ``--stop``/``--list``
    exist to manage what is running.
    """
    from stateset_agents.remote import serve_session

    if list_pods:
        try:
            rows = serve_session.list_serve_pods(
                serve_session.RemoteServeSession()._require_api()
            )
        except StateSetError as exc:
            _echo(str(exc), err=True)
            raise typer.Exit(code=1) from exc
        if not rows:
            _echo("No serve pods running.")
            return
        for row in rows:
            cost = row["cost_per_hr"]
            cost_s = f"${cost}/hr" if cost is not None else "?/hr"
            _echo(
                f"{row['name']}  {row['id']}  {row['status']}  "
                f"age {row['age']}  {cost_s}"
            )
        return

    if stop is not None:
        try:
            api = serve_session.RemoteServeSession()._require_api()
            pod = serve_session.find_serve_pod(api, stop)
            api.terminate_pod(str(pod["id"]))
        except StateSetError as exc:
            _echo(str(exc), err=True)
            raise typer.Exit(code=1) from exc
        _echo(f"Terminated pod {pod.get('name')} ({pod['id']}). Billing stopped.")
        return

    if base_model is None:
        _echo("--base-model is required (or use --stop / --list).", err=True)
        raise typer.Exit(code=2)
    adapters = _parse_adapters(adapter)
    for directory in adapters.values():
        if not directory.exists():
            _echo(f"Adapter directory does not exist: {directory}", err=True)
            raise typer.Exit(code=2)
    if max_hours <= 0:
        _echo("--max-hours must be positive.", err=True)
        raise typer.Exit(code=2)

    if vllm_image is not None:
        session = serve_session.RemoteServeSession(
            container_disk_gb=container_disk_gb,
            ready_timeout_s=ready_timeout_s,
            direct_vllm_image=True,
            vllm_args=vllm_arg,
            image=vllm_image,
        )
    else:
        session = serve_session.RemoteServeSession(
            container_disk_gb=container_disk_gb,
            ready_timeout_s=ready_timeout_s,
            direct_vllm_image=False,
            vllm_args=vllm_arg,
        )
    _echo(f"Renting {gpu_count}× {gpu} and serving {base_model} with vLLM…")
    for name, directory in adapters.items():
        _echo(f"With adapter: {directory} (served-model name: {name})")
    if merge:
        _echo("Merging the adapter into full weights before serving (--merge).")
    _echo(f"Self-destruct armed on the pod at {max_hours}h.")
    try:
        session.start(
            base_model=base_model,
            adapters=adapters,
            gpu=gpu,
            max_hours=max_hours,
            merge=merge,
            strict_effect=strict,
            gpu_count=gpu_count,
            max_cost_usd=max_cost_usd,
            network_volume_id=network_volume_id,
        )
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    model_name = "adapter" if adapters else base_model
    for warning in getattr(session, "effect_warnings", []):
        _echo(f"WARNING: {warning}", err=True)
    _echo("")
    _echo(f"Endpoint ready (bills until stopped, max {max_hours}h):")
    _echo(f"  URL:   {session.endpoint_url}/v1")
    _echo(f"  Token: {session.token}")
    _echo(f"  Pod:   {session.pod_name} ({session.pod_id})")
    _echo("")
    _echo("Example:")
    _echo(f"  curl {session.endpoint_url}/v1/chat/completions \\")
    _echo(f'    -H "Authorization: Bearer {session.token}" \\')
    _echo('    -H "Content-Type: application/json" \\')
    _echo(
        f'    -d \'{{"model": "{model_name}", '
        '"messages": [{"role": "user", "content": "Hello"}]}\''
    )
    _echo("")
    _echo("Stop it (billing stops immediately):")
    _echo(f"  stateset-agents serve-remote --stop {session.pod_name}")


def _parse_eval_prompt_line(line: str) -> str | dict:
    """One line of the --eval-prompts file.

    A line that parses as a JSON *object* is a prompt-spec dict
    (``{"prompt", "expect", "forbid", "judge", "min_judge_score"}``);
    anything else — including JSON that isn't an object — is a plain prompt
    string, exactly as before. Spec contents are validated by
    ``RemoteJobSpec``, so a malformed spec exits 2 with the reason.
    """
    import json

    try:
        parsed = json.loads(line)
    except json.JSONDecodeError:
        return line
    return parsed if isinstance(parsed, dict) else line


@app.command("deploy")
def deploy(
    dataset: Path = typer.Option(
        ..., "--dataset", help="Chat-format JSONL to train on."
    ),
    base_model: str = typer.Option(
        ..., "--base-model", help="Hugging Face base model."
    ),
    output_dir: Path = typer.Option(
        Path("outputs/deploy_v1"),
        "--output-dir",
        help="Where the trained adapter is written locally.",
    ),
    gpu: str | None = typer.Option(
        None,
        "--gpu",
        help="RunPod GPU used for both phases. Catalog default when omitted.",
    ),
    gpu_count: int | None = typer.Option(
        None,
        "--gpu-count",
        min=1,
        help="Identical GPUs used for both training and serving.",
    ),
    container_disk_gb: int | None = typer.Option(
        None, "--container-disk-gb", help="~2.5x the checkpoint size."
    ),
    num_epochs: int = typer.Option(3, "--num-epochs"),
    max_cost_usd: float | None = typer.Option(
        None,
        "--max-cost",
        help="Per-phase ceiling for training and serving provisioning.",
    ),
    max_hours: float = typer.Option(
        1.0,
        "--max-hours",
        help="Endpoint self-destruct, armed on the serving pod.",
    ),
) -> None:
    """Fine-tune on a rented GPU, then serve the result — one command.

    ``train-remote`` then ``serve-remote``, glued: rent, train, give the
    hardware back, rent again, serve the fresh adapter as an authenticated
    OpenAI-compatible endpoint, print the URL and token. The zero-to-API
    story of docs/GETTING_STARTED_API.md as a single invocation.
    """
    from stateset_agents.remote import serve_session
    from stateset_agents.remote.model_catalog import (
        get_model_support,
        plan_runpod_resources,
    )

    support = get_model_support(base_model)
    if support is not None:
        plan = plan_runpod_resources(
            base_model,
            gpu=gpu,
            gpu_count=gpu_count,
            container_disk_gb=container_disk_gb,
        )
        gpu = plan["gpu"]
        gpu_count = plan["gpu_count"]
        container_disk_gb = plan["container_disk_gb"]
        if plan["manual_review_required"] and max_cost_usd is None:
            _echo(
                "Frontier deploy plans require --max-cost because both training "
                "and serving allocate estimated multi-GPU resources.",
                err=True,
            )
            raise typer.Exit(code=2)
    else:
        gpu = gpu or "NVIDIA H100 80GB HBM3"
        gpu_count = gpu_count or 1
    assert gpu is not None and gpu_count is not None

    spec = RemoteJobSpec(
        dataset=dataset,
        base_model=base_model,
        output_dir=output_dir,
        num_epochs=num_epochs,
        gpu=gpu,
        gpu_count=gpu_count,
        container_disk_gb=container_disk_gb,
        max_cost_usd=max_cost_usd,
    )
    try:
        executor = get_executor("runpod")
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo(f"[1/2] Training {base_model} on {dataset} ({gpu})…")
    try:
        result = executor.wait(executor.submit(spec))
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    if not result.succeeded or result.output_dir is None:
        for line in result.logs[-20:]:
            _echo(line)
        _echo(f"Training {result.status.value}; not serving.", err=True)
        raise typer.Exit(code=1)
    if result.cost_usd is not None:
        _echo(f"Trained. Cost: ~${result.cost_usd:.2f}")

    _echo(f"[2/2] Serving {base_model} + fresh adapter…")
    session = serve_session.RemoteServeSession(
        container_disk_gb=container_disk_gb or 60
    )
    _echo(f"Self-destruct armed on the pod at {max_hours}h.")
    try:
        session.start(
            base_model=base_model,
            adapters={"adapter": Path(result.output_dir)},
            gpu=gpu,
            gpu_count=gpu_count,
            max_hours=max_hours,
            max_cost_usd=max_cost_usd,
        )
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo("")
    _echo(f"Endpoint ready (bills until stopped, max {max_hours}h):")
    _echo(f"URL:   {session.endpoint_url}/v1")
    _echo(f"Token: {session.token}")
    _echo(
        "Ask the fine-tune:  curl "
        f"{session.endpoint_url}/v1/chat/completions "
        f'-H "Authorization: Bearer {session.token}" '
        '-H "Content-Type: application/json" '
        '-d \'{"model":"adapter","messages":[{"role":"user",'
        '"content":"hello"}]}\''
    )
    _echo(f"Stop it:  stateset-agents serve-remote --stop {session.pod_name}")


@app.command("train-remote")
def train_remote(
    dataset: Path = typer.Option(
        ...,
        "--dataset",
        help="Chat-format JSONL to train on — typically improved/curated.jsonl.",
    ),
    base_model: str = typer.Option(
        ..., "--base-model", help="Hugging Face base model (e.g. Qwen/Qwen3.5-0.8B)."
    ),
    provider: str = typer.Option(
        "modal",
        "--provider",
        help=(
            f"Where to run (default: modal): {', '.join(available_providers())}. "
            "'river' is River AI's remote autograd service: it trains without "
            "renting a machine, so the GPU/disk/cloud-type options are "
            "ignored, and the result is a river:// checkpoint pointer rather "
            "than local adapter weights (live-verified; see "
            "docs/GETTING_STARTED_RIVER.md). 'fireworks' is Fireworks AI's "
            "managed "
            "fine-tuning service: it also picks its own training hardware, "
            "so the GPU/disk/cloud-type options are ignored, and the tuned "
            "LoRA addon lives on Fireworks — add --deploy to serve it (see "
            "docs/FIREWORKS_PROVIDER.md). 'nebius' runs an OCI training job "
            "on Serverless AI; 'coreweave' submits a Kubernetes Job to an "
            "existing CKS cluster. Both exchange artifacts through their "
            "S3-compatible object stores. Tinker runs remote-autograd SFT/RL; "
            "Prime runs verifiers/OpenEnv RL; Hugging Face runs container Jobs; "
            "Together runs managed SFT. See docs/MANAGED_TRAINING_PROVIDERS.md."
        ),
    ),
    job_kind: str = typer.Option(
        "sft",
        "--job-kind",
        help="Training mode: sft, harvest, or rl (provider capabilities apply).",
    ),
    provider_options_json: str | None = typer.Option(
        None,
        "--provider-options-json",
        help=(
            "Provider/mode options as JSON. River SFT accepts seed and shuffle. "
            "Prime RL accepts environment, "
            "harness, runtime, max_steps, rollouts_per_example, max_tokens, "
            "and temperature."
        ),
    ),
    output_dir: Path = typer.Option(
        Path("outputs/sft_v1"),
        "--output-dir",
        help="Where the trained adapter is written.",
    ),
    num_epochs: int = typer.Option(3, "--num-epochs"),
    lora_r: int = typer.Option(16, "--lora-r"),
    lora_alpha: int = typer.Option(32, "--lora-alpha"),
    learning_rate: float = typer.Option(2e-5, "--learning-rate"),
    max_length: int = typer.Option(1024, "--max-length"),
    per_device_batch_size: int = typer.Option(2, "--per-device-batch-size"),
    gradient_accumulation_steps: int = typer.Option(4, "--gradient-accumulation-steps"),
    gpu: str | None = typer.Option(
        None,
        "--gpu",
        help="GPU to request, in the provider's own vocabulary (Modal: "
        '"A10"; RunPod: "NVIDIA RTX A4000"). Defaults to the provider\'s '
        "own default.",
    ),
    gpu_count: int | None = typer.Option(
        None,
        "--gpu-count",
        help="How many GPUs to request on providers that expose topology. "
        "With more than one, the job shards the model across all of them "
        "(device_map='auto'), letting a checkpoint bigger than one card "
        "train. Nebius requires an exact matching NEBIUS_PRESET. When "
        "omitted on RunPod, the model catalog selects a count.",
    ),
    timeout: int = typer.Option(3600, "--timeout", help="Job timeout in seconds."),
    seed: int | None = typer.Option(
        None,
        "--seed",
        help="Explicit SFT initialization/training seed (0–4294967295); providers must declare support. Omit to keep provider defaults.",
    ),
    package_version: str | None = typer.Option(
        None,
        "--package-version",
        help="stateset-agents version installed remotely. Defaults to the "
        "running version.",
    ),
    container_disk_gb: int | None = typer.Option(
        None,
        "--container-disk-gb",
        help="Provider container/scratch disk in GB for the model "
        "download. Size it at roughly 2.5x the checkpoint (a 30B BF16 "
        "model is ~63GB). Defaults to the executor's own default.",
    ),
    cloud_type: str = typer.Option(
        "SECURE",
        "--cloud-type",
        help="RunPod only: SECURE (default, reserved capacity) or COMMUNITY "
        "(~spot pricing — markedly cheaper, but the pod can be reclaimed "
        "mid-job; the executor then provisions a fresh pod once and "
        "restarts training from scratch).",
    ),
    max_cost_usd: float | None = typer.Option(
        None,
        "--max-cost",
        help=(
            "Refuse to run if the pod could cost more than this many dollars "
            "(its full --timeout at the provider's quoted hourly rate). The "
            "check happens before any work starts."
        ),
    ),
    network_volume_id: str | None = typer.Option(
        None,
        "--network-volume-id",
        help="RunPod only: id of an existing network volume to mount at "
        "/workspace. Checkpoints then survive pod death, and the "
        "pod-died-mid-job retry resumes from the newest checkpoint "
        "instead of restarting from scratch. The pod is pinned to the "
        "volume's datacenter. The volume is yours to manage — it bills "
        "monthly until you delete it.",
    ),
    resume: bool = typer.Option(
        False,
        "--resume",
        help="Resume from the newest checkpoint-* in --output-dir when one "
        "exists (otherwise trains fresh). Useful for rerunning an "
        "interrupted local job, or a RunPod job whose checkpoints live "
        "on a network volume (--network-volume-id); a fresh RunPod pod "
        "without a volume starts with an empty output dir, so this is a "
        "no-op there.",
    ),
    eval_prompts: Path | None = typer.Option(
        None,
        "--eval-prompts",
        help="Local text file of prompts, one per line (blanks skipped). "
        "A line that parses as a JSON object is a prompt spec — "
        '{"prompt", "expect", "forbid", "judge", "min_judge_score"} — '
        "whose assertions gate the job's exit code; any other line is a "
        "plain prompt. After training, each prompt is answered by both "
        "the base model and the tuned adapter; the comparison lands in "
        "output_dir/eval_results.json.",
    ),
    eval_max_new_tokens: int = typer.Option(
        90,
        "--eval-max-new-tokens",
        help="Token budget per eval completion. Raise it for reasoning "
        "models whose answers follow a long preamble.",
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        help="Fireworks only: after training, create an on-demand deployment "
        "and load the tuned LoRA addon onto it, printing the "
        "OpenAI-compatible base URL. This rents hardware and bills for as "
        "long as the deployment exists — tear it down with "
        "`stateset-agents undeploy --deployment <name>`.",
    ),
    deploy_accelerator: str | None = typer.Option(
        None,
        "--deploy-accelerator",
        help="Fireworks only: accelerator for --deploy, in Fireworks' own "
        'vocabulary ("NVIDIA_H100_80GB", "NVIDIA_A100_80GB", …). '
        "Defaults to whatever Fireworks picks for the base model.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Run the packaged training command in dry-run mode. Remote providers "
        "may still allocate compute; use --plan-only for a non-billable plan.",
    ),
    plan_only: bool = typer.Option(
        False,
        "--plan-only",
        help="Print the resolved provider/resource plan and exit without provisioning.",
    ),
    auto_resources: bool = typer.Option(
        True,
        "--auto-resources/--no-auto-resources",
        help="Apply catalog GPU/count/disk recommendations on RunPod when omitted.",
    ),
) -> None:
    """Run SFT, harvest, or RL on local, rented, or managed compute."""
    prompts: list[str | dict] | None = None
    if eval_prompts is not None:
        if not eval_prompts.exists():
            _echo(f"Eval prompts file does not exist: {eval_prompts}", err=True)
            raise typer.Exit(code=2)
        prompts = [
            _parse_eval_prompt_line(line.strip())
            for line in eval_prompts.read_text().splitlines()
            if line.strip()
        ]

    provider_options: dict[str, object] | None = None
    if provider_options_json:
        import json

        try:
            decoded = json.loads(provider_options_json)
            if not isinstance(decoded, dict):
                raise ValueError("must decode to an object")
            provider_options = decoded
        except (json.JSONDecodeError, ValueError) as exc:
            _echo(f"Invalid --provider-options-json: {exc}", err=True)
            raise typer.Exit(code=2) from exc

    normalized_provider = provider.strip().lower()
    resource_plan: dict[str, object] | None = None
    if normalized_provider == "runpod" and auto_resources:
        from stateset_agents.remote.model_catalog import plan_runpod_resources

        runpod_plan = plan_runpod_resources(
            base_model,
            gpu=gpu,
            gpu_count=gpu_count,
            container_disk_gb=container_disk_gb,
        )
        resource_plan = dict(runpod_plan)
        resource_plan.update(
            {
                "timeout_s": timeout,
                "max_cost_usd": max_cost_usd,
                "network_volume_id": network_volume_id,
            }
        )
        gpu = runpod_plan["gpu"]
        gpu_count = runpod_plan["gpu_count"]
        container_disk_gb = runpod_plan["container_disk_gb"]
        if runpod_plan["manual_review_required"] and not plan_only:
            if max_cost_usd is None:
                _echo(
                    "This model's RunPod topology is estimated or unknown. "
                    "Pass --max-cost to acknowledge a bounded live run, or "
                    "use --plan-only to inspect the non-billable plan.",
                    err=True,
                )
                raise typer.Exit(code=2)

    if plan_only:
        import json

        if resource_plan is None:
            resource_plan = {
                "provider": normalized_provider,
                "model": base_model,
                "gpu": gpu or "provider default",
                "gpu_count": gpu_count or 1,
                "container_disk_gb": container_disk_gb,
                "provisions_hardware": False,
                "note": "The provider selects managed resources where applicable.",
            }
        _echo(json.dumps(resource_plan, indent=2, sort_keys=True))
        return

    try:
        spec = RemoteJobSpec(
            dataset=dataset,
            base_model=base_model,
            output_dir=output_dir,
            num_epochs=num_epochs,
            lora_r=lora_r,
            lora_alpha=lora_alpha,
            learning_rate=learning_rate,
            max_length=max_length,
            per_device_batch_size=per_device_batch_size,
            gradient_accumulation_steps=gradient_accumulation_steps,
            dry_run=dry_run,
            resume=resume,
            eval_prompts=prompts,
            eval_max_new_tokens=eval_max_new_tokens,
            job_kind=job_kind,
            harvest=provider_options,
            gpu=gpu,
            gpu_count=gpu_count or 1,
            timeout_s=timeout,
            package_version=package_version,
            container_disk_gb=container_disk_gb,
            cloud_type=cloud_type,
            network_volume_id=network_volume_id,
            max_cost_usd=max_cost_usd,
            seed=seed,
        )
    except ValueError as exc:
        _echo(f"Invalid job: {exc}", err=True)
        raise typer.Exit(code=2) from exc

    try:
        executor = get_executor(provider)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc

    if deploy and normalized_provider != "fireworks":
        _echo("--deploy is only supported by --provider fireworks.", err=True)
        raise typer.Exit(code=2)

    _echo(
        f"Submitting {spec.job_kind.upper()} job to '{provider}' "
        f"({spec.gpu or 'provider default'})…"
    )
    try:
        handle = executor.submit(spec)
        result = executor.wait(handle)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    for line in result.logs:
        _echo(line)

    if not result.succeeded:
        _echo(f"Job {result.status.value}.", err=True)
        raise typer.Exit(code=1)

    if result.cost_usd is not None:
        _echo(f"Cost: ~${result.cost_usd:.2f} ({result.duration_s:.0f}s of pod time)")
    if normalized_provider in {
        "river",
        "tinker",
        "prime",
        "huggingface",
        "together",
    }:
        # River keeps the weights; what landed locally is a pointer, so the
        # usual `serve --checkpoint` hint would be a lie.
        _echo(f"Done. {executor.name} result pointer written to {result.output_dir}")
        _echo(
            f"The managed result lives on {executor.name}; use the JSON pointer "
            f"in {result.output_dir} to reconnect or deploy it."
        )
        return
    if normalized_provider == "fireworks":
        _fireworks_done(executor, handle, result, deploy, deploy_accelerator)
        return
    _echo(f"Done. Adapter written to {result.output_dir}")
    _echo(f"Use it with: stateset-agents serve --checkpoint {result.output_dir}")


def _fireworks_done(executor, handle, result, deploy: bool, accelerator: str | None):
    """Report where the tuned addon lives, and optionally serve it.

    Whether local weights landed depends on the account, so the pointer is
    read back rather than assumed — telling a user to `serve --checkpoint`
    a directory holding only a pointer would be a lie.
    """
    import json

    from stateset_agents.remote.fireworks import CHECKPOINT_POINTER_NAME

    pointer_path = Path(result.output_dir) / CHECKPOINT_POINTER_NAME
    pointer = json.loads(pointer_path.read_text()) if pointer_path.exists() else {}
    model = pointer.get("model", "<unknown>")

    _echo(f"Done. Fireworks model: {model}")
    if pointer.get("weights_downloaded"):
        _echo(
            "Adapter weights were downloaded — use them with: "
            f"stateset-agents serve --checkpoint {result.output_dir}"
        )
    else:
        _echo(
            "The trained LoRA lives on Fireworks — sample it through their "
            f"OpenAI-compatible API at {pointer.get('inference_base_url', '')} "
            f"using model id {model}"
        )

    if not deploy:
        return
    _echo("Creating an on-demand deployment (this rents hardware)…")
    try:
        deployment = executor.deploy(handle, accelerator_type=accelerator)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo(f"Deployed: {deployment['deployment']}")
    _echo(f"Base URL: {deployment['base_url']}  model: {deployment['model']}")
    _echo(
        "It bills until deleted: stateset-agents undeploy --deployment "
        f"{deployment['deployment']}"
    )


@app.command("remote-job")
def remote_job(
    job_id: str = typer.Option(..., "--job-id", help="Provider job id to resume."),
    provider: str = typer.Option(
        "fireworks",
        "--provider",
        help=(
            "Provider that owns the job. Durable reconnect is supported by "
            "Fireworks, Hugging Face Jobs, and Together."
        ),
    ),
    wait: bool = typer.Option(
        False, "--wait", help="Poll to a terminal state and fetch its artifacts."
    ),
    fetch: bool = typer.Option(
        False, "--fetch", help="Fetch artifacts now; the job must be complete."
    ),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", help="Override the persisted artifact destination."
    ),
) -> None:
    """Reconnect to an asynchronous remote job after the original CLI exits."""
    from stateset_agents.remote.job import JobHandle

    try:
        executor = get_executor(provider)
        handle = JobHandle(provider=executor.name, job_id=job_id)
        if wait:
            result = executor.wait(handle)
            for line in result.logs:
                _echo(line)
            _echo(f"Job {job_id}: {result.status.value}")
            if result.output_dir is not None:
                _echo(f"Artifacts: {result.output_dir}")
            if not result.succeeded:
                raise typer.Exit(code=1)
            return

        status = executor.status(handle)
        for line in executor.logs(handle):
            _echo(line)
        _echo(f"Job {job_id}: {status.value}")
        if fetch:
            destination = executor.fetch(handle, output_dir)
            _echo(f"Artifacts: {destination}")
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc


@app.command("remote-providers")
def remote_providers(
    json_output: bool = typer.Option(
        False, "--json", "--json-output", help="Emit machine-readable JSON."
    ),
) -> None:
    """List provider capabilities without loading SDKs or credentials."""
    import json

    rows = [get_executor(name).capabilities() for name in available_providers()]
    if json_output:
        _echo(json.dumps(rows, indent=2, sort_keys=True))
        return
    for row in rows:
        flags = []
        if row["durable_handles"]:
            flags.append("durable")
        if row["managed_deployments"]:
            flags.append("deployments")
        suffix = f"; {', '.join(flags)}" if flags else ""
        _echo(
            f"{row['provider']}: {', '.join(row['job_kinds'])}; "
            f"compute={row['compute_model']}; result={row['result_kind']}; "
            f"verification={row['verification_status']}{suffix}"
        )


@app.command("model-support")
def model_support(
    json_output: bool = typer.Option(
        False, "--json", "--json-output", help="Emit machine-readable JSON."
    ),
) -> None:
    """Show model/provider proof levels without overstating live support."""
    import json

    from stateset_agents.remote.model_catalog import model_catalog
    from stateset_agents.remote.model_evidence import model_provider_evidence

    rows = model_provider_evidence()
    if json_output:
        _echo(
            json.dumps(
                {"schema_version": 2, "models": model_catalog(), "evidence": rows},
                indent=2,
            )
        )
        return
    for model in model_catalog():
        _echo(
            f"{model['model']}: tier={model['tier']}; "
            f"certification={model['certification']}; "
            f"recommended_provider={model['recommended_provider']}"
        )
    _echo("\nEvidence:")
    for row in rows:
        checked = f" ({row['checked_at']})" if row["checked_at"] else ""
        _echo(
            f"{row['model']} @ {row['provider']}: {row['level']}/"
            f"{row['outcome']}{checked}\n  {row['evidence']}"
        )


@app.command("river-preflight")
def river_preflight(
    base_model: list[str] = typer.Option(
        [], "--base-model", help="Exact model ID to check (repeatable)."
    ),
    live: bool = typer.Option(
        False, "--live", help="Also query account model access; creates no sessions."
    ),
    timeout_seconds: float = typer.Option(
        15.0,
        "--timeout-seconds",
        help="Live SDK request timeout; retries are disabled.",
    ),
    output: Path | None = typer.Option(
        None, "--output", help="Also save JSON to a new file; refuses overwrite."
    ),
) -> None:
    """Check River prerequisites and optional live model access, emitting JSON.

    Exit 0 means the requested checks passed, 1 means a check failed, and 2
    means invalid options or a report-write error. No training or inference runs.
    """
    import json

    from stateset_agents.remote.river_runtime import river_preflight as preflight

    if output is not None and (output.exists() or output.is_symlink()):
        _echo(f"Refusing to overwrite preflight report: {output}", err=True)
        raise typer.Exit(code=2)
    try:
        payload = preflight(base_model, live=live, timeout_seconds=timeout_seconds)
    except ValueError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    rendered = json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if output is not None:
        try:
            output.parent.mkdir(parents=True, exist_ok=True)
            with output.open("x", encoding="utf-8") as stream:
                stream.write(rendered)
        except OSError as exc:
            _echo(f"Could not write preflight report: {exc}", err=True)
            raise typer.Exit(code=2) from exc
    _echo(rendered.rstrip())
    if not payload["passed"]:
        raise typer.Exit(code=1)


@app.command("provider-canary")
def provider_canary(
    provider: list[str] = typer.Option(
        [],
        "--provider",
        help="Provider to probe (repeatable). Default: river, runpod, fireworks.",
    ),
    output: Path | None = typer.Option(
        None, "--output", help="Optional path for the JSON evidence report."
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Exit non-zero when a provider fails or credentials are missing.",
    ),
) -> None:
    """Run non-billable live authentication and cleanup canaries."""
    import json

    from stateset_agents.remote.canary import (
        provider_canary_envelope,
        run_canary_matrix,
    )

    selected = provider or ["river", "runpod", "fireworks"]
    try:
        results = run_canary_matrix(selected)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc

    payload = provider_canary_envelope(results)
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if output is not None:
        try:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(rendered, encoding="utf-8")
        except OSError as exc:
            _echo(f"Could not write canary report: {exc}", err=True)
            raise typer.Exit(code=2) from exc
        _echo(f"Canary report: {output}", err=True)
    _echo(rendered.rstrip())

    if strict and any(not result.ok for result in results):
        raise typer.Exit(code=1)


@app.command("runpod-orphans")
def runpod_orphans(
    terminate: bool = typer.Option(
        False,
        "--terminate",
        help="Terminate every leased pod. Without this flag the command is read-only.",
    ),
) -> None:
    """Find training pods left behind when their submitting process crashed."""
    from stateset_agents.remote.runpod import RunPodExecutor

    executor = get_executor("runpod")
    if not isinstance(
        executor, RunPodExecutor
    ):  # pragma: no cover - registry invariant
        raise typer.Exit(code=1)
    leases = executor.orphaned_leases()
    if not leases:
        _echo("No locally recorded RunPod orphans.")
        return
    for lease in leases:
        _echo(
            f"{lease.get('pod_id')}: job={lease.get('job_id')} "
            f"model={lease.get('base_model')} gpu={lease.get('gpu')}"
        )
    if not terminate:
        _echo("Read-only. Re-run with --terminate after checking active jobs.")
        return
    try:
        terminated = executor.cleanup_orphans()
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    for pod_id in terminated:
        _echo(f"Terminated {pod_id}; cleanup lease removed.")


@app.command("undeploy")
def undeploy(
    deployment: str = typer.Option(
        ...,
        "--deployment",
        help="Fireworks deployment name or id to delete, as printed by "
        "`train-remote --deploy`.",
    ),
) -> None:
    """Delete a Fireworks deployment so it stops billing."""
    executor = get_executor("fireworks")
    try:
        executor.undeploy(deployment)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    except NotImplementedError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo(f"Deleted deployment {deployment}.")


@app.command("costs")
def costs(
    ledger: Path | None = typer.Option(
        None,
        "--ledger",
        help="Ledger file to read (default: the shared per-user ledger).",
    ),
    limit: int = typer.Option(10, "--limit", help="How many recent runs to list."),
    json_output: bool = typer.Option(
        False, "--json", "--json-output", help="Emit machine-readable JSON."
    ),
) -> None:
    """Show what remote runs have actually cost.

    Every remote run appends a line to the cost ledger — what it trained, on
    what hardware, for how long, and the dollar amount. This reads it back.
    """
    import json as _json

    from stateset_agents.remote.ledger import read_entries, summarize

    entries = read_entries(ledger)
    summary = summarize(entries)

    if json_output:
        _echo(
            _json.dumps(
                {"summary": summary, "recent": entries[-limit:]},
                indent=2,
                sort_keys=True,
            )
        )
        return

    if not entries:
        _echo("No remote runs recorded yet.")
        return

    _echo(
        f"{summary['runs']} run(s), ${summary['total_usd']:.2f} total "
        f"({summary['runs_with_known_cost']} with a known price)"
    )
    _echo("")
    for entry in entries[-limit:]:
        cost = entry.get("cost_usd")
        cost_text = f"${cost:.2f}" if isinstance(cost, (int, float)) else "  ? "
        duration = entry.get("duration_s")
        mins = f"{duration / 60:.0f}m" if isinstance(duration, (int, float)) else "?"
        _echo(
            f"  {cost_text:>7}  {mins:>4}  {entry.get('status', '?'):<9} "
            f"{entry.get('gpu', '?')}  {entry.get('base_model', '?')}"
        )
    _echo("")
    for model, total in sorted(summary["by_model"].items(), key=lambda kv: -kv[1])[:5]:
        _echo(f"  ${total:>7.2f}  {model}")


@app.command("adapters")
def adapters(
    directory: Path = typer.Option(
        Path("outputs"),
        "--dir",
        "-d",
        help="Directory to scan for trained adapters.",
    ),
    json_output: bool = typer.Option(
        False, "--json", "--json-output", help="Emit machine-readable JSON."
    ),
) -> None:
    """List trained adapters with their provenance and lineage.

    Every training run writes a manifest beside its adapter — base model,
    dataset hash, hyperparameters, eval outcome, and the adapter it descends
    from. This reads them back, so an adapter directory is never anonymous.
    """
    import json as _json

    from stateset_agents.training.lineage import build_lineage, discover_adapters

    found = discover_adapters(directory)
    if json_output:
        _echo(
            _json.dumps(
                {"adapters": found, "lineage": build_lineage(found)},
                indent=2,
                sort_keys=True,
            )
        )
        return

    if not found:
        _echo(f"No adapters found under {directory}/")
        return

    lineage = build_lineage(found)
    _echo(f"{len(found)} adapter(s) under {directory}/")
    _echo("")
    for entry in found:
        manifest = entry.get("manifest")
        _echo(f"  {entry['path']}")
        if not manifest:
            _echo("      (no manifest — trained before provenance was recorded)")
        else:
            _echo(f"      base:    {manifest.get('base_model', '?')}")
            rows = manifest.get("dataset_rows")
            sha = (manifest.get("dataset_sha256") or "")[:12]
            _echo(f"      data:    {rows if rows is not None else '?'} rows  {sha}")
            hyper = manifest.get("hyperparameters") or {}
            if hyper:
                _echo(
                    f"      train:   r={hyper.get('lora_r', '?')} "
                    f"epochs={hyper.get('num_epochs', '?')} "
                    f"lr={hyper.get('learning_rate', '?')}"
                )
            passed, total = manifest.get("eval_passed"), manifest.get("eval_total")
            if total:
                _echo(f"      eval:    {passed}/{total} assertion(s) passed")
            if manifest.get("parent_adapter"):
                _echo(f"      parent:  {manifest['parent_adapter']}")
        children = lineage.get(entry["path"], [])
        for child in children:
            _echo(f"      child:   {child}")
    if lineage:
        _echo("")
        _echo(f"{len(lineage)} lineage link(s) found.")


@app.command("inference-deploy")
def inference_deploy(
    provider: str = typer.Option(
        ..., "--provider", help="coreweave, huggingface, or nebius."
    ),
    name: str = typer.Option(..., "--name", help="Provider deployment name."),
    model_name: str = typer.Option(
        ..., "--model-name", help="Model name exposed by the OpenAI-compatible API."
    ),
    weights_uri: str = typer.Option(
        ..., "--weights-uri", help="Complete model directory in s3://bucket/path."
    ),
    gpu: str = typer.Option(
        ..., "--gpu", help="Provider GPU platform or instance type."
    ),
    gpu_count: int = typer.Option(1, "--gpu-count", min=1),
    min_replicas: int = typer.Option(1, "--min-replicas", min=1),
    max_replicas: int = typer.Option(1, "--max-replicas", min=1),
    runtime: str = typer.Option(
        "vllm", "--runtime", help="Inference runtime (vllm or dynamo-vllm)."
    ),
    gateway_id: str | None = typer.Option(
        None, "--gateway-id", help="Existing CoreWeave inference gateway."
    ),
    zone: str | None = typer.Option(
        None, "--zone", help="CoreWeave zone used when creating a gateway."
    ),
    runtime_version: str | None = typer.Option(None, "--runtime-version"),
    production: bool = typer.Option(
        False,
        "--production",
        help="Require artifact-bound quality and lineage evidence.",
    ),
    promotion_receipt: Path | None = typer.Option(None, "--promotion-receipt"),
    artifact_directory: Path | None = typer.Option(None, "--artifact-directory"),
) -> None:
    """Deploy complete model weights to managed OpenAI-compatible inference."""
    import json

    from stateset_agents.remote.deployment import DeploymentSpec
    from stateset_agents.remote.deployment_registry import get_deployment_provider

    if max_replicas < min_replicas:
        _echo("--max-replicas must be >= --min-replicas", err=True)
        raise typer.Exit(code=2)
    try:
        spec = DeploymentSpec(
            name=name,
            model_name=model_name,
            weights_uri=weights_uri,
            gpu=gpu,
            gpu_count=gpu_count,
            min_replicas=min_replicas,
            max_replicas=max_replicas,
            runtime=runtime,
            runtime_version=runtime_version,
            gateway_id=gateway_id,
            zone=zone,
            production=production,
            promotion_receipt=str(promotion_receipt) if promotion_receipt else None,
            artifact_directory=str(artifact_directory) if artifact_directory else None,
        )
        handle = get_deployment_provider(provider).deploy(spec)
    except (StateSetError, ValueError, OSError) as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo(json.dumps(handle.__dict__, indent=2, sort_keys=True))


@app.command("inference-status")
def inference_status(
    provider: str = typer.Option(
        ..., "--provider", help="coreweave, huggingface, or nebius."
    ),
    deployment_id: str = typer.Option(..., "--deployment-id"),
    model_name: str = typer.Option(..., "--model-name"),
) -> None:
    """Read a managed inference deployment without mutating it."""
    import json

    from stateset_agents.remote.deployment import DeploymentHandle
    from stateset_agents.remote.deployment_registry import get_deployment_provider

    normalized_provider = provider.strip().lower()
    handle = DeploymentHandle(normalized_provider, deployment_id, model_name)
    try:
        payload = get_deployment_provider(provider).status(handle)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo(json.dumps(payload, indent=2, sort_keys=True))


@app.command("inference-delete")
def inference_delete(
    provider: str = typer.Option(
        ..., "--provider", help="coreweave, huggingface, or nebius."
    ),
    deployment_id: str = typer.Option(..., "--deployment-id"),
    model_name: str = typer.Option(..., "--model-name"),
    gateway_id: str | None = typer.Option(
        None,
        "--gateway-id",
        help="CoreWeave gateway associated with the deployment.",
    ),
    delete_gateway: bool = typer.Option(
        False,
        "--delete-gateway",
        help="Also delete the CoreWeave gateway created for this deployment.",
    ),
) -> None:
    """Delete a managed inference deployment so its compute stops billing."""
    from stateset_agents.remote.deployment import DeploymentHandle
    from stateset_agents.remote.deployment_registry import get_deployment_provider

    normalized_provider = provider.strip().lower()
    if delete_gateway and not gateway_id:
        _echo("--delete-gateway requires --gateway-id", err=True)
        raise typer.Exit(code=2)
    handle = DeploymentHandle(
        normalized_provider,
        deployment_id,
        model_name,
        gateway_id=gateway_id,
        owns_gateway=delete_gateway,
    )
    try:
        get_deployment_provider(provider).delete(handle)
    except StateSetError as exc:
        _echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    _echo(f"Deleted {provider} deployment {deployment_id}.")
