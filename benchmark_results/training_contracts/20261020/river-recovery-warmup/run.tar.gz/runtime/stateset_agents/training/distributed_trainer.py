"""
Distributed Multi-GPU Training for GRPO Agent Framework

This module provides advanced distributed training capabilities with
proper rank handling, memory optimization, and fault tolerance.
"""

import asyncio
import logging
import os
import warnings
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist
import torch.multiprocessing as mp

try:
    from torch.distributed.elastic.multiprocessing.errors import record
    from torch.nn.parallel import DistributedDataParallel as DDP

    DISTRIBUTED_AVAILABLE = True
except ImportError:
    DISTRIBUTED_AVAILABLE = False

try:
    import wandb

    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False

from stateset_agents.core.agent import Agent
from stateset_agents.core.environment import Environment
from stateset_agents.core.reward import RewardFunction
from stateset_agents.core.trajectory import TrajectoryGroup
from stateset_agents.utils.monitoring import MonitoringService

from .config import TrainingConfig
from .loss_computation import compute_grpo_loss
from .multi_turn_evaluation import coerce_reward_result

logger = logging.getLogger(__name__)

DISTRIBUTED_TRAIN_EXCEPTIONS = (OSError, RuntimeError, ValueError)


@dataclass
class DistributedConfig:
    """Configuration for distributed training"""

    backend: str = "nccl"  # nccl for GPU, gloo for CPU
    init_method: str = "env://"
    world_size: int = 1
    rank: int = 0
    local_rank: int = 0
    master_addr: str = "localhost"
    master_port: str = "12355"

    # Training specific
    gradient_accumulation_steps: int = 1
    sync_bn: bool = True
    find_unused_parameters: bool = False

    # Fault tolerance
    max_restarts: int = 3
    restart_interval: int = 60

    # Memory optimization
    cpu_offload: bool = False
    activation_checkpointing: bool = False
    mixed_precision: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "backend": self.backend,
            "init_method": self.init_method,
            "world_size": self.world_size,
            "rank": self.rank,
            "local_rank": self.local_rank,
            "master_addr": self.master_addr,
            "master_port": self.master_port,
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "sync_bn": self.sync_bn,
            "find_unused_parameters": self.find_unused_parameters,
            "max_restarts": self.max_restarts,
            "restart_interval": self.restart_interval,
            "cpu_offload": self.cpu_offload,
            "activation_checkpointing": self.activation_checkpointing,
            "mixed_precision": self.mixed_precision,
        }


class DistributedGRPOTrainer:
    """
    Distributed GRPO trainer with advanced multi-GPU capabilities
    """

    def __init__(
        self,
        agent: Agent,
        environment: Environment,
        reward_function: RewardFunction,
        training_config: TrainingConfig,
        distributed_config: DistributedConfig,
        monitoring_service: MonitoringService | None = None,
    ):
        if not DISTRIBUTED_AVAILABLE:
            raise ImportError("PyTorch distributed training is not available")

        self.agent = agent
        self.environment = environment
        self.reward_function = reward_function
        self.training_config = training_config
        self.distributed_config = distributed_config
        self.monitoring = monitoring_service

        # Training state
        self.is_initialized = False
        self.is_master = False
        self.device: torch.device | None = None
        self.model: Any | None = None
        self.optimizer: Any | None = None
        self.scaler: torch.cuda.amp.GradScaler | None = None

        # Metrics
        self.training_metrics: dict[str, Any] = {}
        self.step_count = 0
        self.epoch_count = 0

        # Running reward statistics (used by the `global_mean` GRPO baseline)
        self._global_reward_mean = 0.0
        self._global_reward_sum = 0.0
        self._global_reward_count = 0

        warnings.warn(
            "DistributedGRPOTrainer is deprecated and non-functional for real "
            "training; use stateset_agents.training.distributed.DistributedTrainer",
            DeprecationWarning,
            stacklevel=2,
        )

    def setup_distributed(self, rank: int, world_size: int):
        """Setup distributed training environment"""
        # Set environment variables
        os.environ["MASTER_ADDR"] = self.distributed_config.master_addr
        os.environ["MASTER_PORT"] = self.distributed_config.master_port
        os.environ["WORLD_SIZE"] = str(world_size)
        os.environ["RANK"] = str(rank)
        os.environ["LOCAL_RANK"] = str(rank)

        # Initialize process group
        dist.init_process_group(
            backend=self.distributed_config.backend,
            init_method=self.distributed_config.init_method,
            world_size=world_size,
            rank=rank,
        )

        # Set device
        if torch.cuda.is_available():
            self.device = torch.device(f"cuda:{rank}")
            torch.cuda.set_device(self.device)
        else:
            self.device = torch.device("cpu")

        # Set master process
        self.is_master = rank == 0

        # Update configs
        self.distributed_config.rank = rank
        self.distributed_config.world_size = world_size
        self.distributed_config.local_rank = rank

        self.is_initialized = True

        if self.is_master:
            logger.info(
                f"Initialized distributed training: rank={rank}, world_size={world_size}"
            )

    def setup_model(self):
        """Setup model for distributed training"""
        if not self.is_initialized:
            raise RuntimeError("Distributed training not initialized")

        # Get model from agent
        self.model = self.agent.get_model()

        # Move to device
        self.model.to(self.device)

        # Enable gradient checkpointing for memory efficiency
        if self.distributed_config.activation_checkpointing:
            self.model.gradient_checkpointing_enable()

        # Wrap with DDP
        self.model = DDP(
            self.model,
            device_ids=[self.device.index] if self.device.type == "cuda" else None,
            output_device=self.device.index if self.device.type == "cuda" else None,
            find_unused_parameters=self.distributed_config.find_unused_parameters,
        )

        # Setup optimizer
        self.optimizer = self.agent.get_optimizer()

        # Setup mixed precision scaler
        if self.distributed_config.mixed_precision:
            self.scaler = torch.cuda.amp.GradScaler()

        if self.is_master:
            logger.info("Model setup complete for distributed training")

    def setup_wandb(self):
        """Setup Weights & Biases for distributed training"""
        if not WANDB_AVAILABLE or not self.is_master:
            return

        # Initialize wandb only on master process
        wandb.init(
            project=self.training_config.wandb_project,
            name=f"grpo-distributed-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
            config={
                **self.training_config.to_dict(),
                **self.distributed_config.to_dict(),
            },
        )

        # Log model architecture
        if hasattr(self.model, "module"):
            wandb.watch(self.model.module)
        else:
            wandb.watch(self.model)

    async def train(self) -> dict[str, Any]:
        """
        Main training loop with distributed coordination
        """
        if not self.is_initialized:
            raise RuntimeError("Distributed training not initialized")

        # Setup wandb
        self.setup_wandb()

        # Training loop
        for epoch in range(self.training_config.num_epochs):
            self.epoch_count = epoch

            # Train epoch
            epoch_metrics = await self._train_epoch()

            # Log metrics (only master process)
            if self.is_master:
                await self._log_metrics(epoch_metrics, epoch)

            # Synchronize processes
            dist.barrier()

            # Save checkpoint (only master process)
            if self.is_master and epoch % self.training_config.save_steps == 0:
                await self._save_checkpoint(epoch)

        # Final cleanup
        if self.is_master and WANDB_AVAILABLE:
            wandb.finish()

        return self.training_metrics

    async def _train_epoch(self) -> dict[str, Any]:
        """Train for one epoch"""
        model = self.model
        optimizer = self.optimizer
        scaler = self.scaler
        if model is None or optimizer is None:
            raise RuntimeError("Distributed trainer is not initialized")

        model.train()
        epoch_metrics: dict[str, Any] = {
            "loss": 0.0,
            "rewards": [],
            "trajectories": 0,
            "step_time": 0.0,
            "gpu_memory": 0.0,
        }

        # Generate training data
        training_data = await self._generate_training_data()

        # Distribute data across processes
        local_data = self._distribute_data(training_data)

        # Training steps
        for step_idx, batch in enumerate(local_data):
            step_start = asyncio.get_event_loop().time()

            # Forward pass with mixed precision
            with torch.cuda.amp.autocast(
                enabled=self.distributed_config.mixed_precision
            ):
                loss, step_metrics = await self._training_step(batch)

            # Backward pass
            if self.distributed_config.mixed_precision:
                if scaler is None:
                    raise RuntimeError("Mixed precision enabled without GradScaler")
                scaler.scale(loss).backward()
            else:
                loss.backward()

            # Gradient synchronization and update
            if (
                step_idx + 1
            ) % self.distributed_config.gradient_accumulation_steps == 0:
                if self.distributed_config.mixed_precision:
                    if scaler is None:
                        raise RuntimeError("Mixed precision enabled without GradScaler")
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    optimizer.step()

                optimizer.zero_grad()
                self.step_count += 1

            # Update metrics
            epoch_metrics["loss"] += loss.item()
            rewards = step_metrics.get("rewards", [])
            if isinstance(rewards, list):
                epoch_metrics["rewards"].extend(rewards)
            trajectories = step_metrics.get("trajectories", 0)
            if isinstance(trajectories, int):
                epoch_metrics["trajectories"] += trajectories
            epoch_metrics["step_time"] += asyncio.get_event_loop().time() - step_start

            # Memory tracking
            if torch.cuda.is_available():
                epoch_metrics["gpu_memory"] = (
                    torch.cuda.max_memory_allocated() / 1024**3
                )

        # Average metrics across processes
        epoch_metrics = self._reduce_metrics(epoch_metrics)

        return epoch_metrics

    async def _generate_training_data(self) -> list[dict[str, Any]]:
        """This trainer has no data source — fabricated scenarios are not training."""
        raise NotImplementedError(
            "DistributedGRPOTrainer has no data source; use "
            "stateset_agents.training.distributed.DistributedTrainer, which "
            "drives real scenarios"
        )

    def _distribute_data(self, data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Distribute training data across processes"""
        # Simple round-robin distribution
        local_data = []
        for i, item in enumerate(data):
            if i % self.distributed_config.world_size == self.distributed_config.rank:
                local_data.append(item)
        return local_data

    async def _training_step(
        self, batch: dict[str, Any]
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        """Execute one training step"""
        # Generate trajectories
        trajectories = await self._generate_trajectories(batch)

        # Compute rewards
        rewards = await self._compute_rewards(trajectories)

        # Compute GRPO loss
        loss = self._compute_grpo_loss(trajectories, rewards)

        step_metrics = {
            "rewards": rewards,
            "trajectories": len(trajectories),
            "loss": loss.item(),
        }

        return loss, step_metrics

    async def _generate_trajectories(self, batch: dict[str, Any]) -> list[Any]:
        """Roll out `num_generations` episodes for the batch's scenario."""
        scenario = dict(batch)
        num_generations = int(getattr(self.training_config, "num_generations", 1) or 1)

        async def agent_fn(history: Any, context: Any) -> Any:
            return await self.agent.generate_response(history, context)

        trajectories: list[Any] = []
        for _ in range(num_generations):
            reset_fn = getattr(self.agent, "reset", None)
            if callable(reset_fn):
                reset_result = reset_fn()
                if asyncio.iscoroutine(reset_result):
                    await reset_result
            trajectories.append(await self.environment.run_episode(agent_fn, scenario))
        return trajectories

    async def _compute_rewards(self, trajectories: list[Any]) -> list[float]:
        """Score each trajectory with the configured reward function."""
        rewards: list[float] = []
        for trajectory in trajectories:
            context = getattr(trajectory, "metadata", None) or {}
            reward_result = await self.reward_function.compute_reward(
                getattr(trajectory, "turns", []), context
            )
            score, breakdown = await coerce_reward_result(
                reward_result, DISTRIBUTED_TRAIN_EXCEPTIONS
            )
            trajectory.total_reward = score
            if hasattr(trajectory, "metadata") and isinstance(
                trajectory.metadata, dict
            ):
                trajectory.metadata["reward_breakdown"] = breakdown
            rewards.append(score)
        return rewards

    def _compute_grpo_loss(
        self, trajectories: list[Any], rewards: list[float]
    ) -> torch.Tensor:
        """Compute the real GRPO loss for one group of trajectories."""
        for trajectory, reward in zip(trajectories, rewards, strict=False):
            trajectory.total_reward = float(reward)

        group = TrajectoryGroup(
            scenario_id=f"step_{self.step_count}",
            trajectories=list(trajectories),
        )
        # NOTE: the forward pass inside `compute_grpo_loss` runs through the
        # unwrapped `agent.model`, bypassing the DDP wrapper held in
        # `self.model`, so gradient all-reduce never fires. This is one of the
        # reasons the class is deprecated (see the __init__ warning).
        loss_dict = compute_grpo_loss(
            trajectory_groups=[group],
            config=self.training_config,
            agent=self.agent,
            global_reward_mean=self._global_reward_mean,
            global_reward_count=self._global_reward_count,
            update_global_stats=self._update_global_stats,
        )
        loss = loss_dict["total_loss"]
        if self.device is not None:
            loss = loss.to(self.device)
        return loss

    def _update_global_stats(self, batch_mean: float, batch_size: int) -> None:
        """Track a running global reward mean for the `global_mean` baseline."""
        self._global_reward_sum += batch_mean * batch_size
        self._global_reward_count += batch_size
        if self._global_reward_count > 0:
            self._global_reward_mean = (
                self._global_reward_sum / self._global_reward_count
            )

    def _reduce_metrics(self, metrics: dict[str, Any]) -> dict[str, Any]:
        """Reduce metrics across all processes"""
        # Gather metrics from all processes
        gathered_metrics: list[dict[str, Any] | None] = [
            None
        ] * self.distributed_config.world_size
        dist.all_gather_object(gathered_metrics, metrics)
        valid_metrics = [metric for metric in gathered_metrics if metric is not None]

        # Aggregate metrics
        if self.is_master:
            aggregated: dict[str, Any] = {}
            for key in metrics:
                if key == "rewards":
                    aggregated[key] = [
                        reward
                        for metric in valid_metrics
                        for reward in metric.get("rewards", [])
                    ]
                elif key == "trajectories":
                    aggregated[key] = sum(
                        int(metric.get("trajectories", 0)) for metric in valid_metrics
                    )
                elif isinstance(metrics[key], (int, float)):
                    aggregated[key] = sum(
                        float(metric.get(key, 0.0)) for metric in valid_metrics
                    ) / max(len(valid_metrics), 1)
                else:
                    aggregated[key] = metrics[key]

            return aggregated
        else:
            return metrics

    async def _log_metrics(self, metrics: dict[str, Any], epoch: int):
        """Log metrics to monitoring services"""
        # Log to wandb
        if WANDB_AVAILABLE and self.is_master:
            wandb_metrics = {
                "epoch": epoch,
                "loss": metrics["loss"],
                "average_reward": (
                    sum(metrics["rewards"]) / len(metrics["rewards"])
                    if metrics["rewards"]
                    else 0
                ),
                "trajectories": metrics["trajectories"],
                "step_time": metrics["step_time"],
                "gpu_memory_gb": metrics["gpu_memory"],
            }
            wandb.log(wandb_metrics)

        # Log to monitoring service
        if self.monitoring and self.is_master:
            await self.monitoring.log_metric("grpo.distributed.loss", metrics["loss"])
            await self.monitoring.log_metric(
                "grpo.distributed.trajectories", metrics["trajectories"]
            )
            await self.monitoring.log_metric(
                "grpo.distributed.gpu_memory", metrics["gpu_memory"]
            )

    async def _save_checkpoint(self, epoch: int):
        """Save training checkpoint"""
        model = self.model
        optimizer = self.optimizer
        if model is None or optimizer is None:
            raise RuntimeError("Distributed trainer is not initialized")

        checkpoint_dir = Path(self.training_config.output_dir) / "checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)

        checkpoint_path = checkpoint_dir / f"checkpoint_epoch_{epoch}.pt"

        # Save model state
        model_state = (
            model.module.state_dict()
            if hasattr(model, "module")
            else model.state_dict()
        )

        checkpoint = {
            "epoch": epoch,
            "model_state_dict": model_state,
            "optimizer_state_dict": optimizer.state_dict(),
            "training_config": self.training_config.to_dict(),
            "distributed_config": self.distributed_config.to_dict(),
            "step_count": self.step_count,
            "training_metrics": self.training_metrics,
        }

        if self.scaler is not None:
            checkpoint["scaler_state_dict"] = self.scaler.state_dict()

        torch.save(checkpoint, checkpoint_path)
        logger.info(f"Saved checkpoint: {checkpoint_path}")

    def cleanup(self):
        """Cleanup distributed training"""
        if self.is_initialized:
            dist.destroy_process_group()
            logger.info("Distributed training cleanup complete")


@record
def run_distributed_training(
    rank: int,
    world_size: int,
    agent: Agent,
    environment: Environment,
    reward_function: RewardFunction,
    training_config: TrainingConfig,
    distributed_config: DistributedConfig,
    monitoring_service: MonitoringService | None = None,
):
    """
    Entry point for distributed training process
    """
    # Create trainer
    trainer = DistributedGRPOTrainer(
        agent=agent,
        environment=environment,
        reward_function=reward_function,
        training_config=training_config,
        distributed_config=distributed_config,
        monitoring_service=monitoring_service,
    )

    try:
        # Setup distributed environment
        trainer.setup_distributed(rank, world_size)

        # Setup model
        trainer.setup_model()

        # Run training
        asyncio.run(trainer.train())

    except DISTRIBUTED_TRAIN_EXCEPTIONS as e:
        logger.error(f"Distributed training failed on rank {rank}: {e}")
        raise
    finally:
        # Cleanup
        trainer.cleanup()


def launch_distributed_training(
    agent: Agent,
    environment: Environment,
    reward_function: RewardFunction,
    training_config: TrainingConfig,
    distributed_config: DistributedConfig,
    monitoring_service: MonitoringService | None = None,
) -> dict[str, Any]:
    """
    Launch distributed training across multiple GPUs
    """
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA not available for distributed training")

    world_size = distributed_config.world_size
    if world_size <= 0:
        world_size = torch.cuda.device_count()
        distributed_config.world_size = world_size

    logger.info(f"Launching distributed training with {world_size} processes")

    # Launch training processes
    mp.spawn(
        run_distributed_training,
        args=(
            world_size,
            agent,
            environment,
            reward_function,
            training_config,
            distributed_config,
            monitoring_service,
        ),
        nprocs=world_size,
        join=True,
    )

    return {
        "status": "completed",
        "world_size": world_size,
        "distributed_config": distributed_config.to_dict(),
    }


# Utility functions
def get_optimal_distributed_config(
    num_gpus: int | None = None, memory_per_gpu: float | None = None
) -> DistributedConfig:
    """Get optimal distributed configuration for available hardware"""
    if num_gpus is None:
        num_gpus = torch.cuda.device_count()

    if memory_per_gpu is None:
        memory_per_gpu = torch.cuda.get_device_properties(0).total_memory / 1024**3

    # Determine optimal settings based on hardware
    config = DistributedConfig()
    config.world_size = num_gpus

    # Memory optimization based on GPU memory
    if memory_per_gpu < 8:  # Less than 8GB
        config.gradient_accumulation_steps = 4
        config.mixed_precision = True
        config.activation_checkpointing = True
    elif memory_per_gpu < 16:  # Less than 16GB
        config.gradient_accumulation_steps = 2
        config.mixed_precision = True
        config.activation_checkpointing = False
    else:  # 16GB or more
        config.gradient_accumulation_steps = 1
        config.mixed_precision = False
        config.activation_checkpointing = False

    return config


def estimate_memory_usage(
    model_parameters: int,
    batch_size: int,
    sequence_length: int,
    mixed_precision: bool = True,
) -> float:
    """Estimate GPU memory usage in GB"""
    # Model parameters
    param_memory = model_parameters * 4 / 1024**3  # 4 bytes per param

    # Gradients
    grad_memory = param_memory

    # Optimizer states (Adam)
    optimizer_memory = param_memory * 2

    # Activations (rough estimate)
    activation_memory = batch_size * sequence_length * 1024 * 4 / 1024**3

    # Mixed precision reduces some memory usage
    if mixed_precision:
        total_memory = (
            param_memory
            + grad_memory
            + optimizer_memory * 0.5
            + activation_memory * 0.5
        )
    else:
        total_memory = param_memory + grad_memory + optimizer_memory + activation_memory

    # Add 20% safety margin
    return total_memory * 1.2
