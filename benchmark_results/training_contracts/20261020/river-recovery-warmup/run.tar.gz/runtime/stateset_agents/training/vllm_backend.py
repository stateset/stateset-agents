"""
vLLM Backend for High-Performance Generation in RL Training

This module provides a unified vLLM integration for all trainers in the framework,
enabling 5-20x faster generation compared to standard HuggingFace generation.

Key Features:
- Batched generation with efficient KV cache management
- Automatic log probability extraction for importance ratios
- Prefix caching for repeated prompts (common in RL)
- Memory-efficient inference with PagedAttention
- Seamless fallback to HuggingFace when vLLM is unavailable

Usage:
    from stateset_agents.training.vllm_backend import VLLMGenerator, VLLMConfig

    config = VLLMConfig(
        model_name="meta-llama/Llama-2-7b-hf",
        tensor_parallel_size=1,
        gpu_memory_utilization=0.8,
    )

    generator = VLLMGenerator(config)
    await generator.initialize()

    results = await generator.generate_with_logprobs(
        prompts=["What is 2+2?", "Explain gravity"],
        sampling_params={"temperature": 0.7, "max_tokens": 512}
    )

Reference:
- vLLM Paper: https://arxiv.org/abs/2309.06180
- PagedAttention: Efficient memory management for LLM serving
"""

import asyncio
import logging
import math
import os
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from typing import Any, Optional, cast

import torch

logger = logging.getLogger(__name__)

VLLM_EXCEPTIONS = (
    ImportError,
    RuntimeError,
    ValueError,
    TypeError,
    AttributeError,
    OSError,
    asyncio.TimeoutError,
)

# Check vLLM availability
try:
    from vllm import LLM, SamplingParams
    from vllm.outputs import RequestOutput

    VLLM_AVAILABLE = True
    logger.info("vLLM is available - high-performance generation enabled")
except VLLM_EXCEPTIONS as exc:
    VLLM_AVAILABLE = False
    LLM = None
    SamplingParams = None
    RequestOutput = None
    logger.info(
        "vLLM is not installed or cannot initialize (%s). Falling back to "
        "HuggingFace generation.",
        exc,
    )


@dataclass
class VLLMConfig:
    """Configuration for vLLM backend"""

    # Model configuration
    model_name: str = "gpt2"
    tokenizer_name: str | None = None  # Defaults to model_name
    revision: str | None = None

    # Hardware configuration
    tensor_parallel_size: int = 1  # Number of GPUs for tensor parallelism
    pipeline_parallel_size: int = 1  # Number of GPUs for pipeline parallelism
    gpu_memory_utilization: float = 0.85  # Fraction of GPU memory to use
    max_model_len: int | None = None  # Max sequence length (auto-detect if None)

    # Generation defaults
    max_tokens: int = 512
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = -1  # -1 means disabled

    # Performance options
    enable_prefix_caching: bool = True  # Cache KV for repeated prefixes
    enable_chunked_prefill: bool = True  # Better memory efficiency
    max_num_seqs: int = 256  # Max concurrent sequences
    max_num_batched_tokens: int | None = None  # Auto-compute if None

    # Quantization
    quantization: str | None = None  # "awq", "gptq", "squeezellm", None
    dtype: str = "auto"  # "auto", "float16", "bfloat16", "float32"

    # LoRA support
    enable_lora: bool = False
    max_loras: int = 1
    max_lora_rank: int = 64
    lora_modules: list[dict[str, Any]] | None = None

    # Seed for reproducibility
    seed: int | None = None

    # Trust remote code (for custom models)
    trust_remote_code: bool = True

    # Keep the vLLM V1 engine core in this process (VLLM_ENABLE_V1_MULTIPROCESSING=0)
    # so ``sync_weights`` can hand tensors straight to the engine's model after
    # every optimizer step. Set False for a standalone/serving engine.
    in_process_weight_sync: bool = True

    def to_vllm_kwargs(self) -> dict[str, Any]:
        """Convert to vLLM LLM constructor kwargs"""
        kwargs = {
            "model": self.model_name,
            "tokenizer": self.tokenizer_name or self.model_name,
            "tensor_parallel_size": self.tensor_parallel_size,
            "pipeline_parallel_size": self.pipeline_parallel_size,
            "gpu_memory_utilization": self.gpu_memory_utilization,
            "trust_remote_code": self.trust_remote_code,
            "dtype": self.dtype,
            "max_num_seqs": self.max_num_seqs,
            "enable_prefix_caching": self.enable_prefix_caching,
            "enable_chunked_prefill": self.enable_chunked_prefill,
        }

        if self.max_model_len is not None:
            kwargs["max_model_len"] = self.max_model_len

        if self.max_num_batched_tokens is not None:
            kwargs["max_num_batched_tokens"] = self.max_num_batched_tokens

        if self.quantization is not None:
            kwargs["quantization"] = self.quantization

        if self.revision is not None:
            kwargs["revision"] = self.revision

        if self.seed is not None:
            kwargs["seed"] = self.seed

        if self.enable_lora:
            kwargs["enable_lora"] = True
            kwargs["max_loras"] = self.max_loras
            kwargs["max_lora_rank"] = self.max_lora_rank

        return kwargs


@dataclass
class GenerationResult:
    """Result from a single generation"""

    prompt: str
    response: str
    full_text: str
    prompt_token_ids: list[int]
    response_token_ids: list[int]
    token_logprobs: list[float]  # Log prob for each response token
    cumulative_logprob: float  # Sum of token log probs
    sequence_length: int
    finish_reason: str  # "stop", "length", "abort"

    @property
    def mean_logprob(self) -> float:
        """Average log probability per token"""
        if self.sequence_length == 0:
            return 0.0
        return self.cumulative_logprob / self.sequence_length

    @property
    def perplexity(self) -> float:
        """Perplexity of the generation"""
        import math

        return math.exp(-self.mean_logprob)


@dataclass
class BatchGenerationResult:
    """Results from a batch generation"""

    results: list[GenerationResult]
    total_tokens_generated: int
    generation_time_seconds: float
    tokens_per_second: float


def _validate_group_request(prompts: list[str], group_size: int) -> None:
    """Reject requests a prompt-keyed result cannot represent faithfully."""
    if group_size <= 0:
        raise ValueError("num_generations_per_prompt must be positive")
    if len(prompts) != len(set(prompts)):
        raise ValueError("grouped generation requires unique prompts")


# Attribute names worth following from an ``LLM`` to reach the in-process
# model whose ``load_weights(iterable[(name, tensor)])`` hot-swaps weights.
# vLLM has moved this object several times (V0 ``driver_worker.model_runner``,
# V1 ``driver_worker.worker.model_runner``, ``engine_core`` wrappers), so the
# search follows these names breadth-first instead of pinning one path.
_ENGINE_HOPS: tuple[str, ...] = (
    "llm_engine",
    "engine_core",
    "model_executor",
    "driver_worker",
    "worker",
    "model_runner",
    "model",
)
_ENGINE_SEARCH_DEPTH = 8


def _find_engine_model(engine: Any) -> Any | None:
    """Breadth-first search along :data:`_ENGINE_HOPS` for the first object
    exposing a callable ``load_weights``; ``None`` when nothing is reachable."""
    frontier: list[tuple[Any, int]] = [(engine, 0)]
    seen: set[int] = {id(engine)}
    while frontier:
        node, depth = frontier.pop(0)
        if node is not engine and callable(getattr(node, "load_weights", None)):
            return node
        if depth >= _ENGINE_SEARCH_DEPTH:
            continue
        for hop in _ENGINE_HOPS:
            try:
                child = getattr(node, hop, None)
            except Exception:  # noqa: BLE001 - lazy engine attributes may raise
                child = None
            if child is None or id(child) in seen:
                continue
            seen.add(id(child))
            frontier.append((child, depth + 1))
    return None


_WRAPPER_PREFIXES = ("base_model.model.", "module.", "_orig_mod.")


def _engine_weight_name(name: str) -> str:
    """Strip PEFT / DDP / torch.compile wrapper prefixes and PEFT's per-module
    ``.base_layer`` indirection from a parameter name, so it matches the
    engine's own naming (``model.layers.0.self_attn.q_proj.weight``)."""
    changed = True
    while changed:
        changed = False
        for prefix in _WRAPPER_PREFIXES:
            if name.startswith(prefix):
                name = name[len(prefix) :]
                changed = True
    return name.replace(".base_layer.", ".")


def _iter_policy_weights(model: Any) -> Iterator[tuple[str, Any]]:
    """Yield ``(engine_name, detached tensor)`` for every parameter of ``model``.

    PEFT models (``peft_config`` + ``merge_adapter``) are merged while their
    base model's parameters are read and unmerged afterwards; LoRA-specific
    parameters are skipped since the merged base weights already carry them.
    """
    is_peft = hasattr(model, "peft_config") and callable(
        getattr(model, "merge_adapter", None)
    )
    if is_peft:
        model.merge_adapter()
        try:
            base = (
                model.get_base_model()
                if callable(getattr(model, "get_base_model", None))
                else model
            )
            for name, param in base.named_parameters():
                if "lora_" in name:
                    continue
                yield _engine_weight_name(name), param.detach()
        finally:
            model.unmerge_adapter()
        return
    for name, param in model.named_parameters():
        yield _engine_weight_name(name), param.detach()


class VLLMGenerator:
    """
    High-performance text generation using vLLM.

    Provides batched generation with automatic log probability extraction,
    which is essential for computing importance ratios in policy gradient methods.
    """

    def __init__(self, config: VLLMConfig):
        self.config = config
        self.engine: LLM | None = None
        self.tokenizer: Any | None = None
        self._lora_adapters: dict[str, Any] = {}
        self._initialized = False
        # Optional override: ``weight_loader(iter[(name, tensor)])`` pushes
        # weights into the engine. ``None`` resolves the engine's own
        # ``load_weights`` at sync time (see ``sync_weights``).
        self.weight_loader: Callable[[Iterable[tuple[str, Any]]], Any] | None = None
        self.weight_sync_count = 0

    async def initialize(self) -> bool:
        """
        Initialize the vLLM engine.

        Returns True if vLLM was successfully initialized, False if falling back to HF.
        """
        if not VLLM_AVAILABLE:
            logger.warning("vLLM not available, will use HuggingFace fallback")
            return False

        try:
            logger.info(f"Initializing vLLM engine for {self.config.model_name}...")
            logger.info(f"  Tensor parallel size: {self.config.tensor_parallel_size}")
            logger.info(
                f"  GPU memory utilization: {self.config.gpu_memory_utilization}"
            )
            logger.info(f"  Prefix caching: {self.config.enable_prefix_caching}")

            # Initialize vLLM engine
            if self.config.in_process_weight_sync:
                # vLLM reads this at engine construction; an out-of-process
                # engine core has no model object for sync_weights to reach.
                os.environ.setdefault("VLLM_ENABLE_V1_MULTIPROCESSING", "0")
            vllm_kwargs = self.config.to_vllm_kwargs()
            self.engine = LLM(**vllm_kwargs)
            self.tokenizer = self.engine.get_tokenizer()

            self._initialized = True
            logger.info("vLLM engine initialized successfully")
            return True

        except VLLM_EXCEPTIONS as e:
            logger.error(f"Failed to initialize vLLM: {e}")
            logger.warning("Falling back to HuggingFace generation")
            self._initialized = False
            return False

    @property
    def is_available(self) -> bool:
        """Check if vLLM is available and initialized"""
        return self._initialized and self.engine is not None

    def create_sampling_params(
        self,
        temperature: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        logprobs: int = 1,  # Number of log probs to return per token
        prompt_logprobs: int | None = None,  # Log probs for prompt tokens
        **kwargs,
    ) -> "SamplingParams":
        """Create vLLM SamplingParams with defaults from config"""
        if not VLLM_AVAILABLE:
            raise RuntimeError("vLLM not available")

        return SamplingParams(
            temperature=(
                temperature if temperature is not None else self.config.temperature
            ),
            top_p=top_p if top_p is not None else self.config.top_p,
            top_k=top_k if top_k is not None else self.config.top_k,
            max_tokens=max_tokens if max_tokens is not None else self.config.max_tokens,
            stop=stop,
            logprobs=logprobs,
            prompt_logprobs=prompt_logprobs,
            **kwargs,
        )

    def generate_sync(
        self,
        prompts: str | list[str],
        sampling_params: Optional["SamplingParams"] = None,
        **kwargs,
    ) -> list[GenerationResult]:
        """
        Synchronous generation with log probabilities.

        Args:
            prompts: Single prompt or list of prompts
            sampling_params: vLLM SamplingParams (or created from kwargs)
            **kwargs: Passed to create_sampling_params if sampling_params not provided

        Returns:
            List of GenerationResult objects with responses and log probs
        """
        if not self.is_available:
            raise RuntimeError(
                "vLLM not initialized. Call initialize() first or use fallback."
            )

        # Normalize to list
        if isinstance(prompts, str):
            prompts = [prompts]

        # Create sampling params if not provided
        if sampling_params is None:
            sampling_params = self.create_sampling_params(**kwargs)

        # Generate with vLLM
        engine = self.engine
        if engine is None:
            raise RuntimeError("vLLM engine not initialized")
        outputs: list[RequestOutput] = engine.generate(prompts, sampling_params)
        if len(outputs) != len(prompts):
            raise ValueError("vLLM returned the wrong number of generation results")

        # Process outputs
        results = []
        for expected_prompt, output in zip(prompts, outputs, strict=True):
            prompt = output.prompt
            if prompt != expected_prompt:
                raise ValueError("vLLM returned generation results out of prompt order")

            # Get the first (best) completion
            completion = output.outputs[0]
            response_text = completion.text
            response_token_ids = list(completion.token_ids)

            # Exact sampled-token probabilities are required for importance
            # ratios. A top-k alternative or zero would silently bias training.
            token_logprobs: list[float] = []
            if response_token_ids and completion.logprobs is None:
                raise ValueError("vLLM omitted sampled-token log-probabilities")
            if completion.logprobs is not None and len(completion.logprobs) != len(
                response_token_ids
            ):
                raise ValueError("vLLM omitted sampled-token log-probabilities")
            for token_id, logprob_dict in zip(
                response_token_ids, completion.logprobs or (), strict=True
            ):
                if logprob_dict is None or token_id not in logprob_dict:
                    raise ValueError("vLLM omitted a sampled token's log-probability")
                value = float(logprob_dict[token_id].logprob)
                if not math.isfinite(value) or value > 1e-6:
                    raise ValueError("vLLM returned an invalid sampled log-probability")
                token_logprobs.append(value)

            # Compute cumulative log prob
            cumulative_logprob = sum(token_logprobs) if token_logprobs else 0.0

            result = GenerationResult(
                prompt=prompt,
                response=response_text,
                full_text=prompt + response_text,
                prompt_token_ids=list(output.prompt_token_ids),
                response_token_ids=response_token_ids,
                token_logprobs=token_logprobs,
                cumulative_logprob=cumulative_logprob,
                sequence_length=len(response_token_ids),
                finish_reason=completion.finish_reason,
            )
            results.append(result)

        return results

    async def generate(
        self,
        prompts: str | list[str],
        sampling_params: Optional["SamplingParams"] = None,
        **kwargs,
    ) -> list[GenerationResult]:
        """
        Async generation with log probabilities.

        Wraps synchronous vLLM generation in asyncio executor for non-blocking use.
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: self.generate_sync(prompts, sampling_params, **kwargs)
        )

    async def generate_with_logprobs(
        self, prompts: list[str], **kwargs: Any
    ) -> list[GenerationResult]:
        """Rollout-backend entry point (see ``MultiTurnAgent.set_rollout_backend``).

        One result per prompt with exact prompt/response token ids and
        per-token log-probs; ``kwargs`` (``temperature``, ``top_p``,
        ``max_tokens``, ...) become the sampling parameters.
        """
        return await self.generate(list(prompts), None, **kwargs)

    async def generate_groups(
        self,
        prompts: list[str],
        num_generations_per_prompt: int,
        sampling_params: Optional["SamplingParams"] = None,
        **kwargs,
    ) -> dict[str, list[GenerationResult]]:
        """
        Generate multiple responses per prompt (for GRPO/GSPO group generation).

        This is more efficient than calling generate() multiple times because
        vLLM can batch all generations together.

        Args:
            prompts: Unique prompt strings; the returned mapping is keyed by prompt
            num_generations_per_prompt: Number of responses per prompt (G in GRPO)
            sampling_params: vLLM SamplingParams
            **kwargs: Passed to create_sampling_params

        Returns:
            Dict mapping each prompt to its list of GenerationResults
        """
        if not self.is_available:
            raise RuntimeError("vLLM not initialized")
        _validate_group_request(prompts, num_generations_per_prompt)
        if not prompts:
            return {}

        # Expand prompts for batched generation
        expanded_prompts = []
        for prompt in prompts:
            expanded_prompts.extend([prompt] * num_generations_per_prompt)

        # Generate all at once (vLLM handles batching efficiently)
        all_results = await self.generate(expanded_prompts, sampling_params, **kwargs)
        if len(all_results) != len(expanded_prompts):
            raise ValueError("vLLM returned an incomplete response group")

        # Group results by prompt
        grouped_results: dict[str, list[GenerationResult]] = {p: [] for p in prompts}
        for i, result in enumerate(all_results):
            if getattr(result, "prompt", None) != expanded_prompts[i]:
                raise ValueError("vLLM returned a response for the wrong prompt")
            prompt_idx = i // num_generations_per_prompt
            original_prompt = prompts[prompt_idx]
            grouped_results[original_prompt].append(result)

        return grouped_results

    def compute_log_probs_for_sequences(
        self,
        prompts: list[str],
        responses: list[str],
    ) -> list[tuple[float, list[float]]]:
        """
        Compute log probabilities for given prompt-response pairs.

        This is useful for computing importance ratios when you already
        have the responses (e.g., from old policy).

        Args:
            prompts: List of prompts
            responses: List of corresponding responses

        Returns:
            List of (cumulative_logprob, token_logprobs) tuples
        """
        if not self.is_available:
            raise RuntimeError("vLLM not initialized")
        if len(prompts) != len(responses):
            raise ValueError("prompts and responses must have the same length")
        if not prompts:
            return []

        # Combine prompts and responses
        full_sequences = [p + r for p, r in zip(prompts, responses, strict=True)]

        # Use prompt_logprobs to get log probs for the full sequence
        sampling_params = self.create_sampling_params(
            max_tokens=1,  # We just want the log probs, not more generation
            prompt_logprobs=1,
        )

        engine = self.engine
        tokenizer = self.tokenizer
        if engine is None or tokenizer is None:
            raise RuntimeError("vLLM engine not initialized")
        outputs = engine.generate(full_sequences, sampling_params)
        if len(outputs) != len(full_sequences):
            raise ValueError("vLLM returned the wrong number of scoring results")

        results = []
        for i, output in enumerate(outputs):
            if output.prompt != full_sequences[i]:
                raise ValueError("vLLM returned scoring results out of prompt order")
            prompt = prompts[i]
            prompt_tokens = list(tokenizer.encode(prompt))
            prompt_length = len(prompt_tokens)
            full_token_ids = output.prompt_token_ids
            if (
                full_token_ids is None
                or list(full_token_ids[:prompt_length]) != prompt_tokens
            ):
                raise ValueError(
                    "response tokenization does not preserve the prompt prefix"
                )
            prompt_logprobs = output.prompt_logprobs
            if prompt_logprobs is None and len(full_token_ids) > prompt_length:
                raise ValueError("vLLM omitted response prompt log-probabilities")
            if prompt_logprobs is not None and len(prompt_logprobs) != len(
                full_token_ids
            ):
                raise ValueError("vLLM returned misaligned prompt log-probabilities")

            # Extract log probs for response tokens (after prompt)
            token_logprobs: list[float] = []
            if prompt_logprobs is not None:
                for j in range(prompt_length, len(full_token_ids)):
                    token_id = full_token_ids[j]
                    logprob_dict = prompt_logprobs[j]
                    if logprob_dict is None or token_id not in logprob_dict:
                        raise ValueError(
                            "vLLM omitted a response token's log-probability"
                        )
                    value = float(logprob_dict[token_id].logprob)
                    if not math.isfinite(value) or value > 1e-6:
                        raise ValueError(
                            "vLLM returned an invalid response log-probability"
                        )
                    token_logprobs.append(value)

            cumulative = sum(token_logprobs) if token_logprobs else 0.0
            results.append((cumulative, token_logprobs))

        return results

    def add_lora_adapter(
        self,
        adapter_name: str,
        adapter_path: str,
    ) -> bool:
        """
        Add a LoRA adapter to the vLLM engine.

        Args:
            adapter_name: Unique name for the adapter.
            adapter_path: Path to a directory containing adapter_config.json
                and adapter weights.

        Returns:
            True if the adapter was loaded successfully.

        Raises:
            RuntimeError: If vLLM is not initialized or LoRA is not enabled.
            FileNotFoundError: If adapter_path does not exist.
        """
        if not self.is_available:
            raise RuntimeError("vLLM not initialized")

        if not self.config.enable_lora:
            raise RuntimeError("LoRA not enabled in config. Set enable_lora=True.")

        from pathlib import Path

        adapter_dir = Path(adapter_path)
        if not adapter_dir.exists():
            raise FileNotFoundError(f"LoRA adapter path not found: {adapter_path}")

        config_file = adapter_dir / "adapter_config.json"
        if not config_file.exists():
            logger.warning(
                "No adapter_config.json in %s — vLLM may fail to load", adapter_path
            )

        logger.info("Adding LoRA adapter: %s from %s", adapter_name, adapter_path)

        try:
            # vLLM >= 0.4.0 uses LoRARequest for dynamic adapter loading.
            # The engine's generate() accepts lora_request= parameter.
            if not VLLM_AVAILABLE:
                raise ImportError("vLLM not available")

            from vllm.lora.request import LoRARequest

            # Register the adapter for later use in generate() calls.
            # vLLM requires a unique integer ID per adapter.
            adapter_id = len(self._lora_adapters) + 1
            lora_request = LoRARequest(
                lora_name=adapter_name,
                lora_int_id=adapter_id,
                lora_local_path=str(adapter_dir),
            )
            self._lora_adapters[adapter_name] = lora_request

            logger.info(
                "LoRA adapter '%s' registered (id=%d). Use generate() with "
                "lora_request='%s' to apply.",
                adapter_name,
                adapter_id,
                adapter_name,
            )
            return True

        except ImportError:
            logger.warning(
                "vLLM LoRARequest not available (requires vLLM >= 0.4.0). "
                "LoRA adapter '%s' not loaded.",
                adapter_name,
            )
            return False
        except VLLM_EXCEPTIONS as exc:
            logger.error("Failed to register LoRA adapter '%s': %s", adapter_name, exc)
            return False

    def sync_weights(self, model: Any) -> None:
        """Push ``model``'s current weights into the running engine.

        This is the hook ``MultiTurnAgent.sync_rollout_backend`` calls after
        every optimizer step. A PEFT model is merged for the duration of the
        read and unmerged afterwards, so the engine serves base+adapter while
        training keeps the adapter separate. Wrapper prefixes (``module.``,
        ``base_model.model.``) are stripped so names match the engine's.

        Raises ``RuntimeError`` when no engine is initialised or when the
        engine's weight-loading entry point cannot be found; set
        ``weight_loader`` to adapt an unfamiliar engine layout.
        """
        loader = self.weight_loader or self._resolve_weight_loader()
        loader(_iter_policy_weights(model))
        self.weight_sync_count = int(getattr(self, "weight_sync_count", 0)) + 1

    def _resolve_weight_loader(self) -> Callable[[Iterable[tuple[str, Any]]], Any]:
        engine = getattr(self, "engine", None)
        if engine is None:
            raise RuntimeError("vLLM not initialized; cannot sync weights")
        target = _find_engine_model(engine)
        if target is not None:
            self.engine_model_path = type(target).__name__
            return cast(Callable[[Iterable[tuple[str, Any]]], Any], target.load_weights)
        raise RuntimeError(
            "could not find the engine's load_weights entry point for this vLLM "
            "version; set VLLMGenerator.weight_loader to a callable taking an "
            "iterable of (name, tensor) pairs"
        )

    def token_logprobs_for_ids(
        self, prompt_token_ids: list[int], response_token_ids: list[int]
    ) -> list[float]:
        """The engine's current log-probs of ``response_token_ids`` given
        ``prompt_token_ids`` (one prefill with ``prompt_logprobs``), so a
        caller can measure how far the engine is from the training policy
        before and after :meth:`sync_weights`.
        """
        if not self.is_available:
            raise RuntimeError("vLLM not initialized")
        engine = self.engine
        if engine is None:
            raise RuntimeError("vLLM engine not initialized")
        ids = [int(t) for t in prompt_token_ids] + [int(t) for t in response_token_ids]
        params = self.create_sampling_params(
            max_tokens=1, temperature=1.0, top_p=1.0, top_k=-1, prompt_logprobs=0
        )
        output = engine.generate([{"prompt_token_ids": ids}], params)[0]
        start = len(prompt_token_ids)
        out: list[float] = []
        for position, token_id in enumerate(response_token_ids, start=start):
            entry = (output.prompt_logprobs or [None] * len(ids))[position]
            if entry is None or int(token_id) not in entry:
                raise RuntimeError(
                    f"engine returned no log-prob for response token {position}"
                )
            out.append(float(entry[int(token_id)].logprob))
        return out

    def get_lora_request(self, adapter_name: str) -> Any:
        """Get a registered LoRA request by name for use in generate() calls."""
        adapters = getattr(self, "_lora_adapters", {})
        return adapters.get(adapter_name)

    def get_tokenizer(self):
        """Get the underlying tokenizer"""
        return self.tokenizer

    def shutdown(self):
        """Shutdown the vLLM engine and free resources"""
        if self.engine is not None:
            # vLLM cleanup
            del self.engine
            self.engine = None
            self._initialized = False

            # Force CUDA memory cleanup
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            logger.info("vLLM engine shutdown complete")


class HuggingFaceGeneratorFallback:
    """
    Fallback generator using HuggingFace transformers.

    Used when vLLM is not available or fails to initialize.
    Provides the same interface as VLLMGenerator but with HF generation.
    """

    def __init__(self, model_name: str | VLLMConfig, device: str | None = None):
        self.config = (
            model_name
            if isinstance(model_name, VLLMConfig)
            else VLLMConfig(model_name=model_name)
        )
        self.model_name = self.config.model_name
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model: Any | None = None
        self.tokenizer: Any | None = None
        self._initialized = False

    async def initialize(self) -> bool:
        """Initialize HuggingFace model and tokenizer"""
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer

            logger.info(f"Initializing HuggingFace fallback for {self.model_name}...")

            # Model and tokenizer identifiers are caller supplied. Respect an
            # explicit revision and remote-code policy on either backend.
            load_options: dict[str, Any] = {
                "trust_remote_code": self.config.trust_remote_code,
            }
            if self.config.revision is not None:
                load_options["revision"] = self.config.revision
            self.tokenizer = AutoTokenizer.from_pretrained(  # nosec: B615
                self.config.tokenizer_name or self.model_name,
                padding_side="left",
                **load_options,
            )
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token

            self.model = AutoModelForCausalLM.from_pretrained(  # nosec: B615
                self.model_name,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None,
                **load_options,
            )

            if self.device != "cuda":
                self.model = self.model.to(self.device)

            self.model.eval()
            self._initialized = True
            logger.info("HuggingFace fallback initialized")
            return True

        except VLLM_EXCEPTIONS as e:
            logger.error(f"Failed to initialize HuggingFace fallback: {e}")
            return False

    @property
    def is_available(self) -> bool:
        return self._initialized

    async def generate(
        self,
        prompts: str | list[str],
        temperature: float | None = None,
        top_p: float | None = None,
        max_tokens: int | None = None,
        top_k: int | None = None,
        **kwargs,
    ) -> list[GenerationResult]:
        """Generate responses using HuggingFace"""
        if not self.is_available:
            raise RuntimeError("HuggingFace model not initialized")

        if isinstance(prompts, str):
            prompts = [prompts]

        tokenizer = self.tokenizer
        model = self.model
        assert tokenizer is not None and model is not None

        temperature = self.config.temperature if temperature is None else temperature
        top_p = self.config.top_p if top_p is None else top_p
        max_tokens = self.config.max_tokens if max_tokens is None else max_tokens
        top_k = self.config.top_k if top_k is None else top_k

        results = []

        for prompt in prompts:
            inputs = tokenizer(
                prompt,
                return_tensors="pt",
                truncation=True,
                max_length=2048,
            ).to(model.device)

            prompt_length = inputs["input_ids"].shape[1]

            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature if temperature > 0 else 1.0,
                    top_p=top_p,
                    top_k=0 if top_k == -1 else top_k,
                    do_sample=temperature > 0,
                    pad_token_id=tokenizer.pad_token_id,
                    output_scores=True,
                    return_dict_in_generate=True,
                )

            generated_ids = outputs.sequences[0]
            response_ids = generated_ids[prompt_length:]
            response_text = tokenizer.decode(response_ids, skip_special_tokens=True)

            # Every sampled token needs its own score for importance ratios.
            if outputs.scores is None or len(outputs.scores) != len(response_ids):
                raise ValueError(
                    "HuggingFace returned misaligned sampled-token log-probabilities"
                )
            token_logprobs = []
            if outputs.scores:
                import torch.nn.functional as F

                for i, score in enumerate(outputs.scores):
                    if i < len(response_ids):
                        log_probs = F.log_softmax(score[0], dim=-1)
                        token_id = response_ids[i].item()
                        value = log_probs[token_id].item()
                        if not math.isfinite(value):
                            raise ValueError(
                                "HuggingFace returned an invalid sampled-token log-probability"
                            )
                        token_logprobs.append(value)

            cumulative_logprob = sum(token_logprobs) if token_logprobs else 0.0

            result = GenerationResult(
                prompt=prompt,
                response=response_text,
                full_text=prompt + response_text,
                prompt_token_ids=inputs["input_ids"][0].tolist(),
                response_token_ids=response_ids.tolist(),
                token_logprobs=token_logprobs,
                cumulative_logprob=cumulative_logprob,
                sequence_length=len(response_ids),
                finish_reason="stop" if len(response_ids) < max_tokens else "length",
            )
            results.append(result)

        return results

    async def generate_groups(
        self,
        prompts: list[str],
        num_generations_per_prompt: int,
        **kwargs,
    ) -> dict[str, list[GenerationResult]]:
        """Generate multiple responses per prompt"""
        _validate_group_request(prompts, num_generations_per_prompt)
        grouped_results: dict[str, list[GenerationResult]] = {p: [] for p in prompts}

        for prompt in prompts:
            for _ in range(num_generations_per_prompt):
                results = await self.generate([prompt], **kwargs)
                if len(results) != 1 or getattr(results[0], "prompt", None) != prompt:
                    raise ValueError("HuggingFace returned an invalid response group")
                grouped_results[prompt].append(results[0])

        return grouped_results

    def get_tokenizer(self):
        return self.tokenizer

    def shutdown(self):
        if self.model is not None:
            del self.model
            self.model = None
        if self.tokenizer is not None:
            del self.tokenizer
            self.tokenizer = None
        self._initialized = False

        if torch.cuda.is_available():
            torch.cuda.empty_cache()


def create_generator(
    config: VLLMConfig | dict[str, Any] | str,
    prefer_vllm: bool = True,
) -> VLLMGenerator | HuggingFaceGeneratorFallback:
    """
    Factory function to create the appropriate generator.

    Args:
        config: VLLMConfig, dict with config options, or model name string
        prefer_vllm: If True, try vLLM first; if False, always use HF

    Returns:
        VLLMGenerator if available and preferred, else HuggingFaceGeneratorFallback
    """
    # Normalize config
    if isinstance(config, str):
        config = VLLMConfig(model_name=config)
    elif isinstance(config, dict):
        config = VLLMConfig(**config)

    if prefer_vllm and VLLM_AVAILABLE:
        return VLLMGenerator(config)
    else:
        return HuggingFaceGeneratorFallback(config)


# Convenience function for quick generation
async def quick_generate(
    model_name: str,
    prompts: str | list[str],
    num_generations: int = 1,
    **kwargs,
) -> list[GenerationResult] | dict[str, list[GenerationResult]]:
    """
    Quick generation utility for one-off use.

    Automatically handles initialization and cleanup.
    """
    if num_generations <= 0:
        raise ValueError("num_generations must be positive")
    if num_generations > 1:
        _validate_group_request(
            [prompts] if isinstance(prompts, str) else prompts, num_generations
        )
    generator = create_generator(model_name)
    await generator.initialize()

    try:
        if num_generations == 1:
            return await generator.generate(prompts, **kwargs)
        else:
            if isinstance(prompts, str):
                prompts = [prompts]
            return await generator.generate_groups(prompts, num_generations, **kwargs)
    finally:
        generator.shutdown()


# Export
__all__ = [
    "VLLM_AVAILABLE",
    "VLLMConfig",
    "VLLMGenerator",
    "HuggingFaceGeneratorFallback",
    "GenerationResult",
    "BatchGenerationResult",
    "create_generator",
    "quick_generate",
]
