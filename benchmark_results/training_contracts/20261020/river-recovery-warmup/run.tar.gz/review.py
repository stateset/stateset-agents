"""Independently verify SFT provenance, fresh comparisons, and diagnostics."""

import asyncio
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

import experiment as study
from stateset_agents.core.environments.refund_policy_environment import (
    RefundPolicyEnvironment,
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import (
    refund_recovery_cases,
    replay_recovery_candidate,
)
from stateset_agents.evaluation.agent_runs import (
    content_hash,
    validate_report,
    summarize_outcomes,
)
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace
from stateset_agents.remote.river_rl import atomic_json


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


async def main():
    plan = study.validate(ROOT)
    diagnostic = study.support(ROOT, "diagnostics")
    old = REPO / "outputs/river-recovery-pilot-20261020"
    for name in ("train.json", "train.jsonl", "manifest.json"):
        assert sha(ROOT / "training" / name) == sha(old / "data" / name)
    cases = read(ROOT / "training/train.json")
    records = [
        json.loads(line)
        for line in (ROOT / "training/train.jsonl").read_text().splitlines()
    ]
    by_id = {r["order_id"]: r for r in cases}
    assert len(records) == len(by_id) == 160
    seen = set()
    for record in records:
        meta = record["metadata"]
        key = meta["case_id"]
        assert key in by_id and key not in seen and meta["split"] == "train"
        await replay_recovery_candidate(
            by_id[key],
            {
                "case_id": key,
                "case_hash": meta["case_hash"],
                "messages": record["messages"],
                "truncated": None,
            },
        )
        seen.add(key)
    selection = study.probe_selection(cases, records)
    assert selection == read(ROOT / "probe-selection.json")
    history = read(ROOT / "historical-sources.json")
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in history.items():
        assert sha(REPO / name) == digest
        rows = read(REPO / name)
        if isinstance(rows, list):
            excluded.extend(
                r for r in rows if isinstance(r, dict) and "return_window_days" in r
            )
    fingerprint = RefundPolicyEnvironment.case_fingerprint
    ids, facts = {r["order_id"] for r in excluded}, {fingerprint(r) for r in excluded}
    for split, count in (("validation", 80), ("test", 160)):
        rows = read(ROOT / f"{split}.json")
        expected = refund_recovery_cases(
            split, count=count, seed=plan["case_seed"], excluded=excluded
        )
        assert content_hash(rows) == content_hash(expected)
        new_ids, new_facts = {r["order_id"] for r in rows}, {
            fingerprint(r) for r in rows
        }
        assert not ids & new_ids and not facts & new_facts
        ids.update(new_ids)
        facts.update(new_facts)
        excluded.extend(rows)
    execution = read(ROOT / "execution-summary.json")
    assert execution["exit_code"] == 0 and not execution["timed_out"]
    result = read(ROOT / "result.json")
    assert execution["result"] == result
    trained = read(ROOT / "training-result.json")
    pointer = read(ROOT / "warmup/river_checkpoint.json")
    training_manifest = read(ROOT / "warmup/stateset_manifest.json")
    assert training_manifest["dataset_rows"] == 160
    assert (
        training_manifest["dataset_sha256"]
        == plan["input_sha256"]["training/train.jsonl"]
    )
    assert training_manifest["hyperparameters"]["steps"] == 10
    assert training_manifest["hyperparameters"]["seed"] == plan["seed"]
    assert training_manifest["hyperparameters"]["num_epochs"] == 1
    assert (
        training_manifest["hyperparameters"]["dataset_provenance"]
        == "captured_at_submission"
    )
    assert (
        trained["status"] == "succeeded"
        and pointer["steps"] == plan["expected_sft_updates"] == 10
    )
    assert (
        pointer["sft_options"]["checkpoint"]
        == read(ROOT / "parent/river_checkpoint.json")["checkpoint"]
    )
    assert result["sft_updates"] == 10 and result["rl_updates"] == 0
    assert read(ROOT / "training-attempt.json")["spec"] == plan["sft_spec"]
    probe = read(ROOT / "train-probe.json")
    assert (
        probe["split"] == "train"
        and probe["group_size"] == 4
        and probe["temperature"] == 1.0
        and probe["rl_updates"] == 0
    )
    assert len(probe["groups"]) == len(probe["diagnostics"]) == len(selection)
    checked, probe_seen, variances, probe_diagnostics = 0, set(), {}, []
    for group, diagnosed in zip(probe["groups"], probe["diagnostics"], strict=True):
        assert (
            len(group) == len(diagnosed) == 4
            and len({o["case_id"] for o in group}) == 1
        )
        key = group[0]["case_id"]
        assert key in {row["case_id"] for row in selection} and key not in probe_seen
        probe_seen.add(key)
        # Resource counters must be valid even when a case has multiple sampled members.
        summarize_outcomes(
            [{**o, "case_id": f"{key}:{index}"} for index, o in enumerate(group)]
        )
        for outcome, classification in zip(group, diagnosed, strict=True):
            replay = await replay_recovery_trace(
                by_id[key], outcome["environment_trace"]
            )
            for field in (
                "case_hash",
                "reward",
                "success",
                "policy_violations",
                "tool_calls",
                "backend_calls",
                "resolution_count",
                "refunded_cents",
                "duplicate_attempts",
                "reconciliations",
                "truncated",
            ):
                assert replay[field] == outcome[field]
            assert classification == await diagnostic.diagnose(
                by_id[key], outcome["environment_trace"]
            )
            probe_diagnostics.append(classification)
            checked += 1
        variances[key] = statistics.pvariance(o["reward"] for o in group)
    assert variances == probe["variances"]
    nonzero = sum(value > 0 for value in variances.values())
    assert (
        probe["nonzero_variance_groups"] == result["nonzero_variance_groups"] == nonzero
    )
    evaluated, decisions, paired_outcomes = {}, {}, {}
    for split in (
        ("validation", "test") if result["test_attempted"] else ("validation",)
    ):
        cases = read(ROOT / f"{split}.json")
        rows = {r["order_id"]: r for r in cases}
        reports, diagnosed = {}, {}
        for arm in study.ARMS:
            report = read(ROOT / f"{arm}-{split}.json")
            assert (
                report["environment"] == "refund-recovery-v1"
                and report["settings"] == plan["settings"]
            )
            assert report["implementation"] == plan["implementation"]
            expected_pointer = read(
                ROOT
                / ("parent" if arm == "parent" else "warmup")
                / "river_checkpoint.json"
            )
            assert (
                report["selected_checkpoint"]["path"] == expected_pointer["checkpoint"]
            )
            summary = validate_report(report, expected_split=split)
            assert all(report[key] == value for key, value in summary.items())
            assert report["case_hashes"] == {
                key: content_hash(row) for key, row in rows.items()
            }
            assert report["case_families"] == {
                key: row["recovery"] for key, row in rows.items()
            }
            classified = []
            for outcome in report["outcomes"]:
                replay = await replay_recovery_trace(
                    rows[outcome["case_id"]], outcome["environment_trace"]
                )
                for field in (
                    "case_hash",
                    "reward",
                    "success",
                    "policy_violations",
                    "tool_calls",
                    "backend_calls",
                    "resolution_count",
                    "refunded_cents",
                    "duplicate_attempts",
                    "reconciliations",
                    "truncated",
                ):
                    assert replay[field] == outcome[field]
                assert replay["resolution_count"] <= 1
                classified.append(
                    await diagnostic.diagnose(
                        rows[outcome["case_id"]], outcome["environment_trace"]
                    )
                )
                checked += 1
            assert classified == read(ROOT / f"{arm}-{split}-diagnostics.json")
            reports[arm], diagnosed[arm] = report, classified
            seal = read(ROOT / f"{arm}-{split}-attempt.json")
            assert (
                seal["plan_hash"] == plan["plan_hash"]
                and seal["case_sha256"] == plan["input_sha256"][f"{split}.json"]
            )
            evaluated[f"{arm}-{split}"] = {
                key: summary[key]
                for key in (
                    "total",
                    "passed",
                    "violation_rate",
                    "truncation_rate",
                    "generated_tokens",
                    "trajectory_seconds",
                )
            }
        decision = read(ROOT / f"{split}-decision.json")
        # Recompute all safety and error-count cells without the launcher's gate.
        cells = {"overall": list(rows)}
        for key, row in rows.items():
            cells.setdefault("family:" + row["recovery"], []).append(key)
        outcomes = {
            arm: {o["case_id"]: o for o in reports[arm]["outcomes"]}
            for arm in study.ARMS
        }
        paired = {
            "both_passed": 0,
            "warmup_only": 0,
            "parent_only": 0,
            "neither_passed": 0,
        }
        for key in rows:
            parent_ok = outcomes["parent"][key]["success"]
            warmup_ok = outcomes["warmup"][key]["success"]
            label = (
                "both_passed"
                if parent_ok and warmup_ok
                else (
                    "warmup_only"
                    if warmup_ok
                    else "parent_only" if parent_ok else "neither_passed"
                )
            )
            paired[label] += 1
        assert sum(paired.values()) == len(rows)
        assert (
            paired["both_passed"] + paired["warmup_only"] == reports["warmup"]["passed"]
        )
        assert (
            paired["both_passed"] + paired["parent_only"] == reports["parent"]["passed"]
        )
        paired_outcomes[split] = paired
        all_safe = True
        for cell, keys in cells.items():
            parent_passed = sum(outcomes["parent"][key]["success"] for key in keys)
            warmup_passed = sum(outcomes["warmup"][key]["success"] for key in keys)
            violations = sum(
                outcomes["warmup"][key]["policy_violations"] > 0 for key in keys
            )
            truncated = sum(
                outcomes["warmup"][key]["truncated"] is not None for key in keys
            )
            expected = {
                "total": len(keys),
                "parent_passed": parent_passed,
                "warmup_passed": warmup_passed,
                "warmup_violations": violations,
                "warmup_truncated": truncated,
                "passed": warmup_passed == len(keys)
                and warmup_passed >= parent_passed
                and violations == truncated == 0,
            }
            assert decision["cells"][cell] == expected
            all_safe &= expected["passed"]
        errors = {
            arm: {
                category: sum(
                    item["error_counts"][category] > 0 for item in diagnosed[arm]
                )
                for category in plan["error_categories"]
            }
            for arm in study.ARMS
        }
        error_safe = all(
            errors["warmup"][category] <= errors["parent"][category]
            for category in plan["error_categories"]
        )
        improved = reports["warmup"]["passed"] > reports["parent"]["passed"]
        assert decision["diagnostic_cases"] == errors
        assert (
            decision["diagnostic_nonregression"] == error_safe
            and decision["strict_success_improvement"] == improved
        )
        assert decision["passed"] == (
            all_safe and error_safe and (split == "validation" or improved)
        )
        decisions[split] = {"passed": decision["passed"], "diagnostic_cases": errors}
    assert decisions["validation"]["passed"] == result["test_attempted"]
    if not result["test_attempted"]:
        assert not result["accepted"] and not any(
            (ROOT / f"{arm}-test-attempt.json").exists() for arm in study.ARMS
        )
    else:
        assert decisions["test"]["passed"] == result["accepted"]
    budget = read(ROOT / "rollout-budget.json")
    assert budget["admitted_trajectories"] == checked
    assert (
        budget["reserved_generated_tokens"]
        == checked * 1024
        <= plan["limits"]["reserved_output_tokens"]
    )
    assert (
        not (old / "test-attempt.json").exists()
        and len(read(old / "data/test.json")) == 80
    )
    arithmetic = REPO / "outputs/river-arithmetic-pilot-20261020"
    assert len(read(arithmetic / "data/test.json")) == 308
    assert not any(
        (arithmetic / f"{arm}-test-attempt.json").exists()
        for arm in ("control", "arithmetic")
    )
    prior = {}
    target = (
        REPO / "benchmark_results/training_contracts/20261020/river-recovery-warmup"
    )
    for index in sorted(
        (REPO / "benchmark_results/training_contracts").rglob("artifacts.sha256.json")
    ):
        if index.parent == target:
            continue
        for name, digest in read(index).items():
            assert sha(index.parent / name) == digest
            prior[str((index.parent / name).relative_to(REPO))] = digest
    atomic_json(ROOT / "prior-evidence-verified.json", prior)
    review = {
        "passed": True,
        "plan_hash": plan["plan_hash"],
        "replayed_outcomes": checked,
        "replayed_training_teachers": 160,
        "sft_updates": 10,
        "rl_updates": 0,
        "probe_groups": len(selection),
        "nonzero_variance_groups": nonzero,
        "probe_passed": sum(o["success"] for group in probe["groups"] for o in group),
        "probe_total": sum(len(g) for g in probe["groups"]),
        "probe_diagnostic_cases": diagnostic.summarize(probe_diagnostics),
        "evaluations": evaluated,
        "paired_outcomes": paired_outcomes,
        "decisions": decisions,
        "accepted": result["accepted"],
        "test_attempted": result["test_attempted"],
        "prior_artifacts_unchanged": len(prior),
        "previous_recovery_test_cases_unattempted": 80,
        "previous_arithmetic_test_cases_unattempted": 308,
        "provider_calls_during_review": 0,
        "cost_usd": None,
    }
    atomic_json(ROOT / "review-summary.json", review)
    print(json.dumps(review), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
