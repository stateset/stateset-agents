"""Offline scoring, replay attribution, and gated-test behavior contracts."""

import copy
import importlib.util
import json
from pathlib import Path

import pytest

from stateset_agents.core.environment_base import EpisodeStatus
from stateset_agents.core.environments.refund_recovery_environment import (
    RefundRecoveryEnvironment,
)
from stateset_agents.core.trajectory import ConversationTurn
from stateset_agents.data.refund_recovery import refund_recovery_cases
from stateset_agents.evaluation.agent_runs import content_hash, evaluation_report

ROOT = Path(__file__).parent


def load(name):
    spec = importlib.util.spec_from_file_location(
        "tested_" + name, ROOT / (name + ".py")
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


async def trace_for(row, actions):
    env = RefundRecoveryEnvironment()
    state = await env.reset(row)
    trace = {
        "schema_version": 3,
        "protocol": "refund-recovery-v1",
        "case_id": row["order_id"],
        "case_hash": content_hash(row),
        "initial_messages": copy.deepcopy(state.context["messages"]),
        "steps": [],
    }
    total, done = 0.0, False
    for action in actions:
        message = {
            "role": "assistant",
            "content": action if isinstance(action, str) else json.dumps(action),
        }
        state, reward, done, info = await env.step(state, ConversationTurn(**message))
        total += reward
        trace["steps"].append(
            {
                "action": message,
                "reward": reward,
                "done": done,
                "status": state.status.value,
                "observations": info["messages"],
                "metrics": info["metrics"],
                "execution": env.execution_events(),
            }
        )
    assert done
    trace["terminal"] = {
        "reward": total,
        "status": state.status.value,
        "truncated": (
            "environment_timeout" if state.status == EpisodeStatus.TIMEOUT else None
        ),
    }
    return trace


RESOLVE = {"tool": "resolve_refund", "args": {"intent": "resolve_refund"}}
FINISH = {"tool": "finish", "args": {"outcome": "resolved"}}


@pytest.mark.parametrize(
    "bad,category",
    [
        ("{broken", "format"),
        ({"tool": "finish", "args": {"outcome": "bad"}}, "tool_contract"),
        ({"tool": "reconcile", "args": {}}, "reconciliation"),
    ],
)
async def test_diagnostics_count_actual_replayed_error_classes(bad, category):
    row = refund_recovery_cases("train", count=10, seed=9501)[0]
    trace = await trace_for(row, [bad, RESOLVE, FINISH])
    diagnosed = await load("diagnostics").diagnose(row, trace)
    assert diagnosed["error_counts"][category] == 1
    assert sum(diagnosed["error_counts"].values()) == 1
    assert not diagnosed["success"]


@pytest.mark.parametrize(
    "kind", ["completion_outcome", "premature_finish", "unsafe_retry"]
)
async def test_diagnostics_distinguish_semantic_completion_and_unsafe_retry(kind):
    rows = refund_recovery_cases("train", count=10, seed=9502)
    row = rows[0]
    actions = [RESOLVE, {"tool": "finish", "args": {"outcome": "unauthorized"}}]
    if kind == "premature_finish":
        actions = [FINISH]
    elif kind == "unsafe_retry":
        row = next(r for r in rows if r["recovery"] == "lost_ack_applied")
        actions = [RESOLVE, RESOLVE, {"tool": "reconcile", "args": {}}, FINISH]
    diagnosed = await load("diagnostics").diagnose(row, await trace_for(row, actions))
    assert diagnosed["error_counts"][kind] == 1
    assert sum(diagnosed["error_counts"].values()) == 1


async def test_classifier_refuses_forged_evidence():
    row = refund_recovery_cases("train", count=10, seed=9503)[0]
    trace = await trace_for(row, [RESOLVE, FINISH])
    trace["steps"][0]["observations"] = []
    with pytest.raises(ValueError):
        await load("diagnostics").diagnose(row, trace)


def report(cases, arm, split, fail=False):
    return evaluation_report(
        environment="refund-recovery-v1",
        base_model="model",
        seed=1,
        cases={r["order_id"]: r for r in cases},
        settings={"max_turns": 6},
        checkpoint={"path": "river://" + arm},
        split=split,
        outcomes=[
            {
                "case_id": r["order_id"],
                "success": not fail,
                "reward": -1 if fail else 1,
                "policy_violations": 0,
                "tool_calls": 2,
                "generated_tokens": 30,
                "elapsed_seconds": 0.1,
                "truncated": None,
            }
            for r in cases
        ],
    )


def diagnostics(cases):
    categories = load("diagnostics").CATEGORIES
    return [
        {"case_id": r["order_id"], "error_counts": dict.fromkeys(categories, 0)}
        for r in cases
    ]


@pytest.mark.parametrize("split,pass_gate", [("validation", True), ("test", False)])
def test_test_gate_requires_strict_improvement_beyond_perfect_tie(split, pass_gate):
    cases = refund_recovery_cases(split, count=10, seed=9504)
    reports = {arm: report(cases, arm, split) for arm in ("parent", "warmup")}
    diagnosed = {arm: diagnostics(cases) for arm in reports}
    assert (
        load("experiment").gate(reports, diagnosed, cases, split=split)["passed"]
        == pass_gate
    )


def test_gate_blocks_new_error_category_even_when_success_is_equal():
    cases = refund_recovery_cases("validation", count=10, seed=9505)
    reports = {arm: report(cases, arm, "validation") for arm in ("parent", "warmup")}
    diagnosed = {arm: diagnostics(cases) for arm in reports}
    diagnosed["warmup"][0]["error_counts"]["format"] = 1
    decision = load("experiment").gate(reports, diagnosed, cases, split="validation")
    assert not decision["passed"] and not decision["diagnostic_nonregression"]


@pytest.mark.parametrize("validation_passes", [False, True])
async def test_attempts_sealed_before_sampling_and_test_waits_for_validation(
    tmp_path, monkeypatch, validation_passes
):
    study = load("experiment")
    cases = refund_recovery_cases("train", count=10, seed=9506)
    (tmp_path / "training").mkdir()
    study.atomic_json(tmp_path / "training/train.json", cases)
    study.atomic_json(
        tmp_path / "probe-selection.json", [{"case_id": cases[0]["order_id"]}]
    )
    for split in ("validation", "test"):
        study.atomic_json(tmp_path / f"{split}.json", cases)
    calls = []

    class Checkpoint:
        pass

    # Use a real dataclass for the existing controller's asdict evidence.
    from dataclasses import dataclass

    @dataclass
    class Fixed:
        path: str = "river://fixed"

    class Controller:
        @staticmethod
        def seal(path, value):
            with path.open("x") as stream:
                json.dump(value, stream)

    class Recovery:
        @staticmethod
        async def collect(*args, **kwargs):
            return [
                [
                    {
                        "case_id": cases[0]["order_id"],
                        "reward": 1,
                        "environment_trace": {},
                    }
                    for _ in range(4)
                ]
            ]

    class Diagnostic:
        @staticmethod
        async def diagnose(*args):
            return {"error_counts": dict.fromkeys(load("diagnostics").CATEGORIES, 0)}

    def support(root, name):
        return {
            "controller": Controller,
            "recovery": Recovery,
            "diagnostics": Diagnostic,
        }[name]

    async def evaluate(
        root, plan, session, renderer, checkpoint, rows, budget, arm, split
    ):
        assert all((root / f"{a}-{split}-attempt.json").exists() for a in study.ARMS)
        calls.append((arm, split))
        return report(
            rows, arm, split, fail=(arm == "parent" or not validation_passes)
        ), diagnostics(rows)

    monkeypatch.setattr(study, "support", support)
    monkeypatch.setattr(study, "evaluate_arm", evaluate)
    plan = {
        "plan_hash": "fixed",
        "input_sha256": {"validation.json": "val", "test.json": "test"},
    }
    await study.evaluations(
        tmp_path, plan, None, None, {arm: Fixed() for arm in study.ARMS}, None
    )
    assert len(calls) == (4 if validation_passes else 2)
    assert (tmp_path / "parent-test-attempt.json").exists() == validation_passes
    with pytest.raises(FileExistsError):
        await study.evaluations(
            tmp_path, plan, None, None, {arm: Fixed() for arm in study.ARMS}, None
        )
    assert len(calls) == (4 if validation_passes else 2)
