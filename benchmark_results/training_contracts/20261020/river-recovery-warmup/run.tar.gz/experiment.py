"""Fixed ten-update recovery SFT continuation with fresh paired evaluation."""

import argparse
import asyncio
import hashlib
import importlib.util
import json
import math
import os
import shutil
import statistics
from contextlib import closing
from dataclasses import asdict
from pathlib import Path

from stateset_agents.core.environments.refund_policy_environment import (
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import (
    audit_refund_recovery_data,
    refund_recovery_cases,
)
from stateset_agents.evaluation.agent_runs import (
    content_hash,
    evaluation_report,
    validate_report,
)
from stateset_agents.evaluation.implementation import package_implementation
from stateset_agents.remote.job import RemoteJobSpec
from stateset_agents.remote.river_rl import atomic_json, exclusive_run
from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget

MODEL = "Qwen/Qwen3.5-9B"
SEED = 2026109401
ARMS = ("parent", "warmup")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def support(root, name):
    return load("warmup_" + name, root / "runtime" / (name + ".py"))


def spec_for(root):
    return RemoteJobSpec(
        dataset=root / "training/train.jsonl",
        base_model=MODEL,
        output_dir=root / "warmup",
        num_epochs=1,
        lora_r=16,
        learning_rate=2e-5,
        max_length=4096,
        per_device_batch_size=16,
        gradient_accumulation_steps=1,
        seed=SEED,
        timeout_s=900,
        job_kind="sft",
        parent_adapter=str(root / "parent"),
        harvest={
            "checkpoint": read(root / "parent/river_checkpoint.json")["checkpoint"]
        },
    )


def probe_selection(cases, records):
    """Pick one training case per recovery family and public terminal receipt type."""
    by_id = {row["order_id"]: row for row in cases}
    cells = {}
    for record in records:
        key = record["metadata"]["case_id"]
        outcome, tool = None, None
        for message in record["messages"]:
            if message["role"] == "user":
                try:
                    observation = json.loads(message["content"])
                except json.JSONDecodeError:
                    continue
                if observation.get("status") == "applied":
                    tool = observation["receipt"]["action"]["tool"]
            elif message["role"] == "assistant":
                action = json.loads(message["content"])
                if action["tool"] == "finish":
                    outcome = action["args"]["outcome"]
        category = tool if outcome == "resolved" else outcome
        cell = (by_id[key]["recovery"], category)
        cells[cell] = min(cells.get(cell, key), key)
    return [
        {"family": family, "receipt_type": category, "case_id": key}
        for (family, category), key in sorted(cells.items())
    ]


async def prepare(root, repo):
    assert not (root / "plan.json").exists()
    previous = repo / "outputs/river-recovery-pilot-20261020"
    audit = await audit_refund_recovery_data(previous / "data")
    assert audit["replayed_train_demonstrations"] == 160
    source = root / "training"
    source.mkdir(exist_ok=False)
    for name in ("train.json", "train.jsonl", "manifest.json"):
        shutil.copyfile(previous / "data" / name, source / name)
    atomic_json(root / "training-source-audit.json", audit)
    shutil.copytree(
        repo / "outputs/river-arithmetic-pilot-20261020/arithmetic", root / "parent"
    )
    history = read(previous / "historical-sources.json")
    for split in ("train", "validation", "test"):
        path = previous / "data" / f"{split}.json"
        history[str(path.relative_to(repo))] = sha(path)
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in history.items():
        assert sha(repo / name) == digest
        rows = read(repo / name)
        if isinstance(rows, list):
            excluded.extend(
                row
                for row in rows
                if isinstance(row, dict) and "return_window_days" in row
            )
    rejected = []
    for attempt in range(100):
        case_seed = 2026109301 + attempt * 100
        working, proposed = list(excluded), {}
        try:
            for split, count in (("validation", 80), ("test", 160)):
                proposed[split] = refund_recovery_cases(
                    split, count=count, seed=case_seed, excluded=working
                )
                working.extend(proposed[split])
        except ValueError as exc:
            if "overlap" not in str(exc).lower():
                raise
            rejected.append({"seed": case_seed, "reason": str(exc)})
            continue
        break
    else:
        raise ValueError("No fresh input seed among 100 prospective candidates")
    for split, rows in proposed.items():
        atomic_json(root / f"{split}.json", rows)
    atomic_json(root / "historical-sources.json", history)
    cases = read(source / "train.json")
    records = [
        json.loads(line) for line in (source / "train.jsonl").read_text().splitlines()
    ]
    selection = probe_selection(cases, records)
    assert 10 <= len(selection) <= 30
    atomic_json(root / "probe-selection.json", selection)
    implementation = package_implementation()
    runtime = root / "runtime"
    for name, digest in implementation["files"].items():
        path = repo / "stateset_agents" / name
        assert sha(path) == digest
        target = runtime / "stateset_agents" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    shutil.copyfile(Path(__file__), runtime / "experiment.py")
    shutil.copyfile(root / "diagnostics.py", runtime / "diagnostics.py")
    shutil.copyfile(previous / "runtime/experiment.py", runtime / "recovery.py")
    shutil.copyfile(previous / "runtime/controller.py", runtime / "controller.py")
    input_files = (
        "training/train.json",
        "training/train.jsonl",
        "training/manifest.json",
        "training-source-audit.json",
        "parent/river_checkpoint.json",
        "parent/stateset_manifest.json",
        "historical-sources.json",
        "probe-selection.json",
        "validation.json",
        "test.json",
    )
    plan = {
        "schema_version": 1,
        "kind": "exploratory-recovery-sft-warmup",
        "base_model": MODEL,
        "seed": SEED,
        "case_seed": case_seed,
        "arms": list(ARMS),
        "implementation": implementation,
        "sft_spec": spec_for(root).to_dict(),
        "expected_sft_updates": 10,
        "optimizer": "fresh optimizer; parent weights only",
        "training_rows": 160,
        "training_source": "Unmodified canonical train split from the recovery pilot; no harvested validation examples",
        "settings": support(root, "recovery").SETTINGS,
        "counts": {
            "validation_per_arm": 80,
            "test_per_arm": 160,
            "post_warmup_train_probe": len(selection) * 4,
        },
        "probe": {
            "group_size": 4,
            "temperature": 1.0,
            "selection": "First training case ID per recovery family and public terminal receipt type",
        },
        "limits": {
            "wall_seconds": 1500,
            "training_updates": 10,
            "reserved_output_tokens": (480 + len(selection) * 4) * 1024,
            "request_timeout_seconds": 180,
            "provider_retries": False,
            "attempts_per_stage": 1,
            "concurrency_per_arm": 6,
        },
        "acceptance": "Warmup must pass all fresh validation cases with zero violations/truncations before sealing either test arm. Test requires all warmup cases safe, no family or diagnostic-category regression, and strictly more successes than parent.",
        "error_categories": list(support(root, "diagnostics").CATEGORIES),
        "rejected_input_seeds": rejected,
        "input_sha256": {name: sha(root / name) for name in input_files},
        "runner_sha256": {
            name: sha(runtime / (name + ".py"))
            for name in ("experiment", "diagnostics", "recovery", "controller")
        },
        "quality_certification": False,
        "dollar_cap_enforced": False,
        "cost_usd": None,
        "scope": "One fixed final SFT checkpoint. Post-warmup probe observes variance only, without RL updates. Synthetic fixture, not real financial recovery.",
    }
    plan["plan_hash"] = content_hash(plan)
    atomic_json(root / "plan.json", plan)
    return {
        "prepared": True,
        "case_seed": case_seed,
        "counts": plan["counts"],
        "limits": plan["limits"],
        "plan_hash": plan["plan_hash"],
    }


def validate(root):
    plan = read(root / "plan.json")
    assert (
        content_hash({k: v for k, v in plan.items() if k != "plan_hash"})
        == plan["plan_hash"]
    )
    assert package_implementation() == plan["implementation"]
    assert spec_for(root).to_dict() == plan["sft_spec"]
    for name, digest in plan["input_sha256"].items():
        assert sha(root / name) == digest
    for name, digest in plan["runner_sha256"].items():
        assert sha(root / "runtime" / (name + ".py")) == digest
    assert sha(Path(__file__)) == plan["runner_sha256"]["experiment"]
    for name, digest in plan["implementation"]["files"].items():
        assert sha(root / "runtime/stateset_agents" / name) == digest
    return plan


def gate(reports, diagnostics, cases, *, split):
    expected = {r["order_id"] for r in cases}
    for arm in ARMS:
        assert reports[arm]["environment"] == "refund-recovery-v1"
        validate_report(reports[arm], expected_split=split)
        assert {o["case_id"] for o in reports[arm]["outcomes"]} == expected
        assert {o["case_id"] for o in diagnostics[arm]} == expected
    groups = {"overall": list(expected)}
    for row in cases:
        groups.setdefault("family:" + row["recovery"], []).append(row["order_id"])
    outcomes = {
        arm: {o["case_id"]: o for o in reports[arm]["outcomes"]} for arm in ARMS
    }
    cells = {}
    for name, ids in groups.items():
        parent = sum(outcomes["parent"][key]["success"] for key in ids)
        warmup = sum(outcomes["warmup"][key]["success"] for key in ids)
        violations = sum(
            outcomes["warmup"][key]["policy_violations"] > 0 for key in ids
        )
        truncated = sum(outcomes["warmup"][key]["truncated"] is not None for key in ids)
        cells[name] = {
            "total": len(ids),
            "parent_passed": parent,
            "warmup_passed": warmup,
            "warmup_violations": violations,
            "warmup_truncated": truncated,
            "passed": warmup == len(ids)
            and warmup >= parent
            and violations == truncated == 0,
        }
    errors = {
        arm: {
            category: sum(
                item["error_counts"][category] > 0 for item in diagnostics[arm]
            )
            for category in diagnostics[arm][0]["error_counts"]
        }
        for arm in ARMS
    }
    diagnostic_passed = all(
        errors["warmup"][category] <= errors["parent"][category]
        for category in errors["parent"]
    )
    improvement = reports["warmup"]["passed"] > reports["parent"]["passed"]
    return {
        "passed": all(cell["passed"] for cell in cells.values())
        and diagnostic_passed
        and (split == "validation" or improvement),
        "cells": cells,
        "diagnostic_cases": errors,
        "diagnostic_nonregression": diagnostic_passed,
        "strict_success_improvement": improvement,
    }


async def evaluate_arm(
    root, plan, session, renderer, checkpoint, cases, budget, arm, split
):
    helper, diagnostic = support(root, "recovery"), support(root, "diagnostics")
    helper.SEED = SEED
    stage = root / f"{arm}-{split}"
    stage.mkdir(exist_ok=False)
    outcomes = await helper.collect(
        stage, plan, session, renderer, checkpoint, cases, budget
    )
    report = evaluation_report(
        environment="refund-recovery-v1",
        base_model=MODEL,
        seed=SEED,
        cases={r["order_id"]: r for r in cases},
        settings=plan["settings"],
        checkpoint=asdict(checkpoint),
        outcomes=outcomes,
        case_families={r["order_id"]: r["recovery"] for r in cases},
        implementation=plan["implementation"],
        split=split,
    )
    by_id = {r["order_id"]: r for r in cases}
    diagnosed = [
        await diagnostic.diagnose(
            by_id[outcome["case_id"]], outcome["environment_trace"]
        )
        for outcome in report["outcomes"]
    ]
    atomic_json(root / f"{arm}-{split}.json", report)
    atomic_json(root / f"{arm}-{split}-diagnostics.json", diagnosed)
    return report, diagnosed


async def evaluations(root, plan, session, renderer, checkpoints, budget):
    helper = support(root, "recovery")
    helper.SEED = SEED
    diagnostic = support(root, "diagnostics")
    selection = read(root / "probe-selection.json")
    train = {r["order_id"]: r for r in read(root / "training/train.json")}
    support(root, "controller").seal(
        root / "probe-attempt.json",
        {"plan_hash": plan["plan_hash"], "checkpoint": asdict(checkpoints["warmup"])},
    )
    stage = root / "train-probe"
    stage.mkdir(exist_ok=False)
    groups = await helper.collect(
        stage,
        plan,
        session,
        renderer,
        checkpoints["warmup"],
        [train[item["case_id"]] for item in selection],
        budget,
        probe=True,
    )
    probe_diagnostics = [
        [
            await diagnostic.diagnose(train[o["case_id"]], o["environment_trace"])
            for o in group
        ]
        for group in groups
    ]
    probe = {
        "split": "train",
        "group_size": 4,
        "temperature": 1.0,
        "groups": groups,
        "diagnostics": probe_diagnostics,
        "variances": {
            group[0]["case_id"]: statistics.pvariance(o["reward"] for o in group)
            for group in groups
        },
        "rl_updates": 0,
    }
    probe["nonzero_variance_groups"] = sum(
        value > 0 for value in probe["variances"].values()
    )
    atomic_json(root / "train-probe.json", probe)
    print(
        json.dumps(
            {
                "probe_completed": sum(len(g) for g in groups),
                "nonzero_variance_groups": probe["nonzero_variance_groups"],
            }
        ),
        flush=True,
    )
    for split in ("validation", "test"):
        cases = read(root / f"{split}.json")
        for arm in ARMS:
            support(root, "controller").seal(
                root / f"{arm}-{split}-attempt.json",
                {
                    "plan_hash": plan["plan_hash"],
                    "checkpoint": asdict(checkpoints[arm]),
                    "case_sha256": plan["input_sha256"][f"{split}.json"],
                },
            )
        values = await asyncio.gather(
            *(
                evaluate_arm(
                    root,
                    plan,
                    session,
                    renderer,
                    checkpoints[arm],
                    cases,
                    budget,
                    arm,
                    split,
                )
                for arm in ARMS
            )
        )
        reports = {arm: value[0] for arm, value in zip(ARMS, values, strict=True)}
        diagnostics = {arm: value[1] for arm, value in zip(ARMS, values, strict=True)}
        decision = gate(reports, diagnostics, cases, split=split)
        atomic_json(root / f"{split}-decision.json", decision)
        print(
            json.dumps(
                {
                    "split": split,
                    "passed": decision["passed"],
                    "counts": {arm: r["passed"] for arm, r in reports.items()},
                    "errors": decision["diagnostic_cases"],
                }
            ),
            flush=True,
        )
        if split == "validation" and not decision["passed"]:
            atomic_json(
                root / "result.json",
                {
                    "status": "validation_blocked_test_not_attempted",
                    "test_attempted": False,
                    "accepted": False,
                    "sft_updates": 10,
                    "rl_updates": 0,
                    "nonzero_variance_groups": probe["nonzero_variance_groups"],
                },
            )
            return
    atomic_json(
        root / "result.json",
        {
            "status": "completed",
            "test_attempted": True,
            "accepted": decision["passed"],
            "sft_updates": 10,
            "rl_updates": 0,
            "nonzero_variance_groups": probe["nonzero_variance_groups"],
            "quality_certification": False,
        },
    )


def worker(root):
    import river_client as river

    from stateset_agents.remote.river import RiverExecutor
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_runtime import (
        require_model_access,
        require_native_runtime,
    )

    plan = validate(root)
    require_native_runtime()
    with exclusive_run(root / "worker"):
        support(root, "controller").seal(
            root / "worker-attempt.json", {"plan_hash": plan["plan_hash"]}
        )
        budget = RolloutAdmissionBudget(
            root / "rollout-budget.json",
            limit=plan["limits"]["reserved_output_tokens"],
            trajectory_tokens=1024,
            fingerprint=plan["plan_hash"],
            create=True,
        )
        with closing(
            river.Client(
                api_key=os.environ["RIVER_API_KEY"], timeout=180, enable_retries=False
            )
        ) as client:
            require_model_access(client, MODEL)
            renderer = get_river_renderer(MODEL, thinking=False)
            support(root, "controller").seal(
                root / "training-attempt.json",
                {"plan_hash": plan["plan_hash"], "spec": spec_for(root).to_dict()},
            )
            executor = RiverExecutor(
                client=client,
                tokenizer=renderer.tokenizer,
                ledger_path=root / "river-ledger.jsonl",
            )
            executor.MAX_TRANSIENT_ATTEMPTS = 1
            trained = executor.wait(executor.submit(spec_for(root)))
            atomic_json(
                root / "training-result.json",
                {
                    "status": trained.status.value,
                    "logs": trained.logs,
                    "duration_s": trained.duration_s,
                    "cost_usd": trained.cost_usd,
                },
            )
            assert trained.succeeded
            pointer = read(root / "warmup/river_checkpoint.json")
            assert pointer["steps"] == 10 and math.isfinite(pointer["final_loss"])
            checkpoints = {
                "parent": river.Checkpoint(
                    path=read(root / "parent/river_checkpoint.json")["checkpoint"],
                    step=44,
                    checkpoint_type="inference",
                ),
                "warmup": river.Checkpoint(
                    path=pointer["checkpoint"], step=10, checkpoint_type="inference"
                ),
            }
            with client.session(
                experiment="stateset-recovery-warmup",
                role="paired-final-checkpoint-evaluation",
            ) as session:
                asyncio.run(
                    evaluations(root, plan, session, renderer, checkpoints, budget)
                )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "validate", "launch", "worker"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    args = parser.parse_args()
    root = args.output.resolve()
    if args.command == "prepare":
        result = asyncio.run(prepare(root, args.repo.resolve()))
    elif args.command == "validate":
        result = {"valid": True, "plan_hash": validate(root)["plan_hash"]}
    elif args.command == "launch":
        helper = support(root, "controller")
        helper.validate = validate
        result = helper.launch(root)
    else:
        worker(root)
        return
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
