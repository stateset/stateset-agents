"""Offline supervisor qualification under uncertain or delayed worker exits."""

import importlib.util
from pathlib import Path
import subprocess
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "cohort_test_fixtures", ROOT / "test_study.py"
)
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
study = fixtures.study


class DeadlineChecks(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.CohortChecks("test_missing_seed_blocks_every_test_seal")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.fixture.qualify_all()

    def require_blocked(self):
        cohort = study.validation_cohort(self.fixture.root, self.fixture.plan)
        self.assertFalse(cohort["passed"])
        with self.assertRaises(AssertionError):
            study.seal_test_cohort(self.fixture.root, self.fixture.plan)
        self.assertFalse((self.fixture.root / "test-cohort-attempt.json").exists())

    def test_timeout_blocks_test_despite_zero_exit_and_claimed_validation_success(self):
        path = (
            study.seed_root(self.fixture.root, study.SEEDS[0])
            / "train-validation-execution.json"
        )
        execution = study.read(path)
        execution["timed_out"] = True
        fixtures.write(path, execution)
        self.require_blocked()

    def test_graceful_exit_after_deadline_stays_disqualified_and_is_not_retried(self):
        process = SimpleNamespace(
            wait=Mock(side_effect=[subprocess.TimeoutExpired("offline", 1), 0]),
            terminate=Mock(),
            kill=Mock(),
        )
        with patch("subprocess.Popen", return_value=process) as spawn:
            result = study.run_child(
                self.fixture.root, self.fixture.plan, study.SEEDS[0], "train-validation"
            )
        self.assertTrue(result["timed_out"])
        self.assertEqual(result["exit_code"], 0)
        self.assertEqual(spawn.call_count, 1)
        process.terminate.assert_called_once()
        process.kill.assert_not_called()
        self.require_blocked()

    def test_unresponsive_worker_is_killed_once_and_cannot_open_test(self):
        process = SimpleNamespace(
            wait=Mock(
                side_effect=[
                    subprocess.TimeoutExpired("offline", 1),
                    subprocess.TimeoutExpired("offline", 10),
                    -9,
                ]
            ),
            terminate=Mock(),
            kill=Mock(),
        )
        with patch("subprocess.Popen", return_value=process) as spawn:
            result = study.run_child(
                self.fixture.root, self.fixture.plan, study.SEEDS[0], "train-validation"
            )
        self.assertTrue(result["timed_out"])
        self.assertEqual(result["exit_code"], -9)
        self.assertEqual(spawn.call_count, 1)
        process.terminate.assert_called_once()
        process.kill.assert_called_once()
        self.require_blocked()


if __name__ == "__main__":
    unittest.main()
