"""Independently replay the complete six-seed cohort without provider calls."""

import asyncio
from collections import Counter
from dataclasses import asdict
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

import experiment as study
from river_client.rl.trajectory import Trajectory
from stateset_agents.core.environments.refund_policy_environment import (
    RefundPolicyEnvironment,
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import refund_recovery_cases
from stateset_agents.evaluation.agent_runs import content_hash
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace
from stateset_agents.remote.river_rl import atomic_json


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def reference(root):
    spec = importlib.util.spec_from_file_location(
        "independent_pilot_review", root / "reference-review.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


async def checked(value, row, diagnostic, fields):
    replay = await replay_recovery_trace(row, value["environment_trace"])
    assert all(replay[field] == value[field] for field in fields)
    assert replay["resolution_count"] <= 1
    return await diagnostic.diagnose(row, value["environment_trace"])


async def main():
    plan = study.validate(ROOT)
    aborted = (
        REPO
        / "benchmark_results/training_contracts/20261020/river-recovery-six-seed-aborted"
    )
    abort_record = read(aborted / "aborted.json")
    assert (
        abort_record["optimizer_updates_submitted"] == 0
        and not abort_record["evaluation_attempted"]
    )
    assert plan["supersedes_aborted_protocol"] == {
        "plan_hash": abort_record["plan_hash"],
        "admitted_trajectories": abort_record["admitted_trajectories"],
        "reserved_output_tokens": abort_record["reserved_output_tokens"],
        "optimizer_updates": 0,
        "held_out_cases_reused": False,
    }
    assert sha(REPO / "outputs/river-recovery-six-seed-20261020/aborted.json") == sha(
        aborted / "aborted.json"
    )
    verification = read(ROOT / "test-receipt.json")
    assert verification["plan_hash"] == plan["plan_hash"]
    assert (
        verification["supervisor_tests"]["passed"] == 3
        and verification["supervisor_tests"]["failed"] == 0
    )
    assert (
        verification["cohort_tests"]["passed"] == 7
        and verification["cohort_tests"]["failed"] == 0
    )
    assert (
        verification["analysis_unit_tests"]["passed"] == 34
        and verification["package_type_check"]["sources"] == 456
    )
    for name, digest in verification["source_sha256"].items():
        assert sha(REPO / name) == digest
    suites = list(
        ET.parse(ROOT / "analysis-checks-final.xml").getroot().iter("testsuite")
    )
    assert suites and all(
        int(s.attrib["failures"]) == int(s.attrib["errors"]) == 0 for s in suites
    )
    regression_tests = sum(int(s.attrib["tests"]) for s in suites)
    previous = REPO / "outputs/river-recovery-rl-pilot-20261020"
    for name in (
        "train.json",
        "train-source.json",
        "train-selection.json",
        "parent/river_checkpoint.json",
        "parent/stateset_manifest.json",
    ):
        assert sha(ROOT / name) == sha(previous / name)
    previous_plan = read(previous / "plan.json")
    assert plan["training"] == previous_plan["training"]
    assert plan["parent_checkpoint"] == previous_plan["parent_checkpoint"]
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in read(ROOT / "historical-sources.json").items():
        assert sha(REPO / name) == digest
        rows = read(REPO / name)
        if isinstance(rows, list):
            excluded.extend(
                row
                for row in rows
                if isinstance(row, dict) and "return_window_days" in row
            )
    fingerprint = RefundPolicyEnvironment.case_fingerprint
    ids, facts = {r["order_id"] for r in excluded}, {fingerprint(r) for r in excluded}
    for index, (stage, count, _) in enumerate(study.STAGES):
        rows = read(ROOT / f"{stage}.json")
        assert rows == refund_recovery_cases(
            "test" if stage == "test" else "validation",
            count=count,
            seed=plan["case_seed"] + index,
            excluded=excluded,
        )
        assert not ids & {r["order_id"] for r in rows} and not facts & {
            fingerprint(r) for r in rows
        }
        ids.update(r["order_id"] for r in rows)
        facts.update(fingerprint(r) for r in rows)
        excluded.extend(rows)
    execution, result = read(ROOT / "execution-summary.json"), read(
        ROOT / "result.json"
    )
    assert (
        execution["exit_code"] == 0
        and not execution["timed_out"]
        and execution["result"] == result
    )
    assert (
        result["plan_hash"] == plan["plan_hash"]
        and result["sft_updates"] == 0
        and not result["quality_certification"]
    )
    pilot = study.support(ROOT, "pilot")
    diagnostic = study.support(ROOT, "diagnostics")
    baseline = reference(ROOT)
    baseline.study = pilot
    cases = {row["order_id"]: row for row in read(ROOT / "train.json")}
    checked_count = admitted = updates = 0
    seed_reviews, qualified = {}, {}
    for seed in study.SEEDS:
        directory = study.seed_root(ROOT, seed)
        phase = read(directory / "train-validation-execution.json")
        assert phase["seed"] == seed and phase["plan_hash"] == plan["plan_hash"]
        phase_clean = phase["exit_code"] == 0 and not phase["timed_out"]
        entry = {
            "train_validation_execution_clean": phase_clean,
            "rl_updates": None,
            "training_rollouts_replayed": 0,
            "evaluations": {},
            "decisions": {},
        }
        initial_path = directory / "initial-model.json"
        initial = read(initial_path) if initial_path.exists() else None
        batch_path = directory / "batch-evidence.json"
        if batch_path.exists():
            evidence = read(batch_path)
            assert (
                evidence["plan_hash"] == plan["plan_hash"]
                and evidence["current_step"] == 0
            )
            assert (
                initial["step"] == 0
                and initial["parent_checkpoint"] == plan["parent_checkpoint"]
            )
            trajectories = [
                Trajectory.from_state_dict(state)
                for state in evidence["trajectory_states"]
            ]
            native, metrics, variances = pilot.exact_batch(
                trajectories,
                cases,
                groups=19,
                policy_id=initial["policy_version"]["id"],
            )
            independent, independent_variances = baseline.reference_datums(
                evidence["trajectory_states"]
            )
            assert native == independent == read(directory / "batch-datums.json")
            assert (
                metrics == evidence["batch_metrics"]
                and variances == independent_variances == evidence["variances"]
            )
            assert (
                content_hash(native) == evidence["datums_hash"]
                and len(native) == evidence["datums"]
            )
            assert evidence["nonzero_variance_groups"] == sum(
                v > 0 for v in variances.values()
            )
            assert len(evidence["outcomes"]) == len(trajectories) == 76
            for trajectory, value, classified in zip(
                trajectories, evidence["outcomes"], evidence["diagnostics"], strict=True
            ):
                assert value == pilot.outcome(trajectory, cases)
                assert classified == await checked(
                    value, cases[value["case_id"]], diagnostic, pilot.FIELDS
                )
                checked_count += 1
            entry.update(
                {
                    "training_rollouts_replayed": 76,
                    "training_passed": sum(o["success"] for o in evidence["outcomes"]),
                    "nonzero_variance_groups": evidence["nonzero_variance_groups"],
                    "native_datums": len(native),
                    "training_errors": diagnostic.summarize(evidence["diagnostics"]),
                }
            )
            if (directory / "training-activity.json").exists():
                activity, steps = read(directory / "training-activity.json"), read(
                    directory / "training-steps.json"
                )
                assert len(steps) == 1 and steps[0]["batch"] == 1
                pilot.validate_training_metrics(steps[0]["metrics"])
                ack = int(steps[0]["metrics"]["train/updated"])
                assert ack == int(bool(native)) == steps[0]["model_step"]
                assert activity == {
                    "consumed_batches": 1,
                    "acknowledged_optimizer_updates": ack,
                    "sft_updates": 0,
                }
                assert all(
                    steps[0]["metrics"][key] == value for key, value in metrics.items()
                )
                entry["rl_updates"] = ack
                updates += ack
                if ack:
                    final, pointer = read(directory / "final-model.json"), read(
                        directory / "rl-checkpoint.json"
                    )
                    assert (
                        final["step"] == pointer["step"] == 1
                        and pointer["policy_version"] == final["policy_version"]
                    )
                    assert (
                        final["policy_version"]["parent_id"]
                        == initial["policy_version"]["id"]
                    )
                    assert (
                        final["policy_version"]["lineage_id"]
                        == initial["policy_version"]["lineage_id"]
                    )
                    assert (
                        final["policy_version"]["step"]
                        == initial["policy_version"]["step"] + 1
                    )
                    entry["provider_reported_grad_norm"] = steps[0]["metrics"].get(
                        "optimizer/grad_norm"
                    )
                else:
                    assert not (directory / "rl-checkpoint.json").exists()
        else:
            assert (
                not phase_clean
            ), "A clean phase must retain its complete training batch"
        for stage, count, size in study.STAGES:
            rows = read(ROOT / f"{stage}.json")
            by_id = {row["order_id"]: row for row in rows}
            reports = {}
            for arm in study.ARMS:
                path = directory / f"{arm}-{stage}.json"
                if not path.exists():
                    continue
                report = read(path)
                assert (
                    report["plan_hash"] == plan["plan_hash"]
                    and report["implementation"] == plan["implementation"]
                )
                assert (
                    report["seed"] == seed
                    and report["arm"] == arm
                    and report["stage"] == stage
                )
                assert report["environment"] == "refund-recovery-v1"
                expected_pointer = (
                    asdict(study.parent_checkpoint(plan))
                    if arm == "parent"
                    else read(directory / "rl-checkpoint.json")
                )
                assert report["checkpoint"] == expected_pointer
                assert report["case_hashes"] == {
                    key: content_hash(row) for key, row in by_id.items()
                }
                assert report["settings"] == {
                    **plan["settings"],
                    "temperature": 0 if size == 1 else 1.0,
                    "group_size": size,
                    "top_p": 1.0,
                    "top_k": -1,
                }
                seal = read(directory / f"{arm}-{stage}-attempt.json")
                assert seal == {
                    "plan_hash": plan["plan_hash"],
                    "checkpoint": expected_pointer,
                    "case_sha256": plan["input_sha256"][f"{stage}.json"],
                }
                groups, ds = report["groups"], report["diagnostics"]
                assert len(groups) == len(ds) == count and Counter(
                    g[0]["case_id"] for g in groups
                ) == dict.fromkeys(by_id, 1)
                for group, diagnosed in zip(groups, ds, strict=True):
                    assert (
                        len(group) == len(diagnosed) == size
                        and len({o["case_id"] for o in group}) == 1
                    )
                    for value, classification in zip(group, diagnosed, strict=True):
                        assert classification == await checked(
                            value, by_id[value["case_id"]], diagnostic, pilot.FIELDS
                        )
                        checked_count += 1
                assert report["summary"] == pilot.summarize(groups, rows, ds)
                entry["evaluations"][f"{arm}-{stage}"] = {
                    key: report["summary"][key]
                    for key in (
                        "total",
                        "passed",
                        "diagnostic_cases",
                        "truncation_rate",
                    )
                }
                reports[arm] = report
            decision_path = directory / f"{stage}-decision.json"
            if decision_path.exists():
                assert set(reports) == set(study.ARMS)
                independent_gate = baseline.independent_gate(reports, rows, stage)
                assert independent_gate == read(decision_path)
                entry["decisions"][stage] = independent_gate["passed"]
        if entry["rl_updates"] == 0:
            assert not any(
                (directory / f"{arm}-{stage}-attempt.json").exists()
                for stage, _, _ in study.STAGES
                for arm in study.ARMS
            )
        qualified[str(seed)] = (
            phase_clean
            and entry["rl_updates"] == 1
            and all(
                entry["decisions"].get(stage, False) for stage, _, _ in study.STAGES[:2]
            )
        )
        budget_path = directory / "rollout-budget.json"
        if budget_path.exists():
            budget = read(budget_path)
            assert (
                budget["fingerprint"] == plan["plan_hash"]
                and budget["reserved_generated_tokens"]
                == budget["admitted_trajectories"] * 1024
                <= 716 * 1024
            )
            admitted += budget["admitted_trajectories"]
        elif phase_clean:
            raise AssertionError("A clean phase must retain its admission budget")
        seed_reviews[str(seed)] = entry
    cohort = read(ROOT / "validation-cohort.json")
    assert cohort["passed"] == all(qualified.values())
    assert {
        seed: row["qualified"] for seed, row in cohort["seeds"].items()
    } == qualified
    assert result["acknowledged_rl_updates"] == updates
    assert result["update_activity_by_seed"] == {
        seed: entry["rl_updates"] for seed, entry in seed_reviews.items()
    }
    assert admitted <= 4296 and checked_count <= admitted
    unreviewed = admitted - checked_count
    if (
        all(
            entry["train_validation_execution_clean"] for entry in seed_reviews.values()
        )
        and result["status"] != "incomplete_test_attempt"
    ):
        assert unreviewed == 0
    if not cohort["passed"]:
        assert not result["test_attempted"] and not result["accepted"]
        assert not (ROOT / "test-cohort-attempt.json").exists()
        assert not any(
            (study.seed_root(ROOT, seed) / f"{arm}-test-attempt.json").exists()
            for seed in study.SEEDS
            for arm in study.ARMS
        )
        assert not (ROOT / "replication-statistics.json").exists()
    else:
        study.verify_test_cohort(ROOT, plan)
        assert result["test_attempted"]
        if result["status"] == "completed":
            statistics = study.analysis(ROOT, plan)
            assert statistics == read(ROOT / "replication-statistics.json")
            deltas = [row["delta_count"] for row in statistics["seed_results"]]
            patterns = list(itertools.product((-1, 1), repeat=6))
            probability = (
                sum(
                    abs(sum(a * b for a, b in zip(pattern, deltas, strict=True)))
                    >= abs(sum(deltas))
                    for pattern in patterns
                )
                / 64
            )
            assert probability == statistics["exact_two_sided_seed_sign_flip_p"]
            individual = all(
                seed_reviews[str(seed)]["decisions"]["test"] for seed in study.SEEDS
            )
            statistical = (
                probability <= 0.05
                and statistics["seed_and_family_case_bootstrap_95"][0] > 0
            )
            assert (
                result["individual_test_gates_passed"] == individual
                and result["statistical_gate_passed"] == statistical
            )
            assert result["accepted"] == (individual and statistical)
        else:
            assert not result["accepted"]
    old = REPO / "outputs/river-recovery-pilot-20261020"
    assert (
        not (old / "test-attempt.json").exists()
        and len(read(old / "data/test.json")) == 80
    )
    arithmetic = REPO / "outputs/river-arithmetic-pilot-20261020"
    assert len(read(arithmetic / "data/test.json")) == 308 and not any(
        (arithmetic / f"{arm}-test-attempt.json").exists()
        for arm in ("control", "arithmetic")
    )
    prior = {}
    target = (
        REPO
        / "benchmark_results/training_contracts/20261020/river-recovery-replication"
    )
    for index in sorted(
        (REPO / "benchmark_results/training_contracts").rglob("artifacts.sha256.json")
    ):
        if index.parent == target:
            continue
        for name, digest in read(index).items():
            assert sha(index.parent / name) == digest
            prior[str((index.parent / name).relative_to(REPO))] = digest
    atomic_json(ROOT / "prior-evidence-verified.json", prior)
    inventory = read(ROOT / "industry-readiness.json")
    for name, digest in inventory["retained_manifest_sha256"].items():
        assert sha(ROOT / name) == digest
    industry_index = read(ROOT / "industry-readiness-source/dataset_manifest.json")
    industry_source = REPO / "outputs/industry-datasets-20261019"
    assert all(
        sha(industry_source / name) == digest
        for name, digest in industry_index["artifacts"].items()
    )
    assert (
        len(industry_index["artifacts"]) == inventory["artifacts_hash_verified"] == 24
    )
    for domain, row in inventory["domains"].items():
        manifest_path = ROOT / "industry-readiness-source" / f"{domain}-manifest.json"
        manifest = read(manifest_path)
        assert sha(manifest_path) == row["manifest_sha256"]
        assert (
            manifest["review_status"]
            == row["review_status"]
            == "not_independently_reviewed"
        )
        assert row["declared_counts"] == {
            split: manifest[f"{split}_rows"]
            for split in ("train", "validation", "test")
        }
        assert (
            not row["independent_review_evidence_in_manifest"]
            and not row["production_quality_established"]
        )
    review = {
        "passed": True,
        "plan_hash": plan["plan_hash"],
        "seeds": seed_reviews,
        "planned_seeds": 6,
        "qualifying_seeds": sum(qualified.values()),
        "acknowledged_rl_updates": updates,
        "replayed_outcomes": checked_count,
        "admitted_trajectories": admitted,
        "admitted_unreplayed_trajectories": unreviewed,
        "test_attempted": result["test_attempted"],
        "accepted": result["accepted"],
        "fresh_test_case_clusters": 40,
        "prior_artifacts_unchanged": len(prior),
        "regression_tests": regression_tests,
        "cohort_tests": 7,
        "supervisor_tests": 3,
        "industry_artifacts_verified": 24,
        "old_recovery_test_cases_unattempted": 80,
        "old_arithmetic_test_cases_unattempted": 308,
        "cost_usd": None,
        "provider_calls_during_review": 0,
    }
    atomic_json(ROOT / "review-summary.json", review)
    print(json.dumps(review), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
