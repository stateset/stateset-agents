"""Offline qualification and cohort sealing checks; no provider requests."""

from dataclasses import asdict
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
spec = importlib.util.spec_from_file_location("six_seed_study", HERE / "experiment.py")
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


class CohortChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "runtime").mkdir()
        previous = REPO / "outputs/river-recovery-rl-pilot-20261020"
        shutil.copyfile(
            previous / "runtime/experiment.py", self.root / "runtime/pilot.py"
        )
        shutil.copyfile(
            previous / "runtime/controller.py", self.root / "runtime/controller.py"
        )
        self.pilot = study.support(self.root, "pilot")
        self.cases = [
            {"order_id": "A", "recovery": "clean"},
            {"order_id": "B", "recovery": "lost_ack_applied"},
        ]
        self.plan = {
            "plan_hash": "offline-cohort",
            "parent_checkpoint": "river://scripted-parent",
            "settings": study.read(previous / "plan.json")["settings"],
            "input_sha256": {},
            "limits": {"phase_worker_wall_seconds": 1},
        }
        for stage, _, _ in study.STAGES:
            path = self.root / f"{stage}.json"
            write(path, self.cases)
            self.plan["input_sha256"][f"{stage}.json"] = study.sha(path)

    def report(self, seed, arm, stage, pointer):
        size = 1 if stage == "greedy-validation" else 4
        groups, diagnostics = [], []
        for case in self.cases:
            groups.append(
                [
                    {
                        "case_id": case["order_id"],
                        "case_hash": study.content_hash(case),
                        "success": True,
                        "reward": 1.0,
                        "policy_violations": 0,
                        "truncated": None,
                        "generated_tokens": 12,
                        "tool_calls": 2,
                        "elapsed_seconds": 1.0,
                    }
                    for _ in range(size)
                ]
            )
            diagnostics.append(
                [
                    {
                        "case_id": case["order_id"],
                        "error_counts": dict.fromkeys(self.pilot.CATEGORIES, 0),
                    }
                    for _ in range(size)
                ]
            )
        return {
            "plan_hash": self.plan["plan_hash"],
            "seed": seed,
            "arm": arm,
            "stage": stage,
            "group_size": size,
            "checkpoint": (
                pointer if arm == "rl" else asdict(study.parent_checkpoint(self.plan))
            ),
            "case_hashes": {
                row["order_id"]: study.content_hash(row) for row in self.cases
            },
            "settings": {
                **self.plan["settings"],
                "temperature": 0 if size == 1 else 1.0,
                "group_size": size,
                "top_p": 1.0,
                "top_k": -1,
            },
            "groups": groups,
            "diagnostics": diagnostics,
            "summary": self.pilot.summarize(groups, self.cases, diagnostics),
        }

    def qualify_all(self):
        for seed in study.SEEDS:
            directory = study.seed_root(self.root, seed)
            write(
                directory / "train-validation-execution.json",
                {
                    "plan_hash": self.plan["plan_hash"],
                    "seed": seed,
                    "phase": "train-validation",
                    "exit_code": 0,
                    "timed_out": False,
                },
            )
            write(
                directory / "train-validation-result.json",
                {"status": "validation_passed", "rl_updates": 1},
            )
            write(
                directory / "training-activity.json",
                {
                    "consumed_batches": 1,
                    "acknowledged_optimizer_updates": 1,
                    "sft_updates": 0,
                },
            )
            write(
                directory / "training-steps.json",
                [
                    {
                        "batch": 1,
                        "model_step": 1,
                        "metrics": {"train/updated": 1, "train/datums": 4},
                    }
                ],
            )
            initial = {
                "id": f"initial-{seed}",
                "lineage_id": f"lineage-{seed}",
                "step": 12,
                "parent_id": None,
            }
            final = {
                **initial,
                "id": f"final-{seed}",
                "parent_id": initial["id"],
                "step": 13,
            }
            write(
                directory / "initial-model.json",
                {
                    "step": 0,
                    "policy_version": initial,
                    "parent_checkpoint": self.plan["parent_checkpoint"],
                },
            )
            write(directory / "final-model.json", {"step": 1, "policy_version": final})
            pointer = {
                "path": f"river://scripted-{seed}",
                "step": 1,
                "checkpoint_type": "inference",
                "policy_version": final,
            }
            write(directory / "rl-checkpoint.json", pointer)
            for stage, _, _ in study.STAGES[:2]:
                reports = {
                    arm: self.report(seed, arm, stage, pointer) for arm in study.ARMS
                }
                for arm in study.ARMS:
                    write(directory / f"{arm}-{stage}.json", reports[arm])
                write(
                    directory / f"{stage}-decision.json",
                    self.pilot.gate(reports, self.cases, stage=stage),
                )

    def test_missing_seed_blocks_every_test_seal(self):
        self.assertFalse(study.validation_cohort(self.root, self.plan)["passed"])
        with self.assertRaises(AssertionError):
            study.seal_test_cohort(self.root, self.plan)
        self.assertFalse((self.root / "test-cohort-attempt.json").exists())

    def test_one_skipped_seed_cannot_be_replaced_or_excluded(self):
        self.qualify_all()
        directory = study.seed_root(self.root, study.SEEDS[-1])
        write(
            directory / "train-validation-result.json",
            {"status": "no_update_observed", "rl_updates": 0},
        )
        cohort = study.validation_cohort(self.root, self.plan)
        self.assertEqual(len(cohort["seeds"]), 6)
        self.assertFalse(cohort["passed"])
        with self.assertRaises(AssertionError):
            study.seal_test_cohort(self.root, self.plan)
        self.assertFalse((self.root / "test-cohort-attempt.json").exists())

    def test_all_twelve_arms_bound_before_test_and_retry_refused(self):
        self.qualify_all()
        study.seal_test_cohort(self.root, self.plan)
        self.assertEqual(
            len(list((self.root / "seeds").glob("*/*-test-attempt.json"))), 12
        )
        study.verify_test_cohort(self.root, self.plan)
        with self.assertRaises(FileExistsError):
            study.seal_test_cohort(self.root, self.plan)

    def test_claimed_success_with_tampered_validation_summary_is_rejected(self):
        self.qualify_all()
        path = study.seed_root(self.root, study.SEEDS[0]) / "rl-greedy-validation.json"
        report = study.read(path)
        report["summary"]["passed"] -= 1
        write(path, report)
        with self.assertRaises(AssertionError):
            study.seal_test_cohort(self.root, self.plan)
        self.assertFalse((self.root / "test-cohort-attempt.json").exists())

    def test_changed_candidate_after_sealing_cannot_be_sampled(self):
        self.qualify_all()
        study.seal_test_cohort(self.root, self.plan)
        path = study.seed_root(self.root, study.SEEDS[0]) / "rl-checkpoint.json"
        pointer = study.read(path)
        pointer["path"] = "river://replacement"
        write(path, pointer)
        with self.assertRaises(AssertionError):
            study.verify_test_cohort(self.root, self.plan)

    def test_missing_test_arm_fails_before_provider_client_is_created(self):
        self.qualify_all()
        study.seal_test_cohort(self.root, self.plan)
        directory = study.seed_root(self.root, study.SEEDS[0])
        (directory / "parent-test-attempt.json").unlink()
        with (
            patch.object(study, "validate", return_value=self.plan),
            patch("stateset_agents.remote.river_runtime.require_native_runtime"),
            patch("river_client.Client") as client,
        ):
            with self.assertRaises(FileNotFoundError):
                study.phase_worker(self.root, study.SEEDS[0], "test")
            client.assert_not_called()

    def test_failed_child_is_recorded_once_without_retry(self):
        directory = study.seed_root(self.root, study.SEEDS[0])
        directory.mkdir(parents=True)
        process = SimpleNamespace(wait=lambda **kwargs: 7)
        with patch("subprocess.Popen", return_value=process) as spawn:
            result = study.run_child(
                self.root, self.plan, study.SEEDS[0], "train-validation"
            )
        self.assertEqual(result["exit_code"], 7)
        self.assertEqual(spawn.call_count, 1)
        with self.assertRaises(FileExistsError):
            study.run_child(self.root, self.plan, study.SEEDS[0], "train-validation")


if __name__ == "__main__":
    unittest.main()
