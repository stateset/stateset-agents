"""Publish the reviewed six-seed attempt once, with byte-verified evidence."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
TARGET = (
    REPO / "benchmark_results/training_contracts/20261020/river-recovery-replication"
)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def score(entry, stage):
    before = entry["evaluations"].get("parent-" + stage)
    after = entry["evaluations"].get("rl-" + stage)
    if before is None or after is None:
        return "unattempted/incomplete"
    return f"{before['passed']}/{before['total']} → {after['passed']}/{after['total']}"


def main():
    review, plan, result = (
        read(ROOT / name)
        for name in ("review-summary.json", "plan.json", "result.json")
    )
    assert review["passed"] and read(ROOT / "execution-summary.json")["exit_code"] == 0
    inputs = [
        p
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    ]
    secret = re.compile(rb"rv_[A-Za-z0-9_-]{32,}")
    assert not any(secret.search(p.read_bytes()) for p in inputs)
    TARGET.mkdir(parents=True, exist_ok=False)
    with tarfile.open(TARGET / "run.tar.gz", "w:gz") as archive:
        for path in inputs:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(TARGET / "run.tar.gz") as archive:
        assert len(archive.getmembers()) == len(inputs)
        for member in archive.getmembers():
            assert member.isfile() and hashlib.sha256(
                archive.extractfile(member).read()
            ).hexdigest() == sha(ROOT / member.name)
    for name in (
        "plan.json",
        "result.json",
        "review-summary.json",
        "execution-summary.json",
        "validation-cohort.json",
        "test-cohort-attempt.json",
        "replication-statistics.json",
        "test-receipt.json",
        "analysis-checks-final.xml",
        "seed-analysis-tests.xml",
        "runtime-versions.json",
        "prior-evidence-verified.json",
        "industry-readiness.json",
    ):
        if (ROOT / name).exists():
            shutil.copyfile(ROOT / name, TARGET / name)
    shutil.copyfile(
        ROOT / "parent/river_checkpoint.json", TARGET / "parent-checkpoint.json"
    )
    for seed in plan["seeds"]:
        pointer = ROOT / "seeds" / str(seed) / "rl-checkpoint.json"
        if pointer.exists():
            shutil.copyfile(pointer, TARGET / f"seed-{seed}-checkpoint.json")
    (TARGET / "archive-inputs.json").write_text(
        json.dumps(
            {str(p.relative_to(ROOT)): sha(p) for p in inputs}, indent=2, sort_keys=True
        )
        + "\n"
    )
    lines = [
        "# Six-seed River recovery RL replication — October 20, 2026",
        "",
        "Six fixed one-batch attempts from the same [accepted recovery SFT parent](../river-recovery-warmup/README.md).",
        f"Status: **{result['status']}**. Qualifying validation seeds: **{review['qualifying_seeds']}/6**.",
        f"Acknowledged RL updates: **{review['acknowledged_rl_updates']}**. New SFT updates: **0**.",
        f"Replication accepted: **{review['accepted']}**. Test attempted: **{review['test_attempted']}**.",
        "No automatic promotion or best-seed nomination occurred.",
        "",
        "| Seed | Train passed | Variable groups | Native datums | RL updates | Greedy validation: parent → RL | Stochastic validation: parent → RL | Test: parent → RL |",
        "| ---: | ---: | ---: | ---: | ---: | --- | --- | --- |",
    ]
    for seed in plan["seeds"]:
        entry = review["seeds"][str(seed)]
        updates = entry["rl_updates"] if entry["rl_updates"] is not None else "unknown"
        lines.append(
            f"| {seed} | {entry.get('training_passed', 'unknown')}/76 | {entry.get('nonzero_variance_groups', 'unknown')}/19 | {entry.get('native_datums', 'unknown')} | {updates} | {score(entry, 'greedy-validation')} | {score(entry, 'stochastic-validation')} | {score(entry, 'test')} |"
        )
    statistics_path = ROOT / "replication-statistics.json"
    if statistics_path.exists():
        stats = read(statistics_path)
        interval = stats["seed_and_family_case_bootstrap_95"]
        lines.extend(
            [
                "",
                "## Prespecified test inference",
                "",
                f"Parent passed **{stats['parent_passed']}/{stats['rollouts_per_arm']}**; RL passed **{stats['candidate_passed']}/{stats['rollouts_per_arm']}**.",
                f"Paired success-rate difference: **{stats['delta_rate']:.3%}**.",
                f"Exact two-sided seed sign-flip p-value: **{stats['exact_two_sided_seed_sign_flip_p']}**.",
                f"Seed/case bootstrap 95% interval: **[{interval[0]:.3%}, {interval[1]:.3%}]**.",
                "These estimates condition on 40 shared synthetic case clusters and six",
                "training seeds. Four rollouts within a case are aggregated before",
                "inference. The exact calculation retains ties and enumerates all 64",
                "seed sign patterns; the 10,000-replicate bootstrap resamples seeds and",
                "case clusters within families, sharing resampled cases across seeds.",
                "Sign exchangeability and resampling assumptions apply. There are no",
                "independent merchant replications or production quality claims.",
            ]
        )
    else:
        lines.extend(
            [
                "",
                "## Test gate",
                "",
                "The prespecified test analysis was not available. No p-value or",
                "confidence interval was manufactured from a subset of seeds or",
                "validation results. Inspect per-seed status and execution receipts.",
            ]
        )
    if not review["test_attempted"]:
        lines.extend(
            [
                "",
                "All **40 fresh test cases** remain unattempted for every seed and arm.",
                "The complete six-seed cohort must qualify before any test attempt is sealed.",
            ]
        )
    lines.extend(
        [
            "",
            "## Replication protocol",
            "",
            "Every seed starts from the same SFT checkpoint with a fresh optimizer.",
            "The 19 training cases and public-receipt coverage are unchanged from the",
            "pilot. Each receives four fresh on-policy samples at temperature 1.",
            "One logical CISPO batch permits at most one optimizer update: group-centered",
            "advantages without standardization, token normalization, eps_max 6, Adam",
            "learning rate 1e-5, LoRA rank 16, and zero policy staleness. Any invalid",
            "native token/logprob evidence, committed-policy mismatch, or training",
            "truncation rejects the batch before forward/backward. Zero signal consumes",
            "the attempt without a replacement batch or optimizer update.",
            "",
            "All six training/validation attempts run, even when another seed fails.",
            "Each seed needs an acknowledged update, 80/80 safe greedy validation",
            "cases, and no overall/family/error-category regression on 20 stochastic",
            "validation cases with four rollouts each. Semantic errors or truncation",
            "block validation. Every seed must qualify before all six fixed final",
            "checkpoints and all twelve test arms are sealed. Test then uses 40 cases",
            "with four rollouts each; every seed must strictly improve successes and",
            "formatting without family/category regression, semantic error, or truncation.",
            "Acceptance additionally requires exact two-sided p≤0.05 and a positive",
            "lower bootstrap endpoint. No seed can be dropped, substituted, or selected",
            "using test outcomes. There is no checkpoint search after evaluation.",
            "",
            "All seeds share fresh cases. Parent/RL arms share the same per-seed",
            "sampling configuration. Inputs exclude every historical training,",
            "prepared, and evaluated case ID and order fact fingerprint, including",
            "the prior pilot, completed SFT comparisons, and the stopped protocol.",
            "",
            "## Sampler stream audit and stopped protocol",
            "",
            "The [initial consecutive-seed protocol](../river-recovery-six-seed-aborted/README.md)",
            "was stopped after finding deterministic member-offset stream reuse.",
            "It admitted 24 training trajectories (24,576 reserved output tokens),",
            "submitted zero optimizer updates, and sampled no evaluation cases. Its",
            "plan, partial state, and original frozen sources are preserved unchanged.",
            "Those admissions and unknown billed costs remain separate from this study.",
            "",
            "This corrected prospective protocol uses fixed run seeds spaced by",
            "350,000,000. The packaged audit checks all possible differences for 80",
            "groups, four members, and up to 1,024 token-bearing sample calls per",
            "member, including modulo-2³¹ wraparound. It pins the inspected SDK engine",
            "source and reruns the audit before provider work. Distinct sampler seed",
            "identities prevent direct stream reuse; they do not prove PRNG independence.",
            "",
            "## Verification and limits",
            "",
            f"Independent review replayed **{review['replayed_outcomes']} outcomes** and reconstructed",
            "native logical datums from generated token IDs, sampled logprobs, group",
            "rewards, and masks without invoking River's batch builder. It checked",
            "server-committed parent/child policy receipts, fresh input regeneration,",
            "attempt seals, diagnostics, per-family gates, and whole-cohort decisions.",
            f"Admitted trajectories: **{review['admitted_trajectories']}**; admitted without a retained/replayed final outcome: **{review['admitted_unreplayed_trajectories']}**.",
            "Uncertain activity is not relabelled as zero updates or successful learning.",
            f"All **{review['prior_artifacts_unchanged']} prior retained artifacts** matched their hashes.",
            "The earlier recovery pilot's 80 and arithmetic pilot's 308 blocked test",
            "cases remain unattempted. Local hashes and client receipts provide",
            "consistency evidence, not independent provider or weight-byte attestation.",
            "",
            f"Verification: **{review['regression_tests']} regression tests**, including **34 analysis/stream-audit tests**,",
            "and **7 cohort-control tests** passed. Type checking passed all **456**",
            "packaged sources. Only the new replication analysis module changes the",
            "preceding 455-source package; recovery environment/reward/trainer behavior",
            "is unchanged. Test transport makes no paid provider calls.",
            "Three additional offline supervisor checks verified deadline rejection,",
            "including a late zero exit and a forced kill, without retrying the worker.",
            "",
            "The separate industry inventory verified 24 existing dataset artifacts.",
            "Ecommerce, logistics, and SaaS each declare 512 training, 64 validation,",
            "and 128 test rows, with status not_independently_reviewed. Production",
            "validation still requires reviewed source conversations, source-group",
            "and temporal isolation, and retained domain review/outcome evidence.",
            "",
            "Study bounds: at most six optimizer updates, 4,296 trajectories,",
            "4,399,104 reserved output tokens, three seed workers at a time, 25 minutes",
            "per phase worker, and 70 minutes overall. Provider and sealed-phase retries",
            "are disabled. Billed dollar cost is unavailable; token reservations are",
            "not a dollar cap. This study plus the stopped attempt reserve at most",
            "4,423,680 output tokens across 4,320 admissions; the overall acknowledged",
            "RL update bound remains six because the stopped attempt submitted none.",
            "",
            f"Archive byte verification checked **{len(inputs)} files**. Frozen package/runner",
            "sources, inspected SDK seed source, inputs, partial or complete native",
            "trainer states, datums, checkpoint receipts, attempt seals, full available",
            "reports, diagnostics, and executable review scripts are retained.",
            "",
            "This conditional synthetic replication does not certify production A+",
            "quality, reviewed industry generalization, real payment recovery, durable",
            "idempotency, optimizer continuity, or independent merchant performance.",
            "",
        ]
    )
    (TARGET / "README.md").write_text("\n".join(lines))
    artifacts = {p.name: sha(p) for p in sorted(TARGET.iterdir()) if p.is_file()}
    (TARGET / "artifacts.sha256.json").write_text(
        json.dumps(artifacts, indent=2, sort_keys=True) + "\n"
    )
    assert all(sha(TARGET / name) == digest for name, digest in artifacts.items())
    print(
        json.dumps(
            {
                "retained": str(TARGET.relative_to(REPO)),
                "artifacts": len(artifacts),
                "archive_files_verified": len(inputs),
            }
        )
    )


if __name__ == "__main__":
    main()
