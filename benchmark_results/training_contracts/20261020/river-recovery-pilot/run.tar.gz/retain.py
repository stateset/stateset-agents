"""Retain the recovery result, complete runtime, and replay evidence once."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
TARGET = REPO / "benchmark_results/training_contracts/20261020/river-recovery-pilot"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    review = read(ROOT / "review-summary.json")
    assert review["passed"] and read(ROOT / "execution-summary.json")["exit_code"] == 0
    TARGET.mkdir(parents=True, exist_ok=False)
    inputs = [
        p
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    ]
    secret = re.compile(rb"rv_[A-Za-z0-9_-]{32,}")
    assert all(
        not secret.search(p.read_bytes()) for p in inputs
    ), "Credential-like material cannot be retained"
    with tarfile.open(TARGET / "run.tar.gz", "w:gz") as archive:
        for path in inputs:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(TARGET / "run.tar.gz") as archive:
        members = archive.getmembers()
        assert len(members) == len(inputs)
        for member in members:
            assert member.isfile()
            assert hashlib.sha256(
                archive.extractfile(member).read()
            ).hexdigest() == sha(ROOT / member.name)
    for name in (
        "plan.json",
        "result.json",
        "review-summary.json",
        "execution-summary.json",
        "validation-decision.json",
        "rollout-budget.json",
        "data-audit.json",
        "sft-token-check.json",
        "sampling-contract.json",
        "train-probe-failures.json",
        "validation-failures.json",
        "prior-evidence-verified.json",
        "unit-tests.xml",
        "outcome-contract-tests.xml",
        "runtime-versions.json",
    ):
        shutil.copyfile(ROOT / name, TARGET / name)
    (TARGET / "archive-inputs.json").write_text(
        json.dumps(
            {str(p.relative_to(ROOT)): sha(p) for p in inputs}, sort_keys=True, indent=2
        )
        + "\n"
    )
    result = read(ROOT / "result.json")
    token_check = read(ROOT / "sft-token-check.json")
    report = read(ROOT / "validation-report.json")
    lines = [
        "# River refund recovery pilot — October 20, 2026",
        "",
        "Inference-only evaluation of the retained Qwen/Qwen3.5-9B arithmetic",
        "candidate on the separate synthetic `refund-recovery-v1` protocol.",
        "This pilot performed **zero training updates** and promoted no model.",
        "",
        f"- Train-only stochastic probe: **{review['probe_passed']}/{review['probe_total']}** successful rollouts.",
        f"- Nonzero within-group reward variance: **{review['nonzero_variance_groups']}/10 groups** (four rollouts per group).",
        f"- Greedy validation: **{report['passed']}/{report['total']}**, with a **{report['violation_rate']:.1%}** policy-violation rate.",
        f"- Test attempted: **{result['test_attempted']}**; all 80 new test cases remain unattempted.",
        "",
        "## What failed",
        "",
        "All three sampled training failures began with malformed JSON. Their",
        "positive within-group variance is an output-reliability learning signal;",
        "it does not establish learning about uncertain commits or authorization.",
        "",
        "All five greedy validation failures incorrectly finished with outcome",
        "`unauthorized` after the tool confirmed an applied denial or escalation.",
        "An applied denial/escalation resolves the workflow; it does not indicate",
        "that the caller lacked authorization. The model must finish `resolved`.",
        "No duplicate resolution or unauthorized payment effect was applied.",
        "",
        "## Training data and provenance",
        "",
        "The ten fault families cover clean resolution, denied/revoked",
        "authorization, transient lookup failure, stale chargeback/refund facts,",
        "lost acknowledgments with and without commits, and unavailable/pending",
        "reconciliation. Labels and commit knowledge remain private; model",
        "messages expose only the tool's current knowledge and receipts.",
        "",
        "The frozen bundle contains **160 train, 40 validation, and 80 test cases**.",
        "Only training cases produce teacher transcripts. The reference follows",
        "public observations and each transcript is independently replayed.",
        "Canonical split/seed/count reconstruction and artifact hashes reject",
        "held-out substitution or transcript fabrication, including rehashed edits.",
        "",
        f"All **160** teachers are usable by the River SFT batch builder; maximum",
        f"sequence length was **{token_check['max_sequence_tokens']}** tokens, with no truncation.",
        "Assistant loss masks exclude backend observations. The batch builder",
        "intentionally omits trailing prompt-only terminal observations.",
        "",
        "The train probe selected one case per family before sampling, four",
        "rollouts at temperature 1. Validation used temperature 0. A native SDK",
        "transport check verifies explicit zero reaches the sampling session;",
        "provider-side sampling behavior is not independently attested.",
        "",
        "## Limits and verification",
        "",
        "One attempt, no provider retries, at most 160 trajectories and 163,840",
        "reserved output tokens, with a 15-minute worker deadline. Only 80",
        "trajectories were admitted: 40 training-probe and 40 validation cases.",
        "Validation failure stopped the run before the test-attempt seal.",
        "Actual billed cost was unavailable; the output budget is not a dollar cap.",
        "",
        f"Independent review replayed **{review['replayed_outcomes']} model outcomes** plus all",
        f"160 teachers. All **{review['prior_artifacts_unchanged']} earlier retained artifacts** matched their hashes.",
        "The prior arithmetic pilot's 308 test cases also remain unattempted.",
        "",
        "Local checks: **1,181 regression tests passed**, one skipped; two added",
        "outcome-contract checks passed; **22 native SDK checks passed** with",
        "scripted transport and provider clients forbidden. Type checking passed",
        "for **455 packaged source files**. The archive includes the full frozen",
        "runtime, controller, inputs, traces, test sources, and offline review scripts.",
        "",
        f"Archive byte verification checked **{len(inputs)} files**. Local hashes are",
        "consistency checks, not independent provider attestation.",
        "",
        "All policies and faults are fictional, in-memory fixtures. This pilot",
        "does not prove real payment persistence, production A+ quality, live",
        "optimizer recovery, or an RL learning improvement.",
        "",
        "The next training study should use train-only examples to distinguish",
        "authorization from successfully applied policy denials/escalations,",
        "measure format versus semantic errors separately, and reassess rollout",
        "reward variance before selecting an RL budget.",
        "",
    ]
    (TARGET / "README.md").write_text("\n".join(lines))
    artifacts = {p.name: sha(p) for p in sorted(TARGET.iterdir()) if p.is_file()}
    (TARGET / "artifacts.sha256.json").write_text(
        json.dumps(artifacts, sort_keys=True, indent=2) + "\n"
    )
    assert all(sha(TARGET / name) == digest for name, digest in artifacts.items())
    print(
        json.dumps(
            {
                "retained": str(TARGET.relative_to(REPO)),
                "artifacts": len(artifacts),
                "archive_files_verified": len(inputs),
            }
        )
    )


if __name__ == "__main__":
    main()
