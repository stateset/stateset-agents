"""Verify real-tokenizer assistant targets; never train on backend observations."""

import json
from pathlib import Path

from transformers import AutoTokenizer

from stateset_agents.remote.river_batches import build_sft_batch
from stateset_agents.training.sft import parse_chat_dataset

ROOT = Path(__file__).resolve().parent


def main():
    rows = parse_chat_dataset((ROOT / "data/train.jsonl").read_bytes())
    tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen3.5-9B", local_files_only=True)
    data = build_sft_batch(rows, tokenizer, max_length=4096)
    assert len(rows) == len(data) == 160
    lengths = []
    dropped_trailing_observations = 0
    for row, datum in zip(rows, data, strict=True):
        last_assistant = max(
            i for i, m in enumerate(row["messages"]) if m["role"] == "assistant"
        )
        trimmed = row["messages"][: last_assistant + 1]
        dropped_trailing_observations += len(row["messages"]) - len(trimmed)
        rendered = tokenizer.apply_chat_template(
            trimmed, tokenize=False, add_generation_prompt=False
        )
        ids = tokenizer.encode(rendered, add_special_tokens=False)
        assert len(ids) <= 4096
        assert datum["input_ids"] == ids[:-1] and datum["target_tokens"] == ids[1:]
        targets = tokenizer.decode(
            [
                token
                for token, weight in zip(
                    datum["target_tokens"], datum["weights"], strict=True
                )
                if weight
            ]
        )
        assert "resolve_refund" in targets and "finish" in targets
        assert "outcome_unknown" not in targets and "retry_safe" not in targets
        lengths.append(len(ids))
    result = {
        "rows": 160,
        "trainable_rows": len(data),
        "dropped_or_truncated_rows": 0,
        "max_sequence_tokens": max(lengths),
        "input_tokens": sum(len(d["input_ids"]) for d in data),
        "assistant_target_tokens": sum(sum(d["weights"]) for d in data),
        "max_length": 4096,
        "trailing_prompt_only_observations_omitted": dropped_trailing_observations,
        "backend_observations_masked": True,
        "provider_requests": 0,
    }
    (ROOT / "sft-token-check.json").write_text(
        json.dumps(result, sort_keys=True, indent=2) + "\n"
    )
    print(json.dumps(result))


if __name__ == "__main__":
    main()
