"""Offline independent replay and provenance review of the recovery pilot."""

import asyncio
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

import experiment as study
from stateset_agents.data.refund_recovery import audit_refund_recovery_data
from stateset_agents.evaluation.agent_runs import content_hash, validate_report
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace
from stateset_agents.remote.river_rl import atomic_json


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


async def main():
    plan = study.validate(ROOT)
    data_audit = await audit_refund_recovery_data(ROOT / "data")
    assert data_audit == read(ROOT / "data-audit.json")
    assert read(ROOT / "sft-token-check.json")["trainable_rows"] == 160
    for name, digest in read(ROOT / "historical-sources.json").items():
        assert sha(REPO / name) == digest
    train = {r["order_id"]: r for r in read(ROOT / "data/train.json")}
    by_split = {
        split: {r["order_id"]: r for r in read(ROOT / f"data/{split}.json")}
        for split in ("validation", "test")
    }
    expected_probe = [
        min(r["order_id"] for r in train.values() if r["recovery"] == family)
        for family in sorted({r["recovery"] for r in train.values()})
    ]
    assert read(ROOT / "probe-case-ids.json") == expected_probe
    probe = read(ROOT / "train-probe.json")
    assert (
        probe["split"] == "train"
        and probe["group_size"] == 4
        and probe["temperature"] == 1
    )
    assert len(probe["groups"]) == 10 and probe["training_updates"] == 0
    seen, variances, checked, families = set(), {}, 0, {}

    async def replay(row, outcome):
        trace = outcome["environment_trace"]
        result = await replay_recovery_trace(row, trace)
        for key in (
            "case_hash",
            "reward",
            "success",
            "policy_violations",
            "tool_calls",
            "backend_calls",
            "resolution_count",
            "refunded_cents",
            "duplicate_attempts",
            "reconciliations",
            "truncated",
        ):
            assert result[key] == outcome[key]
        assert result["resolution_count"] <= 1
        return result

    for group in probe["groups"]:
        assert len(group) == 4 and len({o["case_id"] for o in group}) == 1
        key = group[0]["case_id"]
        assert key in expected_probe and key not in seen
        seen.add(key)
        for outcome in group:
            await replay(train[key], outcome)
            checked += 1
        variances[key] = statistics.pvariance(o["reward"] for o in group)
        families[train[key]["recovery"]] = {
            "passed": sum(o["success"] for o in group),
            "total": 4,
            "reward_variance": variances[key],
            "policy_violating_trajectories": sum(
                o["policy_violations"] > 0 for o in group
            ),
        }
    assert set(expected_probe) == seen
    assert probe["variances"] == variances
    nonzero = sum(value > 0 for value in variances.values())
    assert probe["nonzero_variance_groups"] == nonzero
    result = read(ROOT / "result.json")
    assert result["nonzero_variance_groups"] == nonzero
    execution = read(ROOT / "execution-summary.json")
    assert execution["exit_code"] == 0 and not execution["timed_out"]
    assert execution["result"] == result and result["training_updates"] == 0
    summaries = {}
    for split in (
        ("validation", "test") if result["test_attempted"] else ("validation",)
    ):
        report = read(ROOT / f"{split}-report.json")
        assert report["environment"] == "refund-recovery-v1"
        assert (
            report["implementation"] == plan["implementation"]
            and report["settings"] == plan["settings"]
        )
        assert report["selected_checkpoint"]["path"] == plan["checkpoint"]
        summary = validate_report(report, expected_split=split)
        assert all(report[key] == value for key, value in summary.items())
        cases = by_split[split]
        assert report["case_hashes"] == {
            key: content_hash(row) for key, row in cases.items()
        }
        assert report["case_families"] == {
            key: row["recovery"] for key, row in cases.items()
        }
        for outcome in report["outcomes"]:
            await replay(cases[outcome["case_id"]], outcome)
            checked += 1
        seal = read(ROOT / f"{split}-attempt.json")
        assert seal["plan_hash"] == plan["plan_hash"]
        assert seal["case_sha256"] == plan["input_sha256"][f"data/{split}.json"]
        passed = (
            summary["passed"] == summary["total"]
            and summary["violation_rate"] == summary["truncation_rate"] == 0
        )
        assert read(ROOT / f"{split}-decision.json") == {
            "passed": passed,
            "successes": summary["passed"],
            "total": summary["total"],
        }
        summaries[split] = {
            k: summary[k]
            for k in (
                "passed",
                "total",
                "violation_rate",
                "truncation_rate",
                "generated_tokens",
                "families",
            )
        }
    assert read(ROOT / "validation-decision.json")["passed"] == result["test_attempted"]
    if not result["test_attempted"]:
        assert result["accepted"] is False
        assert not (ROOT / "test-attempt.json").exists()
    else:
        assert read(ROOT / "test-decision.json")["passed"] == result["accepted"]
    budget = read(ROOT / "rollout-budget.json")
    assert budget["fingerprint"] == plan["plan_hash"]
    assert budget["admitted_trajectories"] == checked
    assert (
        budget["reserved_generated_tokens"]
        == checked * 1024
        <= plan["limits"]["reserved_output_tokens"]
    )
    prior = {}
    target = REPO / "benchmark_results/training_contracts/20261020/river-recovery-pilot"
    for index in sorted(
        (REPO / "benchmark_results/training_contracts").rglob("artifacts.sha256.json")
    ):
        if index.parent == target:
            continue
        for name, digest in read(index).items():
            assert sha(index.parent / name) == digest
            prior[str((index.parent / name).relative_to(REPO))] = digest
    old = REPO / "outputs/river-arithmetic-pilot-20261020"
    assert len(read(old / "data/test.json")) == 308
    assert not any(
        (old / f"{arm}-test-attempt.json").exists() for arm in ("control", "arithmetic")
    )
    atomic_json(ROOT / "prior-evidence-verified.json", prior)
    reviewed = {
        "passed": True,
        "plan_hash": plan["plan_hash"],
        "replayed_outcomes": checked,
        "replayed_train_teachers": 160,
        "training_updates": 0,
        "probe_passed": sum(f["passed"] for f in families.values()),
        "probe_total": 40,
        "nonzero_variance_groups": nonzero,
        "probe_families": families,
        "evaluations": summaries,
        "test_attempted": result["test_attempted"],
        "prior_artifacts_unchanged": len(prior),
        "provider_calls_during_review": 0,
        "cost_usd": None,
        "previous_arithmetic_test_cases_unattempted": 308,
    }
    atomic_json(ROOT / "review-summary.json", reviewed)
    print(json.dumps(reviewed), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
