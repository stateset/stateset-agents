"""Offline gate and native-trainer checks with scripted provider transport."""

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


study = load("recovery_rl_study", ROOT / "experiment.py")
native = load(
    "scripted_sdk_contracts", REPO / "tests/integration/test_river_native_sdk.py"
)

from river_client import Checkpoint, Sample
from river_client.types import PolicyVersion
from river_client.rl.trajectory import Trajectory
from stateset_agents.data.refund_recovery import reference_recovery_action
from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget


class RecoveryModel(native.ScriptedModel):
    base_model = "scripted-recovery"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.policy = PolicyVersion("policy-0", "offline-lineage", 0)

    def get_policy_version(self):
        return self.policy

    def optim_step(self, **kwargs):
        assert kwargs["expected_policy_id"] == self.policy.id
        previous = self.policy
        result = super().optim_step(**kwargs)
        self.policy = PolicyVersion(
            f"policy-{self.step}", previous.lineage_id, self.step, previous.id
        )
        return SimpleNamespace(metrics=result.metrics, policy_version=self.policy)

    def save_weights(self, name, *, mode, **kwargs):
        if "expected_policy_id" in kwargs:
            assert kwargs["expected_policy_id"] == self.policy.id
        return Checkpoint(
            path=f"river://scripted-{name}",
            step=self.step,
            checkpoint_type=mode,
            policy_version=self.policy,
        )

    async def sample(self, *, model_input, seeds, max_tokens, **kwargs):
        output = []
        for chunks, seed in zip(model_input, seeds, strict=True):
            text = native.ScriptedRenderer.tokenizer.decode(
                [token for chunk in chunks for token in chunk["tokens"]]
            )
            messages = json.loads(text.rsplit("\n", 1)[-1])
            observations = []
            for message in messages:
                if message["role"] == "user" and message["content"].startswith("{"):
                    value = json.loads(message["content"])
                    if "error" not in value:
                        observations.append(value)
            action = reference_recovery_action(
                observations[-1] if observations else None
            )
            first = native.STOP not in text
            content = "{]" if self.mixed and first and seed % 2 else json.dumps(action)
            self.sampled.append((seed, first, content))
            tokens = native.ScriptedRenderer.tokenizer.encode(content + native.STOP)
            complete = len(tokens) <= max_tokens
            tokens = tokens[:max_tokens]
            output.append(
                [
                    Sample(
                        tokens=tokens,
                        text=native.ScriptedRenderer.tokenizer.decode(tokens),
                        logprobs=[-0.1] * len(tokens),
                        stop_reason="stop" if complete else "length",
                        model_step=self.step,
                        token_data_is_exact=self.exact,
                        policy_version=self.policy,
                    )
                ]
            )
        return output


class NativeStudy(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        for name in ("grpc.secure_channel", "grpc.insecure_channel"):
            guard = patch(name, side_effect=AssertionError("No RPCs allowed"))
            guard.start()
            self.addCleanup(guard.stop)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        runtime = self.root / "runtime"
        runtime.mkdir()
        previous = REPO / "outputs/river-recovery-warmup-20261020"
        (runtime / "diagnostics.py").write_bytes(
            (previous / "runtime/diagnostics.py").read_bytes()
        )
        source = study.read(previous / "training/train.json")
        selected = {
            row["case_id"] for row in study.read(previous / "probe-selection.json")
        }
        self.cases = [row for row in source if row["order_id"] in selected]
        (self.root / "train.json").write_text(json.dumps(self.cases))
        self.plan = {
            "plan_hash": "offline-contract",
            "parent_checkpoint": "river://scripted-parent",
            "settings": {
                "max_turns": 6,
                "max_generated_tokens": 1024,
                "max_context_tokens": 8192,
                "max_turn_tokens": 256,
            },
        }
        self.budget = RolloutAdmissionBudget(
            self.root / "budget.json",
            limit=76 * 1024,
            trajectory_tokens=1024,
            fingerprint="offline",
            create=True,
        )

    async def run_train(self, model):
        return await study.train(
            self.root, self.plan, model, native.ScriptedRenderer(), self.budget
        )

    async def test_real_trainer_updates_once_and_batch_reconstructs_from_exact_spans(
        self,
    ):
        model = RecoveryModel(mixed=True)
        checkpoint = await self.run_train(model)
        batch = study.read(self.root / "batch-evidence.json")
        self.assertIsNotNone(
            checkpoint,
            {
                "samples": model.sampled[:12],
                "rewards": [o["reward"] for o in batch["outcomes"][:12]],
                "variance_groups": batch["nonzero_variance_groups"],
            },
        )
        self.assertEqual(checkpoint.step, 1)
        self.assertEqual(model.optimizer_calls, 1)
        self.assertEqual(self.budget.snapshot()["admitted_trajectories"], 76)
        self.assertGreater(batch["nonzero_variance_groups"], 0)
        self.assertEqual(
            batch["datums_hash"],
            study.content_hash(study.read(self.root / "batch-datums.json")),
        )
        self.assertEqual(len(batch["outcomes"]), 76)
        trajectories = [
            Trajectory.from_state_dict(state) for state in batch["trajectory_states"]
        ]
        by_id = {row["order_id"]: row for row in self.cases}
        data, metrics, variances = study.exact_batch(trajectories, by_id, groups=19)
        self.assertEqual(data, study.read(self.root / "batch-datums.json"))
        self.assertEqual(metrics, batch["batch_metrics"])
        self.assertEqual(variances, batch["variances"])
        actual = [datum for call in model.backward_batches for datum in call]
        self.assertEqual(actual, data)
        trajectories[0].truncated = "max_turns"
        with self.assertRaises(AssertionError):
            study.exact_batch(trajectories, by_id, groups=19)

    async def test_zero_variance_consumes_batch_without_optimizer_or_candidate(self):
        model = RecoveryModel()
        checkpoint = await self.run_train(model)
        self.assertIsNone(checkpoint)
        self.assertEqual(model.optimizer_calls, 0)
        self.assertFalse((self.root / "rl-checkpoint.json").exists())
        self.assertEqual(
            study.read(self.root / "training-activity.json")[
                "acknowledged_optimizer_updates"
            ],
            0,
        )
        self.assertEqual(self.budget.snapshot()["admitted_trajectories"], 76)

    async def test_inexact_samples_fail_before_optimizer(self):
        model = RecoveryModel(mixed=True, exact=False)
        with self.assertRaises(ValueError):
            await self.run_train(model)
        self.assertEqual(model.optimizer_calls, 0)
        self.assertFalse((self.root / "batch-datums.json").exists())

    async def test_truncation_rejected_before_any_backward_or_optimizer(self):
        self.plan["settings"]["max_turns"] = 1
        model = RecoveryModel(mixed=True)
        with self.assertRaises(AssertionError):
            await self.run_train(model)
        self.assertEqual(model.backward_batches, [])
        self.assertEqual(model.optimizer_calls, 0)

    async def test_missing_committed_policy_stops_before_sampling(self):
        model = RecoveryModel(mixed=True)
        model.policy = None
        with self.assertRaises(AssertionError):
            await self.run_train(model)
        self.assertEqual(self.budget.snapshot()["admitted_trajectories"], 0)
        self.assertEqual(model.optimizer_calls, 0)


class Gates(unittest.TestCase):
    def setUp(self):
        self.cases = [
            {"order_id": "A", "recovery": "clean"},
            {"order_id": "B", "recovery": "lost_ack_applied"},
        ]
        self.categories = (
            "format",
            "tool_contract",
            "completion_outcome",
            "unsafe_retry",
            "reconciliation",
            "premature_finish",
        )

    def report(
        self, arm, failures=(), category="format", stage="stochastic-validation"
    ):
        size = 1 if stage == "greedy-validation" else 4
        groups, diagnostics = [], []
        for row in self.cases:
            group, ds = [], []
            for i in range(size):
                failed = (row["order_id"], i) in failures
                group.append(
                    {
                        "case_id": row["order_id"],
                        "case_hash": "hash",
                        "success": not failed,
                        "reward": -1.0 if failed else 1.0,
                        "policy_violations": int(failed),
                        "truncated": None,
                        "tool_calls": 2,
                        "generated_tokens": 12,
                        "elapsed_seconds": 1.0,
                    }
                )
                ds.append(
                    {
                        "case_id": row["order_id"],
                        "error_counts": {
                            k: int(failed and k == category) for k in self.categories
                        },
                    }
                )
            groups.append(group)
            diagnostics.append(ds)
        return {
            "stage": stage,
            "group_size": size,
            "groups": groups,
            "diagnostics": diagnostics,
            "summary": study.summarize(groups, self.cases, diagnostics),
        }

    def test_stochastic_validation_can_pass_a_safe_tie(self):
        reports = {arm: self.report(arm) for arm in study.ARMS}
        result = study.gate(reports, self.cases, stage="stochastic-validation")
        self.assertTrue(result["passed"])
        self.assertFalse(result["strict_formatting_and_success_improvement"])

    def test_test_tie_is_rejected(self):
        reports = {arm: self.report(arm, stage="test") for arm in study.ARMS}
        self.assertFalse(study.gate(reports, self.cases, stage="test")["passed"])

    def test_test_requires_fewer_format_errors_and_more_successes(self):
        reports = {
            "parent": self.report("parent", failures=(("A", 0),), stage="test"),
            "rl": self.report("rl", stage="test"),
        }
        self.assertTrue(study.gate(reports, self.cases, stage="test")["passed"])

    def test_family_regression_blocks_aggregate_gain(self):
        reports = {
            "parent": self.report("parent", failures=(("A", 0), ("A", 1))),
            "rl": self.report("rl", failures=(("B", 0),)),
        }
        self.assertFalse(
            study.gate(reports, self.cases, stage="stochastic-validation")["passed"]
        )

    def test_semantic_error_blocks_even_overall_gain(self):
        reports = {
            "parent": self.report("parent", failures=(("A", 0), ("A", 1))),
            "rl": self.report(
                "rl", failures=(("A", 0),), category="completion_outcome"
            ),
        }
        self.assertFalse(
            study.gate(reports, self.cases, stage="stochastic-validation")["passed"]
        )

    def test_greedy_validation_requires_perfect_safety(self):
        reports = {
            arm: self.report(arm, failures=(("A", 0),), stage="greedy-validation")
            for arm in study.ARMS
        }
        self.assertFalse(
            study.gate(reports, self.cases, stage="greedy-validation")["passed"]
        )

    def test_duplicate_case_coverage_rejected(self):
        reports = {arm: self.report(arm) for arm in study.ARMS}
        reports["rl"]["groups"][1] = copy.deepcopy(reports["rl"]["groups"][0])
        with self.assertRaises(AssertionError):
            study.gate(reports, self.cases, stage="stochastic-validation")

    def test_tampered_summary_rejected(self):
        reports = {arm: self.report(arm) for arm in study.ARMS}
        reports["rl"]["summary"]["passed"] -= 1
        with self.assertRaises(AssertionError):
            study.gate(reports, self.cases, stage="stochastic-validation")


class StageSeals(unittest.IsolatedAsyncioTestCase):
    async def test_both_arms_sealed_before_sampling_and_failure_keeps_test_unattempted(
        self,
    ):
        gates = Gates()
        gates.setUp()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "greedy-validation.json").write_text(json.dumps(gates.cases))
            plan = {
                "plan_hash": "offline",
                "input_sha256": {"greedy-validation.json": "hash"},
            }
            checkpoints = {
                arm: Checkpoint(
                    path="river://scripted-" + arm, step=1, checkpoint_type="inference"
                )
                for arm in study.ARMS
            }
            sampled = []

            def seal(target, name, value):
                with (target / name).open("x") as stream:
                    json.dump(value, stream)

            async def evaluate(*args):
                arm, stage = args[-2:]
                self.assertTrue(
                    all(
                        (root / f"{key}-{stage}-attempt.json").exists()
                        for key in study.ARMS
                    )
                )
                sampled.append((arm, stage))
                return gates.report(arm, failures=(("A", 0),), stage=stage)

            with (
                patch.object(study, "seal", seal),
                patch.object(study, "evaluate_arm", evaluate),
            ):
                result = await study.evaluate(root, plan, None, None, checkpoints, None)
                self.assertFalse(result["test_attempted"])
                self.assertFalse(result["accepted"])
                self.assertEqual(len(sampled), 2)
                self.assertFalse(any(root.glob("*test-attempt.json")))
                with self.assertRaises(FileExistsError):
                    await study.evaluate(root, plan, None, None, checkpoints, None)
                self.assertEqual(len(sampled), 2)


if __name__ == "__main__":
    unittest.main()
