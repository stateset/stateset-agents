"""Retain the single reviewed RL attempt without modifying earlier evidence."""

import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
TARGET = REPO / "benchmark_results/training_contracts/20261020/river-recovery-rl-pilot"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    review = read(ROOT / "review-summary.json")
    assert review["passed"] and read(ROOT / "execution-summary.json")["exit_code"] == 0
    inputs = [
        p
        for p in sorted(ROOT.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    ]
    secret = re.compile(rb"rv_[A-Za-z0-9_-]{32,}")
    assert not any(secret.search(p.read_bytes()) for p in inputs)
    TARGET.mkdir(parents=True, exist_ok=False)
    with tarfile.open(TARGET / "run.tar.gz", "w:gz") as archive:
        for path in inputs:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(TARGET / "run.tar.gz") as archive:
        assert len(archive.getmembers()) == len(inputs)
        for member in archive.getmembers():
            assert member.isfile() and hashlib.sha256(
                archive.extractfile(member).read()
            ).hexdigest() == sha(ROOT / member.name)
    for name in (
        "plan.json",
        "result.json",
        "review-summary.json",
        "execution-summary.json",
        "training-activity.json",
        "training-steps.json",
        "initial-model.json",
        "final-model.json",
        "rl-checkpoint.json",
        "greedy-validation-decision.json",
        "stochastic-validation-decision.json",
        "test-decision.json",
        "test-receipt.json",
        "runtime-versions.json",
        "server-capabilities.json",
        "rollout-budget.json",
        "prior-evidence-verified.json",
    ):
        if (ROOT / name).exists():
            shutil.copyfile(ROOT / name, TARGET / name)
    shutil.copyfile(
        ROOT / "parent/river_checkpoint.json", TARGET / "parent-checkpoint.json"
    )
    (TARGET / "archive-inputs.json").write_text(
        json.dumps(
            {str(p.relative_to(ROOT)): sha(p) for p in inputs}, indent=2, sort_keys=True
        )
        + "\n"
    )
    lines = [
        "# River recovery RL formatting pilot — October 20, 2026",
        "",
        "One fixed native CISPO batch from the [accepted recovery SFT checkpoint](../river-recovery-warmup/README.md).",
        f"Acknowledged RL optimizer updates: **{review['rl_updates']}**. New SFT updates: **0**.",
        f"Declared pilot acceptance: **{review['accepted']}**. Test attempted: **{review['test_attempted']}**.",
        "No automatic production promotion occurred.",
        "",
        "| Stage | SFT parent | RL | Parent format-error rollouts | RL format-error rollouts |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for stage in ("greedy-validation", "stochastic-validation", "test"):
        if f"parent-{stage}" not in review["evaluations"]:
            continue
        parent, candidate = (
            review["evaluations"][f"{arm}-{stage}"] for arm in ("parent", "rl")
        )
        lines.append(
            f"| {stage} | {parent['passed']}/{parent['total']} | {candidate['passed']}/{candidate['total']} | {parent['diagnostic_cases']['format']} | {candidate['diagnostic_cases']['format']} |"
        )
    lines.extend(
        [
            "",
            "| Paired stage | Cases with more RL successes | Cases with fewer RL successes | Cases tied |",
            "| --- | ---: | ---: | ---: |",
        ]
    )
    for stage, counts in review["paired_case_counts"].items():
        lines.append(
            f"| {stage} | {counts['cases_improved']} | {counts['cases_regressed']} | {counts['cases_tied']} |"
        )
    lines.extend(
        [
            "",
            "Four stochastic rollouts share a case. Counts are descriptive and must",
            "not be treated as independent case, merchant, or training-seed replications.",
            "A pilot pass alone cannot establish repeatable learning improvement.",
            "",
            "## Native training evidence",
            "",
            f"The fresh on-policy batch passed **{review['training_passed']}/76 rollouts**,",
            f"with nonzero within-group reward variance in **{review['nonzero_variance_groups']}/19 groups**.",
            "Training case selection was carried forward unchanged from the SFT plan:",
            "first training case per family and public terminal receipt type, four",
            "samples per case at temperature 1, top-p 1, top-k -1, and seed 2026109601.",
            "Earlier sampled traces were not replayed into training.",
            "",
            "The native trainer uses group-centered advantages without standardization,",
            "token normalization, CISPO eps_max 6, Adam learning rate 1e-5, LoRA rank 16,",
            "one logical batch, and zero policy staleness. Starting weights came from",
            "the accepted recovery SFT checkpoint with a fresh optimizer. This does",
            "not establish optimizer continuity from SFT.",
            "",
            "Every training outcome was exactly replayed before forward/backward.",
            "Any training truncation, missing committed policy identity, invalid native",
            "token/logprob data, or mixed policy rejects the batch. A zero-variance batch",
            "consumes the attempt without an update or replacement. Generated token IDs",
            "and sampled logprobs remain in the native trajectory states; assistant text",
            "is used for tool execution and reward inspection, never retokenized as",
            "replacement training actions.",
            "",
            f"Independent token alignment and group advantages reconstructed **{review['exact_native_datums_independently_reconstructed']} logical datums**",
            "without calling River's batch builder. Their full bytes matched the",
            "persisted datums and native reconstruction. The optimizer acknowledgement",
            "and subsequent server read bind the child policy to the initial committed",
            "policy. These are client-retained protocol receipts, not weight-byte or",
            "independent provider attestation.",
            "",
            f"Provider-reported gradient norm: `{review['provider_reported_grad_norm']}`;",
            f"provider-reported loss: `{review['provider_reported_loss']}`. These are",
            "training diagnostics, not held-out quality evidence.",
            "",
            "Training error counts: `"
            + json.dumps(review["training_diagnostic_cases"], sort_keys=True)
            + "`.",
            "",
            "## Frozen evaluation and gates",
            "",
            "The final checkpoint is fixed after one batch. There is no validation- or",
            "test-based checkpoint selection. Fresh cases exclude every historical",
            "training, prepared, and evaluated case ID and order fact fingerprint.",
            "Both arms share prompts, tools, seed, six model turns, 1,024 generated",
            "tokens, 256 tokens per turn, and an 8,192-token context limit.",
            "Report stage-level temperature/group_size fields override the shared",
            "base settings block: greedy uses temperature 0 and one rollout; stochastic",
            "uses temperature 1 and four rollouts. The review summary records the",
            "effective settings explicitly; frozen sampler construction enforces them.",
            "",
            "First, the candidate must pass 80/80 paired greedy validation cases",
            "without violations or truncation. Next, 20 validation cases receive four",
            "stochastic rollouts per arm. No overall, family, or diagnostic-category",
            "regression, semantic error, or truncation is allowed. A validation tie",
            "is permitted. Only then may the 40-case, four-rollout stochastic test",
            "be sealed. Test additionally requires strictly more successful rollouts",
            "and fewer formatting-error rollouts than parent. Both arms are sealed",
            "before sampling each stage; uncertain or failed attempts are not retried.",
            "",
            "| Stage / semantic category | Parent affected rollouts | RL affected rollouts |",
            "| --- | ---: | ---: |",
        ]
    )
    for stage, decision in review["decisions"].items():
        for category in (
            "completion_outcome",
            "tool_contract",
            "unsafe_retry",
            "reconciliation",
            "premature_finish",
        ):
            errors = decision["diagnostic_cases"]
            lines.append(
                f"| {stage} / {category} | {errors['parent'][category]} | {errors['rl'][category]} |"
            )
    lines.extend(
        [
            "",
            "## Audit and limits",
            "",
            f"Independent review replayed **{review['replayed_outcomes']} outcomes** and regenerated",
            "all fresh cases. It checked training source bytes, exact native spans,",
            "group advantages, masks, logical datums, committed policy progression,",
            "attempt seals, error classifications, family cells, and final gates.",
            f"All **{review['prior_artifacts_unchanged']} prior retained artifacts** matched their hashes.",
            "The earlier recovery pilot's 80 and arithmetic pilot's 308 blocked test",
            "cases remain unattempted. Completed SFT evaluation cases were also excluded.",
            "",
            "Prelaunch verification: **14 offline tests passed**, including the real",
            "River engine/trainer with scripted transport, one acknowledged optimizer",
            "step, exact submitted-batch reconstruction, zero-update behavior, rejection",
            "of inexact samples/truncations/missing policy support, and test sealing.",
            "All provider RPCs were blocked during those tests. The packaged 455-source",
            "implementation is unchanged from the preceding validated recovery study.",
            "",
            "Bounds: one RL optimizer update, at most 716 trajectories, 733,184 reserved",
            "output tokens, no transport retries, one attempt per stage, and 25 minutes",
            "of worker time. Provider billed cost was unavailable. Token reservations",
            "are not a dollar cap. Optimizer acknowledgement alone does not establish",
            "nonzero gradients or a useful learned policy.",
            "",
            f"Archive byte verification checked **{len(inputs)} files**. The archive contains",
            "frozen package/runner sources, exact inputs, native states/datums, committed",
            "policy receipts, checkpoint pointers, traces, review scripts, and the",
            "tested SDK source snapshots. Local hashes establish consistency only.",
            "",
            "This remains a single-parent synthetic pilot. It does not certify A+",
            "production quality, independent merchant generalization, real payment",
            "recovery, durable idempotency, or repeatable RL improvement.",
            "",
        ]
    )
    (TARGET / "README.md").write_text("\n".join(lines))
    artifacts = {p.name: sha(p) for p in sorted(TARGET.iterdir()) if p.is_file()}
    (TARGET / "artifacts.sha256.json").write_text(
        json.dumps(artifacts, indent=2, sort_keys=True) + "\n"
    )
    assert all(sha(TARGET / name) == digest for name, digest in artifacts.items())
    print(
        json.dumps(
            {
                "retained": str(TARGET.relative_to(REPO)),
                "artifacts": len(artifacts),
                "archive_files_verified": len(inputs),
            }
        )
    )


if __name__ == "__main__":
    main()
