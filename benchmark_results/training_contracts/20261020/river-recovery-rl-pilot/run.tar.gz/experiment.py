"""One native recovery RL update with fresh paired safety/formatting checks."""

import argparse
import asyncio
from collections import Counter
from contextlib import closing
from dataclasses import asdict
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import statistics

from stateset_agents.core.environments.refund_policy_environment import (
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import refund_recovery_cases
from stateset_agents.evaluation.agent_runs import content_hash, summarize_outcomes
from stateset_agents.evaluation.implementation import package_implementation
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace
from stateset_agents.remote.river_environment import (
    trajectory_case_identity,
    trajectory_truncation,
)
from stateset_agents.remote.river_refund_recovery import (
    river_refund_recovery_factory,
    trajectory_recovery_trace,
)
from stateset_agents.remote.river_rl import atomic_json, exclusive_run
from stateset_agents.remote.rollout_budget import RolloutAdmissionBudget
from stateset_agents.training.river_progress import validate_training_metrics
from stateset_agents.utils.async_calls import closing_async_generator, run_sync_owned

MODEL = "Qwen/Qwen3.5-9B"
SEED = 2026109601
ARMS = ("parent", "rl")
CATEGORIES = (
    "format",
    "tool_contract",
    "completion_outcome",
    "unsafe_retry",
    "reconciliation",
    "premature_finish",
)
STAGES = (
    ("greedy-validation", 80, 1),
    ("stochastic-validation", 20, 4),
    ("test", 40, 4),
)
FIELDS = (
    "case_hash",
    "reward",
    "success",
    "policy_violations",
    "tool_calls",
    "backend_calls",
    "resolution_count",
    "refunded_cents",
    "duplicate_attempts",
    "reconciliations",
    "truncated",
)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def support(root, name):
    spec = importlib.util.spec_from_file_location(
        "recovery_rl_" + name, root / "runtime" / (name + ".py")
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def seal(root, name, value):
    support(root, "controller").seal(root / name, value)


async def prepare(root, repo):
    assert not (root / "plan.json").exists()
    previous = repo / "outputs/river-recovery-warmup-20261020"
    assert read(previous / "review-summary.json")["accepted"]
    # Verify every retained receipt before using its accepted checkpoint.
    retained = (
        repo / "benchmark_results/training_contracts/20261020/river-recovery-warmup"
    )
    assert all(
        sha(retained / name) == digest
        for name, digest in read(retained / "artifacts.sha256.json").items()
    )
    root.mkdir(exist_ok=True)
    shutil.copytree(previous / "warmup", root / "parent")
    assert sha(root / "parent/river_checkpoint.json") == sha(
        retained / "warmup-checkpoint.json"
    )
    shutil.copyfile(previous / "training/train.json", root / "train-source.json")
    shutil.copyfile(previous / "probe-selection.json", root / "train-selection.json")
    selection = read(root / "train-selection.json")
    train = {row["order_id"]: row for row in read(root / "train-source.json")}
    assert len(selection) == 19 and len(train) == 160
    atomic_json(root / "train.json", [train[row["case_id"]] for row in selection])
    history = read(previous / "historical-sources.json")
    for name in ("training/train.json", "validation.json", "test.json"):
        path = previous / name
        history[str(path.relative_to(repo))] = sha(path)
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in history.items():
        assert sha(repo / name) == digest
        rows = read(repo / name)
        if isinstance(rows, list):
            excluded.extend(
                row
                for row in rows
                if isinstance(row, dict) and "return_window_days" in row
            )
    rejected = []
    for attempt in range(100):
        seed = 2026109501 + attempt * 100
        working, proposed = list(excluded), {}
        try:
            for index, (stage, count, _) in enumerate(STAGES):
                rows = refund_recovery_cases(
                    "test" if stage == "test" else "validation",
                    count=count,
                    seed=seed + index,
                    excluded=working,
                )
                working.extend(rows)
                proposed[stage] = rows
        except ValueError as exc:
            if "overlap" not in str(exc).lower():
                raise
            rejected.append({"seed": seed, "reason": str(exc)})
            continue
        break
    else:
        raise ValueError("No disjoint prospective input seed among 100 candidates")
    for stage, rows in proposed.items():
        atomic_json(root / f"{stage}.json", rows)
    atomic_json(root / "historical-sources.json", history)
    implementation = package_implementation()
    runtime = root / "runtime"
    for name, digest in implementation["files"].items():
        source = repo / "stateset_agents" / name
        assert sha(source) == digest
        target = runtime / "stateset_agents" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    shutil.copyfile(__file__, runtime / "experiment.py")
    for name in ("controller", "recovery", "diagnostics"):
        shutil.copyfile(previous / "runtime" / (name + ".py"), runtime / (name + ".py"))
    input_files = [
        "parent/river_checkpoint.json",
        "parent/stateset_manifest.json",
        "train-source.json",
        "train-selection.json",
        "train.json",
        "historical-sources.json",
    ]
    input_files.extend(f"{stage}.json" for stage, _, _ in STAGES)
    plan = {
        "schema_version": 1,
        "kind": "exploratory-one-update-recovery-native-rl",
        "base_model": MODEL,
        "seed": SEED,
        "case_seed": seed,
        "implementation": implementation,
        "parent_checkpoint": read(root / "parent/river_checkpoint.json")["checkpoint"],
        "training": {
            "batches": 1,
            "max_optimizer_updates": 1,
            "groups_per_batch": 19,
            "group_size": 4,
            "temperature": 1.0,
            "top_p": 1.0,
            "top_k": -1,
            "learning_rate": 1e-5,
            "lora_rank": 16,
            "loss": "cispo",
            "eps_max": 6.0,
            "normalization": "token",
            "advantage": "group centered, no standardization",
            "max_staleness": 0,
            "selection": "Unchanged first train case per family/public receipt from the SFT protocol; fresh samples, no prior probe replay",
            "optimizer": "fresh optimizer initialized with accepted SFT weights only",
            "truncation": "Reject any truncated training trajectory before forward/backward",
            "zero_update": "Stop before evaluation if the one batch contains no usable datums; no replacement batch",
        },
        "settings": support(root, "recovery").SETTINGS,
        "stages": [
            {
                "name": stage,
                "cases_per_arm": count,
                "group_size": size,
                "temperature": 0 if size == 1 else 1.0,
            }
            for stage, count, size in STAGES
        ],
        "acceptance": {
            "greedy_validation": "RL must pass all 80 cases without violations/truncations; parent cannot change training/checkpoint choice",
            "stochastic_validation": "No overall, family, or diagnostic-category regression; no new semantic error or truncation. Strict formatting/success improvement is required only on test",
            "test": "Strictly more successful rollouts and fewer formatting-error rollouts; no family or error-category regression, semantic errors, or truncations",
            "checkpoint": "Fixed final one-update weights; no validation or test checkpoint selection",
        },
        "limits": {
            "wall_seconds": 1500,
            "request_timeout_seconds": 180,
            "reserved_output_tokens": 716 * 1024,
            "max_trajectories": 716,
            "provider_retries": False,
            "attempts_per_stage": 1,
            "concurrency_per_arm": 6,
        },
        "error_categories": list(support(root, "diagnostics").CATEGORIES),
        "required_server_features": [
            "sampling_batch_v1",
            "sampling_policy_pinning_v1",
            "policy_versions_v1",
        ],
        "input_sha256": {name: sha(root / name) for name in input_files},
        "runner_sha256": {
            name: sha(runtime / (name + ".py"))
            for name in ("experiment", "controller", "recovery", "diagnostics")
        },
        "rejected_input_seeds": rejected,
        "quality_certification": False,
        "dollar_cap_enforced": False,
        "cost_usd": None,
        "scope": "Single fixed SFT parent, one native RL batch, synthetic fault simulation. Passing this pilot cannot establish production quality or repeatable RL gains.",
    }
    plan["plan_hash"] = content_hash(plan)
    atomic_json(root / "plan.json", plan)
    return {
        "prepared": True,
        "plan_hash": plan["plan_hash"],
        "limits": plan["limits"],
        "stages": plan["stages"],
    }


def validate(root):
    plan = read(root / "plan.json")
    assert (
        content_hash({k: v for k, v in plan.items() if k != "plan_hash"})
        == plan["plan_hash"]
    )
    assert package_implementation() == plan["implementation"]
    assert sha(__file__) == plan["runner_sha256"]["experiment"]
    for name, digest in plan["input_sha256"].items():
        assert sha(root / name) == digest
    for name, digest in plan["runner_sha256"].items():
        assert sha(root / "runtime" / (name + ".py")) == digest
    for name, digest in plan["implementation"]["files"].items():
        assert sha(root / "runtime/stateset_agents" / name) == digest
    return plan


def outcome(trajectory, cases):
    return {
        **trajectory_case_identity(trajectory, cases=cases),
        "environment_trace": trajectory_recovery_trace(trajectory),
        "reward": trajectory.reward,
        "success": trajectory.metrics.get("task_success", 0) == 1,
        **{
            key: trajectory.metrics.get(key, 0)
            for key in FIELDS
            if key not in {"case_hash", "reward", "success", "truncated"}
        },
        "generated_tokens": trajectory.generated_tokens,
        "elapsed_seconds": trajectory.elapsed,
        "truncated": trajectory_truncation(trajectory),
    }


async def checked_outcome(trajectory, cases, diagnostic):
    value = outcome(trajectory, cases)
    row = cases[value["case_id"]]
    replay = await replay_recovery_trace(row, value["environment_trace"])
    assert all(replay[key] == value[key] for key in FIELDS)
    return value, await diagnostic.diagnose(row, value["environment_trace"])


def exact_batch(trajectories, cases, *, groups, policy_id=None):
    """Validate exact native state and reconstruct the one logical SDK batch."""
    from river_client import rl
    from river_client.rl.advantages import build_batch

    assert len(trajectories) == groups * 4
    grouped, ids = [], []
    for offset in range(0, len(trajectories), 4):
        group = trajectories[offset : offset + 4]
        keys = [trajectory_case_identity(t, cases=cases)["case_id"] for t in group]
        assert len(set(keys)) == 1
        ids.append(keys[0])
        grouped.append(group)
    assert Counter(ids) == dict.fromkeys(cases, 1)
    trajectory_ids, policies = set(), set()
    for trajectory in trajectories:
        assert trajectory.id not in trajectory_ids
        trajectory_ids.add(trajectory.id)
        assert trajectory.done and trajectory.truncated is None
        assert math.isfinite(trajectory.reward)
        generated = [span for span in trajectory.spans if span.kind == "generated"]
        assert generated and trajectory.generated_tokens > 0
        for span in generated:
            assert span.policy_step == 0
            assert len(span.logprobs) == len(span)
            assert all(math.isfinite(float(v)) and v <= 1e-6 for v in span.logprobs)
            if span.policy_version is not None:
                policies.add(span.policy_version.id)
                if policy_id is not None:
                    assert span.policy_version.id == policy_id
            elif policy_id is not None:
                raise ValueError("Sampler omitted an advertised policy identity")
    assert len(policies) <= 1
    data, metrics = build_batch(
        grouped,
        estimator=rl.GroupCentered(),
        normalize="token",
        truncation=rl.Truncation(train="reward"),
        min_members=4,
        current_step=0,
        max_staleness=0,
    )
    assert metrics["staleness/frac_masked"] == 0
    assert metrics["train/generated_tokens"] == sum(
        t.generated_tokens for t in trajectories
    )
    return (
        data,
        metrics,
        {g[0].id: statistics.pvariance(t.reward for t in g) for g in grouped},
    )


async def train(root, plan, model, renderer, budget):
    from river_client import rl

    cases = {row["order_id"]: row for row in read(root / "train.json")}
    diagnostic = support(root, "diagnostics")
    initial_policy = await run_sync_owned(model.get_policy_version)
    assert (
        initial_policy is not None
    ), "Native RL requires committed policy-version support"
    atomic_json(
        root / "initial-model.json",
        {
            "step": model.step,
            "parent_checkpoint": plan["parent_checkpoint"],
            "policy_version": asdict(initial_policy) if initial_policy else None,
        },
    )
    assert model.step == 0

    async def reserve():
        await asyncio.to_thread(budget.reserve)

    async def capture(trajectories, metrics):
        assert not (root / "batch-evidence.json").exists()
        data, reconstructed, variances = exact_batch(
            trajectories,
            cases,
            groups=19,
            policy_id=initial_policy.id if initial_policy else None,
        )
        assert all(metrics[key] == value for key, value in reconstructed.items())
        checked = [await checked_outcome(t, cases, diagnostic) for t in trajectories]
        evidence = {
            "plan_hash": plan["plan_hash"],
            "current_step": model.step,
            "trajectory_states": [t.state_dict() for t in trajectories],
            "outcomes": [item[0] for item in checked],
            "diagnostics": [item[1] for item in checked],
            "batch_metrics": reconstructed,
            "variances": variances,
            "nonzero_variance_groups": sum(value > 0 for value in variances.values()),
            "datums_hash": content_hash(data),
            "datums": len(data),
            "native_token_contract": "Real RolloutEngine rejects samples without token_data_is_exact; generated tokens/logprobs are retained unchanged in trajectory_states",
        }
        await run_sync_owned(atomic_json, root / "batch-datums.json", data)
        await run_sync_owned(atomic_json, root / "batch-evidence.json", evidence)

    engine = rl.RolloutEngine(
        model,
        env=river_refund_recovery_factory(before_reset=reserve),
        renderer=renderer,
        budget=rl.Budget(
            **{k: v for k, v in plan["settings"].items() if k.startswith("max_")}
        ),
        schedule=rl.Schedule(concurrency=6),
        temperature=1.0,
        top_p=1.0,
        top_k=-1,
        seed=SEED,
    )
    trainer = rl.AsyncTrainer(
        engine=engine,
        optimizer=rl.Adam(lr=1e-5),
        advantage=rl.GroupCentered(),
        truncation=rl.Truncation(train="reward"),
        completion=rl.GroupCompletion(mode="wait", min_members=4),
        normalize="token",
        loss="cispo",
        eps_max=6.0,
        groups_per_step=19,
        group_size=4,
        max_staleness=0,
        repeat_dataset=False,
        batch_order="admission",
        validate_batch=capture,
        forward_backward_batch=None,
        checkpoint=rl.Checkpointing(root / "training", weights_every=1, on_signal=()),
        run_config={
            "plan_hash": plan["plan_hash"],
            "environment": "refund-recovery-v1",
        },
    )
    observed = []
    async with closing_async_generator(
        trainer.run(list(cases.values()), steps=1)
    ) as stream:
        async for step in stream:
            validate_training_metrics(step.metrics)
            observed.append(
                {
                    "batch": step.n,
                    "model_step": step.model_step,
                    "metrics": dict(step.metrics),
                }
            )
            await run_sync_owned(atomic_json, root / "training-steps.json", observed)
    assert len(observed) == 1 and observed[0]["batch"] == 1
    updates = int(observed[0]["metrics"]["train/updated"])
    assert updates in (0, 1) and model.step == updates
    atomic_json(
        root / "training-activity.json",
        {
            "consumed_batches": 1,
            "acknowledged_optimizer_updates": updates,
            "sft_updates": 0,
        },
    )
    if not updates:
        return None
    final_policy = await run_sync_owned(model.get_policy_version)
    assert final_policy is not None and final_policy.parent_id == initial_policy.id
    assert final_policy.step == initial_policy.step + 1
    checkpoint = await run_sync_owned(
        model.save_weights,
        "recovery-rl-one-update",
        mode="inference",
        immutable=True,
        expected_policy_id=final_policy.id,
    )
    assert checkpoint.step == 1
    assert checkpoint.policy_version == final_policy
    atomic_json(
        root / "final-model.json",
        {"step": model.step, "policy_version": asdict(final_policy)},
    )
    atomic_json(root / "rl-checkpoint.json", asdict(checkpoint))
    return checkpoint


def summarize(groups, cases, diagnostics):
    assert len(groups) == len(cases)
    ids = [group[0]["case_id"] for group in groups]
    assert len(set(ids)) == len(ids) and set(ids) == {r["order_id"] for r in cases}
    assert all(
        len(g) == len(ds) and len({o["case_id"] for o in g}) == 1
        for g, ds in zip(groups, diagnostics, strict=True)
    )
    flat = [o for group in groups for o in group]
    for group, diagnosed in zip(groups, diagnostics, strict=True):
        for value, item in zip(group, diagnosed, strict=True):
            assert value["case_id"] == item["case_id"]
            assert set(item["error_counts"]) == set(CATEGORIES)
            assert all(
                type(count) is int and count >= 0
                for count in item["error_counts"].values()
            )
            assert sum(item["error_counts"].values()) == value["policy_violations"]
    summary = summarize_outcomes(
        [{**o, "case_id": f"{o['case_id']}:{index}"} for index, o in enumerate(flat)]
    )
    errors = {
        category: sum(d["error_counts"][category] > 0 for ds in diagnostics for d in ds)
        for category in CATEGORIES
    }
    return {**summary, "diagnostic_cases": errors}


def gate(reports, cases, *, stage):
    """Require paired coverage and safety; test must improve formatting and success."""
    size = 1 if stage == "greedy-validation" else 4
    by_id = {row["order_id"]: row for row in cases}
    for arm in ARMS:
        report = reports[arm]
        assert report["stage"] == stage and report["group_size"] == size
        assert all(len(g) == size for g in report["groups"])
        assert report["summary"] == summarize(
            report["groups"], cases, report["diagnostics"]
        )
    indexed = {
        arm: {g[0]["case_id"]: g for g in reports[arm]["groups"]} for arm in ARMS
    }
    cells = {"overall": list(by_id)}
    for key, row in by_id.items():
        cells.setdefault("family:" + row["recovery"], []).append(key)
    measured = {}
    for name, keys in cells.items():
        parent_passed = sum(
            o["success"] for key in keys for o in indexed["parent"][key]
        )
        rl_values = [o for key in keys for o in indexed["rl"][key]]
        rl_passed = sum(o["success"] for o in rl_values)
        truncated = sum(o["truncated"] is not None for o in rl_values)
        violations = sum(o["policy_violations"] > 0 for o in rl_values)
        safe = rl_passed >= parent_passed and truncated == 0
        if stage == "greedy-validation":
            safe = safe and rl_passed == len(rl_values) and violations == 0
        measured[name] = {
            "total": len(rl_values),
            "parent_passed": parent_passed,
            "rl_passed": rl_passed,
            "rl_violation_cases": violations,
            "rl_truncated": truncated,
            "passed": safe,
        }
    errors = {arm: reports[arm]["summary"]["diagnostic_cases"] for arm in ARMS}
    no_regression = all(
        errors["rl"][k] <= errors["parent"][k] for k in errors["parent"]
    )
    semantics_safe = all(
        value == 0 for key, value in errors["rl"].items() if key != "format"
    )
    improvement = (
        measured["overall"]["rl_passed"] > measured["overall"]["parent_passed"]
        and errors["rl"]["format"] < errors["parent"]["format"]
    )
    return {
        "passed": all(cell["passed"] for cell in measured.values())
        and no_regression
        and semantics_safe
        and (stage != "test" or improvement),
        "cells": measured,
        "diagnostic_cases": errors,
        "diagnostic_nonregression": no_regression,
        "zero_semantic_errors": semantics_safe,
        "strict_formatting_and_success_improvement": improvement,
    }


async def evaluate_arm(
    root, plan, session, renderer, checkpoint, cases, budget, arm, stage
):
    helper, diagnostic = support(root, "recovery"), support(root, "diagnostics")
    helper.SEED = SEED
    target = root / f"{arm}-{stage}"
    target.mkdir(exist_ok=False)
    size = 1 if stage == "greedy-validation" else 4
    result = await helper.collect(
        target, plan, session, renderer, checkpoint, cases, budget, probe=size == 4
    )
    groups = [[o] for o in result] if size == 1 else result
    by_id = {row["order_id"]: row for row in cases}
    diagnosed = [
        [
            await diagnostic.diagnose(by_id[o["case_id"]], o["environment_trace"])
            for o in g
        ]
        for g in groups
    ]
    report = {
        "plan_hash": plan["plan_hash"],
        "environment": "refund-recovery-v1",
        "stage": stage,
        "arm": arm,
        "checkpoint": asdict(checkpoint),
        "seed": SEED,
        "group_size": size,
        "temperature": 0 if size == 1 else 1.0,
        "settings": plan["settings"],
        "case_hashes": {key: content_hash(row) for key, row in by_id.items()},
        "groups": groups,
        "diagnostics": diagnosed,
        "summary": summarize(groups, cases, diagnosed),
    }
    atomic_json(root / f"{arm}-{stage}.json", report)
    return report


async def evaluate(root, plan, session, renderer, checkpoints, budget):
    for stage, _, _ in STAGES:
        cases = read(root / f"{stage}.json")
        for arm in ARMS:
            seal(
                root,
                f"{arm}-{stage}-attempt.json",
                {
                    "plan_hash": plan["plan_hash"],
                    "checkpoint": asdict(checkpoints[arm]),
                    "case_sha256": plan["input_sha256"][f"{stage}.json"],
                },
            )
        values = await asyncio.gather(
            *(
                evaluate_arm(
                    root,
                    plan,
                    session,
                    renderer,
                    checkpoints[arm],
                    cases,
                    budget,
                    arm,
                    stage,
                )
                for arm in ARMS
            )
        )
        reports = dict(zip(ARMS, values, strict=True))
        decision = gate(reports, cases, stage=stage)
        atomic_json(root / f"{stage}-decision.json", decision)
        print(
            json.dumps(
                {
                    "stage": stage,
                    "passed": decision["passed"],
                    "counts": {
                        arm: r["summary"]["passed"] for arm, r in reports.items()
                    },
                    "diagnostics": decision["diagnostic_cases"],
                }
            ),
            flush=True,
        )
        if stage != "test" and not decision["passed"]:
            return {
                "status": "validation_blocked",
                "blocked_stage": stage,
                "accepted": False,
                "test_attempted": False,
                "rl_updates": 1,
                "sft_updates": 0,
            }
    return {
        "status": "completed",
        "accepted": decision["passed"],
        "test_attempted": True,
        "rl_updates": 1,
        "sft_updates": 0,
        "quality_certification": False,
    }


def worker(root):
    import river_client as river
    from stateset_agents.remote.river_renderers import get_river_renderer
    from stateset_agents.remote.river_runtime import (
        require_model_access,
        require_native_runtime,
    )

    plan = validate(root)
    require_native_runtime()
    with exclusive_run(root / "worker"):
        seal(root, "worker-attempt.json", {"plan_hash": plan["plan_hash"]})
        budget = RolloutAdmissionBudget(
            root / "rollout-budget.json",
            limit=plan["limits"]["reserved_output_tokens"],
            trajectory_tokens=1024,
            fingerprint=plan["plan_hash"],
            create=True,
        )
        with closing(
            river.Client(
                api_key=os.environ["RIVER_API_KEY"], timeout=180, enable_retries=False
            )
        ) as client:
            require_model_access(client, MODEL)
            capabilities = client.get_server_capabilities(model_name=MODEL)
            atomic_json(
                root / "server-capabilities.json",
                {
                    "supported_models": list(capabilities.supported_models),
                    "features": sorted(capabilities.features),
                    "model_features": {
                        key: sorted(value)
                        for key, value in capabilities.model_features.items()
                    },
                },
            )
            capabilities.require(*plan["required_server_features"])
            renderer = get_river_renderer(MODEL, thinking=False)
            seal(
                root,
                "training-attempt.json",
                {
                    "plan_hash": plan["plan_hash"],
                    "parent_checkpoint": plan["parent_checkpoint"],
                    "training": plan["training"],
                },
            )
            with client.session(
                experiment="stateset-recovery-rl", role="one-native-update"
            ) as session:
                model = session.create_model(
                    base_model=MODEL,
                    tokenizer=renderer.tokenizer,
                    lora=river.LoraConfig(rank=16, seed=SEED, train_unembed=False),
                    checkpoint=river.Checkpoint(
                        path=plan["parent_checkpoint"],
                        step=0,
                        checkpoint_type="inference",
                    ),
                )
                checkpoint = asyncio.run(train(root, plan, model, renderer, budget))
            if checkpoint is None:
                result = {
                    "status": "no_update_observed",
                    "accepted": False,
                    "test_attempted": False,
                    "rl_updates": 0,
                    "sft_updates": 0,
                }
            else:
                parent = river.Checkpoint(
                    path=plan["parent_checkpoint"], step=10, checkpoint_type="inference"
                )
                with client.session(
                    experiment="stateset-recovery-rl", role="paired-frozen-checkpoints"
                ) as session:
                    result = asyncio.run(
                        evaluate(
                            root,
                            plan,
                            session,
                            renderer,
                            {"parent": parent, "rl": checkpoint},
                            budget,
                        )
                    )
            atomic_json(root / "result.json", result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "validate", "launch", "worker"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    args = parser.parse_args()
    root = args.output.resolve()
    if args.command == "prepare":
        result = asyncio.run(prepare(root, args.repo.resolve()))
    elif args.command == "validate":
        result = {"valid": True, "plan_hash": validate(root)["plan_hash"]}
    elif args.command == "launch":
        controller = support(root, "controller")
        controller.validate = validate
        result = controller.launch(root)
    else:
        worker(root)
        return
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
