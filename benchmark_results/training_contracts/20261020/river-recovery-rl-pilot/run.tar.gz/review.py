"""Offline reconstruction of native RL tokens, replay, splits, and gates."""

import asyncio
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

import experiment as study
from river_client.rl.trajectory import Trajectory
from stateset_agents.core.environments.refund_policy_environment import (
    RefundPolicyEnvironment,
    refund_policy_benchmark,
)
from stateset_agents.data.refund_recovery import refund_recovery_cases
from stateset_agents.evaluation.agent_runs import content_hash, summarize_outcomes
from stateset_agents.evaluation.refund_recovery_trace import replay_recovery_trace
from stateset_agents.remote.river_rl import atomic_json


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def reference_datums(states):
    """Compute token alignment/advantages without calling River's batch builder."""
    denominator = sum(
        len(span["logprobs"])
        for state in states
        for span in state["spans"]
        if span["kind"] == "generated"
    )
    assert denominator > 0 and len(states) == 76
    data, variances = [], {}
    for offset in range(0, len(states), 4):
        group = states[offset : offset + 4]
        rewards = [state["reward"] for state in group]
        mean = statistics.mean(rewards)
        variances[group[0]["id"]] = statistics.pvariance(rewards)
        for state in group:
            assert state["done"] is True and state["truncated"] is None
            ids, spans = [], state["spans"]
            for span in spans:
                assert span["run"] == 0 and all(
                    c["type"] == "text" for c in span["chunks"]
                )
                ids.extend(token for c in span["chunks"] for token in c["tokens"])
            old, advantages, cursor = [0.0] * len(ids), [0.0] * len(ids), 0
            for span in spans:
                length = sum(len(c["tokens"]) for c in span["chunks"])
                if span["kind"] == "generated":
                    assert cursor > 0 and span["policy_step"] == 0
                    assert len(span["logprobs"]) == length
                    old[cursor - 1 : cursor + length - 1] = span["logprobs"]
                    advantages[cursor - 1 : cursor + length - 1] = [
                        (state["reward"] - mean) / denominator
                    ] * length
                cursor += length
            if any(advantages):
                data.append(
                    {
                        "input_ids": ids,
                        "attention_mask": [1] * len(ids),
                        "old_logprobs": old,
                        "advantages": advantages,
                    }
                )
    return data, variances


async def replay(value, row, diagnostic):
    checked = await replay_recovery_trace(row, value["environment_trace"])
    assert all(checked[key] == value[key] for key in study.FIELDS)
    assert checked["resolution_count"] <= 1
    return await diagnostic.diagnose(row, value["environment_trace"])


def independent_gate(reports, cases, stage):
    indexed = {
        arm: {g[0]["case_id"]: g for g in reports[arm]["groups"]} for arm in study.ARMS
    }
    families = {"overall": [row["order_id"] for row in cases]}
    for row in cases:
        families.setdefault("family:" + row["recovery"], []).append(row["order_id"])
    cells = {}
    for family, keys in families.items():
        parent = [o for key in keys for o in indexed["parent"][key]]
        candidate = [o for key in keys for o in indexed["rl"][key]]
        good = sum(o["success"] for o in candidate)
        parent_good = sum(o["success"] for o in parent)
        violations = sum(o["policy_violations"] > 0 for o in candidate)
        truncations = sum(o["truncated"] is not None for o in candidate)
        passes = good >= parent_good and truncations == 0
        if stage == "greedy-validation":
            passes &= good == len(candidate) and violations == 0
        cells[family] = {
            "total": len(candidate),
            "parent_passed": parent_good,
            "rl_passed": good,
            "rl_violation_cases": violations,
            "rl_truncated": truncations,
            "passed": passes,
        }
    errors = {
        arm: {
            category: sum(
                d["error_counts"][category] > 0
                for group in reports[arm]["diagnostics"]
                for d in group
            )
            for category in study.CATEGORIES
        }
        for arm in study.ARMS
    }
    nonregression = all(
        errors["rl"][key] <= errors["parent"][key] for key in study.CATEGORIES
    )
    semantic = all(
        errors["rl"][key] == 0 for key in study.CATEGORIES if key != "format"
    )
    improvement = (
        cells["overall"]["rl_passed"] > cells["overall"]["parent_passed"]
        and errors["rl"]["format"] < errors["parent"]["format"]
    )
    return {
        "passed": all(c["passed"] for c in cells.values())
        and nonregression
        and semantic
        and (stage != "test" or improvement),
        "cells": cells,
        "diagnostic_cases": errors,
        "diagnostic_nonregression": nonregression,
        "zero_semantic_errors": semantic,
        "strict_formatting_and_success_improvement": improvement,
    }


async def main():
    plan = study.validate(ROOT)
    verification = read(ROOT / "test-receipt.json")
    assert verification["passed"] and verification["tests"] == 14
    assert verification["plan_hash"] == plan["plan_hash"]
    for name, digest in verification["source_sha256"].items():
        assert sha(REPO / name) == digest
    previous = REPO / "outputs/river-recovery-warmup-20261020"
    assert sha(ROOT / "train-source.json") == sha(previous / "training/train.json")
    assert sha(ROOT / "train-selection.json") == sha(previous / "probe-selection.json")
    assert sha(ROOT / "parent/river_checkpoint.json") == sha(
        previous / "warmup/river_checkpoint.json"
    )
    source = {row["order_id"]: row for row in read(ROOT / "train-source.json")}
    train = read(ROOT / "train.json")
    assert train == [
        source[item["case_id"]] for item in read(ROOT / "train-selection.json")
    ]
    excluded = refund_policy_benchmark("train", count=128, seed=20261020)
    for name, digest in read(ROOT / "historical-sources.json").items():
        assert sha(REPO / name) == digest
        rows = read(REPO / name)
        if isinstance(rows, list):
            excluded.extend(
                row
                for row in rows
                if isinstance(row, dict) and "return_window_days" in row
            )
    fingerprint = RefundPolicyEnvironment.case_fingerprint
    ids, facts = {r["order_id"] for r in excluded}, {fingerprint(r) for r in excluded}
    for index, (stage, count, _) in enumerate(study.STAGES):
        rows = read(ROOT / f"{stage}.json")
        expected = refund_recovery_cases(
            "test" if stage == "test" else "validation",
            count=count,
            seed=plan["case_seed"] + index,
            excluded=excluded,
        )
        assert rows == expected
        assert not ids & {r["order_id"] for r in rows}
        assert not facts & {fingerprint(r) for r in rows}
        ids.update(r["order_id"] for r in rows)
        facts.update(fingerprint(r) for r in rows)
        excluded.extend(rows)
    execution, result = read(ROOT / "execution-summary.json"), read(
        ROOT / "result.json"
    )
    assert (
        execution["exit_code"] == 0
        and not execution["timed_out"]
        and execution["result"] == result
    )
    assert result["sft_updates"] == 0
    assert set(plan["required_server_features"]) <= set(
        read(ROOT / "server-capabilities.json")["features"]
    )
    diagnostic = study.support(ROOT, "diagnostics")
    evidence = read(ROOT / "batch-evidence.json")
    assert evidence["plan_hash"] == plan["plan_hash"] and evidence["current_step"] == 0
    initial = read(ROOT / "initial-model.json")
    assert (
        initial["step"] == 0
        and initial["parent_checkpoint"] == plan["parent_checkpoint"]
    )
    assert initial["policy_version"]["id"]
    states = evidence["trajectory_states"]
    trajectories = [Trajectory.from_state_dict(state) for state in states]
    cases = {row["order_id"]: row for row in train}
    native_data, native_metrics, native_variances = study.exact_batch(
        trajectories, cases, groups=19, policy_id=initial["policy_version"]["id"]
    )
    data, variances = reference_datums(states)
    assert data == native_data == read(ROOT / "batch-datums.json")
    assert variances == native_variances == evidence["variances"]
    assert (
        content_hash(data) == evidence["datums_hash"]
        and len(data) == evidence["datums"]
    )
    assert native_metrics == evidence["batch_metrics"]
    assert evidence["nonzero_variance_groups"] == sum(
        value > 0 for value in variances.values()
    )
    checked, evaluations, decisions, paired = 0, {}, {}, {}
    for trajectory, saved, classification in zip(
        trajectories, evidence["outcomes"], evidence["diagnostics"], strict=True
    ):
        assert study.outcome(trajectory, cases) == saved
        assert (
            await replay(saved, cases[saved["case_id"]], diagnostic) == classification
        )
        checked += 1
    assert checked == 76
    steps = read(ROOT / "training-steps.json")
    assert len(steps) == 1 and steps[0]["batch"] == 1
    study.validate_training_metrics(steps[0]["metrics"])
    metrics = steps[0]["metrics"]
    assert all(metrics[key] == value for key, value in native_metrics.items())
    updates = int(metrics["train/updated"])
    assert updates == int(bool(data)) == steps[0]["model_step"] == result["rl_updates"]
    assert read(ROOT / "training-activity.json") == {
        "consumed_batches": 1,
        "acknowledged_optimizer_updates": updates,
        "sft_updates": 0,
    }
    if updates:
        final, checkpoint = read(ROOT / "final-model.json"), read(
            ROOT / "rl-checkpoint.json"
        )
        assert final["step"] == checkpoint["step"] == 1
        assert checkpoint["policy_version"] == final["policy_version"]
        assert final["policy_version"]["parent_id"] == initial["policy_version"]["id"]
        assert final["policy_version"]["step"] == initial["policy_version"]["step"] + 1
    else:
        assert not (ROOT / "rl-checkpoint.json").exists() and not result["accepted"]
    continue_allowed = bool(updates)
    for stage, count, size in study.STAGES:
        if not continue_allowed:
            assert not any(
                (ROOT / f"{arm}-{stage}-attempt.json").exists() for arm in study.ARMS
            )
            continue
        reports, rows = {}, read(ROOT / f"{stage}.json")
        by_id = {row["order_id"]: row for row in rows}
        assert len(rows) == count
        for arm in study.ARMS:
            report = read(ROOT / f"{arm}-{stage}.json")
            assert (
                report["plan_hash"] == plan["plan_hash"]
                and report["stage"] == stage
                and report["arm"] == arm
            )
            assert (
                report["seed"] == plan["seed"]
                and report["settings"] == plan["settings"]
            )
            assert report["group_size"] == size and report["temperature"] == (
                0 if size == 1 else 1.0
            )
            expected_checkpoint = (
                read(ROOT / "rl-checkpoint.json")
                if arm == "rl"
                else {
                    "path": plan["parent_checkpoint"],
                    "step": 10,
                    "checkpoint_type": "inference",
                    "policy_version": None,
                }
            )
            assert report["checkpoint"] == expected_checkpoint
            seal = read(ROOT / f"{arm}-{stage}-attempt.json")
            assert seal == {
                "plan_hash": plan["plan_hash"],
                "checkpoint": expected_checkpoint,
                "case_sha256": plan["input_sha256"][f"{stage}.json"],
            }
            assert report["case_hashes"] == {
                key: content_hash(row) for key, row in by_id.items()
            }
            groups, ds = report["groups"], report["diagnostics"]
            assert len(groups) == len(ds) == count
            assert Counter(g[0]["case_id"] for g in groups) == dict.fromkeys(by_id, 1)
            for group, diagnosed in zip(groups, ds, strict=True):
                assert (
                    len(group) == len(diagnosed) == size
                    and len({o["case_id"] for o in group}) == 1
                )
                for value, classification in zip(group, diagnosed, strict=True):
                    assert (
                        await replay(value, by_id[value["case_id"]], diagnostic)
                        == classification
                    )
                    checked += 1
            flat = [o for g in groups for o in g]
            summary = summarize_outcomes(
                [
                    {**o, "case_id": f"{o['case_id']}:{index}"}
                    for index, o in enumerate(flat)
                ]
            )
            errors = {
                category: sum(
                    d["error_counts"][category] > 0 for group in ds for d in group
                )
                for category in study.CATEGORIES
            }
            assert report["summary"] == {**summary, "diagnostic_cases": errors}
            evaluations[f"{arm}-{stage}"] = {
                "total": summary["total"],
                "passed": summary["passed"],
                "diagnostic_cases": errors,
                "truncation_rate": summary["truncation_rate"],
            }
            reports[arm] = report
        decision = independent_gate(reports, rows, stage)
        assert decision == read(ROOT / f"{stage}-decision.json")
        decisions[stage] = decision
        counts = {
            arm: {
                g[0]["case_id"]: sum(o["success"] for o in g)
                for g in reports[arm]["groups"]
            }
            for arm in study.ARMS
        }
        paired[stage] = {
            "cases_improved": sum(
                counts["rl"][key] > counts["parent"][key] for key in by_id
            ),
            "cases_regressed": sum(
                counts["rl"][key] < counts["parent"][key] for key in by_id
            ),
            "cases_tied": sum(
                counts["rl"][key] == counts["parent"][key] for key in by_id
            ),
        }
        continue_allowed = decision["passed"]
    attempted = "test" in decisions
    assert result["test_attempted"] == attempted
    assert result["accepted"] == (attempted and decisions["test"]["passed"])
    budget = read(ROOT / "rollout-budget.json")
    assert budget["admitted_trajectories"] == checked <= 716
    assert (
        budget["reserved_generated_tokens"]
        == checked * 1024
        <= plan["limits"]["reserved_output_tokens"]
    )
    old = REPO / "outputs/river-recovery-pilot-20261020"
    assert (
        not (old / "test-attempt.json").exists()
        and len(read(old / "data/test.json")) == 80
    )
    arithmetic = REPO / "outputs/river-arithmetic-pilot-20261020"
    assert len(read(arithmetic / "data/test.json")) == 308
    assert not any(
        (arithmetic / f"{arm}-test-attempt.json").exists()
        for arm in ("control", "arithmetic")
    )
    prior = {}
    target = (
        REPO / "benchmark_results/training_contracts/20261020/river-recovery-rl-pilot"
    )
    for index in sorted(
        (REPO / "benchmark_results/training_contracts").rglob("artifacts.sha256.json")
    ):
        if index.parent == target:
            continue
        for name, digest in read(index).items():
            assert sha(index.parent / name) == digest
            prior[str((index.parent / name).relative_to(REPO))] = digest
    atomic_json(ROOT / "prior-evidence-verified.json", prior)
    review = {
        "passed": True,
        "plan_hash": plan["plan_hash"],
        "rl_updates": updates,
        "sft_updates": 0,
        "replayed_outcomes": checked,
        "training_rollouts": 76,
        "training_passed": sum(o["success"] for o in evidence["outcomes"]),
        "nonzero_variance_groups": evidence["nonzero_variance_groups"],
        "exact_native_datums_independently_reconstructed": len(data),
        "provider_reported_grad_norm": metrics.get("optimizer/grad_norm"),
        "provider_reported_loss": metrics.get("loss/loss"),
        "training_diagnostic_cases": diagnostic.summarize(evidence["diagnostics"]),
        "evaluations": evaluations,
        "effective_evaluation_settings": {
            stage: {
                **plan["settings"],
                "temperature": 0 if size == 1 else 1.0,
                "group_size": size,
                "top_p": 1.0,
                "top_k": -1,
            }
            for stage, _, size in study.STAGES
        },
        "decisions": decisions,
        "paired_case_counts": paired,
        "accepted": result["accepted"],
        "test_attempted": attempted,
        "prior_artifacts_unchanged": len(prior),
        "cost_usd": None,
        "old_recovery_test_cases_unattempted": 80,
        "old_arithmetic_test_cases_unattempted": 308,
        "provider_calls_during_review": 0,
    }
    atomic_json(ROOT / "review-summary.json", review)
    print(json.dumps(review), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
