"""
Proximal Policy Optimization (PPO) Trainer for StateSet Agents

This module provides lower-level PPO updates for caller-supplied text batches.
Online rollout collection is not implemented; ``train`` and ``train_ppo`` reject
instead of training on fabricated completions. This reference surface does not
certify that externally supplied responses came from the behavior policy.

PPO is the foundation algorithm that most modern RL-from-feedback methods build upon.
This implementation includes:
- Clipped surrogate objective
- Generalized Advantage Estimation (GAE)
- Value function training
- Entropy bonus for exploration
- Adaptive KL penalty (optional)

Reference: https://arxiv.org/abs/1707.06347
"""

import logging
import math
import os
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F

from . import objectives, rl_losses
from .config import TrainingConfig
from .runtime_state import TrainingRuntime, validate_training_config

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

try:
    import numpy as _np

    np: Any = _np
except ImportError:
    np = None
    logger.warning("NumPy not available")

# Lazy import transformers
_transformers_ppo_loaded = False
AutoModelForCausalLM = None
AutoTokenizer = None
get_cosine_schedule_with_warmup = None


def _load_transformers_ppo():
    """Lazily load transformers to avoid import-time errors."""
    global _transformers_ppo_loaded, AutoModelForCausalLM, AutoTokenizer
    global get_cosine_schedule_with_warmup

    if _transformers_ppo_loaded:
        return True

    try:
        from transformers import AutoModelForCausalLM as _AutoModelForCausalLM
        from transformers import AutoTokenizer as _AutoTokenizer
        from transformers import get_cosine_schedule_with_warmup as _get_cosine

        AutoModelForCausalLM = _AutoModelForCausalLM
        AutoTokenizer = _AutoTokenizer
        get_cosine_schedule_with_warmup = _get_cosine
        _transformers_ppo_loaded = True
        return True
    except (ImportError, RuntimeError) as e:
        logger.warning(f"Failed to load transformers: {e}")
        return False


@dataclass
class PPOConfig(TrainingConfig):
    """
    Configuration for PPO training.

    PPO provides a good baseline for RL from human/AI feedback tasks.
    """

    # Model
    model_name: str = "gpt2"

    # PPO-specific hyperparameters
    clip_eps: float = 0.2  # Clipping epsilon (standard PPO)
    value_clip_eps: float = 0.2  # Value function clipping
    gamma: float = 0.99  # Discount factor
    gae_lambda: float = 0.95  # GAE lambda

    # KL penalty (optional, use 0 to disable)
    beta: float = 0.0  # KL penalty coefficient
    target_kl: float | None = None  # Target KL for early stopping
    use_adaptive_kl: bool = False  # Adaptive KL penalty

    # Training parameters
    num_ppo_epochs: int = 4  # Inner PPO epochs per batch
    mini_batch_size: int = 4  # Mini-batch size

    # Value function
    value_coef: float = 0.5  # Value loss coefficient
    value_hidden_size: int = 256  # Value head hidden size

    # Entropy bonus
    entropy_coef: float = 0.01  # Entropy bonus coefficient

    # Generation
    num_generations: int = 4  # Generations per prompt
    max_prompt_length: int = 256
    max_completion_length: int = 256
    temperature: float = 0.7
    top_p: float = 0.9

    # Model optimization
    use_lora: bool = True
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05

    # Memory optimization
    gradient_checkpointing: bool = True
    use_8bit: bool = False
    use_4bit: bool = False

    # Reference model (for KL computation)
    use_reference_model: bool = True


class PPOValueHead(nn.Module):
    """
    Value prediction head for PPO.

    Takes hidden states from the language model and outputs value estimates.
    """

    def __init__(
        self,
        hidden_size: int,
        value_hidden_size: int = 256,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(hidden_size, value_hidden_size),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(value_hidden_size, value_hidden_size),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(value_hidden_size, 1),
        )

        # Initialize with small weights
        for module in self.net:
            if isinstance(module, nn.Linear):
                nn.init.normal_(module.weight, mean=0.0, std=0.01)
                nn.init.zeros_(module.bias)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """
        Args:
            hidden_states: [batch, seq_len, hidden_size]

        Returns:
            values: [batch, seq_len, 1]
        """
        return self.net(hidden_states)


class AdaptiveKLController:
    """
    Adaptive KL penalty controller.

    Adjusts the KL penalty coefficient to keep KL divergence near target.
    """

    def __init__(
        self,
        init_kl_coef: float = 0.1,
        target_kl: float = 0.01,
        horizon: int = 10000,
    ):
        self.kl_coef = init_kl_coef
        self.target_kl = target_kl
        self.horizon = horizon

    def propose(self, current_kl: float, n_steps: int) -> float:
        """Calculate a coefficient without changing controller state."""
        if not math.isfinite(current_kl):
            raise FloatingPointError("PPO KL divergence must remain finite")
        proportional_error = (current_kl - self.target_kl) / self.target_kl
        mult = 1.0 + proportional_error * n_steps / self.horizon
        proposed = self.kl_coef * mult
        if not math.isfinite(proposed):
            raise FloatingPointError("PPO KL coefficient must remain finite")
        return max(0.001, min(proposed, 100.0))

    def update(self, current_kl: float, n_steps: int) -> float:
        """Update KL coefficient based on current KL divergence."""
        self.kl_coef = self.propose(current_kl, n_steps)
        return self.kl_coef


def compute_gae(
    rewards: torch.Tensor,
    values: torch.Tensor,
    gamma: float = 0.99,
    gae_lambda: float = 0.95,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Compute Generalized Advantage Estimation.

    Args:
        rewards: [batch, seq_len] rewards for each token
        values: [batch, seq_len] value estimates
        gamma: Discount factor
        gae_lambda: GAE lambda

    Returns:
        advantages: [batch, seq_len]
        returns: [batch, seq_len]
    """
    batch_size, seq_len = rewards.shape
    device = rewards.device

    advantages = torch.zeros_like(rewards)
    returns = torch.zeros_like(rewards)

    # Compute advantages in reverse order
    last_gae = torch.zeros(batch_size, device=device)
    last_value = torch.zeros(batch_size, device=device)

    for t in reversed(range(seq_len)):
        # TD error
        delta = rewards[:, t] + gamma * last_value - values[:, t]

        # GAE
        last_gae = delta + gamma * gae_lambda * last_gae
        advantages[:, t] = last_gae

        # Update for next iteration
        last_value = values[:, t]

    # Returns = advantages + values
    returns = advantages + values

    return advantages, returns


class PPOTrainer(TrainingRuntime):
    """
    Proximal Policy Optimization (PPO) Trainer

    Reference PPO updates for externally supplied language-model text batches.

    Online rollout collection is unavailable. ``train`` rejects explicitly;
    ``train_step`` requires callers to establish behavior-policy provenance.

    Features:
    - Clipped surrogate objective for stable policy updates
    - Generalized Advantage Estimation (GAE)
    - Value function training with clipping
    - Entropy bonus for exploration
    - Optional adaptive KL penalty

    Reference: https://arxiv.org/abs/1707.06347
    """

    def __init__(
        self,
        config: PPOConfig,
        model: Any,
        tokenizer: Any,
        reward_fn: Callable[[str, str], float],
        ref_model: Any | None = None,
    ):
        # Ensure transformers is loaded
        _load_transformers_ppo()

        validate_training_config(config)
        self.config = config
        # PPO clipped surrogate as one declarative PolicyObjective; the KL
        # penalty is added separately in train_step (adaptive coefficient).
        self._objective = objectives.resolve_objective(
            config,
            "ppo",
            max_completion_length=int(config.max_completion_length),
            supported_ratios=("token", "sequence", "sequence_token"),
            clip_low=float(config.clip_eps),
            clip_high=float(config.clip_eps),
            kl="none",
        )
        self.model = model
        self.tokenizer = tokenizer
        self.reward_fn = reward_fn
        self.ref_model = ref_model
        self.device = next(model.parameters()).device

        # Get hidden size from model
        if hasattr(model, "config"):
            hidden_size = getattr(model.config, "hidden_size", 768)
        else:
            hidden_size = 768

        # Initialize value head
        self.value_head = PPOValueHead(
            hidden_size=hidden_size,
            value_hidden_size=config.value_hidden_size,
        ).to(self.device)

        # Optimizers
        self.policy_optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=config.learning_rate,
            betas=(config.adam_beta1, config.adam_beta2),
            weight_decay=config.weight_decay,
        )

        self.value_optimizer = torch.optim.AdamW(
            self.value_head.parameters(),
            lr=config.learning_rate * 2,  # Value head often needs higher LR
            betas=(config.adam_beta1, config.adam_beta2),
            weight_decay=config.weight_decay,
        )

        # Schedulers
        total_steps = config.num_episodes * config.num_epochs

        if get_cosine_schedule_with_warmup is not None:
            warmup_steps = int(total_steps * config.warmup_ratio)
            self.policy_scheduler = get_cosine_schedule_with_warmup(
                self.policy_optimizer,
                num_warmup_steps=warmup_steps,
                num_training_steps=total_steps,
            )
            self.value_scheduler = get_cosine_schedule_with_warmup(
                self.value_optimizer,
                num_warmup_steps=warmup_steps,
                num_training_steps=total_steps,
            )
        else:
            self.policy_scheduler = torch.optim.lr_scheduler.ConstantLR(
                self.policy_optimizer, factor=1.0, total_iters=total_steps
            )
            self.value_scheduler = torch.optim.lr_scheduler.ConstantLR(
                self.value_optimizer, factor=1.0, total_iters=total_steps
            )

        # Adaptive KL controller
        self.kl_controller: AdaptiveKLController | None
        if config.use_adaptive_kl and config.target_kl:
            self.kl_controller = AdaptiveKLController(
                init_kl_coef=config.beta,
                target_kl=config.target_kl,
            )
        else:
            self.kl_controller = None

        # Metrics tracking
        self.metrics_history: dict[str, list[float]] = {
            "policy_loss": [],
            "value_loss": [],
            "entropy": [],
            "kl_divergence": [],
            "average_reward": [],
            "clip_fraction": [],
            "approx_kl": [],
        }

        self.global_step = 0

    def get_hidden_states(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Extract hidden states from model."""
        with torch.set_grad_enabled(self.model.training):
            outputs = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                output_hidden_states=True,
            )
            return outputs.hidden_states[-1]

    def compute_log_probs(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Compute per-token log probabilities.

        Returns:
            log_probs: [batch, seq_len-1]
            entropy: [batch, seq_len-1]
        """
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
        logits = outputs.logits

        # Shift for next-token prediction
        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = input_ids[:, 1:].contiguous()

        # Log probabilities
        log_probs_all = F.log_softmax(shift_logits, dim=-1)
        probs = F.softmax(shift_logits, dim=-1)

        # Gather log probs for actual tokens
        token_log_probs = log_probs_all.gather(
            dim=-1, index=shift_labels.unsqueeze(-1)
        ).squeeze(-1)

        # Entropy
        entropy = -(probs * log_probs_all).sum(dim=-1)

        return token_log_probs, entropy

    def compute_kl_divergence(
        self,
        current_log_probs: torch.Tensor,
        reference_log_probs: torch.Tensor,
        mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """k3 estimate of KL(pi_cur || pi_ref) over response tokens.

        Replaces the naive ``log pi - log pi_ref`` mean, whose gradient has
        zero expectation and therefore never pulled the policy toward the
        reference.
        """
        if mask is None:
            return rl_losses.k3_kl(current_log_probs, reference_log_probs)
        return rl_losses.k3_kl(current_log_probs, reference_log_probs, mask)

    def ppo_loss(
        self,
        log_probs: torch.Tensor,
        old_log_probs: torch.Tensor,
        advantages: torch.Tensor,
        mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """PPO clipped surrogate via ``objectives.policy_loss``.

        Returns ``(loss, clip_fraction)``; the log-ratio is clamped before
        exponentiating so a wildly off-policy token cannot make the loss
        non-finite.
        """
        if mask is None:
            mask = torch.ones_like(log_probs)
        result = objectives.policy_loss(
            logp_cur=log_probs,
            mask=mask,
            advantages=advantages,
            objective=self._objective,
            logp_old=old_log_probs,
        )
        clip_fraction = torch.tensor(
            result.metrics["clip_fraction"], device=log_probs.device
        )
        return result.loss, clip_fraction

    def value_loss(
        self,
        values: torch.Tensor,
        old_values: torch.Tensor,
        returns: torch.Tensor,
        mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Compute clipped value loss.

        Args:
            values: Current value estimates
            old_values: Old value estimates (from rollout)
            returns: Computed returns
            mask: Token mask
        """
        # Clipped values
        clipped_values = old_values + torch.clamp(
            values - old_values,
            -self.config.value_clip_eps,
            self.config.value_clip_eps,
        )

        # Value losses
        vf_loss1 = (values - returns) ** 2
        vf_loss2 = (clipped_values - returns) ** 2

        # Take maximum (pessimistic)
        loss = 0.5 * torch.max(vf_loss1, vf_loss2)

        if mask is not None:
            loss = loss * mask
            return loss.sum() / mask.sum().clamp(min=1)

        return loss.mean()

    @staticmethod
    def build_response_mask(
        attention_mask: torch.Tensor,
        prompt_lengths: torch.Tensor,
        padding_side: str = "right",
    ) -> torch.Tensor:
        """1.0 on completion tokens of each row; prompt and padding are 0."""
        response_mask = torch.zeros_like(attention_mask, dtype=torch.float)
        seq_len = attention_mask.shape[1]
        for i, prompt_len in enumerate(prompt_lengths.tolist()):
            pad = (
                seq_len - int(attention_mask[i].sum()) if padding_side == "left" else 0
            )
            response_mask[i, pad + int(prompt_len) :] = 1.0
        return response_mask * attention_mask.to(response_mask.dtype)

    def compute_episode_advantages(
        self,
        rewards: torch.Tensor,
        action_mask: torch.Tensor,
        old_values: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """GAE for one scalar reward per episode, in the shifted action frame.

        The reward sits on each row's last response action (broadcasting it to
        every token would inflate returns with response length). Values outside
        the mask are zeroed so padding after a response neither bootstraps nor
        earns reward, and advantages are normalized over response actions only.
        """
        idx = torch.arange(action_mask.shape[1], device=action_mask.device)
        last = torch.where(action_mask > 0, idx, -1).max(dim=1).values
        token_rewards = torch.zeros_like(action_mask)
        rows = torch.nonzero(last >= 0).flatten()
        token_rewards[rows, last[rows]] = rewards.to(token_rewards.dtype)[rows]

        advantages, returns = compute_gae(
            token_rewards,
            old_values * action_mask,
            gamma=self.config.gamma,
            gae_lambda=self.config.gae_lambda,
        )
        valid = advantages[action_mask > 0]
        if valid.numel() > 1:
            advantages = (advantages - valid.mean()) / (valid.std() + 1e-8)
        return advantages * action_mask, returns

    async def train_step(
        self,
        prompts: list[str],
        completions: list[str],
        rewards: list[float],
    ) -> dict[str, float]:
        """
        Execute one PPO training step.

        Args:
            prompts: List of prompt strings
            completions: List of completion strings
            rewards: List of reward scores

        Returns:
            Dictionary of metrics

        This lower-level API scores caller-supplied text. It does not establish
        that completions were sampled from the policy or retain exact sampled
        token boundaries, including BPE merges across prompt/completion text.
        Callers remain responsible for that provenance. Finite-value guards
        apply before each inner optimizer update; they do not roll back earlier
        completed updates or make exceptions between optimizer commits atomic.
        """
        if self.config.beta > 0 and self.ref_model is None:
            raise ValueError("PPO beta > 0 requires a reference model")
        if (
            type(self.config.num_ppo_epochs) is not int
            or self.config.num_ppo_epochs < 1
        ):
            raise ValueError("num_ppo_epochs must be a positive integer")
        if (
            not prompts
            or len(prompts) != len(completions)
            or len(prompts) != len(rewards)
        ):
            raise ValueError(
                "PPO requires equal nonempty prompt, completion and reward batches"
            )
        if any(not isinstance(value, str) for value in (*prompts, *completions)):
            raise TypeError("PPO prompts and completions must be strings")
        try:
            finite_rewards = [float(value) for value in rewards]
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("PPO rewards must be finite numbers") from exc
        if any(isinstance(value, bool) for value in rewards) or not all(
            math.isfinite(value) for value in finite_rewards
        ):
            raise ValueError("PPO rewards must be finite numbers")
        rewards_tensor = torch.tensor(
            finite_rewards, device=self.device, dtype=torch.float
        )
        if not torch.isfinite(rewards_tensor).all():
            raise ValueError("PPO rewards must remain finite in the learner dtype")

        # One extra token detects an overlong prompt without allocating an
        # unbounded prompt batch. Never label a truncated prompt's tail as a
        # response merely because the full text has a larger token budget.
        prompt_encodings = self.tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=self.config.max_prompt_length + 1,
        )
        prompt_lengths = prompt_encodings["attention_mask"].sum(dim=1)
        if (prompt_lengths > self.config.max_prompt_length).any():
            raise ValueError(
                "PPO prompts exceed max_prompt_length; truncate them explicitly"
            )

        # Tokenize inputs
        full_texts = [p + c for p, c in zip(prompts, completions, strict=True)]
        encodings = self.tokenizer(
            full_texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=self.config.max_prompt_length
            + self.config.max_completion_length,
        )

        input_ids = encodings["input_ids"].to(self.device)
        attention_mask = encodings["attention_mask"].to(self.device)

        response_mask = self.build_response_mask(
            attention_mask,
            prompt_lengths,
            getattr(self.tokenizer, "padding_side", "right"),
        )
        if not (response_mask[:, 1:].sum(dim=1) > 0).all():
            raise ValueError("PPO requires at least one response action in every row")

        self.model.train()
        self.value_head.train()

        # Get initial values and log probs (for old policy)
        with torch.no_grad():
            old_log_probs, _ = self.compute_log_probs(input_ids, attention_mask)
            hidden_states = self.get_hidden_states(input_ids, attention_mask)
            old_values = self.value_head(hidden_states).squeeze(-1)[:, :-1]

        advantages, returns = self.compute_episode_advantages(
            rewards_tensor, response_mask[:, 1:], old_values
        )
        if not torch.isfinite(advantages).all() or not torch.isfinite(returns).all():
            raise FloatingPointError("PPO advantages and returns must remain finite")

        # PPO epochs
        total_policy_loss = 0.0
        total_value_loss = 0.0
        total_entropy = 0.0
        total_clip_fraction = 0.0

        response_mask_shift = response_mask[:, 1:]

        for _ in range(self.config.num_ppo_epochs):
            # Forward pass
            log_probs, entropy = self.compute_log_probs(input_ids, attention_mask)
            hidden_states = self.get_hidden_states(input_ids, attention_mask)
            values = self.value_head(hidden_states).squeeze(-1)[:, :-1]

            # Policy loss
            policy_loss, clip_fraction = self.ppo_loss(
                log_probs, old_log_probs, advantages, response_mask_shift
            )

            # Value loss
            vf_loss = self.value_loss(values, old_values, returns, response_mask_shift)

            # Entropy bonus
            if response_mask_shift is not None:
                entropy_bonus = (
                    entropy * response_mask_shift
                ).sum() / response_mask_shift.sum().clamp(min=1)
            else:
                entropy_bonus = entropy.mean()

            # Total loss
            total_loss = (
                policy_loss
                + self.config.value_coef * vf_loss
                - self.config.entropy_coef * entropy_bonus
            )

            # Stage adaptive state until this inner update has committed both
            # optimizers. Rejected losses/gradients must not consume adaptation.
            proposed_kl_coef = None
            if self.config.beta > 0 and self.ref_model is not None:
                with torch.no_grad():
                    ref_outputs = self.ref_model(
                        input_ids=input_ids, attention_mask=attention_mask
                    )
                    ref_logits = ref_outputs.logits[:, :-1, :]
                    ref_log_probs = F.log_softmax(ref_logits, dim=-1)
                    ref_token_log_probs = ref_log_probs.gather(
                        dim=-1, index=input_ids[:, 1:].unsqueeze(-1)
                    ).squeeze(-1)

                kl = self.compute_kl_divergence(
                    log_probs, ref_token_log_probs, response_mask_shift
                )

                kl_coef = self.config.beta
                if self.kl_controller:
                    proposed_kl_coef = self.kl_controller.propose(kl.item(), 1)
                    kl_coef = proposed_kl_coef

                total_loss = total_loss + kl_coef * kl

            # Reject an invalid objective before discarding existing gradients.
            if total_loss.numel() != 1 or not torch.isfinite(total_loss).all():
                raise FloatingPointError("PPO loss must be a finite scalar")

            # Both optimizers share this backward pass. Check both gradient
            # populations before either optimizer can commit an update.
            self.policy_optimizer.zero_grad()
            self.value_optimizer.zero_grad()
            total_loss.backward()

            try:
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    self.config.max_grad_norm,
                    error_if_nonfinite=True,
                )
                torch.nn.utils.clip_grad_norm_(
                    self.value_head.parameters(),
                    self.config.max_grad_norm,
                    error_if_nonfinite=True,
                )
            except RuntimeError as exc:
                self.policy_optimizer.zero_grad(set_to_none=True)
                self.value_optimizer.zero_grad(set_to_none=True)
                raise FloatingPointError("PPO gradients must remain finite") from exc

            self.policy_optimizer.step()
            self.value_optimizer.step()
            if proposed_kl_coef is not None and self.kl_controller is not None:
                self.kl_controller.kl_coef = proposed_kl_coef

            total_policy_loss += policy_loss.item()
            total_value_loss += vf_loss.item()
            total_entropy += entropy_bonus.item()
            total_clip_fraction += clip_fraction.item()

        # Average over epochs
        num_epochs = self.config.num_ppo_epochs
        avg_policy_loss = total_policy_loss / num_epochs
        avg_value_loss = total_value_loss / num_epochs
        avg_entropy = total_entropy / num_epochs
        avg_clip_fraction = total_clip_fraction / num_epochs

        # Update schedulers
        self.policy_scheduler.step()
        self.value_scheduler.step()

        self.global_step += 1

        metrics = {
            "policy_loss": avg_policy_loss,
            "value_loss": avg_value_loss,
            "entropy": avg_entropy,
            "clip_fraction": avg_clip_fraction,
            "average_reward": math.fsum(finite_rewards) / len(finite_rewards),
        }

        # Update history
        for key, value in metrics.items():
            if key in self.metrics_history:
                self.metrics_history[key].append(value)

        return metrics

    async def train(
        self,
        prompts: list[str],
        num_episodes: int | None = None,
    ) -> dict[str, Any]:
        """Reject online PPO until a token-exact rollout protocol is implemented.

        Use ``train_step`` only for externally supplied, provenance-checked text
        batches. The former loop trained on a constant placeholder completion;
        returning an explicit error prevents it from fabricating an RL run.
        """
        raise NotImplementedError(
            "Online PPO rollouts are not implemented. "
            "PPOTrainer.train() cannot generate a training population; "
            "use train_step() with externally supplied, provenance-checked batches "
            "or a supported native GRPO training entry point."
        )

    def save_checkpoint(self, path: str | None = None) -> str:
        """Publish policy and critic state through the shared runtime."""
        if path is None:
            path = os.path.join(
                self.config.output_dir, f"ppo-checkpoint-{self.global_step}"
            )
        self.save_runtime_checkpoint(path)
        return path


# Convenience function for quick training
async def train_ppo(
    model_name: str,
    prompts: list[str],
    reward_fn: Callable[[str, str], float],
    num_episodes: int = 100,
    **kwargs,
) -> dict[str, Any]:
    """
    Reject unavailable online PPO before loading a model or tokenizer.

    Args:
        model_name: HuggingFace model name
        prompts: Training prompts
        reward_fn: Reward function
        num_episodes: Number of training episodes
        **kwargs: Additional config parameters

    Returns:
        Training results
    """
    raise NotImplementedError(
        "Online PPO rollouts are not implemented. "
        "Use PPOTrainer.train_step() with externally supplied, provenance-checked "
        "batches or a supported native GRPO training entry point."
    )
